<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
ini_set('error_log', '/var/log/php_errors.log');

// 1. Configuration
$base_dir = '/var/lib/minidlna';
$web_base = '/files';

// 2. Upload Logic (TRANSLATION FIX)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['media_upload'])) {
    $raw_target = $_POST['upload_to'] ?? $web_base; 
    
    // Convert Web Path (/files/Music) to System Path (/var/lib/minidlna/Music)
    $relative_part = trim(str_replace($web_base, '', $raw_target), '/');
    $target_dir = $base_dir . ($relative_part ? '/' . $relative_part : '');
    
    $filename = basename($_FILES['media_upload']['name']);
    $target_file = rtrim($target_dir, '/') . '/' . $filename;
    
    if ($filename === 'index.php') {
        die("Error: Cannot overwrite system files.");
    }

    // Security check and folder validation
    if (strpos(realpath($target_dir), realpath($base_dir)) === 0) {
        if (move_uploaded_file($_FILES['media_upload']['tmp_name'], $target_file)) {
            chmod($target_file, 0664);
            @chgrp($target_file, 'minidlna');
            
            // Return 200 OK for the XHR upload handler (no redirect needed)
            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
            exit;
        } else {
            die("Error: Failed to move file. Check permissions on " . $target_dir);
        }
    } else {
        die("Error: Invalid destination path.");
    }
}


// ── Cross-device resume: self-install save_progress.php if missing or outdated ─
$save_progress_path = __DIR__ . '/save_progress.php';
$save_progress_version = 'v4'; // bump this to force regeneration on next page load
$needs_install = !file_exists($save_progress_path) ||
    strpos(file_get_contents($save_progress_path), $save_progress_version) === false;
if ($needs_install) {
    $save_progress_code = <<<'SAVEPHP'
<?php
// save_progress.php — Cross-device resume position store — v4
// Created automatically by index.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$progress_dir = __DIR__ . '/.progress';
if (!is_dir($progress_dir)) {
    mkdir($progress_dir, 0755, true);
}

// Normalise path to a pure relative form before hashing so that web paths
// (/files/Movies/Foo.mp4) and system paths (/var/lib/minidlna/Movies/Foo.mp4)
// both resolve to the same key. md5 avoids basename() collisions between files
// with the same name in different subdirectories.
function make_key($file_path) {
    $normalized = str_replace(['/var/lib/minidlna', '/files'], '', $file_path);
    $normalized = trim($normalized, '/');
    return md5($normalized) . '.json';
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $body    = json_decode(file_get_contents('php://input'), true);
    $file     = $body['file']     ?? '';
    $time     = floatval($body['time'] ?? 0);
    $duration = floatval($body['duration'] ?? 0);
    $updated  = intval($body['updated'] ?? time());

    if ($file === '' || !isset($body['time'])) {
        http_response_code(400);
        echo json_encode(['error' => 'missing file or time']);
        exit;
    }

    $key      = make_key($file);
    $data_path = $progress_dir . '/' . $key;

    $is_reset = isset($body['reset']) && $body['reset'] === true;

    // Allow explicit resets through regardless of existing value.
    // For normal saves, only update if the incoming data is chronologically
    // newer than what is on disk (compare wall-clock time, not playhead).
    $existing_updated = 0;
    if (!$is_reset && file_exists($data_path)) {
        $existing = json_decode(file_get_contents($data_path), true);
        $existing_updated = intval($existing['updated'] ?? 0);
    }

    if ($is_reset || $updated >= $existing_updated) {
        file_put_contents($data_path, json_encode([
            'file'     => $file,
            'time'     => $time,
            'duration' => $duration,
            'reset'    => $is_reset,
            'updated'  => $updated
        ]), LOCK_EX);
    }

    echo json_encode(['ok' => true, 'saved' => $time]);

} elseif ($method === 'GET') {
    $file = $_GET['file'] ?? '';
    if (!$file) {
        http_response_code(400);
        echo json_encode(['error' => 'missing file']);
        exit;
    }

    $key       = make_key($file);
    $data_path = $progress_dir . '/' . $key;

    if (file_exists($data_path)) {
        echo file_get_contents($data_path);
    } else {
        echo json_encode(['time' => 0]);
    }

} elseif ($method === 'DELETE') {
    $file = $_GET['file'] ?? '';
    if ($file) {
        $key       = make_key($file);
        $data_path = $progress_dir . '/' . $key;
        if (file_exists($data_path)) unlink($data_path);
    }
    echo json_encode(['ok' => true]);

} else {
    http_response_code(405);
    echo json_encode(['error' => 'method not allowed']);
}
SAVEPHP;
    file_put_contents($save_progress_path, $save_progress_code);
    chmod($save_progress_path, 0644);
}
// ─────────────────────────────────────────────────────────────────────────────

// ── Self-install get_progress_bulk.php if missing or outdated ────────────────
$bulk_progress_path    = __DIR__ . '/get_progress_bulk.php';
$bulk_progress_version = 'v1';
$bulk_needs_install = !file_exists($bulk_progress_path) ||
    strpos(file_get_contents($bulk_progress_path), $bulk_progress_version) === false;
if ($bulk_needs_install) {
    $bulk_progress_code = <<<'BULKPHP'
<?php
// get_progress_bulk.php — Batch progress lookup for file list overlay — v1
// Created automatically by index.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$progress_dir = __DIR__ . '/.progress';

$body  = json_decode(file_get_contents('php://input'), true);
$files = $body['files'] ?? [];

if (!is_array($files) || count($files) === 0) {
    echo json_encode([]);
    exit;
}

function make_key($file_path) {
    $normalized = str_replace(['/var/lib/minidlna', '/files'], '', $file_path);
    $normalized = trim($normalized, '/');
    return md5($normalized) . '.json';
}

$result = [];

foreach ($files as $webPath) {
    $key       = make_key($webPath);
    $data_path = $progress_dir . '/' . $key;

    if (file_exists($data_path)) {
        $data     = json_decode(file_get_contents($data_path), true);
        $time     = floatval($data['time']     ?? 0);
        $duration = floatval($data['duration'] ?? 0);
        $reset    = isset($data['reset']) && $data['reset'] === true;

        if (!$reset && $time > 5 && $duration > 0) {
            $pct = min(100, round(($time / $duration) * 100));
            $result[$webPath] = ['time' => $time, 'duration' => $duration, 'pct' => $pct];
        }
    }
}

echo json_encode($result);
BULKPHP;
    file_put_contents($bulk_progress_path, $bulk_progress_code);
    chmod($bulk_progress_path, 0644);
}
// ─────────────────────────────────────────────────────────────────────────────

// File extensions
$image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
$video_extensions = ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm'];
$audio_extensions = ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'];
$hidden_extensions = ['php', 'env', 'srt', 'vtt', 'db', 'm3u', 'txt', 'nfo', 'DS_Store', 'thumbs'];

function get_file_extension($filename) {
    return strtolower(trim(pathinfo($filename, PATHINFO_EXTENSION)));
}

// PHP Helper to check for a poster file locally
function get_poster_url($filename, $poster_base) {
    $name_only = pathinfo($filename, PATHINFO_FILENAME);
    $local_check = $_SERVER['DOCUMENT_ROOT'] . $poster_base . '/' . $name_only . '.jpg';
    
    if (file_exists($local_check)) {
        return $poster_base . '/' . $name_only . '.jpg';
    }
    return '/movie.png'; 
}

function format_file_size($bytes) {
    if ($bytes === false) return 'Unknown';
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    elseif ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    elseif ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    else return $bytes . ' bytes';
}

function get_web_path($file_path, $base_dir, $web_base) {
    $relative = trim(str_replace($base_dir, '', $file_path), '/');
    return $web_base . ($relative ? '/' . $relative : '');
}

function get_directory_icon($dir_path, $image_extensions, $video_extensions, $audio_extensions, $hidden_extensions) {
    // 1. Define the SVG shapes — no hardcoded width/height, sized via CSS class .dir-icon
    $svgs = [
        'video'   => '<svg class="dir-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M18 7c0-1.103-.897-2-2-2H4c-1.103 0-2 .897-2 2v10c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-3.333L22 17V7l-4 3.333V7z"/></svg>',
        'audio'   => '<svg class="dir-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm1 10.19c.703.264 1.2 1.031 1.2 1.81 0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2c.101 0 .193.021.29.043V7h3v2-1.5v3.19z"/></svg>',
        'picture' => '<svg class="dir-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M19 3H5c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2V5c0-1.103-.897-2-2-2zM5 19V5h14l.002 14H5z"/><path d="m10 14-1-1-3 4h12l-5-7-3 4z"/><circle cx="8.5" cy="8.5" r="1.5"/></svg>',
        'folder'  => '<svg class="dir-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M20 5h-9.586L8.707 3.293A.997.997 0 0 0 8 3H4c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V7c0-1.103-.897-2-2-2z"/></svg>'
    ];

    // 2. Hardcoded Name Check (Pictures Priority)
    $folder_name = strtolower(basename($dir_path));
    if ($folder_name === 'pictures' || $folder_name === 'photos') return $svgs['picture'];
    if ($folder_name === 'video' || $folder_name === 'videos') return $svgs['video'];
    if ($folder_name === 'music') return $svgs['audio'];

    // 3. Subfolder Content Check
    $items = @scandir($dir_path);
    if ($items === false) return $svgs['folder'];
    
    $has_images = $has_videos = $has_audio = false;
    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item[0] === '.') continue;
        $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
        if (in_array($ext, $hidden_extensions)) continue;
        if (in_array($ext, $video_extensions)) $has_videos = true;
        elseif (in_array($ext, $audio_extensions)) $has_audio = true;
        elseif (in_array($ext, $image_extensions)) $has_images = true;
    }

    if ($has_videos) return $svgs['video'];
    if ($has_audio)  return $svgs['audio'];
    if ($has_images) return $svgs['picture'];
    
    return $svgs['folder'];
}

// Note: directory/file listing is handled at runtime by get_files.php via JS fetch (loadFiles()).
// The PHP helper functions above (get_directory_icon, format_file_size, get_web_path, get_poster_url)
// are used by get_files.php, not by this file directly.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini-Pi Media Browser</title>
    <link rel="icon" type="image/png" href="/logo.png" />
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&family=Lora:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Cinzel', serif; }
    body { background: #000; color: #f4e9cd; overflow: auto; }
    /* Strict Layout control for the Preview Panel */
    .preview {
        flex: 1;
        padding: 30px;
        display: flex;
        flex-direction: column;
        align-items: stretch;
        justify-content: flex-start;
        overflow-y: auto;
        min-height: 0;
    }
    
    .preview-wrapper {
    display: flex;
    flex-direction: column;
    justify-content: center;
    width: 100%;
    }
    /* 1. Container for Title and Rating */
.preview-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    width: 100%;
    margin-bottom: 15px;
    min-width: 0;
}

/* 2. Style for the Title (Force Truncation) */
.preview-title {
    font-size: 1.4em;
    font-weight: bold;
    margin: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis; 
    min-width: 0; 
    flex: 1; 
}

/* 3. Style for the Rating Badge */
.preview-rating {
    background: #f5c518;
    color: #000;
    padding: 3px 8px;
    border-radius: 4px;
    font-weight: bold;
    font-size: 0.9em;
    flex-shrink: 0; 
    white-space: nowrap;
}
    .breadcrumb {
    display: flex;
    align-items: center;
    gap: 8px;
}
   #movie-synopsis {
    margin-top: 20px;
    padding: 18px 22px;
    background: rgba(0, 0, 0, 0.5);
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.8);
    max-height: 25vh; 
    overflow-y: auto;
    opacity: 0;
    transition: opacity 0.8s ease-in-out;
    display: none;
    font-family: 'Lora', serif;
    font-weight: 400;
    font-size: 0.92rem; 
    line-height: 1.75; 
    letter-spacing: 0.2px; 
    text-transform: none;
    text-align: left;
    hyphens: auto;
    color: #ddd5c0; 
    border-left: 2px solid rgba(212,175,55,0.35);
}
    #movie-synopsis::-webkit-scrollbar {
        width: 6px;
    }
    #movie-synopsis::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.4);
    border-radius: 10px;
    }
    #movie-synopsis::-webkit-scrollbar-thumb {
    background: rgba(244, 233, 205, 0.3);
    border-radius: 10px;
    transition: background 0.3s ease;
    }
    .preview-rt-rating {
    background: #ff3333;
    color: #fff;
    padding: 3px 8px;
    border-radius: 4px;
    font-weight: bold;
    font-size: 0.85em;
    flex-shrink: 0;
    white-space: nowrap;
    display: none;
    box-shadow: 0 2px 5px rgba(0,0,0,0.3);
}
    #movie-synopsis::-webkit-scrollbar-thumb:hover {
    background: rgba(244, 233, 205, 0.6);
}
    .rating-container {
    display: flex;
    gap: 8px;
    align-items: center;
}
/* Directory folder SVG icon — sized via CSS, not HTML attributes */
.dir-icon {
    display: block;
    margin: auto;
    width: 48px;
    height: 48px;
    color: #d4af37;
    flex-shrink: 0;
}

/* 1. The Glass Container for each item */
.file-item {
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
}

/* 2. The Signature Gold Icons */
.file-item svg {
    filter: drop-shadow(0 10px 15px rgba(0,0,0,0.5));
    transition: transform 0.4s ease;
}

/* 3. The Premium Hover Animation */
.file-item:hover {
    background: rgba(255, 255, 255, 0.08);
    border-color: rgba(255, 215, 0, 0.3); 
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.6);
}

.file-item:hover svg {
    transform: scale(1.1) rotate(2deg);
}

/* 4. MERGED FILE NAME (Style + Layout) */
.file-item .file-name {
    font-family: 'Cinzel', serif;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    color: #d4af37; 
    margin-top: 15px;
    text-shadow: 0px 2px 4px rgba(0, 0, 0, 0.8), 
                 0px 0px 10px rgba(0, 0, 0, 0.5);
    
    /* essential layout logic */
    font-size: 0.85rem; 
    font-weight: bold; 
    word-wrap: break-word;
    overflow: hidden; 
    display: -webkit-box; 
    -webkit-line-clamp: 2; 
    -webkit-box-orient: vertical;
    line-height: 1.3;
}

/* 5. Keep mobile fix at the bottom */
@media (max-width: 768px) {
    .container { 
        flex-direction: column; 
        height: auto; 
    }
}

    /* Resume Playback Overlay */
.resume-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    z-index: 10;
    border-radius: 15px;
    backdrop-filter: blur(5px);
    transition: opacity 0.3s ease;
}

.resume-box {
    background: rgba(255, 255, 255, 0.1);
    padding: 30px;
    border-radius: 15px;
    border: 1px solid rgba(255, 255, 255, 0.3);
    text-align: center;
}

.resume-box h4 {
    margin-bottom: 20px;
    color: #f4e9cd;
    letter-spacing: 2px;
}

.resume-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
}

.resume-btn {
    padding: 10px 25px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-family: 'Cinzel', serif;
    font-weight: bold;
    transition: 0.3s;
}

.resume-yes { background: #d4af37; color: #000; }
.resume-no { background: rgba(255,255,255,0.2); color: #fff; }

.resume-yes:hover { background: #fff; transform: scale(1.05); }
.resume-no:hover { background: rgba(255,255,255,0.4); }
/* 1. Style the text the user actually types */
#fileSearch {
    font-family: 'Cinzel', serif !important;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: #ffffff !important;
}

/* 2. Force the placeholder text to be solid white (no transparency) and Cinzel */
#fileSearch::placeholder {
    color: #ffffff !important;
    opacity: 1 !important; /* This prevents the 'grey' look */
    font-family: 'Cinzel', serif !important;
    text-transform: uppercase;
}

/* Chrome, Safari, and newer Edge */
#fileSearch::-webkit-input-placeholder {
    color: #ffffff !important;
    opacity: 1 !important;
    font-family: 'Cinzel', serif !important;
    text-transform: uppercase;
}

/* Firefox */
#fileSearch::-moz-placeholder {
    color: #ffffff !important;
    opacity: 1 !important;
    font-family: 'Cinzel', serif !important;
    text-transform: uppercase;
}

/* Internet Explorer / Old Edge */
#fileSearch:-ms-input-placeholder {
    color: #ffffff !important;
    font-family: 'Cinzel', serif !important;
    text-transform: uppercase;
}
    .parallax { 
    min-height: 100vh; 
    position: relative; 
    display: flex; 
    justify-content: center; 
    align-items: center;
    overflow: hidden; 
    animation: fadeIn 0.8s ease-out; 
}
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .background { 
    position: fixed; 
    top: 0; 
    left: 0; 
    width: 100%; 
    height: 100%; 
    filter: blur(2px) brightness(0.7); 
    z-index: -1; 
    
    background-size: cover; 
    background-position: center; 
    background-repeat: no-repeat;
}
    .background-video { position: absolute; top: 0; left: 0; width: 100vw; height: 100vh; object-fit: cover; filter: blur(2px) brightness(0.7); }
    .container { max-width: 1800px; width: 100%; display: flex; gap: 25px; padding: 20px; margin-top: 2vh; height: 95vh; }
/* --- ORIGINAL LOOK PRESERVED --- */
.file-list, .preview { 
    background: rgba(255, 255, 255, 0.08); 
    backdrop-filter: blur(20px); 
    border: 1px solid rgba(255, 255, 255, 0.15); 
    border-radius: 18px; 
    box-shadow: 0 8px 32px rgba(0,0,0,0.8); 
}

.file-list { 
    flex: 0 0 50%; 
    padding: 25px; 
    display: flex; 
    flex-direction: column; 
    overflow: hidden; 
    /* This line anchors the '?' icon to the corner */
    position: relative; 
}

/* --- HELP SYSTEM (TOP RIGHT PREVIEW) --- */
.help-container {
    position: absolute;
    top: 10px; 
    right: 10px; 
    z-index: 1001; 
}

.help-icon {
    width: 26px;
    height: 26px;
    border: 1px solid rgba(244, 233, 205, 0.4);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #f4e9cd;
    cursor: help;
    font-size: 0.9rem;
    background: rgba(0, 0, 0, 0.6);
    transition: all 0.3s ease;
}

.help-container:hover .help-icon {
    background: #d4af37;
    color: #000;
    border-color: #d4af37;
    box-shadow: 0 0 15px rgba(212, 175, 55, 0.4);
}

.help-tooltip {
    position: absolute;
    top: 40px;
    right: 0; /* anchor to the right edge of the icon */
    transform: translateX(-110%) translateY(-10px); /* push it to the LEFT */

    width: 220px;
    max-width: min(220px, 80vw); /* responsive safety */

    background: rgba(10, 10, 10, 0.98);
    backdrop-filter: blur(15px);
    border: 1px solid rgba(255, 255, 255, 0.4);
    border-radius: 10px;
    padding: 15px;

    opacity: 0;
    visibility: hidden;
    
    transition: all 0.3s ease;
    box-shadow: 0 10px 30px rgba(0,0,0,1);

    text-align: left;
    font-family: 'Cinzel', serif;
    letter-spacing: 0.5px;
}

.help-container:hover .help-tooltip {
    opacity: 1;
    visibility: visible;
    transform: translateX(-110%) translateY(0);
}

.help-header {
    font-family: 'Cinzel', serif;
    color: #d4af37;
    font-size: 0.85rem;
    font-weight: 700;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    padding-bottom: 8px;
    margin-bottom: 12px;
    letter-spacing: 2px;
    text-transform: uppercase;
}

.help-row {
    font-family: 'Cinzel', serif;
    display: flex;
    justify-content: space-between;
    font-size: 0.7rem;
    margin-bottom: 8px;
    color: #f4e9cd;
    letter-spacing: 1px;
}

.help-row span:last-child {
    color: rgba(244, 233, 205, 0.6);
}
.home-title, .breadcrumb a, .btn { 
    display: inline-flex; 
    align-items: center; 
    justify-content: center;
    padding: 10px 22px; 
    font-size: 0.9rem; 
    font-weight: 600; 
    text-decoration: none; 
    color: rgba(255, 255, 255, 0.95); 
    background: rgba(255, 255, 255, 0.08); 
    backdrop-filter: blur(20px) saturate(180%); 
    -webkit-backdrop-filter: blur(20px) saturate(180%);
    
    border: 1px solid rgba(255, 255, 255, 0.18); 
    border-radius: 12px; 
    position: relative; 
    overflow: hidden; 
    box-shadow: 0 4px 15px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.1);
    transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), background 0.3s ease;
    cursor: pointer; 
    line-height: 1;
    min-height: 40px;
    position: relative; 
    z-index: 999 !important;
}
/* 1. Style for the image specifically */
#preview-content img {
    max-width: 100%;
    border-radius: 15px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.9);
    border: 1px solid rgba(255, 255, 255, 0.1);
    transition: transform 0.3s ease;
}

/* 2. Apply the animation to the CONTAINER */
#preview-content {
    animation: fadeIn 0.4s ease-in-out;
}

/* 3. The Keyframes */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.2); 
    transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), 
                background-color 0.3s ease, 
                box-shadow 0.3s ease;
    cursor: pointer; 
}

/* The Shimmer Hover Effect */
.home-title::before, .breadcrumb a::before, .btn::before { 
    content: ""; 
    position: absolute; 
    top: 0; 
    left: -100%; 
    width: 100%; 
    height: 100%; 
    background: linear-gradient(120deg, transparent, rgba(255, 255, 255, 0.15), transparent); 
    transition: all 0.6s; 
}

.home-title:hover, .breadcrumb a:hover, .btn:hover { 
    background: rgba(255, 255, 255, 0.25); 
    transform: translateY(-2px); 
}

.home-title:hover::before, .breadcrumb a:hover::before, .btn:hover::before { 
    left: 100%; 
}

.btn:active, .home-title:active, .breadcrumb a:active { 
    transform: translateY(1px); 
}
    #directory-list, #file-list { display: grid; gap: 20px; grid-template-columns: repeat(3, 1fr); overflow-y: auto; flex-grow: 1; padding-bottom: 20px; -webkit-overflow-scrolling: touch; scroll-behavior: smooth; margin-top: 15px;}
    /* Fire TV / Silk remote D-pad scroll: make list focusable and show focus outline */
    #file-list:focus, #directory-list:focus { outline: 2px solid rgba(212,175,55,0.5); outline-offset: -2px; }
    .file-item { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 10px; background: rgba(255,255,255,0.05); border-radius: 15px; transition: 0.3s; height: 240px; text-align: center; width: 100%;
    box-sizing: border-box; overflow: hidden;}
    .file-item:hover { background: rgba(255,255,255,0.2); transform: translateY(-5px); }
    .file-icon { width: 100%; height: 120px; object-fit: contain; border-radius: 8px; margin-bottom: 8px; background: #000; }
	#video-player {
    	width: 100%;
    	height: 50vh; 
    	object-fit: contain;
    	background: #000;
    	border-radius: 15px;
   	margin-bottom: 20px;
   	box-shadow: 0 10px 30px rgba(0, 0, 0, 0.8);
	}

	/* Mobile Devices (Phones) */
	@media (max-width: 768px) {
    	#video-player {
        height: 30vh; 
    		}
	}
    .file-poster {
        width: 100%;
        height: 160px;
        object-fit: contain; 
        background: rgba(0,0,0,0.2);
        border-radius: 6px;
        margin-bottom: 10px;
    }
    .file-name { font-size: 0.85rem; 
        font-weight: bold; 
        color: #f4e9cd;
        word-wrap: break-word;
        overflow: hidden; 
        display: -webkit-box; 
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        line-height: 1.2; }
    .file-info { font-size: 0.7rem; opacity: 0.6; margin-top: 5px; }
    @media (max-width: 768px) {
        .container { flex-direction: column; height: auto; }
        #directory-list, #file-list { grid-template-columns: repeat(2, 1fr); }
    }

/* Recently Played Section */
#recently-played-section {
    display: none;
    margin-top: 18px;
    padding-top: 14px;
    border-top: 1px solid rgba(244, 233, 205, 0.15);
}
#recently-played-section h4 {
    font-family: 'Cinzel', serif;
    font-size: 0.7rem;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: rgba(212, 175, 55, 0.7);
    margin-bottom: 10px;
    padding-left: 4px;
}
#recently-played-list {
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.recent-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 12px;
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid rgba(255, 255, 255, 0.06);
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.25s ease, border-color 0.25s ease;
    overflow: hidden;
}
.recent-item:hover {
    background: rgba(255, 255, 255, 0.1);
    border-color: rgba(212, 175, 55, 0.3);
}
.recent-item-icon {
    font-size: 1.1rem;
    flex-shrink: 0;
}
.recent-item-name {
    font-family: 'Cinzel', serif;
    font-size: 0.72rem;
    letter-spacing: 0.8px;
    color: #d4af37;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    flex: 1;
}

/* ── Mobile & Tablet Responsive ─────────────────────────────────────────── */

/* Tablet portrait & large phones landscape (600–1024px) */
@media (max-width: 1024px) {
    .container {
        gap: 15px;
        padding: 12px;
        margin-top: 1vh;
        height: 97vh;
    }
    .file-list {
        flex: 0 0 45%;
        padding: 15px;
    }
    .preview {
        padding: 15px;
    }
    .home-title, .breadcrumb a, .btn {
        padding: 8px 14px;
        font-size: 0.8rem;
    }
}

/* Phone portrait & small landscape (max 768px) */
@media (max-width: 768px) {
    /* Full-page scrollable layout — no clipping */
    .container {
        flex-direction: column;
        height: auto;
        min-height: 0;
        padding: 10px;
        gap: 12px;
        margin-top: 0;
    }

    /* File browser: natural height, scrolls with page */
    .file-list {
        flex: none;
        width: 100%;
        max-height: none;
        height: auto;
        padding: 12px;
        overflow: visible;
    }

    /* Directory/file grid scrolls inside its own area when in a subfolder */
    #directory-list, #file-list {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
        max-height: 55vh;
        overflow-y: auto;
    }

    /* Root row overrides the scroll — it's always short */
    #directory-list.root-row {
        max-height: none !important;
        overflow: visible !important;
        display: flex !important;
        flex-direction: row !important;
        gap: 8px !important;
    }

    /* Shorter file cards when in subfolders */
    .file-item {
        height: 160px !important;
        padding: 10px !important;
        overflow: visible !important;
    }

    /* File names in subfolder cards — show up to 2 lines */
    .file-item .file-name {
        font-size: 0.7rem !important;
        margin-top: 6px !important;
        -webkit-line-clamp: 2;
        overflow: hidden;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        white-space: normal !important;
        max-height: 2.6em;
        width: 100% !important;
        text-align: center !important;
        color: #d4af37 !important;
    }

    /* Recently played: cap height and scroll internally so it never spills */
    #recently-played-section {
        margin-top: 10px;
        padding-top: 10px;
        max-height: 130px;
        overflow-y: auto;
        overflow-x: hidden;
    }

    /* Root folder cards: icon + label, no squashing — MUST come after .file-item override */
    #directory-list.root-row .file-item {
        height: 120px !important;
        min-height: 0 !important;
        padding: 12px 8px 10px !important;
        flex: 1;
        overflow: visible;
        justify-content: center;
    }
    /* Icon size for root-row on mobile */
    #directory-list.root-row .file-item .dir-icon {
        width: 40px !important;
        height: 40px !important;
    }
    /* Hide the old font-size:3.5rem wrapper text inflation */
    #directory-list.root-row .file-item > div:first-child {
        font-size: 0 !important;
        line-height: 0 !important;
        overflow: visible !important;
    }
    /* Show folder name below icon */
    #directory-list.root-row .file-item .file-name {
        display: block !important;
        font-size: 0.65rem !important;
        margin-top: 8px !important;
        letter-spacing: 1px !important;
        white-space: nowrap !important;
        overflow: visible !important;
        text-overflow: ellipsis !important;
        width: 100% !important;
        text-align: center !important;
        color: #d4af37 !important;
        -webkit-line-clamp: unset !important;
        -webkit-box-orient: unset !important;
        max-height: none !important;
    }

    .file-poster {
        height: 90px !important;
        margin-bottom: 6px !important;
    }
    .file-icon {
        height: 90px !important;
        margin-bottom: 6px !important;
    }

    /* Preview panel: sits below, scrolled to by user */
    .preview {
        flex: none;
        width: 100%;
        min-height: 50vh;
        padding: 12px;
    }

    /* Smaller nav buttons */
    .home-title, .breadcrumb a, .btn {
        padding: 7px 11px;
        font-size: 0.75rem;
        min-height: 34px;
    }

    /* Search bar */
    #fileSearch {
        font-size: 0.75rem !important;
        padding: 9px !important;
    }

    
        padding: 7px 10px;
    }
    .recent-item-name {
        font-size: 0.68rem;
    }

    /* Help tooltip */
    .help-tooltip {
        right: auto;
        left: 0;
        width: 190px;
    }

    /* Video player */
    #video-player {
        height: 35vh !important;
    }
}

/* Small phones portrait only (max 480px) */
@media (max-width: 480px) {
    .file-list {
        max-height: 52vh;
    }
    #directory-list, #file-list {
        grid-template-columns: repeat(2, 1fr);
        gap: 8px;
    }
    .file-item {
        height: 140px !important;
        overflow: visible !important;
    }
    .home-title, .breadcrumb a, .btn {
        padding: 6px 9px;
        font-size: 0.7rem;
    }
}

/* Landscape phone (short & wide) */
@media (max-height: 500px) and (orientation: landscape) {
    .container {
        flex-direction: row;
        height: auto;
        min-height: 100vh;
        padding: 8px;
        gap: 10px;
        margin-top: 0;
    }
    .file-list {
        flex: 0 0 48%;
        padding: 10px;
        max-height: none;
        height: auto;
        overflow-y: auto;
    }
    .preview {
        flex: 1;
        padding: 10px;
        min-height: 0;
        height: auto;
    }
    #directory-list, #file-list {
        grid-template-columns: repeat(2, 1fr);
        gap: 8px;
        max-height: none;
        overflow: visible;
    }
    .file-item {
        height: 130px !important;
        overflow: visible !important;
    }

    /* File names in landscape subfolder cards */
    .file-item .file-name {
        font-size: 0.62rem !important;
        margin-top: 4px !important;
        -webkit-line-clamp: 2;
        overflow: hidden;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        white-space: normal !important;
        max-height: 2.4em;
        width: 100% !important;
        text-align: center !important;
        color: #d4af37 !important;
    }

    /* Constrain poster/icon images so they don't overflow the card */
    .file-poster {
        height: 70px !important;
        margin-bottom: 4px !important;
    }
    .file-icon {
        height: 70px !important;
        margin-bottom: 4px !important;
    }
    .dir-icon {
        width: 36px !important;
        height: 36px !important;
    }
    .nav-header {
        margin-bottom: 8px !important;
    }
    #video-player {
        height: 45vh !important;
    }

    /* Root folder row in landscape — compact but not clipped — MUST come after .file-item */
    #directory-list.root-row {
        display: flex !important;
        flex-direction: row !important;
        gap: 8px !important;
        max-height: none !important;
        overflow: visible !important;
    }
    #directory-list.root-row .file-item {
        height: 110px !important;
        min-height: 0 !important;
        padding: 10px 6px 8px !important;
        flex: 1;
        overflow: visible;
        justify-content: center;
    }
    #directory-list.root-row .file-item .dir-icon {
        width: 36px !important;
        height: 36px !important;
    }
    #directory-list.root-row .file-item > div:first-child {
        font-size: 0 !important;
        line-height: 0 !important;
        overflow: visible !important;
    }
    #directory-list.root-row .file-item .file-name {
        display: block !important;
        font-size: 0.58rem !important;
        margin-top: 6px !important;
        letter-spacing: 0.7px !important;
        white-space: nowrap !important;
        overflow: visible !important;
        text-overflow: ellipsis !important;
        width: 100% !important;
        text-align: center !important;
        color: #d4af37 !important;
        -webkit-line-clamp: unset !important;
        -webkit-box-orient: unset !important;
        max-height: none !important;
    }
}
/* ── Audio Controls Bar ──────────────────────────────────────────────────── */

/* The slim toggle pill always visible below the player */
#acb-toggle-pill {
    display: none;
    align-items: center;
    justify-content: center;
    gap: 7px;
    margin: 6px auto 0 auto;
    padding: 5px 18px;
    width: fit-content;
    background: rgba(0,0,0,0.35);
    border: 1px solid rgba(212,175,55,0.2);
    border-radius: 20px;
    cursor: pointer;
    transition: background 0.2s, border-color 0.2s;
    font-family: 'Cinzel', serif;
    font-size: 0.55rem;
    letter-spacing: 2px;
    color: rgba(212,175,55,0.5);
    text-transform: uppercase;
    user-select: none;
}
#acb-toggle-pill:hover {
    background: rgba(212,175,55,0.08);
    border-color: rgba(212,175,55,0.45);
    color: #d4af37;
}
#acb-toggle-pill.open {
    border-color: rgba(212,175,55,0.5);
    color: #d4af37;
}
.acb-pill-chevron {
    display: inline-block;
    transition: transform 0.3s ease;
    font-style: normal;
}
#acb-toggle-pill.open .acb-pill-chevron { transform: rotate(180deg); }

/* The collapsible bar — hidden by default, slides in */
#audio-controls-bar {
    display: none; /* shown via JS as flex */
    flex-direction: column;
    gap: 0;
    margin: 4px 0 0 0;
    padding: 10px 16px;
    background: linear-gradient(135deg, rgba(10,8,4,0.75) 0%, rgba(30,22,6,0.7) 100%);
    border: 1px solid rgba(212,175,55,0.35);
    border-radius: 12px;
    flex-wrap: nowrap;
    box-shadow: 0 4px 20px rgba(0,0,0,0.6), inset 0 1px 0 rgba(212,175,55,0.08);
    backdrop-filter: blur(10px);
    overflow: hidden;
    /* Slide animation */
    animation: acbSlideDown 0.25s ease;
}
@keyframes acbSlideDown {
    from { opacity: 0; transform: translateY(-8px); }
    to   { opacity: 1; transform: translateY(0); }
}
#audio-controls-bar label {
    font-family: 'Cinzel', serif;
    font-size: 0.6rem;
    letter-spacing: 2px;
    color: rgba(212,175,55,0.75);
    white-space: nowrap;
    text-transform: uppercase;
}

/* Track */
#audio-controls-bar input[type=range] {
    -webkit-appearance: none;
    appearance: none;
    flex: 1;
    min-width: 55px;
    height: 4px;
    border-radius: 4px;
    background: rgba(255,255,255,0.1);
    outline: none;
    cursor: pointer;
    vertical-align: middle;
    position: relative;
    /* Gold fill via JS-free CSS custom property trick — override per slider below */
    background-image: linear-gradient(to right, #d4af37 var(--fill, 50%), rgba(255,255,255,0.1) var(--fill, 50%));
}
#audio-controls-bar input[type=range]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: radial-gradient(circle at 38% 38%, #ffe97a, #b8860b);
    cursor: pointer;
    box-shadow: 0 0 6px rgba(212,175,55,0.8), 0 2px 4px rgba(0,0,0,0.5);
    border: 1px solid rgba(255,230,100,0.4);
    transition: transform 0.15s ease, box-shadow 0.15s ease;
}
#audio-controls-bar input[type=range]::-webkit-slider-thumb:hover {
    transform: scale(1.25);
    box-shadow: 0 0 10px rgba(212,175,55,1), 0 2px 6px rgba(0,0,0,0.6);
}
#audio-controls-bar input[type=range]::-moz-range-thumb {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: radial-gradient(circle at 38% 38%, #ffe97a, #b8860b);
    cursor: pointer;
    border: 1px solid rgba(255,230,100,0.4);
    box-shadow: 0 0 6px rgba(212,175,55,0.8);
}
#audio-controls-bar input[type=range]::-moz-range-track {
    height: 4px;
    border-radius: 4px;
    background: rgba(255,255,255,0.1);
}
#audio-controls-bar input[type=range]::-moz-range-progress {
    height: 4px;
    border-radius: 4px;
    background: #d4af37;
}

#btn-normalise {
    font-family: 'Cinzel', serif;
    font-size: 0.58rem;
    letter-spacing: 1.5px;
    padding: 5px 11px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(212,175,55,0.3);
    border-radius: 8px;
    color: rgba(212,175,55,0.7);
    cursor: pointer;
    transition: background 0.2s, border-color 0.2s, color 0.2s, box-shadow 0.2s;
    white-space: nowrap;
    text-transform: uppercase;
}
#btn-normalise.active {
    background: linear-gradient(135deg, rgba(212,175,55,0.25), rgba(212,175,55,0.1));
    border-color: rgba(212,175,55,0.8);
    color: #ffe97a;
    box-shadow: 0 0 8px rgba(212,175,55,0.3), inset 0 1px 0 rgba(255,255,255,0.1);
}
#btn-normalise:hover {
    background: rgba(212,175,55,0.12);
    border-color: rgba(212,175,55,0.55);
    color: #d4af37;
}
.acb-val {
    font-family: 'Cinzel', serif;
    font-size: 0.6rem;
    font-weight: bold;
    color: #d4af37;
    min-width: 34px;
    text-align: right;
    transition: color 0.2s ease;
}
.acb-val.at-zero {
    color: rgba(255,255,255,0.45);
}
/* ─────────────────────────────────────────────────────────────────────────── */
/* ── Advanced audio row ─────────────────────────────────────────────────── */
.acb-main-row {
    display: flex;
    align-items: center;
    gap: 12px;
    width: 100%;
}
.acb-advanced-row {
    display: flex;
    align-items: center;
    gap: 12px;
    width: 100%;
    padding-top: 8px;
    margin-top: 8px;
    border-top: 1px solid rgba(212,175,55,0.15);
    animation: acbFadeIn 0.2s ease;
}
@keyframes acbFadeIn {
    from { opacity: 0; transform: translateY(-4px); }
    to   { opacity: 1; transform: translateY(0); }
}
.acb-adv-toggle {
    font-family: 'Cinzel', serif;
    font-size: 0.55rem;
    letter-spacing: 1.5px;
    padding: 5px 9px;
    background: transparent;
    border: 1px solid rgba(212,175,55,0.2);
    border-radius: 8px;
    color: rgba(212,175,55,0.5);
    cursor: pointer;
    transition: all 0.2s;
    white-space: nowrap;
    text-transform: uppercase;
    margin-left: auto;
}
.acb-adv-toggle:hover, .acb-adv-toggle.open {
    border-color: rgba(212,175,55,0.55);
    color: #d4af37;
    background: rgba(212,175,55,0.08);
}
.acb-adv-btn {
    font-family: 'Cinzel', serif;
    font-size: 0.55rem;
    letter-spacing: 1.2px;
    padding: 5px 10px;
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(212,175,55,0.25);
    border-radius: 8px;
    color: rgba(212,175,55,0.65);
    cursor: pointer;
    transition: all 0.2s;
    white-space: nowrap;
    text-transform: uppercase;
}
.acb-adv-btn.active {
    background: linear-gradient(135deg, rgba(212,175,55,0.25), rgba(212,175,55,0.1));
    border-color: rgba(212,175,55,0.8);
    color: #ffe97a;
    box-shadow: 0 0 8px rgba(212,175,55,0.3);
}
.acb-adv-btn:hover { background: rgba(212,175,55,0.1); color: #d4af37; }
/* ─────────────────────────────────────────────────────────────────────────── */

/* ── Upload Progress Overlay ──────────────────────────────────────────────── */
#upload-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.75);
    backdrop-filter: blur(6px);
    z-index: 9999;
    align-items: center;
    justify-content: center;
}
#upload-overlay.active { display: flex; }

#upload-modal {
    background: linear-gradient(135deg, rgba(10,8,4,0.92) 0%, rgba(30,22,6,0.88) 100%);
    border: 1px solid rgba(212,175,55,0.4);
    border-radius: 18px;
    padding: 36px 40px;
    min-width: 320px;
    max-width: 90vw;
    box-shadow: 0 20px 60px rgba(0,0,0,0.9), inset 0 1px 0 rgba(212,175,55,0.08);
    text-align: center;
    animation: acbSlideDown 0.3s ease;
}

#upload-modal-title {
    font-family: 'Cinzel', serif;
    font-size: 0.85rem;
    letter-spacing: 3px;
    text-transform: uppercase;
    color: #d4af37;
    margin-bottom: 8px;
}

#upload-modal-filename {
    font-family: 'Lora', serif;
    font-size: 0.8rem;
    color: rgba(244,233,205,0.7);
    margin-bottom: 22px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 100%;
}

#upload-progress-track {
    width: 100%;
    height: 8px;
    background: rgba(255,255,255,0.08);
    border-radius: 8px;
    overflow: hidden;
    margin-bottom: 12px;
    border: 1px solid rgba(212,175,55,0.15);
}

#upload-progress-bar {
    height: 100%;
    width: 0%;
    background: linear-gradient(90deg, #b8860b, #d4af37, #ffe97a);
    border-radius: 8px;
    transition: width 0.2s ease;
    box-shadow: 0 0 10px rgba(212,175,55,0.5);
}

#upload-progress-pct {
    font-family: 'Cinzel', serif;
    font-size: 0.75rem;
    letter-spacing: 2px;
    color: rgba(212,175,55,0.8);
}
/* ─────────────────────────────────────────────────────────────────────────── */
/* ── Auto-scroll hover zones (Fire TV cursor) ───────────────────────────── */
.scroll-zone {
    position: absolute;
    left: 0;
    width: 100%;
    height: 80px;
    z-index: 100;
    pointer-events: all;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    border-radius: 12px;
    /* No opacity/transition here — keeps pointer-events stable so mouseenter
       never re-fires mid-hover and resets the acceleration timer */
}
.scroll-zone-up {
    top: 180px;
    height: 30px;
}
.scroll-zone-down { bottom: 0; }
/* Visual fade lives on the inner indicator, not the hit zone */
.scroll-zone .zone-indicator {
    position: absolute;
    left: 0; top: 0; width: 100%; height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease;
    pointer-events: none;
    border-radius: 12px;
}
.scroll-zone-down .zone-indicator { background: linear-gradient(to top, rgba(212,175,55,0.18), transparent); }
.scroll-zone:hover .zone-indicator { opacity: 1; }
.scroll-zone svg { color: rgba(212,175,55,0.7); filter: drop-shadow(0 0 6px rgba(212,175,55,0.5)); }

/* ── Silk / Fire TV performance mode — strip GPU-heavy effects ──────────── */
/* Applied automatically when the Silk browser is detected (see JS below).  */
body.is-silk .file-list,
body.is-silk .preview {
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
    box-shadow: none !important;
    background: rgba(0, 0, 0, 0.82) !important; /* darker solid bg — replaces lost blur */
}

body.is-silk .file-item {
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
    box-shadow: none !important;
}

body.is-silk .file-item svg {
    filter: none !important;
}

body.is-silk .home-title,
body.is-silk .breadcrumb a,
body.is-silk .btn {
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
    box-shadow: none !important;
}

body.is-silk .background,
body.is-silk .background-video {
    filter: brightness(0.7) !important; /* keep dim, drop blur */
}

body.is-silk .resume-overlay {
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
}

body.is-silk .help-tooltip {
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
    box-shadow: none !important;
}

body.is-silk #audio-controls-bar {
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
    box-shadow: none !important;
}

body.is-silk #upload-overlay {
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
}

body.is-silk #upload-modal {
    box-shadow: none !important;
}

body.is-silk #movie-synopsis {
    box-shadow: none !important;
    max-height: 18vh !important;
    font-size: 0.78rem !important;
    line-height: 1.5 !important;
    padding: 10px 14px !important;
    margin-top: 10px !important;
    overflow-y: auto !important;
}

body.is-silk #preview-content img {
    box-shadow: none !important;
}

body.is-silk #video-player {
    box-shadow: none !important;
}

body.is-silk .preview-rt-rating {
    box-shadow: none !important;
}

body.is-silk .scroll-zone svg {
    filter: none !important;
}

body.is-silk #upload-progress-bar {
    box-shadow: none !important;
}

body.is-silk .help-container:hover .help-icon {
    box-shadow: none !important;
}

body.is-silk .help-tooltip {
    box-shadow: none !important;
}

body.is-silk #btn-normalise.active,
body.is-silk .acb-adv-btn.active {
    box-shadow: none !important;
}

body.is-silk #audio-controls-bar input[type=range]::-webkit-slider-thumb {
    box-shadow: none !important;
}

body.is-silk .file-item .file-name {
    text-shadow: none !important;
}

/* ── Per-card playback progress bar ─────────────────────────────────────── */
/* Sits at the bottom of each .file-item. Pure CSS — no video elements.      */
/* On Silk the gradient is replaced with a flat colour to save GPU cycles.   */
.card-progress-wrap {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: rgba(255,255,255,0.08);
    border-radius: 0 0 15px 15px;
    overflow: hidden;
}
.card-progress-bar {
    height: 100%;
    background: linear-gradient(90deg, #b8860b, #d4af37);
    border-radius: 0 0 15px 15px;
    /* No transition — static display, not animated */
}
body.is-silk .card-progress-bar {
    background: #d4af37; /* flat colour — no gradient on Silk */
}
/* file-item needs position:relative for the absolute child */
.file-item { position: relative; }
/* ── End progress bar ───────────────────────────────────────────────────── */

/* Silk on a Fire Stick HD reports a narrow device-width which would normally  */
/* trigger the mobile @media breakpoints. These overrides lock it to the       */
/* side-by-side desktop layout and ensure nothing overflows off-screen.        */
body.is-silk .container {
    flex-direction: row !important;
    height: 95vh !important;
    width: 100% !important;
    max-width: 100% !important;
    padding: 12px !important;
    gap: 12px !important;
    margin-top: 0 !important;
    box-sizing: border-box !important;
    overflow: hidden !important;
}

body.is-silk .file-list {
    flex: 0 0 42% !important;
    width: auto !important;
    max-width: none !important;
    max-height: none !important;
    height: 100% !important;
    overflow: hidden !important;
    padding: 12px !important;
}

body.is-silk .preview {
    flex: 1 1 0 !important;
    width: auto !important;
    min-width: 0 !important;
    max-width: none !important;
    height: 100% !important;
    min-height: 0 !important;
    padding: 12px !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
}

body.is-silk #video-player {
    width: 100% !important;
    max-width: 100% !important;
    height: auto !important;
    max-height: 50vh !important;
}

body.is-silk #directory-list,
body.is-silk #file-list {
    max-height: none !important;
    height: auto !important;
    overflow-y: auto !important;
    flex-grow: 1 !important;
}
/* ─────────────────────────────────────────────────────────────────────────── */
</style>
</head>
<body>
    <div class="parallax">
        <div class="background"></div> 
        <div class="container">
            <div class="file-list">
                <!-- Auto-scroll zones for Fire TV remote cursor -->
                <div class="scroll-zone scroll-zone-up" id="scroll-zone-up">
                    <div class="zone-indicator"><svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M12 8l-6 6h12z"/></svg></div>
                </div>
                <div class="scroll-zone scroll-zone-down" id="scroll-zone-down">
                    <div class="zone-indicator"><svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M12 16l6-6H6z"/></svg></div>
                </div>
                <div class="nav-header" style="display: flex; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 20px;">
                    <a href="/index.html" class="home-title">Home</a>
                    <div class="breadcrumb" style="display: flex; align-items: center; gap: 8px;">
    <a href="#" class="main-directory-link">Main Directory</a>
    
    <div id="upload-section" style="display: none; margin-left: 10px;">
    <form id="uploadForm" action="<?php echo $web_base; ?>/index.php" method="POST" enctype="multipart/form-data" style="display:inline;">
        <input type="hidden" name="upload_to" id="upload_to_path" value="">
        <input type="file" id="media_upload" name="media_upload" style="display:none;">
        <button type="button" class="btn" onclick="document.getElementById('media_upload').click()">
            ↑ Upload File
        </button>
    </form>
</div>
                    </div>
                </div>
                            <div style="margin-bottom: 15px; padding: 0 5px;">
    <input type="text" id="fileSearch" placeholder="SEARCH..." 
           style="width: 100%; background: rgba(255,255,255,0.05); border: 1px solid rgba(244, 233, 205, 0.4); 
           padding: 12px; border-radius: 10px; color: #ffffff; font-family: 'Cinzel', serif; outline: none; font-size: 0.8rem; text-transform: uppercase;">
</div>

<h1 id="list-title" style="margin-bottom:15px; font-size:1rem; color:#d4af37; letter-spacing:3px; display:flex; align-items:center; gap:12px;">Browse <span style="flex:1; height:1px; background:linear-gradient(to right, rgba(212,175,55,0.4), transparent); display:inline-block;"></span></h1>
                <div id="directory-list" tabindex="0">
                    <!-- populated at runtime by loadFiles() via get_files.php -->
                </div>
                <div id="file-list" tabindex="0" style="display: none;"></div>
                <div id="recently-played-section">
                    <h4>Recently Played</h4>
                    <div id="recently-played-list"></div>
                </div>
            </div>
            <div class="preview">
    <div id="preview-content" class="preview-wrapper">
        <p style="text-align: center;">Choose a Directory or select a file to play</p>
    		</div>
	</div>
    </div>

                <div class="help-container">
                    <div class="help-icon">?</div>
                    <div class="help-tooltip">
                        <div class="help-header">Controls</div>
                        <div class="help-row"><span>ARROWS UP/DN</span> <span>VOLUME</span></div>
                        <div class="help-row"><span>ARROWS L/R</span> <span>SEEK / NAV</span></div>
                        <div class="help-row"><span>SPACE</span> <span>PLAY / PAUSE</span></div>
                        <div class="help-row"><span>ENTER / F</span> <span>FULLSCREEN</span></div>
                        <div class="help-row"><span>A</span> <span>ASPECT RATIO</span></div>
                        <div class="help-row"><span>ESC</span> <span>EXIT VIEW</span></div>
                    </div>
                </div>
            </div> </div> </div>



<script>
    // ── Silk / Fire TV detection — add body class to enable performance CSS ──
    (function() {
        if (/Silk/i.test(navigator.userAgent)) {
            document.body.classList.add('is-silk');
        }
    })();
    // ─────────────────────────────────────────────────────────────────────────

    let backgrounds = [];
    let currentPath = '<?php echo $web_base; ?>';
    let audioElement = null;
    let imagePlaylist = [];
    let currentImageIndex = -1;
    let selectedIndex = -1;
    let imageCycleInterval = null;

    // ── Fire TV / Silk remote D-pad scroll support ─────────────────────────
    // ONLY intercepts Up/Down arrows when focus is on the list container itself
    // or a .file-item card inside it. If the user D-pads to an audio slider,
    // button, video player, or any other control this does nothing — those
    // elements handle their own arrow keys normally.
    document.addEventListener('keydown', function(e) {
        if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;

        const active = document.activeElement;
        if (!active) return;

        const fileList = document.getElementById('file-list');
        const dirList  = document.getElementById('directory-list');

        // Which list is visible right now?
        const scrollTarget = (fileList && fileList.style.display !== 'none') ? fileList : dirList;
        if (!scrollTarget) return;

        // Only act if focus is the container itself or a child card inside it
        const focusIsInList = (active === scrollTarget) || scrollTarget.contains(active);
        if (!focusIsInList) return;

        // Let real interactive elements keep their own arrow-key behaviour
        const interactiveTags = ['BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'VIDEO', 'AUDIO', 'A'];
        if (interactiveTags.includes(active.tagName)) return;

        e.preventDefault();
        const SCROLL_STEP = 220; // px — roughly one card row
        scrollTarget.scrollBy({ top: e.key === 'ArrowDown' ? SCROLL_STEP : -SCROLL_STEP, behavior: 'smooth' });
    });
    // ──────────────────────────────────────────────────────────────────────

    // ── Auto-scroll zones for Fire TV remote cursor ───────────────────────
    // When the cursor hovers over the top or bottom strip of the file-list
    // panel, the directory list scrolls continuously until the cursor leaves.
    (function() {
        let scrollTimer = null;
        const INTERVAL = 16;  // ms per tick (~60fps)
        const SPEED    = 10;  // px per tick — increase to scroll faster

        function getScrollTarget() {
            const fl = document.getElementById('file-list');
            const dl = document.getElementById('directory-list');
            return (fl && fl.style.display !== 'none') ? fl : dl;
        }

        function startScroll(direction) {
            if (scrollTimer) return;
            scrollTimer = setInterval(function() {
                const target = getScrollTarget();
                if (target) target.scrollTop += direction * SPEED;
            }, INTERVAL);
        }

        function stopScroll() {
            if (scrollTimer) { clearInterval(scrollTimer); scrollTimer = null; }
        }

        document.addEventListener('DOMContentLoaded', function() {
            const zoneUp   = document.getElementById('scroll-zone-up');
            const zoneDown = document.getElementById('scroll-zone-down');
            if (zoneUp) {
                zoneUp.addEventListener('mouseenter', () => startScroll(-1));
                zoneUp.addEventListener('mouseleave', stopScroll);
                zoneUp.addEventListener('touchstart', () => startScroll(-1), { passive: true });
                zoneUp.addEventListener('touchend',   stopScroll);
            }
            if (zoneDown) {
                zoneDown.addEventListener('mouseenter', () => startScroll(1));
                zoneDown.addEventListener('mouseleave', stopScroll);
                zoneDown.addEventListener('touchstart', () => startScroll(1), { passive: true });
                zoneDown.addEventListener('touchend',   stopScroll);
            }
        });
    })();
    // ──────────────────────────────────────────────────────────────────────

    function stripExt(name) {
        return name.includes('.') ? name.substring(0, name.lastIndexOf('.')) : name;
    }

    // ── Recently Played (localStorage, max 3) ──────────────────────────────
    const RECENT_KEY = 'recentlyPlayed';
    const RECENT_MAX = 3;
    const WEB_BASE   = '<?php echo $web_base; ?>';

    function getRecentlyPlayed() {
        try { return JSON.parse(localStorage.getItem(RECENT_KEY)) || []; }
        catch(e) { return []; }
    }

    function addRecentlyPlayed(filePath, fileName, fileType) {
        let list = getRecentlyPlayed();
        // Remove existing entry for same file so it moves to top
        list = list.filter(item => item.path !== filePath);
        list.unshift({ path: filePath, name: fileName, type: fileType });
        if (list.length > RECENT_MAX) list = list.slice(0, RECENT_MAX);
        try { localStorage.setItem(RECENT_KEY, JSON.stringify(list)); }
        catch(e) { /* storage full – silently ignore */ }
    }

    function renderRecentlyPlayed() {
        const section = document.getElementById('recently-played-section');
        const listEl  = document.getElementById('recently-played-list');
        const list    = getRecentlyPlayed().slice(0, RECENT_MAX);
        const isRoot  = (currentPath === WEB_BASE || currentPath === WEB_BASE + '/');

        if (!isRoot || list.length === 0) {
            section.style.display = 'none';
            return;
        }

        const icons = { video: '🎬', audio: '🎵', image: '🖼️', other: '📄' };
        listEl.innerHTML = '';
        list.forEach(item => {
            const div = document.createElement('div');
            div.className = 'recent-item';
            div.innerHTML = `<span class="recent-item-icon">${icons[item.type] || icons.other}</span>
                             <span class="recent-item-name">${stripExt(item.name)}</span>`;
            div.onclick = (event) => {
                // Clear highlight on all recent items first
                document.querySelectorAll('.recent-item').forEach(el => el.style.border = '');
                // Highlight this one
                div.style.border = '2px solid #d4af37';
                showPreview(item.path, item.type, item.name, event);
            };
            listEl.appendChild(div);
        });
        section.style.display = 'block';
    }
    // ──────────────────────────────────────────────────────────────────────

    // 1. Background Handling
    function setBackground(index = 0) {
    const bgDiv = document.querySelector('.background');
    if (backgrounds.length === 0) {
        bgDiv.style.background = 'linear-gradient(135deg, #000, #1a1a1a)';
        bgDiv.innerHTML = '';
        return;
    }

    const background = backgrounds[index % backgrounds.length];
    bgDiv.innerHTML = '';

    if (background.type === 'video') {
        // 2. Clear image background and create video element
        bgDiv.style.backgroundImage = 'none';
        
        const video = document.createElement('video');
        video.className = 'background-video';
        video.src = background.src;
        video.muted = true;
        video.loop = true;
        video.autoplay = true;
        video.playsInline = true;
        
        bgDiv.appendChild(video);
        video.play().catch(e => console.log('Autoplay blocked:', e));
    } else if (background.type === 'image') {
        // 3. Set image background as usual
        bgDiv.style.backgroundImage = `url('${background.src}')`;
    }
}

    // Fetch backgrounds from get_backgrounds.php
    function loadBackgrounds() {
        fetch('/get_backgrounds.php')
            .then(response => {
                if (!response.ok) throw new Error('Failed to fetch backgrounds: ' + response.statusText);
                return response.json();
            })
            .then(data => {
                if (!data.success) {
                    throw new Error('Background fetch unsuccessful');
                }
                backgrounds = data.backgrounds;
                const savedIndex = Math.max(0, Math.min(parseInt(localStorage.getItem('backgroundIndex')) || 0, backgrounds.length - 1));
                console.log('Backgrounds loaded:', backgrounds, 'Applying index:', savedIndex);
                setBackground(savedIndex);
            })
            .catch(error => {
                console.error('Error fetching backgrounds:', error);
                // Fallback to default gradient
                backgrounds = [{ type: 'gradient', src: 'gradient', name: 'Default Gradient' }];
                setBackground(0);
            });
    } 

    // 2. Main File & Directory Loader
    function loadFiles(path) {
        currentPath = path;
        history.pushState({path: path}, '', path);
        document.getElementById('fileSearch').value = '';
        resumeBackgroundVideo();
        // --- NEW PATH CALCULATION FOR UPLOADS ---
    const baseDir = '<?php echo $base_dir; ?>'; 
    const webBase = '<?php echo $web_base; ?>'; 
    const systemPath = baseDir + path.replace(webBase, '');
    
    const pathInput = document.getElementById('upload_to_path');
    if (pathInput) pathInput.value = systemPath;
    // ----------------------------------------
        
        fetch('/files/get_files.php?path=' + encodeURIComponent(path))
            .then(res => res.json())
            .then(data => {
                const uploadSection = document.getElementById('upload-section');
                 const folderName = path.split('/').filter(Boolean).pop()?.toLowerCase() || '';
                const allowed = ['music', 'pictures', 'photos', 'video', 'videos', 'movies'];

                if (allowed.includes(folderName)) {
                uploadSection.style.display = 'block';
                // Essential: Update the hidden input with the current web path
                document.getElementById('upload_to_path').value = path; 
                } else {
                uploadSection.style.display = 'none';
                }
    
                if (allowed.includes(folderName)) {
        uploadSection.style.display = 'block';
                } else {
        uploadSection.style.display = 'none';
                }
                const dirList = document.getElementById('directory-list');
                dirList.innerHTML = '';
                selectedIndex = -1; 
                imagePlaylist = []; 
                
                const allItems = [];
                if (data.directories) data.directories.forEach(d => allItems.push({...d, isDir: true}));
                if (data.files) data.files.forEach(f => allItems.push({...f, isDir: false}));

                const isRoot = (path === webBase || path === webBase + '/');

                // At root: use a compact single-row layout for the 3 top-level folders
                if (isRoot && data.directories && data.directories.length > 0 && (!data.files || data.files.length === 0)) {
                    dirList.style.display = 'flex';
                    dirList.style.flexDirection = 'row';
                    dirList.style.gridTemplateColumns = '';
                    dirList.style.gap = '12px';
                    dirList.classList.add('root-row');
                } else {
                    dirList.style.display = '';
                    dirList.style.flexDirection = '';
                    dirList.style.gridTemplateColumns = '';
                    dirList.style.gap = '';
                    dirList.classList.remove('root-row');
                }

                allItems.forEach((item, index) => {
                    const div = document.createElement('div');
                    div.className = 'file-item';
                    
                    let thumbHtml;
                    let fileType = 'other';

                    if (item.isDir) {
                fileType = 'directory';
                const isMobile = isRoot && !document.body.classList.contains('is-silk') && (window.innerWidth <= 768 || (window.innerHeight <= 500 && window.innerWidth > window.innerHeight));
                // Desktop root: normal sized icon, auto height card with label
                // Mobile root: scaled-down icon, compact card, no label
                const svgW = 48;
                const svgH = 48;
                const iconBoxH = isMobile ? '56px' : '120px';
                const svgScaled = item.icon
                    .replace(/width="48"/g, 'width="' + svgW + '"')
                    .replace(/height="48"/g, 'height="' + svgH + '"');
                const scaleStyle = isMobile ? 'transform:scale(0.65);transform-origin:center center;' : '';
                thumbHtml = '<div style="width:100%;height:' + iconBoxH + ';display:flex;align-items:center;justify-content:center;' + scaleStyle + '">' + svgScaled + '</div>';
                if (isRoot) {
                    div.style.height = 'auto';
                    div.style.minHeight = '0';
                    div.style.padding = isMobile ? '8px 4px' : '14px 10px';
                    div.style.flex = '1';
                }
                div.onclick = () => loadFiles(item.web_path);
                } else {
                        const ext = item.extension.toLowerCase();
                        const videoExts = <?php echo json_encode($video_extensions); ?>;
                        const audioExts = <?php echo json_encode($audio_extensions); ?>;
                        const isVideo = videoExts.includes(ext);
                        const isAudio = audioExts.includes(ext);
                        const isImage = <?php echo json_encode($image_extensions); ?>.includes(ext);

                        if (isImage) imagePlaylist.push({path: item.web_path, name: item.name});

                        if (isVideo) {
                            fileType = 'video';
                            const posterName = item.name.substring(0, item.name.lastIndexOf('.')) || item.name;
                            thumbHtml = `<img src="/files/.metadata/posters/${encodeURIComponent(posterName)}.jpg" onerror="this.onerror=null;this.src='/movie.png';" class="file-poster">`;
                            div.setAttribute('data-webpath', item.web_path);
                        } else if (isImage) {
                            fileType = 'image';
                            thumbHtml = `<img src="${item.web_path}" class="file-poster" style="object-fit:cover;">`;
                        } else if (isAudio) {
                            fileType = 'audio';
                            thumbHtml = `<div style="font-size:3.5rem;">🎵</div>`;
                        } else {
                            thumbHtml = `<div style="font-size:3.5rem;">📄</div>`;
                        }
                        
                        div.onclick = (event) => {
                            selectedIndex = index;
                            showPreview(item.web_path, fileType, item.name, event);
                        };
                    }

                    const labelHtml = '<div class="file-name">' + stripExt(item.name) + '</div>'; div.innerHTML = thumbHtml + labelHtml;

                    // Fire TV / Silk: make each card focusable by the D-pad remote
                    // and scroll it into view when the remote lands on it
                    div.setAttribute('tabindex', '0');
                    div.addEventListener('focus', function() {
                        this.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                    });
                    // Allow Enter/Select button to trigger the card
                    div.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            this.click();
                        }
                    });

                    dirList.appendChild(div);
                });

                // ── Bulk progress overlay ─────────────────────────────────
                // Collect web paths for video files only, then fire ONE fetch
                // to get all saved progress. No video elements probed.
                // Silk-safe: a single XHR, pure CSS width, zero decoder use.
                (function() {
                    var videoPaths = [];
                    allItems.forEach(function(item) {
                        if (!item.isDir) {
                            var ext = item.extension.toLowerCase();
                            var videoExts = <?php echo json_encode($video_extensions); ?>;
                            if (videoExts.includes(ext)) {
                                videoPaths.push(item.web_path);
                            }
                        }
                    });
                    if (videoPaths.length === 0) return;

                    fetch('/files/get_progress_bulk.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ files: videoPaths })
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(progressMap) {
                        // Walk the rendered cards and stamp progress bars
                        var cards = dirList.querySelectorAll('.file-item[data-webpath]');
                        cards.forEach(function(card) {
                            var wp = card.getAttribute('data-webpath');
                            if (progressMap[wp]) {
                                var pct = progressMap[wp].pct;
                                var wrap = document.createElement('div');
                                wrap.className = 'card-progress-wrap';
                                var bar = document.createElement('div');
                                bar.className = 'card-progress-bar';
                                bar.style.width = pct + '%';
                                wrap.appendChild(bar);
                                card.appendChild(wrap);
                            }
                        });
                    })
                    .catch(function() {}); // silent fail — progress bars are cosmetic
                })();
                // ─────────────────────────────────────────────────────────

                // Show recently played only at root
                renderRecentlyPlayed();

                // Fire TV / Silk: force grid reflow to prevent 2-column flash bug.
                // Silk sometimes miscalculates the grid container width on initial
                // paint; toggling display forces a proper reflow before it renders.
                // This is a no-op on desktop/mobile as it completes before any paint.
                if (!isRoot) {
                    dirList.style.display = 'none';
                    void dirList.offsetHeight;
                    dirList.style.display = '';
                }

                // Fire TV / Silk: auto-focus the list so D-pad remote can scroll it
                if (!isRoot) {
                    setTimeout(() => { dirList.focus({ preventScroll: true }); }, 100);
                }

            }).catch(err => console.error("Error loading files:", err));
    }

    // ── Background video unload/reload (fully frees decoder on Silk/FireStick) ──
    function pauseBackgroundVideo() {
        const bgVid = document.querySelector('.background video');
        if (bgVid && !bgVid.dataset.unloadedByPlayer) {
            // Save src so we can restore it later
            const source = bgVid.querySelector('source');
            bgVid.dataset.savedSrc = source ? source.src : (bgVid.src || '');
            // Set cinema fallback image so the div never goes black
            const bgDiv = document.querySelector('.background');
            bgDiv.style.backgroundImage = `url('/Pictures/20.jpg')`;
            // Fade out smoothly first, then unload after transition
            bgVid.style.transition = 'opacity 0.8s ease';
            bgVid.style.opacity = '0';
            setTimeout(() => {
                bgVid.pause();
                if (source) source.removeAttribute('src');
                bgVid.removeAttribute('src');
                bgVid.load();
            }, 800);
            bgVid.dataset.unloadedByPlayer = '1';
        }
    }

    function resumeBackgroundVideo() {
        const bgVid = document.querySelector('.background video');
        if (bgVid && bgVid.dataset.unloadedByPlayer === '1') {
            const savedSrc = bgVid.dataset.savedSrc || '';
            if (savedSrc) {
                const source = bgVid.querySelector('source');
                if (source) {
                    source.src = savedSrc;
                } else {
                    bgVid.src = savedSrc;
                }
                bgVid.load();
                bgVid.play().catch(() => {});
                // Fade back in once playing, then clear the static fallback
                bgVid.addEventListener('playing', function fadeIn() {
                    bgVid.style.transition = 'opacity 1.2s ease';
                    bgVid.style.opacity = '1';
                    // Clear static fallback after video is fully visible
                    setTimeout(() => {
                        document.querySelector('.background').style.backgroundImage = 'none';
                    }, 1200);
                    bgVid.removeEventListener('playing', fadeIn);
                });
            }
            delete bgVid.dataset.unloadedByPlayer;
            delete bgVid.dataset.savedSrc;
        }
    }
    // ──────────────────────────────────────────────────────────────────────

    // 3. Preview Function
    function showPreview(file, type, filename, event) {
    const previewContent = document.getElementById('preview-content');
    
    // Track recently played (only for media files, not directories)
    if (type !== 'directory' && type !== 'other') {
        addRecentlyPlayed(file, filename, type);
    }

    // --- ANIMATION RESET LOGIC ---
    previewContent.style.animation = 'none';
    previewContent.offsetHeight;
    previewContent.style.animation = null; 
    // -----------------------------

    if (audioElement) { audioElement.pause(); audioElement = null; }
    
    if (type === 'image') {
        currentImageIndex = imagePlaylist.findIndex(img => img.path === file);
        previewContent.innerHTML = `
            <img src="${file}" alt="Preview" style="max-width:100%; border-radius:15px;">
            <div class="preview-info" style="margin-top:15px; text-align:center;">
                <h3>${stripExt(filename)}</h3>
                <p>Image ${currentImageIndex + 1} of ${imagePlaylist.length}. Use ←/→ for prev/next, Enter for full screen</p>
            </div>`;
    } else if (type === 'video') {
        pauseBackgroundVideo();
        const nameOnly = filename.substring(0,      filename.lastIndexOf('.')) || filename;
        const baseUrl = `/files/.metadata/posters/${encodeURIComponent(nameOnly)}`;

        previewContent.innerHTML = `
    <div style="position: relative; width: 100%;">
        <div id="resume-ui" class="resume-overlay" style="display: none;">
            <div class="resume-box">
                <h4>RESUME FROM <span id="resume-time-display">00:00</span>?</h4>
                <div class="resume-buttons">
                    <button id="btn-resume-yes" class="resume-btn resume-yes">YES</button>
                    <button id="btn-resume-no" class="resume-btn resume-no">START OVER</button>
                </div>
            </div>
        </div>
        <video id="video-player" controls
            onerror="document.getElementById('video-error-msg').style.display='block'; this.style.display='none';">
            <source src="${file}" type="video/${file.split('.').pop()}">
        </video>
        <div id="video-error-msg" style="display:none; padding:30px; text-align:center; color:rgba(244,233,205,0.6); font-family:'Cinzel',serif; font-size:0.9rem; letter-spacing:2px;">
            ⚠ MEDIA FILE CANNOT BE PLAYED
        </div>
    </div>
    <div id="acb-toggle-pill"><i class="acb-pill-chevron">▾</i> EQ &amp; FX</div>
    <div id="audio-controls-bar" style="margin-top:4px; flex-direction: column; gap: 0;">
        <div class="acb-main-row">
            <label for="eq-bass">BASS</label>
            <input type="range" id="eq-bass" min="-12" max="12" step="1" value="0">
            <span class="acb-val" id="bass-val">0dB</span>
            <label for="eq-treble">TREBLE</label>
            <input type="range" id="eq-treble" min="-12" max="12" step="1" value="0">
            <span class="acb-val" id="treble-val">0dB</span>
            <button id="btn-adv-toggle" class="acb-adv-toggle" title="Advanced audio effects">ADV ▾</button>
        </div>
        <div id="acb-advanced" class="acb-advanced-row" style="display:none;">
            <button id="btn-normalise" title="Apply dynamic compression to even out volume">◎ NORM</button>
            <button id="btn-night" class="acb-adv-btn" title="Cuts low-end rumble — good for late night viewing">🌙 NIGHT</button>
            <button id="btn-dialogue" class="acb-adv-btn" title="Boosts speech frequencies — helps voices cut through">💬 DIALOGUE</button>
            <button id="btn-subtitles" class="acb-adv-btn" title="Toggle subtitles on/off">🔤 SUBS</button>
            <button id="btn-aspect" class="acb-adv-btn" title="Cycle video fit: Fit (letterbox) → Fill (crop) → Stretch">⛶ FIT</button>
        </div>
    </div>
    <div class="preview-info" style="margin-top:12px; text-align:center;">
        <div style="display: flex; justify-content: space-between; align-items: center; gap: 15px; margin-bottom: 10px; width: 100%; min-width: 0;">
            <h3 title="${stripExt(filename)}" style="margin: 0; color: #f4e9cd; font-size: 1.5rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; min-width: 0; text-align: left;">
                ${stripExt(filename)}
            </h3>
            <div class="rating-container">
                <span id="imdb-rating" class="preview-rating" style="display:none;"></span>
                <span id="rt-rating" class="preview-rt-rating" style="display:none;"></span>
            </div>
        </div>


                <a id="wiki-link" href="javascript:void(0)" target="_blank" style="text-decoration: none; color: inherit; pointer-events: none;">
                    <div id="movie-synopsis" style="margin-top:20px; padding:18px; background: rgba(0, 0, 0, 0.5); border-radius:12px; color: #f4e9cd; font-size:1.05rem; line-height:1.5; text-align:left; display: none; height: 140px; overflow-y: auto;"></div>
                </a>
                <p id="wiki-hint" style="opacity: 0.3; font-size: 0.7rem; margin-top: 10px; display:none;">(Click synopsis for Wikipedia)</p>
            </div>`;

        // --- 1. CROSS-DEVICE RESUME FEATURE LOGIC ---
        const video = document.getElementById('video-player');
        const resumeUI = document.getElementById('resume-ui');
        const resumeTimeDisplay = document.getElementById('resume-time-display');
        const storageKey = 'resume_' + btoa(encodeURIComponent(file));
        const localTime    = parseFloat(localStorage.getItem(storageKey) || '0');

        // Fetch server-side position (written by any device), compare with local.
        // autoplay is intentionally removed from the <video> tag — we always
        // call video.play() manually once we know whether to resume or not.

        // Helper: POST a reset (time:0) to the server so other devices know
        // a conscious "Start Over" was chosen, overriding their localStorage.
        const resetProgress = () => {
            localStorage.removeItem(storageKey);
            fetch('/files/save_progress.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ file: file, time: 0, updated: Math.floor(Date.now() / 1000), reset: true })
            }).catch(() => {});
        };

        fetch('/files/save_progress.php?file=' + encodeURIComponent(file))
            .then(r => r.json())
            .then(data => {
                const serverTime    = parseFloat(data.time || '0');
                const serverUpdated = parseInt(data.updated || '0', 10);
                const localUpdated  = parseInt(localStorage.getItem(storageKey + '_updated') || '0', 10);
                const wasReset      = data.reset === true;
                // Mirror the PHP logic: trust whichever save is chronologically newer,
                // not whichever playhead position is further along.
                const bestTime = wasReset ? 0 : (serverUpdated >= localUpdated ? serverTime : localTime);
                if (bestTime > 15) {
                    // Show resume prompt — do NOT play yet
                    const timeString = new Date(bestTime * 1000).toISOString().substr(11, 8);
                    resumeTimeDisplay.innerText = timeString;
                    resumeUI.style.display = 'flex';

                    document.getElementById('btn-resume-yes').onclick = () => {
                        video.currentTime = bestTime;
                        resumeUI.style.display = 'none';
                        video.play();
                    };

                    document.getElementById('btn-resume-no').onclick = () => {
                        resetProgress();
                        resumeUI.style.display = 'none';
                        video.play();
                    };
                } else {
                    // No saved position (or explicit reset) — just play from the start
                    video.play();
                }
            })
            .catch(() => {
                // Server unavailable — fall back to localStorage only
                if (localTime > 15) {
                    const timeString = new Date(localTime * 1000).toISOString().substr(11, 8);
                    resumeTimeDisplay.innerText = timeString;
                    resumeUI.style.display = 'flex';
                    document.getElementById('btn-resume-yes').onclick = () => {
                        video.currentTime = localTime;
                        resumeUI.style.display = 'none';
                        video.play();
                    };
                    document.getElementById('btn-resume-no').onclick = () => {
                        localStorage.removeItem(storageKey);
                        resumeUI.style.display = 'none';
                        video.play();
                    };
                } else {
                    // No saved position and server unreachable — just play
                    video.play();
                }
            });

        if ('mediaSession' in navigator) {
            navigator.mediaSession.metadata = new MediaMetadata({
                title: stripExt(filename),
                artist: 'Mini-Pi Media'
            });
        }

        let lastServerSave = 0;

        // Unconditional save — used on pause and page exit.
        // No end-of-film guard so pausing near the end always writes correctly.
        const saveToServer = () => {
            if (video.currentTime > 15) {
                const nowSec = Math.floor(Date.now() / 1000);
                localStorage.setItem(storageKey, video.currentTime);
                localStorage.setItem(storageKey + '_updated', nowSec);
                fetch('/files/save_progress.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ file: file, time: video.currentTime, duration: video.duration || 0, updated: nowSec })
                }).catch(() => {});
                lastServerSave = Date.now();
            }
        };

        video.ontimeupdate = () => {
            // Throttled background save every 10s — guard the last 60s to avoid
            // writing a near-end position that would trigger a spurious resume prompt.
            if (video.currentTime > 15 && (video.duration - video.currentTime > 60)) {
                const now = Date.now();
                const nowSec = Math.floor(now / 1000);
                localStorage.setItem(storageKey, video.currentTime);
                localStorage.setItem(storageKey + '_updated', nowSec);
                if (now - lastServerSave > 10000) {
                    lastServerSave = now;
                    fetch('/files/save_progress.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ file: file, time: video.currentTime, duration: video.duration || 0, updated: nowSec })
                    }).catch(() => {});
                }
            }
        };

        // ── Refresh the progress bar on the file-list card for this video ──
        function refreshCardProgressBar() {
            const card = document.querySelector('.file-item[data-webpath="' + file + '"]');
            if (!card || !video.duration) return;
            const pct = Math.min(100, Math.round((video.currentTime / video.duration) * 100));
            if (pct < 1) return;
            let wrap = card.querySelector('.card-progress-wrap');
            if (!wrap) {
                wrap = document.createElement('div');
                wrap.className = 'card-progress-wrap';
                const bar = document.createElement('div');
                bar.className = 'card-progress-bar';
                wrap.appendChild(bar);
                card.appendChild(wrap);
            }
            wrap.querySelector('.card-progress-bar').style.width = pct + '%';
        }
        // ────────────────────────────────────────────────────────────────────

        // Save immediately on pause and tab close — no waiting for the 10s throttle
        video.addEventListener('pause', saveToServer);
        video.addEventListener('pause', refreshCardProgressBar);

        // On page exit use sendBeacon — unlike fetch(), the browser guarantees
        // delivery even when the Home button is pressed or the tab is killed.
        // pagehide covers Fire TV / Silk which sometimes skips beforeunload entirely.
        const saveBeacon = () => {
            if (video.currentTime > 15 && (video.duration - video.currentTime > 5)) {
                const nowSec = Math.floor(Date.now() / 1000);
                localStorage.setItem(storageKey, video.currentTime);
                localStorage.setItem(storageKey + '_updated', nowSec);
                const payload = JSON.stringify({
                    file: file,
                    time: video.currentTime,
                    duration: video.duration || 0,
                    updated: nowSec
                });
                navigator.sendBeacon(
                    '/files/save_progress.php',
                    new Blob([payload], { type: 'application/json' })
                );
            }
        };
        window.addEventListener('beforeunload', saveBeacon);
        window.addEventListener('pagehide', saveBeacon);

        video.onended = () => {
            window.removeEventListener('beforeunload', saveBeacon);
            window.removeEventListener('pagehide', saveBeacon);
            resetProgress();
            resumeBackgroundVideo();
        };

        // --- BACKGROUND VIDEO PAUSE/RESUME ON PLAYER PAUSE/PLAY ---
        let bgResumeTimer = null;

        video.addEventListener('pause', () => {
            // After 5 seconds of the movie being paused, softly bring the background back
            bgResumeTimer = setTimeout(() => resumeBackgroundVideo(), 5000);
        });

        video.addEventListener('play', () => {
            // If the user resumes before the 5s timer fires, cancel it and re-pause background
            clearTimeout(bgResumeTimer);
            pauseBackgroundVideo();
        });
        // ──────────────────────────────────────────────────────────────────

        // --- SUBTITLE (VTT) DETECTION & TOGGLE ---
        const vttUrl = file.substring(0, file.lastIndexOf('.')) + '.vtt';
        let subsOn = localStorage.getItem('subsOn') === '1';

        // Attach VTT track if one exists alongside the video
        fetch(vttUrl, { method: 'HEAD' })
            .then(res => {
                if (!res.ok) return;
                const track = document.createElement('track');
                track.kind    = 'subtitles';
                track.label   = 'English';
                track.srclang = 'en';
                track.src     = vttUrl;
                track.default = false;
                video.appendChild(track);
                // Apply saved subtitle preference once track is ready
                video.addEventListener('loadedmetadata', () => {
                    if (video.textTracks[0]) {
                        video.textTracks[0].mode = subsOn ? 'showing' : 'hidden';
                    }
                });
            })
            .catch(() => {});

        // SUBS button — always visible, only has effect if a track was attached
        const subsBtn = document.getElementById('btn-subtitles');
        if (subsBtn) {
            subsBtn.classList.toggle('active', subsOn);
            subsBtn.onclick = () => {
                subsOn = !subsOn;
                if (video.textTracks[0]) {
                    video.textTracks[0].mode = subsOn ? 'showing' : 'hidden';
                }
                subsBtn.classList.toggle('active', subsOn);
                localStorage.setItem('subsOn', subsOn ? '1' : '0');
            };
        }
        // --- END SUBTITLE LOGIC ---


        const ratingBadge = document.getElementById('imdb-rating');
        fetch(`${baseUrl}.rating`)
            .then(res => res.text())
            .then(rating => {
                const cleanRating = rating.trim();
                if (cleanRating && cleanRating.length < 6 && !cleanRating.includes('<')) {
                    ratingBadge.innerText = "IMDb " + cleanRating;
                    ratingBadge.style.display = 'inline-block';
                } else {
                    ratingBadge.style.display = 'none';
                }
            }).catch(() => { ratingBadge.style.display = 'none'; });
            // --- 3. ROTTEN TOMATOES RATING FETCH ---
	const rtBadge = document.getElementById('rt-rating');
	fetch(`${baseUrl}.rt`)
    	.then(res => res.text())
    	.then(rtData => {
        const cleanRt = rtData.trim();
        // Check if data exists and isn't an HTML error page
        if (cleanRt && !cleanRt.includes('<')) {
            const criticsMatch = cleanRt.match(/Critics: (\d+)%/);
            const audienceMatch = cleanRt.match(/Audience: (\d+)%/);
            let displayHtml = "RT ";
            
            if (criticsMatch) {
                displayHtml += (parseInt(criticsMatch[1]) >= 60 ? '👍 ' : '👎 ') + criticsMatch[1] + '%';
            }
            if (audienceMatch) {
                displayHtml += ' / ' + (parseInt(audienceMatch[1]) >= 60 ? '👍 ' : '👎 ') + audienceMatch[1] + '%';
            }
            
            rtBadge.innerHTML = displayHtml;
            rtBadge.style.display = 'inline-block';
        }
    }).catch(() => { rtBadge.style.display = 'none'; });

        // --- 4. WIKIPEDIA URL FETCH ---
        const wikiLink = document.getElementById('wiki-link');
        const wikiHint = document.getElementById('wiki-hint');
        fetch(`${baseUrl}.url`)
            .then(res => res.text())
            .then(url => {
                const cleanUrl = url.trim();
                if (cleanUrl.startsWith('http')) {
                    wikiLink.href = cleanUrl;
                    wikiLink.style.pointerEvents = 'auto';
                    wikiLink.style.cursor = 'pointer';
                    wikiHint.style.display = 'block';
                }
            }).catch(() => { wikiLink.style.pointerEvents = 'none'; });

            // --- 5. MOVIE SYNOPSIS FETCH ---
const synopsisBox = document.getElementById('movie-synopsis');

// Add a timestamp to bypass browser caching
const cacheBuster = "?t=" + new Date().getTime();

fetch(`${baseUrl}.txt${cacheBuster}`) 
    .then(res => res.text())
    .then(text => {
        const cleanText = text.trim();
        const isHTML = cleanText.startsWith('<');
        
        if (!isHTML && cleanText.length > 10) {
            // It's a real synopsis 
            synopsisBox.innerText = cleanText.replace(/\[\d+\]/g, '');
            if (wikiHint) wikiHint.style.display = 'block';
            synopsisBox.style.display = 'block';
            setTimeout(() => {
                synopsisBox.style.opacity = '1';
            }, 10);
        } else {
            synopsisBox.style.display = 'none';
            if (wikiHint) wikiHint.style.display = 'none';
        }
    }).catch(() => { 
        synopsisBox.style.display = 'none'; 
        if (wikiHint) wikiHint.style.display = 'none';
    });
    } else if (type === 'audio') {
        previewContent.innerHTML = `
            <div style="width: 100%; text-align: center;">
                <div style="font-size:8rem; margin-bottom:30px; filter: drop-shadow(0 0 20px rgba(244, 233, 205, 0.4));">🎵</div>
                <div style="width: 100%; display: flex; justify-content: center; padding: 0 20px;">
                    <audio controls autoplay id="audio-player" style="width: 100%; max-width: 800px; height: 60px;"
                        onerror="document.getElementById('audio-error-msg').style.display='block'; this.style.display='none';">
                        <source src="${file}" type="audio/${file.split('.').pop()}">
                        Your browser does not support the audio tag.
                    </audio>
                    <div id="audio-error-msg" style="display:none; padding:20px; text-align:center; color:rgba(244,233,205,0.6); font-family:'Cinzel',serif; font-size:0.9rem; letter-spacing:2px;">
                        ⚠ MEDIA FILE CANNOT BE PLAYED
                    </div>
                </div>
                <div style="width:100%; display:flex; justify-content:center; padding: 4px 20px 0 20px;">
                    <div id="acb-toggle-pill" style="display:none;"><i class="acb-pill-chevron">▾</i> EQ &amp; FX</div>
                </div>
                <div style="width:100%; display:flex; justify-content:center; padding: 6px 20px 0 20px;">
                    <div id="audio-controls-bar" style="width:100%; max-width:800px; flex-direction: column; gap: 0;">
                        <div class="acb-main-row">
                            <label for="eq-bass">BASS</label>
                            <input type="range" id="eq-bass" min="-12" max="12" step="1" value="0">
                            <span class="acb-val" id="bass-val">0dB</span>
                            <label for="eq-treble">TREBLE</label>
                            <input type="range" id="eq-treble" min="-12" max="12" step="1" value="0">
                            <span class="acb-val" id="treble-val">0dB</span>
                            <button id="btn-adv-toggle" class="acb-adv-toggle" title="Advanced audio effects">ADV ▾</button>
                        </div>
                        <div id="acb-advanced" class="acb-advanced-row" style="display:none;">
                            <button id="btn-normalise" title="Apply dynamic compression to even out volume">◎ NORM</button>
                            <button id="btn-night" class="acb-adv-btn" title="Cuts low-end rumble — good for late night viewing">🌙 NIGHT</button>
                            <button id="btn-dialogue" class="acb-adv-btn" title="Boosts speech frequencies — helps voices cut through">💬 DIALOGUE</button>
                        </div>
                    </div>
                </div>
                <div class="preview-info" style="margin-top:15px;">
                    <h3 style="font-size: 1.5rem; margin-bottom: 10px;">${stripExt(filename)}</h3>

                </div>
            </div>`;
        audioElement = document.getElementById('audio-player');

        if ('mediaSession' in navigator) {
            navigator.mediaSession.metadata = new MediaMetadata({
                title: stripExt(filename),
                artist: 'Mini-Pi Media'
            });
        }
    }

    // Border highlight for selected item
    document.querySelectorAll('.file-item').forEach(item => item.style.border = 'none');
    document.querySelectorAll('.recent-item').forEach(item => item.style.border = '');
    if (event && event.currentTarget) { 
        event.currentTarget.style.border = '2px solid #f4e9cd'; 
    }
}

// 4. Integrated Keyboard Navigation & Media Controls
    document.addEventListener('keydown', (e) => {
        const t = e.target;
        if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;

        const items = document.querySelectorAll('.file-item');
        const media = document.querySelector('#preview-content video, #preview-content audio');
        const image = document.querySelector('#preview-content img');

        if (['ArrowRight', 'ArrowLeft', 'ArrowUp', 'ArrowDown'].includes(e.code)) {
            if (image && (e.code === 'ArrowRight' || e.code === 'ArrowLeft')) {
                e.preventDefault();
                if (e.code === 'ArrowRight' && currentImageIndex < imagePlaylist.length - 1) currentImageIndex++;
                else if (e.code === 'ArrowLeft' && currentImageIndex > 0) currentImageIndex--;
                showPreview(imagePlaylist[currentImageIndex].path, 'image', imagePlaylist[currentImageIndex].name);
            } 
            else if (media) {
                e.preventDefault();
                if (e.code === 'ArrowRight') media.currentTime = Math.min(media.currentTime + 5, media.duration || media.currentTime);
                if (e.code === 'ArrowLeft') media.currentTime = Math.max(media.currentTime - 5, 0);
                if (e.code === 'ArrowUp') media.volume = Math.min((media.volume || 0) + 0.1, 1);
                if (e.code === 'ArrowDown') media.volume = Math.max((media.volume || 0) - 0.1, 0);
            }
            else if (items.length > 0) {
                if (selectedIndex === -1) selectedIndex = 0;
                else if (e.code === 'ArrowRight') selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
                else if (e.code === 'ArrowLeft') selectedIndex = Math.max(selectedIndex - 1, 0);
                else if (e.code === 'ArrowUp') selectedIndex = Math.max(selectedIndex - 3, 0); 
                else if (e.code === 'ArrowDown') selectedIndex = Math.min(selectedIndex + 3, items.length - 1);

                items[selectedIndex].scrollIntoView({ behavior: 'smooth', block: 'center' });
                items[selectedIndex].click();
                e.preventDefault();
            }
        }

        if (e.code === 'Enter' || e.code === 'KeyF') {
            e.preventDefault();
            if (image) {
                if (image.requestFullscreen) image.requestFullscreen();
                else if (image.webkitRequestFullscreen) image.webkitRequestFullscreen();
            } else if (media && media.tagName === 'VIDEO') {
                if (!document.fullscreenElement) {
                    if (media.requestFullscreen) media.requestFullscreen();
                } else {
                    if (document.exitFullscreen) document.exitFullscreen();
                }
            } else if (selectedIndex !== -1) {
                items[selectedIndex].click();
            }
        }

        if (e.code === 'Space' && media) {
            e.preventDefault();
            media.paused ? media.play() : media.pause();
        }

        if (e.code === 'KeyA') {
            const video = document.getElementById('video-player');
            if (video) { e.preventDefault(); cycleAspect(); }
        }
    });

    // 5. Fullscreen Listeners & Initialization
    const handleExitFullscreen = () => {
        if (!document.fullscreenElement && !document.webkitFullscreenElement && imagePlaylist.length > 0 && currentImageIndex >= 0) {
            const imageData = imagePlaylist[currentImageIndex];
            showPreview(imageData.path, 'image', imageData.name);
        }
    };

    document.addEventListener('webkitfullscreenchange', handleExitFullscreen);
    
    document.addEventListener('dblclick', (e) => {
        if (e.target.tagName === 'IMG' && e.target.closest('#preview-content')) {
            if (e.target.requestFullscreen) e.target.requestFullscreen();
            else if (e.target.webkitRequestFullscreen) e.target.webkitRequestFullscreen();
        }
    });

    // Essential: Page Load initialization
    window.onload = () => { 
        loadBackgrounds(); 
        loadFiles(currentPath);

        // ── XHR Upload with Progress Bar ──────────────────────────────────
        const fileInput = document.getElementById('media_upload');
        const overlay   = document.getElementById('upload-overlay');
        const bar       = document.getElementById('upload-progress-bar');
        const pct       = document.getElementById('upload-progress-pct');
        const fnameEl   = document.getElementById('upload-modal-filename');

        if (fileInput && overlay) {
            fileInput.addEventListener('change', function() {
                const file = this.files[0];
                if (!file) return;

                const formData = new FormData();
                formData.append('media_upload', file);
                formData.append('upload_to', document.getElementById('upload_to_path').value);

                fnameEl.textContent = file.name;
                bar.style.width = '0%';
                pct.textContent = '0%';
                overlay.classList.add('active');

                const xhr = new XMLHttpRequest();

                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percent = Math.round((e.loaded / e.total) * 100);
                        bar.style.width = percent + '%';
                        pct.textContent = percent + '%';
                    }
                });

                xhr.addEventListener('load', function() {
                    bar.style.width = '100%';
                    pct.textContent = '100%';
                    setTimeout(function() {
                        overlay.classList.remove('active');
                        fileInput.value = '';
                        loadFiles(currentPath);
                    }, 600);
                });

                xhr.addEventListener('error', function() {
                    overlay.classList.remove('active');
                    alert('Upload failed. Please try again.');
                    fileInput.value = '';
                });

                xhr.open('POST', '<?php echo $web_base; ?>/index.php');
                xhr.send(formData);
            });
        }
        // ──────────────────────────────────────────────────────────────────
    };

    document.querySelector('.main-directory-link').onclick = (e) => { 
        e.preventDefault();
        document.getElementById('fileSearch').value = '';
        loadFiles('<?php echo $web_base; ?>'); 
    };
document.getElementById('fileSearch').addEventListener('input', function(e) {
    const term = e.target.value.toLowerCase();
    const items = document.querySelectorAll('.file-item');

    items.forEach(item => {
        const nameElement = item.querySelector('.file-name');
        if (nameElement) {
            const name = nameElement.textContent.toLowerCase();
            // Toggles visibility based on the search term
            item.style.display = name.includes(term) ? 'flex' : 'none';
        }
    });
});


// ── Aspect Ratio (shared — used by initBar button AND KeyA shortcut) ────────
const aspectModes  = ['fit', 'fill', 'stretch'];
const aspectLabels = { fit: '⛶ FIT', fill: '⛶ FILL', stretch: '⛶ STRETCH' };
const aspectFit    = { fit: 'contain', fill: 'cover', stretch: 'fill' };
let aspectMode = localStorage.getItem('aspectMode') || 'fit';

function applyAspect() {
    const videoEl = document.getElementById('video-player');
    if (videoEl) videoEl.style.objectFit = aspectFit[aspectMode];
    const aspectBtn = document.getElementById('btn-aspect');
    if (aspectBtn) {
        aspectBtn.textContent = aspectLabels[aspectMode];
        aspectBtn.classList.toggle('active', aspectMode !== 'fit');
    }
}

function cycleAspect() {
    aspectMode = aspectModes[(aspectModes.indexOf(aspectMode) + 1) % aspectModes.length];
    localStorage.setItem('aspectMode', aspectMode);
    applyAspect();
}
// ──────────────────────────────────────────────────────────────────────────

// ── Web Audio: Normalise + EQ ──────────────────────────────────────────────
(function() {
    let audioCtx = null, sourceNode = null, compressor = null, bassFilter = null, trebleFilter = null;
    let nightFilter = null, dialogueFilter = null, splitter = null, merger = null;
    let normLevel = parseInt(localStorage.getItem('normLevel') || '0'); // 0=off, 1=gentle, 2=heavy
    let bassVal  = parseFloat(localStorage.getItem('eqBass')   || '0');
    let trebleVal = parseFloat(localStorage.getItem('eqTreble') || '0');
    let nightOn    = localStorage.getItem('nightOn')    === '1';
    let dialogueOn = localStorage.getItem('dialogueOn') === '1';
    let wiredElement = null;

    const normPresets = [
        null, // 0 = off
        { threshold: -18, knee: 20, ratio: 4,  attack: 0.01,  release: 0.3  }, // 1 = gentle
        { threshold: -24, knee: 30, ratio: 12, attack: 0.003, release: 0.25 }  // 2 = heavy
    ];
    const normLabels = ['◎ NORM', '✓ GENTLE', '✓ HEAVY'];
    const normTitles = ['Off — click for gentle compression', 'Gentle — mild dynamic control, good for music', 'Heavy — strong levelling, good for films'];

    function applyNormPreset() {
        if (!compressor) return;
        const p = normPresets[normLevel];
        if (p) {
            compressor.threshold.value = p.threshold;
            compressor.knee.value      = p.knee;
            compressor.ratio.value     = p.ratio;
            compressor.attack.value    = p.attack;
            compressor.release.value   = p.release;
        }
    }

    function buildChain(mediaEl) {
        if (wiredElement === mediaEl) return;
        if (audioCtx) { try { audioCtx.close(); } catch(e){} }
        audioCtx   = new (window.AudioContext || window.webkitAudioContext)();
        sourceNode = audioCtx.createMediaElementSource(mediaEl);

        // EQ chain
        bassFilter   = audioCtx.createBiquadFilter();
        bassFilter.type = 'lowshelf';
        bassFilter.frequency.value = 150;
        bassFilter.gain.value = bassVal;

        trebleFilter = audioCtx.createBiquadFilter();
        trebleFilter.type = 'highshelf';
        trebleFilter.frequency.value = 8000;
        trebleFilter.gain.value = trebleVal;

        // Night mode — high-pass to cut rumble
        nightFilter = audioCtx.createBiquadFilter();
        nightFilter.type = 'highpass';
        nightFilter.frequency.value = nightOn ? 120 : 20;
        nightFilter.Q.value = 0.7;

        // Dialogue enhancer — peaking boost in speech band
        dialogueFilter = audioCtx.createBiquadFilter();
        dialogueFilter.type = 'peaking';
        dialogueFilter.frequency.value = 2500;
        dialogueFilter.Q.value = 0.8;
        dialogueFilter.gain.value = dialogueOn ? 4 : 0;

        // Stereo splitter/merger for future use — pass-through for now
        splitter = audioCtx.createChannelSplitter(2);
        merger   = audioCtx.createChannelMerger(2);

        compressor = audioCtx.createDynamicsCompressor();
        applyNormPreset();

        // Connect: source → bass → treble → night → dialogue → merger → (compressor →) destination
        sourceNode.connect(bassFilter);
        bassFilter.connect(trebleFilter);
        trebleFilter.connect(nightFilter);
        nightFilter.connect(dialogueFilter);
        dialogueFilter.connect(merger, 0, 0);
        dialogueFilter.connect(merger, 0, 1);

        if (normLevel > 0) {
            merger.connect(compressor);
            compressor.connect(audioCtx.destination);
        } else {
            merger.connect(audioCtx.destination);
        }

        wiredElement = mediaEl;
        if (audioCtx.state === 'suspended') audioCtx.resume();
    }

    function reconnect() {
        if (!audioCtx || !merger || !compressor) return;
        applyNormPreset();
        merger.disconnect();
        compressor.disconnect();
        if (normLevel > 0) {
            merger.connect(compressor);
            compressor.connect(audioCtx.destination);
        } else {
            merger.connect(audioCtx.destination);
        }
    }

    function updateSliderFill(slider, min, max) {
        const pct = ((parseFloat(slider.value) - min) / (max - min)) * 100;
        slider.style.backgroundImage =
            `linear-gradient(to right, #d4af37 ${pct}%, rgba(255,255,255,0.1) ${pct}%)`;
    }

    function initBar() {
        const bar  = document.getElementById('audio-controls-bar');
        const btn  = document.getElementById('btn-normalise');
        const bSlider = document.getElementById('eq-bass');
        const tSlider = document.getElementById('eq-treble');
        const bVal    = document.getElementById('bass-val');
        const tVal    = document.getElementById('treble-val');
        if (!bar || !btn || !bSlider || !tSlider) return;

        // Restore saved state
        btn.classList.toggle('active', normLevel > 0);
        btn.textContent = normLabels[normLevel];
        btn.title = normTitles[normLevel];
        bSlider.value = bassVal;
        tSlider.value = trebleVal;
        bVal.textContent  = (bassVal >= 0 ? '+' : '')  + bassVal   + 'dB';
        tVal.textContent  = (trebleVal >= 0 ? '+' : '') + trebleVal + 'dB';
        bVal.classList.toggle('at-zero', bassVal === 0);
        tVal.classList.toggle('at-zero', trebleVal === 0);
        updateSliderFill(bSlider, -12, 12);
        updateSliderFill(tSlider, -12, 12);

        // ── Advanced panel toggle ──────────────────────────────────────────
        const advToggle = document.getElementById('btn-adv-toggle');
        const advPanel  = document.getElementById('acb-advanced');
        const nightBtn  = document.getElementById('btn-night');
        const dlgBtn    = document.getElementById('btn-dialogue');
        const aspectBtn = document.getElementById('btn-aspect');
        if (!advToggle || !advPanel) return;

        // Aspect cycle: fit → fill → stretch
        applyAspect(); // Restore on load

        if (aspectBtn) aspectBtn.onclick = () => { cycleAspect(); };

        // Restore advanced state
        if (nightBtn)  { nightBtn.classList.toggle('active', nightOn); }
        if (dlgBtn)    { dlgBtn.classList.toggle('active', dialogueOn); }

        // Re-open panel if any advanced setting is active
        const anyAdvActive = nightOn || dialogueOn || aspectMode !== 'fit';
        if (anyAdvActive) {
            advPanel.style.display = 'flex';
            advToggle.textContent = 'ADV ▴';
            advToggle.classList.add('open');
        }

        advToggle.onclick = () => {
            const open = advPanel.style.display === 'flex';
            advPanel.style.display = open ? 'none' : 'flex';
            advToggle.textContent  = open ? 'ADV ▾' : 'ADV ▴';
            advToggle.classList.toggle('open', !open);
        };

        if (nightBtn) nightBtn.onclick = () => {
            nightOn = !nightOn;
            nightBtn.classList.toggle('active', nightOn);
            localStorage.setItem('nightOn', nightOn ? '1' : '0');
            if (nightFilter) nightFilter.frequency.value = nightOn ? 120 : 20;
        };

        if (dlgBtn) dlgBtn.onclick = () => {
            dialogueOn = !dialogueOn;
            dlgBtn.classList.toggle('active', dialogueOn);
            localStorage.setItem('dialogueOn', dialogueOn ? '1' : '0');
            if (dialogueFilter) dialogueFilter.gain.value = dialogueOn ? 4 : 0;
        };

        // Show pill, hide bar by default (unless already had it open)
        const pill = document.getElementById('acb-toggle-pill');
        if (pill) {
            pill.style.display = 'flex';
            const barOpen = localStorage.getItem('acbOpen') === '1';
            if (barOpen) {
                bar.style.display = 'flex';
                pill.classList.add('open');
            }
            pill.onclick = () => {
                const isOpen = bar.style.display === 'flex';
                if (isOpen) {
                    bar.style.display = 'none';
                    pill.classList.remove('open');
                    localStorage.setItem('acbOpen', '0');
                } else {
                    bar.style.display = 'flex';
                    pill.classList.add('open');
                    localStorage.setItem('acbOpen', '1');
                }
            };
        }

        // Wire up to whatever media element is present
        const mediaEl = document.getElementById('video-player') || document.getElementById('audio-player');
        if (mediaEl) {
            const wireOnce = () => { buildChain(mediaEl); mediaEl.removeEventListener('play', wireOnce); };
            if (!mediaEl.paused) { buildChain(mediaEl); }
            else { mediaEl.addEventListener('play', wireOnce); }
        }

        btn.onclick = () => {
            normLevel = (normLevel + 1) % 3;
            localStorage.setItem('normLevel', normLevel);
            btn.classList.toggle('active', normLevel > 0);
            btn.textContent = normLabels[normLevel];
            btn.title = normTitles[normLevel];
            reconnect();
        };

        bSlider.oninput = () => {
            bassVal = parseFloat(bSlider.value);
            bVal.textContent = (bassVal >= 0 ? '+' : '') + bassVal + 'dB';
            bVal.classList.toggle('at-zero', bassVal === 0);
            localStorage.setItem('eqBass', bassVal);
            if (bassFilter) bassFilter.gain.value = bassVal;
            updateSliderFill(bSlider, -12, 12);
        };
        const snapToZero = (slider, onUpdate) => {
            slider.addEventListener('change', () => {
                if (Math.abs(parseFloat(slider.value)) <= 1) {
                    slider.value = 0;
                    onUpdate();
                }
            });
        };
        snapToZero(bSlider, () => bSlider.dispatchEvent(new Event('input')));
        snapToZero(tSlider, () => tSlider.dispatchEvent(new Event('input')));

        tSlider.oninput = () => {
            trebleVal = parseFloat(tSlider.value);
            tVal.textContent = (trebleVal >= 0 ? '+' : '') + trebleVal + 'dB';
            tVal.classList.toggle('at-zero', trebleVal === 0);
            localStorage.setItem('eqTreble', trebleVal);
            if (trebleFilter) trebleFilter.gain.value = trebleVal;
            updateSliderFill(tSlider, -12, 12);
        };
    }

    // Hook into showPreview — observe DOM changes to detect when new player lands
    const observer = new MutationObserver(() => {
        const pill = document.getElementById('acb-toggle-pill');
        const bar  = document.getElementById('audio-controls-bar');
        if (bar && pill && pill.style.display !== 'flex') { initBar(); }
    });
    observer.observe(document.getElementById('preview-content') || document.body, { childList: true, subtree: true });
})();
// ──────────────────────────────────────────────────────────────────────────

// --- AMAZON FIRESTICK MEDIA KEY HANDLER ---
// Catches the play/pause button on the FireStick remote (and standard keyboards)
document.addEventListener('keydown', function(e) {
    // MediaPlayPause (keyCode 179) = physical play/pause button on FireStick remote
    // Space (keyCode 32) = spacebar on keyboard, also natural play/pause
    if (e.keyCode === 179 || e.code === 'MediaPlayPause') {
        const video = document.getElementById('video-player');
        const audio = document.getElementById('audio-player');
        const media = video || audio;
        if (media) {
            e.preventDefault();
            media.paused ? media.play() : media.pause();
        }
    }
});
</script>
<!-- Upload Progress Overlay -->
<div id="upload-overlay">
    <div id="upload-modal">
        <div id="upload-modal-title">Uploading</div>
        <div id="upload-modal-filename"></div>
        <div id="upload-progress-track">
            <div id="upload-progress-bar"></div>
        </div>
        <div id="upload-progress-pct">0%</div>
    </div>
</div>

</body>
</html>