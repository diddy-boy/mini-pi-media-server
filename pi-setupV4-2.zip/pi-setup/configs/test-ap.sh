#!/usr/bin/env bash
# test-ap.sh - Refined for stability

set -uo pipefail

VAR_FILE="/etc/raspi-ap.conf"
HTACCESS="/var/www/html/.htaccess"
MODE_FILE="/var/www/html/current_mode.txt"

require_root() {
  [[ $EUID -eq 0 ]] || { echo "This script must be run with sudo"; exit 1; }
}

# --- MOVE THIS UP ---
require_root
[[ -f "$VAR_FILE" ]] || { echo "Missing $VAR_FILE"; exit 1; }
. "$VAR_FILE" # This loads AP_SSID so the next lines work!
# --------------------

echo "**************************************************************************************" > /dev/tty
echo "** Test script: Dropping WiFi and enabling Access Point with REDIRECT logic.        **" > /dev/tty
echo "** look for a wifi network named $AP_SSID on other devices                          **" > /dev/tty
echo "** This test will keep the access point up for 5 minutes.                           **" > /dev/tty
echo "**************************************************************************************" > /dev/tty
sleep 5

log() { echo "[test-access-point] $(date '+%F %T') $*"; }

cleanup() {
  log "CLEANING UP / RESTORING WIFI..."
  echo "WIFI" > "$MODE_FILE"
  rm -f "$HTACCESS"

  # 1. Kill the AP processes first
  pkill hostapd || true
  pkill dnsmasq || true
  sleep 2 # Give the driver a moment to breathe

  # 2. COMPLETELY bring the interface down
  # This tells the kernel to stop trying to send frames (fixing your 'brcmf' crash)
  ip link set "$WLAN_IF" down || true
  ip addr flush dev "$WLAN_IF" || true
  sleep 1

  # 3. Use 'rfkill' to hard-reset the radio state if possible
  # This clears the driver's internal hang
  rfkill block wifi
  sleep 1
  rfkill unblock wifi
  sleep 1

  log "Restarting Network Services"
  systemctl start dhcpcd 2>/dev/null || true
  systemctl start NetworkManager 2>/dev/null || true
  
  # 4. Tell NetworkManager to take the wheel again
  nmcli radio wifi on || true
  nmcli device set "$WLAN_IF" managed yes || true

  if [[ -n "${CURRENT_SSID:-}" ]]; then
    log "Attempting reconnection to: $CURRENT_SSID"
    nmcli connection up "$CURRENT_SSID" --wait 10 || true
  fi
  log "Restore complete."
}

# Trap signals (like Ctrl+C or script errors) to ensure cleanup runs
trap cleanup EXIT

require_root
[[ -f "$VAR_FILE" ]] || { echo "Missing $VAR_FILE"; exit 1; }
. "$VAR_FILE"

# Capture current connection
CURRENT_SSID=$(nmcli -t -f NAME,DEVICE connection show --active | grep ":$WLAN_IF$" | cut -d: -f1 | head -n 1)

log "Starting AP Mode sequence..."
echo "AP" > "$MODE_FILE"

# Stop managers gracefully
systemctl stop NetworkManager || true
systemctl stop dhcpcd || true

# Prepare interface
ip link set "$WLAN_IF" down
ip addr flush dev "$WLAN_IF"
ip addr add "$AP_IP" dev "$WLAN_IF"
ip link set "$WLAN_IF" up

# 1. Configs
TMP_HOSTAPD_CONF=$(mktemp)
cat > "$TMP_HOSTAPD_CONF" <<EOF
interface=$WLAN_IF
ssid=$AP_SSID
hw_mode=g
channel=6
wpa=2
wpa_passphrase=$AP_PASS
EOF

TMP_DNSMASQ_CONF=$(mktemp)
cat > "$TMP_DNSMASQ_CONF" <<EOF
interface=$WLAN_IF
dhcp-range=$AP_DHCP_START,$AP_DHCP_END,255.255.255.0,12h
address=/#/192.168.50.1
EOF

# 2. Redirects
cat > "$HTACCESS" <<EOF
RewriteEngine On
RewriteBase /
RewriteCond %{REQUEST_URI} ^/status.html$ [NC]
RewriteRule ^ - [L]
RewriteRule ^ http://192.168.50.1/status.html [R=302,L]
EOF
chown www-data:www-data "$HTACCESS"

# 3. Start Processes
hostapd -B "$TMP_HOSTAPD_CONF"
dnsmasq -C "$TMP_DNSMASQ_CONF"

log "AP Mode Active for 5 minutes. SSID: $AP_SSID"
sleep 300

# The 'cleanup' function is triggered automatically here by 'trap'
