<?php
header('Content-Type: application/json');

// Define script paths and lock file
$usb_script = '/usr/local/bin/usb_sync.sh';
$server_script = '/usr/local/bin/server_sync.sh';
$server_lock_file = '/var/run/server_sync.lock';

// Function to check if a script is running
function is_script_running($script_path) {
    $cmd = "ps aux | grep -v grep | grep " . escapeshellarg($script_path);
    exec($cmd, $output, $status);
    return !empty($output);
}

// Check statuses
$usb_syncing = is_script_running($usb_script);
$server_syncing = is_script_running($server_script);

// Verify server_sync.sh with lock file
$server_lock_exists = file_exists($server_lock_file);
if ($server_syncing && $server_lock_exists) {
    // Read PID from lock file and verify it's running
    $pid = @file_get_contents($server_lock_file);
    if ($pid && !is_dir("/proc/$pid")) {
        $server_syncing = false; // PID not running, likely stale lock
    }
} elseif (!$server_syncing && $server_lock_exists) {
    $server_syncing = false; // No process, but lock exists (stale)
} elseif ($server_syncing && !$server_lock_exists) {
    // Process running but no lock file (unlikely, but trust ps aux)
    $server_syncing = true;
}

// Determine status message
$status_message = '';
if ($usb_syncing && $server_syncing) {
    $status_message = 'Both USB and Server syncing';
} elseif ($usb_syncing) {
    $status_message = 'USB syncing';
} elseif ($server_syncing) {
    $status_message = 'Server syncing';
} else {
    $status_message = 'No sync running';
}

// Output JSON response
echo json_encode([
    'usb_syncing' => $usb_syncing,
    'server_syncing' => $server_syncing,
    'status' => $status_message
]);
?>
