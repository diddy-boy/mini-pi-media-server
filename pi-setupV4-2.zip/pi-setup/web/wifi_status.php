<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate'); // Extra aggressive cache prevention
header('Pragma: no-cache');
header('Expires: 0');

function getNetworkStatus() {
    clearstatcache();

    // 1. Check for PHYSICAL Ethernet Carrier
    $eth_path = '/sys/class/net/eth0/carrier';
    if (file_exists($eth_path) && trim(file_get_contents($eth_path)) === '1') {
        return ['mode' => 'ETHERNET', 'text' => 'Connected via Ethernet'];
    }

    // 2. Check for Active WiFi Client (Are we actually associated?)
    // Using 'iw wlan0 link' is more reliable than 'iwgetid'
    $wlan_link = shell_exec("iw dev wlan0 link");
    if (strpos($wlan_link, 'Connected to') !== false) {
        $ssid = shell_exec("iwgetid -r");
        return ['mode' => 'WIFI', 'text' => 'Connected to: ' . trim($ssid)];
    }

    // 3. Check for Active Access Point
    // Check if the interface is actually in AP mode rather than just checking the process
    $interface_mode = shell_exec("iw dev wlan0 info | grep type");
    if (strpos($interface_mode, 'AP') !== false) {
        $clients = shell_exec("sudo iw dev wlan0 station dump | grep Station | wc -l");
        $count = intval(trim($clients));
        return [
            'mode' => 'AP', 
            'text' => "AP Mode: $count " . ($count == 1 ? "Client" : "Clients")
        ];
    }

    return ['mode' => 'OFFLINE', 'text' => 'Network Disconnected'];
}
echo json_encode(getNetworkStatus());
?>
