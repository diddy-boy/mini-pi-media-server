#!/usr/bin/env bash
#
# This script will set up a Wi-Fi connection for your home network and turn the Raspberry Pi Zero 2 W
# or a Pi 4 or 5 into a password-protected access point when away from home.
#
# Run this script to configure your Wi-Fi/AP settings. It will generate
# wifi-or-ap-onboot.sh and set up a systemd service to run it once at boot.
#
# Requirements: network-manager, hostapd, dnsmasq, iw, iproute2
# Install: sudo apt install network-manager hostapd dnsmasq iw iproute2
#
# NOTE : This script is only intended for Raspberry Pi computers running Trixie PI OS

set -euo pipefail

CONFIG_FILE="/etc/raspi-ap.conf"
LOG_FILE="/var/log/wifi-or-ap.log"
AP_IP="192.168.50.1/24"
AP_NET="192.168.50.0/24"
AP_DHCP_START="192.168.50.10"
AP_DHCP_END="192.168.50.50"
WLAN_IF="wlan0"

####################
# Utility functions
####################

require_root() {
  [[ $EUID -eq 0 ]] || { echo "This script must be run as root"; exit 1; }
}

have() { command -v "$1" >/dev/null 2>&1; }

check_requirements() {
  local missing=()
  for c in nmcli hostapd dnsmasq iw ip; do
    have "$c" || missing+=("$c")
  done
  if ((${#missing[@]})); then
    echo "Missing required commands: ${missing[*]}"
    echo "Install: sudo apt install network-manager hostapd dnsmasq iw iproute2"
    exit 1
  fi
}

ensure_logfile() {
  : >"$LOG_FILE" 2>/dev/null || {
    echo "Failed to create/truncate $LOG_FILE. Check permissions."
    exit 1
  }
  chmod 644 "$LOG_FILE" 2>/dev/null || true
}

log() { echo "[wifi-or-ap] $(date '+%F %T') $*" | tee -a "$LOG_FILE"; }

####################
# Config functions
####################

make_or_update_config() {
  if [[ -f "$CONFIG_FILE" ]]; then
    . "$CONFIG_FILE"
    echo
    echo "****************************************************************"
    echo "**              Found existing $CONFIG_FILE.                  **"
    echo "** Press Enter to keep current value on the following options **"
    echo "****************************************************************"
    echo
  else
    COUNTRY="GB"
    HOME_SSID=""
    HOME_PASS=""
    AP_SSID="PiAP-$(hostname)"
    AP_PASS="ChangeMe1234"
  fi

  # Prompt for country code
  read -rp "Country code [${COUNTRY:-GB}]: " _in; COUNTRY=${_in:-${COUNTRY}}

  # Scan for WiFi networks and sort by signal strength
  echo "Scanning for WiFi networks..."
  
  if ! systemctl is-active --quiet NetworkManager; then
    echo "NetworkManager is not running. Starting it now..."
    sudo systemctl start NetworkManager
else
    echo "scanning Wifi"
fi

  nmcli device wifi rescan >/dev/null 2>&1 || true
  sleep 2 # Wait for scan to complete

  # Get WiFi list sorted by signal strength (strongest first)
  mapfile -t wifi_list < <(nmcli -t -f SSID,SIGNAL device wifi list | sort -t: -k2 -nr | grep -v "^:")
  if [ ${#wifi_list[@]} -eq 0 ]; then
    echo "No WiFi networks found. Are any WIFI networks within range ?"
    exit 1
  fi

  # Display numbered list of WiFi networks
  echo
  echo "Available WiFi networks (strongest signal first):"
  for i in "${!wifi_list[@]}"; do
    IFS=':' read -r ssid signal <<< "${wifi_list[$i]}"
    printf "%2d. %s (Signal: %s%%)\n" $((i+1)) "$ssid" "$signal"
  done

  # Prompt user to select a WiFi network
  while true; do
    read -rp "Select WiFi network (1-${#wifi_list[@]}, or Enter to keep [${HOME_SSID:-none}]): " selection
    if [[ -z "$selection" && -n "${HOME_SSID:-}" ]]; then
      echo "Keeping existing WIFI: $HOME_SSID"
      break
    elif [[ "$selection" =~ ^[0-9]+$ && "$selection" -ge 1 && "$selection" -le ${#wifi_list[@]} ]]; then
      HOME_SSID=$(echo "${wifi_list[$((selection-1))]}" | cut -d: -f1)
      echo "Selected SSID: $HOME_SSID"
      break
    else
      echo "Invalid selection. Please enter a number between 1 and ${#wifi_list[@]} or press Enter to keep existing."
    fi
  done

  # Prompt for WiFi password
  read -rsp "WiFi password for $HOME_SSID${HOME_PASS:+ [unchanged]}: " _in; echo
  HOME_PASS=${_in:-${HOME_PASS}}

  # Prompt for AP settings
  read -rp "What would you like to call the Access Point name [${AP_SSID:-PiAP-$(hostname)}]: " _in; AP_SSID=${_in:-${AP_SSID}}
  read -rsp "What Access Point password would you like to set (8+ chars)${AP_PASS:+ [unchanged]}: " _in; echo; AP_PASS=${_in:-${AP_PASS}}

  # Validate inputs
  [[ -z "$HOME_SSID" || -z "$HOME_PASS" ]] && { echo "Home WIFI and a Home Password are required"; exit 1; }
  (( ${#AP_PASS} >= 8 )) || { echo "Access Point name must be at least 8 characters"; exit 1; }

  # Write configuration file
  install -m 600 /dev/null "$CONFIG_FILE"
  cat >"$CONFIG_FILE" <<EOF
COUNTRY="$COUNTRY"
HOME_SSID="$HOME_SSID"
HOME_PASS="$HOME_PASS"
AP_SSID="$AP_SSID"
AP_PASS="$AP_PASS"
WLAN_IF="$WLAN_IF"
AP_IP="$AP_IP"
AP_NET="$AP_NET"
AP_DHCP_START="$AP_DHCP_START"
AP_DHCP_END="$AP_DHCP_END"
EOF

  log "Saved config to $CONFIG_FILE"
}

####################
# AP config
####################

write_ap_configs() {
  mkdir -p /etc/hostapd /etc/dnsmasq.d
  . "$CONFIG_FILE"

  cat > /etc/hostapd/hostapd.conf <<EOF
country_code=$COUNTRY
interface=$WLAN_IF
driver=nl80211
ssid=$AP_SSID
hw_mode=g
channel=6
wmm_enabled=0
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase=$AP_PASS
wpa_key_mgmt=WPA-PSK
rsn_pairwise=CCMP
EOF

  if [[ -f /etc/default/hostapd ]]; then
    if grep -q '^#\?\s*DAEMON_CONF=' /etc/default/hostapd; then
      sed -i 's|^#\?\s*DAEMON_CONF=.*|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd
    else
      echo 'DAEMON_CONF="/etc/hostapd/hostapd.conf"' >> /etc/default/hostapd
    fi
  fi

  cat > /etc/dnsmasq.d/raspi-ap.conf <<EOF
interface=$WLAN_IF
bind-interfaces
dhcp-range=$AP_DHCP_START,$AP_DHCP_END,255.255.255.0,24h
EOF

  log "Wrote /etc/hostapd/hostapd.conf and /etc/dnsmasq.d/raspi-ap.conf"
}

####################
# Boot script
####################

install_boot_script() {
  cat > /usr/local/bin/wifi-or-ap-onboot.sh <<'EOS'
#!/usr/bin/env bash
set -euo pipefail

CONFIG_FILE="/etc/raspi-ap.conf"
LOG_FILE="/var/log/wifi-or-ap.log"
log(){ echo "[wifi-or-ap] $(date '+%F %T') $*" | tee -a "$LOG_FILE"; }

[[ -f "$CONFIG_FILE" ]] || { log "Missing $CONFIG_FILE"; exit 1; }
. "$CONFIG_FILE"

log "Starting boot: Checking for HOME_SSID='$HOME_SSID'"

# 1. Prepare Environment
systemctl unmask NetworkManager hostapd dnsmasq 2>/dev/null || true
rfkill unblock wifi || true

# CRITICAL FIX FOR TRIXIE: Force NetworkManager to manage the device
systemctl start NetworkManager
sleep 2
nmcli device set "$WLAN_IF" managed yes
nmcli radio wifi on
sleep 2

# 2. Try Home Network Loop
for i in $(seq 1 15); do
  log "Scan attempt $i/15..."
  # Force an active rescan to find hidden or slow-to-broadcast SSIDs
  nmcli device wifi rescan >/dev/null 2>&1 || true
  sleep 3
  
  if nmcli -t -f SSID device wifi list | grep -Fxq "$HOME_SSID"; then
    log "WIFI found. Connecting..."
    nmcli connection delete "$HOME_SSID" >/dev/null 2>&1 || true
    if nmcli device wifi connect "$HOME_SSID" password "$HOME_PASS" name "$HOME_SSID" >/dev/null 2>&1; then
      log "Connected successfully."
      exit 0
    fi
  fi
done

# 3. Failover to AP Mode
log "Home network not found. Switching to AP Mode..."
# Tell NetworkManager to let go of the device so hostapd can have it
nmcli device set "$WLAN_IF" managed no
systemctl stop NetworkManager
ip link set "$WLAN_IF" down
ip addr flush dev "$WLAN_IF"
ip addr add "$AP_IP" dev "$WLAN_IF"
ip link set "$WLAN_IF" up
sleep 2

systemctl restart hostapd
systemctl restart dnsmasq
systemctl restart ssh
log "AP Mode active."
EOS
  chmod +x /usr/local/bin/wifi-or-ap-onboot.sh
}

####################
# Systemd service
####################

install_systemd_service() {
  cat > /etc/systemd/system/wifi-or-ap-onboot.service <<'EOF'
[Unit]
Description=Choose Wi-Fi or AP at boot (one-shot)
After=network.target
Wants=NetworkManager.service
ConditionPathExists=/etc/raspi-ap.conf

[Service]
Type=oneshot
ExecStart=/usr/local/bin/wifi-or-ap-onboot.sh
RemainAfterExit=yes
TimeoutStartSec=120

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable --now wifi-or-ap-onboot.service
  log "Systemd service wifi-or-ap-onboot.service enabled and started"
}

####################
# Main
####################

main() {
  clear
  echo "**********************************************************************"
  echo "** This script will set up a Wi-Fi connection to your home network  **"
  echo "** and turn the Raspberry Pi Zero 2 W into a password-protected     **"
  echo "**               access point when away from home.                  **"
  echo "** You do not need to run this script if you plan on only using the **"
  echo "**           Raspberry Pi over an Ethernet connection               **"
  echo "**  NOTE: This script is only intended for Raspberry Pi computers   **"
  echo "**                       Running Pi OS Trixie,                      **"
  echo "**                   this script will not work                      **"
  echo "**********************************************************************"
  echo
  require_root
  check_requirements
  ensure_logfile
  make_or_update_config
  write_ap_configs
  install_boot_script
  install_systemd_service
  log "Wi-Fi/AP setup complete"
}

main "$@"
