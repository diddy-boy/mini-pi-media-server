import os
import requests
import PTN
import time
import random
import re
import argparse
import json
import socket
from pathlib import Path
from ddgs import DDGS
from PIL import Image
from bs4 import BeautifulSoup
import io

# --- CONFIG ---
MOVIE_DIR = "/var/lib/minidlna/Video"
POSTER_DIR = "/var/lib/minidlna/.metadata/posters"
VIDEO_EXTS = ['.mp4', '.avi', '.mov', '.wmv', '.mkv']
THUMBNAIL_SIZE = (300, 450)

def is_connected():
    """Returns True if WAN is reachable, False if in Ad-hoc/Offline mode."""
    try:
        # 8.8.8.8 is Google DNS; port 53 is DNS. 
        # This bypasses local DNS issues and confirms actual internet access.
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except OSError:
        return False

def clean_text(text):
    if not text: return None
    text = re.sub(r'\[\d+\]|\[\w+\]', '', text)
    return text.strip()

def get_rt_rating(title, year):
    """Enhanced RT Scraper with more robust parsing."""
    try:
        rt_url = None
        search_query = f"site:rottentomatoes.com/m/ {title} {year if year else ''}"
        with DDGS() as ddgs:
            results = ddgs.text(search_query, max_results=5)
            if results:
                for r in results:
                    if 'rottentomatoes.com/m/' in r['href']:
                        rt_url = r['href']
                        break
        
        if not rt_url: 
            print(f"    ⚠️  RT: Could not find URL for {title}")
            return None

        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}
        response = requests.get(rt_url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Try Scoreboard Component (Standard)
        board = soup.find("score-board")
        if board:
            critics = board.get('tomatometerscore')
            audience = board.get('audiencescore')
            if critics or audience:
                return f"Critics: {critics if critics else '--'}% | Audience: {audience if audience else '--'}%"

        # Fallback: JSON-LD
        json_script = soup.find('script', type='application/ld+json')
        if json_script:
            data = json.loads(json_script.string)
            # RT JSON-LD can be a list or a single object
            item = data[0] if isinstance(data, list) else data
            if 'aggregateRating' in item:
                score = item['aggregateRating'].get('ratingValue')
                return f"Critics: {score}%"

    except Exception as e:
        print(f"    RT Error: {e}")
    return None

def get_imdb_rating(title, year):
    """Enhanced IMDb Scraper with better JSON and Tag handling."""
    try:
        imdb_url = None
        query = f"imdb {title} {year if year else ''} movie"
        with DDGS() as ddgs:
            results = ddgs.text(query, max_results=5)
            if results:
                for r in results:
                    match = re.search(r'imdb\.com/title/(tt\d+)', r['href'])
                    if match:
                        imdb_url = f"https://www.imdb.com/title/{match.group(1)}/"
                        break
        
        if not imdb_url:
            print(f"    ⚠️  IMDb: Could not find URL for {title}")
            return None

        headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9'
        }
        response = requests.get(imdb_url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Primary: JSON-LD
        json_data = soup.find('script', type='application/ld+json')
        if json_data:
            try:
                data = json.loads(json_data.string)
                if isinstance(data, list): data = data[0]
                if 'aggregateRating' in data:
                    return str(data['aggregateRating']['ratingValue'])
            except: pass

        # Fallback: Scrape the actual rating element (Modern Layout)
        rating_tag = soup.find("span", {"class": "sc-b7c53eda-7 hGle8u"}) # Current IMDb class for rating
        if not rating_tag:
            rating_tag = soup.select_one('div[data-testid="hero-rating-bar__aggregate-rating__score"] span')
        
        if rating_tag:
            return rating_tag.get_text(strip=True).split('/')[0]

    except Exception as e:
        print(f"    IMDb Error: {e}")
    return None

def get_wikipedia_plot(title, year):
    try:
        search_query = f"{title} {year if year else ''} film wikipedia"
        wiki_url = None
        
        with DDGS() as ddgs:
            # Using the specialized wikipedia backend if available, or standard text search
            results = ddgs.text(search_query, max_results=3)
            for r in results:
                if 'en.wikipedia.org/wiki/' in r['href']:
                    wiki_url = r['href']
                    break

        if not wiki_url:
            return None, None

        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
        response = requests.get(wiki_url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')

        # 1. Try to find the specific Plot/Synopsis section
        plot_text = []
        # Wikipedia headers usually have the title in a span with a specific ID
        targets = ['Plot', 'Synopsis', 'Premise', 'Summary', 'Plot_summary']
        section_header = None
        
        for target in targets:
            section_header = soup.find('span', id=lambda x: x and x.lower() == target.lower())
            if not section_header:
                section_header = soup.find(['h2', 'h3'], string=re.compile(target, re.I))
            if section_header:
                break

        if section_header:
            # Navigate to the parent H2/H3 then find all following P tags until next header
            curr = section_header.find_parent(['h2', 'h3'])
            if curr:
                for sib in curr.find_next_siblings():
                    if sib.name in ['h2', 'h3']:
                        break
                    if sib.name == 'p':
                        txt = clean_text(sib.get_text())
                        if txt: plot_text.append(txt)
        
        # 2. Fallback: If no Plot section found, take the lead paragraphs
        if not plot_text:
            content_div = soup.find('div', class_='mw-parser-output')
            if content_div:
                for p in content_div.find_all('p', recursive=False)[:3]:
                    txt = clean_text(p.get_text())
                    if txt and len(txt) > 100: # Ignore short intro lines
                        plot_text.append(txt)

        final_plot = "\n\n".join(plot_text).strip()
        return (final_plot[:1500] if final_plot else None), wiki_url

    except Exception as e:
        print(f"    ⚠️ Wikipedia error: {str(e)}")
        return None, None

def download_and_resize_image(url, save_path):
    try:
        response = requests.get(url, timeout=15)
        img = Image.open(io.BytesIO(response.content))
        if img.mode in ("RGBA", "P"): img = img.convert("RGB")
        img.thumbnail(THUMBNAIL_SIZE)
        img.save(save_path, "JPEG", optimize=True, quality=85)
        return True
    except: return False

def is_music_video(filename, filepath):
    """
    Checks if a file is likely a music video based on keywords 
    or the 'Text - Text' naming convention.
    """
    # 1. Check for specific keywords (Case Insensitive)
    exempt_keywords = ['concert', 'live', 'music', 'feat']
    if any(key.lower() in filename.lower() for key in exempt_keywords):
        return True

    # 2. Check for 'Text - Text' pattern (Artist - Title)
    # This looks for any text followed by a dash (with optional spaces) and more text
    if re.search(r'.+?\s?-\s?.+', filename):
        return True

    # 3. Check if the file is inside a folder named 'Test Video' (Specific request)
    if 'Test Video' in filepath:
        return True

    return False

def run_scraper(force=False):
    print("--- Script Started ---")
    if not is_connected():
        print("🛑 No internet access detected. Exiting.")
        return 

    Path(POSTER_DIR).mkdir(parents=True, exist_ok=True)
    count = 0
    for root, dirs, files in os.walk(MOVIE_DIR):
        # Skip hidden metadata folders
        if '.metadata' in root: continue
        
        for file in files:
            if any(file.lower().endswith(ext) for ext in VIDEO_EXTS):
                
                # --- NEW: Intelligence Check ---
                # This checks the filename and the full path for your exemptions
                if is_music_video(file, root):
                    print(f"⏩ Skipping Music Video/Exempt: {file}")
                    continue
                # -------------------------------

                info = PTN.parse(file)
                title = info.get('title')
                year = info.get('year')
                
                # If PTN fails to find a title, it's likely not a standard movie file
                if not title:
                    continue

                base_name = os.path.splitext(file)[0]
                
                paths = {
                    'img': os.path.join(POSTER_DIR, f"{base_name}.jpg"),
                    'txt': os.path.join(POSTER_DIR, f"{base_name}.txt"),
                    'url': os.path.join(POSTER_DIR, f"{base_name}.url"), # New path for the link
                    'imdb': os.path.join(POSTER_DIR, f"{base_name}.rating"),
                    'rt': os.path.join(POSTER_DIR, f"{base_name}.rt")
                }
                
                print(f"Processing: {title} ({year if year else 'Year Unknown'})")

                # 1. Plot - Fetch if missing OR if force is enabled
                if not os.path.exists(paths['txt']) or force:
                    syn, wiki_url = get_wikipedia_plot(title, year)
                    if syn:
                        with open(paths['txt'], 'w') as f: 
                            f.write(syn)
                        if wiki_url:
                            with open(paths['url'], 'w') as f: 
                                f.write(wiki_url)
                        print(f"    ✅ Synopsis and URL updated")
                    else:
                        print(f"    ❌ No synopsis found on Wikipedia")
                else:
                    # Optional: Log that we are skipping the search because the file exists
                    print(f"    ℹ️  Using existing synopsis")
                    
                # 2. IMDb - Fetch latest
                rating = get_imdb_rating(title, year)
                if rating:
                    with open(paths['imdb'], 'w') as f: f.write(rating)
                    print(f"    ✅ IMDb: {rating}")
                else:
                    print(f"    ❌ No IMDb rating found")

                # 3. RT - Fetch latest
                rt_rating = get_rt_rating(title, year)
                if rt_rating:
                    with open(paths['rt'], 'w') as f: f.write(rt_rating)
                    print(f"    ✅ Rotten Tomatoes: {rt_rating}")
                else:
                    print(f"    ❌ No RT rating found")

                # 4. Poster - The "Quiet" Logic
                # If we have it and aren't forcing, DO NOT SEARCH at all.
                if os.path.exists(paths['img']) and not force:
                    print("    ℹ️  Using existing poster")
                else:
                    # We only reach this if the file is missing OR we used --force
                    p_url = None
                    try:
                        # Add an extra small sleep before image search specifically
                        time.sleep(2) 
                        with DDGS() as ddgs:
                            res = ddgs.images(f"{title} {year if year else ''} movie poster", max_results=1)
                            if res: p_url = res[0]['image']
                    except Exception as e:
                        print(f"    ⚠️  Poster search throttled/failed")

                    if p_url and download_and_resize_image(p_url, paths['img']):
                        print("    ✅ Poster downloaded/updated")
                        count += 1
                    elif os.path.exists(paths['img']):
                        print("    ℹ️  Search failed, kept existing poster")
                    else:
                        print("    ❌ No poster available")
                
                # Randomized delay to mimic human browsing (4 to 8 seconds)
                time.sleep(random.uniform(4, 8))

    print(f"--- Finished. Updated {count} items. ---")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--force', action='store_true')
    run_scraper(force=parser.parse_args().force)
