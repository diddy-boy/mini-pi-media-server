#!/bin/bash
set -e
VERSION="4.2"

# --- Explicit Paths ---
BASE_DIR="/home/pi/pi-setup"
CONFIG_DIR="$BASE_DIR/configs"
WEB_DIR="$BASE_DIR/web"
IMAGE_DIR="$BASE_DIR/images"

# --- Tracking Variables for Summary ---
CHOICE_SYNC="[ DISABLED ]"
CHOICE_WIFI="[ DISABLED ]"
CHOICE_SCRAPER="[ DISABLED ]"
CHOICE_MKV="[ DISABLED ]"
CHOICE_SWAP="[ UNCHANGED ]"

# Ensure dialog is installed
sudo apt-get install -y dialog

# Set user to pi explicitly based on your requirements
CURRENT_USER="pi"
HOME_DIR="/home/pi"

# Elevate privileges if not running as root
if [ "$EUID" -ne 0 ]; then
    dialog --msgbox "This script needs root privileges. Restarting with sudo..." 8 60
    exec sudo bash "$0" "$@"
fi

display_header() {
    clear
    dialog --title "Mini-Pi Media Server Setup - v$VERSION" \
           --msgbox "Welcome to the Mini-Pi Media Server setup script.\n\n\
This will install and configure your server for the user '$CURRENT_USER'.\n\
Working Directory: $BASE_DIR" 10 60
}

install_packages() {
    dialog --infobox "Updating and Installing Packages..." 5 60
    apt-get update -q
    apt-get upgrade -y -q

    apt-get install -y -q --no-install-recommends nano preload samba fastfetch minidlna exfatprogs apache2 php php-cli php-common php-mbstring cockpit expect ntfs-3g cifs-utils network-manager hostapd dnsmasq iw iproute2 bc ffmpeg python3-minimal python3-pip

    systemctl enable cockpit.socket

    dialog --infobox "Installing Cockpit Navigator (remote admin)..." 5 60
    wget -q https://github.com/45Drives/cockpit-navigator/releases/download/v0.5.10/cockpit-navigator_0.5.10-1focal_all.deb
    dpkg -i ./cockpit-navigator_0.5.10-1focal_all.deb
    rm ./cockpit-navigator_0.5.10-1focal_all.deb
}

check_files() {
    dialog --infobox "Checking all files are present before setting up..." 5 60
    local missing=0
    # Check key directories
    for dir in "$CONFIG_DIR" "$WEB_DIR" "$IMAGE_DIR"; do
        if [ ! -d "$dir" ]; then
            dialog --msgbox "Error: Directory $dir not found!" 8 60
            missing=1
        fi
    done

    if [ $missing -eq 1 ]; then exit 1; fi
}

copy_configs() {
    dialog --infobox "Copying files and config files..." 5 60
    
    # Create structure
    mkdir -p /var/lib/minidlna/{Video,Music,Pictures}
    mkdir -p /media/usb
    
    if [ ! -d "/var/lib/minidlna/Video/Web" ]; then
        mkdir -p /var/lib/minidlna/Video/Web
    fi

    # 1. CLEANUP RECURSIVE LINKS (The Fix)
    # Find and remove any symlink inside /var/lib/minidlna that points back to itself
    find /var/lib/minidlna -maxdepth 2 -type l -exec rm {} +

    # 2. Copy Media Assets
    cp --force $IMAGE_DIR/{1,2,3,4,5,6,7,8,waves}.mp4 /var/lib/minidlna/Pictures/
    cp --force $IMAGE_DIR/{10,11,12,13,14,15,16,17,18,19,20,21,22}.jpg /var/lib/minidlna/Pictures/
    
    # 3. Copy System Scripts & Configs
    cp --force "$CONFIG_DIR/usb_sync.sh" /usr/local/bin/
    chmod +x /usr/local/bin/usb_sync.sh
    cp --force "$CONFIG_DIR/99-usb-autosync.rules" /etc/udev/rules.d/
    cp --force "$CONFIG_DIR/usb_sync.service" /etc/systemd/system/
    cp --force "$CONFIG_DIR/motd" /etc/motd
    sed "s/SAMBA_USER/$CURRENT_USER/" "$CONFIG_DIR/smb.conf" > /etc/samba/smb.conf
    cp --force "$CONFIG_DIR/minidlna.conf" /etc/
    cp --force "$CONFIG_DIR/mkv-2-mp4.sh" /usr/local/bin/
    chmod +x /usr/local/bin/mkv-2-mp4.sh

    # 4. Web Files (Apache Root)
    rm -rf /var/www/html/*
    cp --force $WEB_DIR/{index.html,sync_status.php,disk_status.php,wifi_status.php,get_backgrounds.php,sw.js} /var/www/html/
    cp --force $IMAGE_DIR/{popcorn.png,movie.png,music.png} /var/www/html/
    cp --force "$CONFIG_DIR/000-default.conf" /etc/apache2/sites-enabled/

    # 5. Web Files (MiniDLNA Overlays)
    # Using explicit file names to prevent directory-to-directory recursion
    cp --force "$WEB_DIR/get_files.php" /var/lib/minidlna/
    cp --force "$WEB_DIR/index.php" /var/lib/minidlna/
    cp --force "$WEB_DIR/env" /var/lib/minidlna/.env
    
    # 6. Permissions
    chown -R www-data:www-data /var/www/html
    chown -R minidlna:minidlna /var/lib/minidlna
    # Ensure standard dirs are searchable
    chmod -R 755 /var/lib/minidlna
	
    systemctl daemon-reload
    a2enmod headers
    systemctl restart apache2
}

set_minidlna_friendly_name() {
    local hostname
    hostname=$(hostname)
    if grep -q "^friendly_name=" /etc/minidlna.conf; then
        sed -i "s/^friendly_name=.*/friendly_name=$hostname/" /etc/minidlna.conf
    else
        echo "friendly_name=$hostname" >> /etc/minidlna.conf
    fi
    dialog --msgbox "This MiniDLNA server will appear to smart devices (like TV's) as '$hostname'." 6 60
}

configure_samba() {
	# Get the hostname and append .local for the hint
	LOCAL_HOSTNAME="$(hostname).local"

	# 1. Ask the user for the password once
    dialog --title "Network Sharing (Samba)" --inputbox "Set a network password for user '$CURRENT_USER'.\n\nThis allows you to see this PC (\\\\$LOCAL_HOSTNAME) on your network to copy or watch media:" 11 70 2> /tmp/smbpass

    # 2. Check if the user entered anything
    if [ ! -s /tmp/smbpass ]; then
        dialog --msgbox "Error: No password provided. Please try again." 7 60
        return 1
    fi

    # 3. Ensure the system user exists
    if ! id "$CURRENT_USER" >/dev/null 2>&1; then
        adduser --system --no-create-home "$CURRENT_USER"
    fi

    # 4. Automate the password entry (Types it twice for the user)
    password=$(cat /tmp/smbpass)
    export SMB_PASS="$password"
    export SMB_USER="$CURRENT_USER"

    /usr/bin/expect << 'EOF'
set timeout 10
spawn smbpasswd -a $env(SMB_USER)
expect {
    "New SMB password:" {
        send "$env(SMB_PASS)\r"
        exp_continue
    }
    "Retype new SMB password:" {
        send "$env(SMB_PASS)\r"
        exp_continue
    }
    eof
}
EOF

    # 5. Cleanup sensitive data
    unset SMB_PASS
    unset SMB_USER
    rm -f /tmp/smbpass

    usermod -aG minidlna $CURRENT_USER
    chmod -R 775 /var/lib/minidlna
    chown -R minidlna:minidlna /var/lib/minidlna
    chgrp minidlna -Rv /var/lib/minidlna/

    rm -f /tmp/smbpass

    SYMLINK_PATH="$HOME_DIR/minidlna-link"
    if [ -L "$SYMLINK_PATH" ]; then
        if [ "$(readlink -f "$SYMLINK_PATH")" != "/var/lib/minidlna" ]; then
            rm "$SYMLINK_PATH"
            ln -s /var/lib/minidlna "$SYMLINK_PATH"
        fi
    elif [ -e "$SYMLINK_PATH" ]; then
        dialog --msgbox "$SYMLINK_PATH exists and is not a symlink. Skipping symlink creation." 6 60
    else
        ln -s /var/lib/minidlna "$SYMLINK_PATH"
    fi
    chown "$CURRENT_USER:$CURRENT_USER" "$SYMLINK_PATH"

    dialog --msgbox "Samba user and directories configured for '$CURRENT_USER'." 7 60
}

offer_swap_option() {
    CHOICE=$(dialog --title "Swap file Options" --default-item "3" --menu "Select a swap configuration:" 15 60 3 \
        1 "Disable swap (Remove rpi-swap & zram)" \
        2 "Enable 1GB ZRAM size (Hard Set)" \
        3 "Keep System Defaults (Exit)" 3>&1 1>&2 2>&3)

    case "$CHOICE" in
        1|2)
            dialog --infobox "Adjusting swap services... Please wait." 5 60
            
            # 1. STOP EVERYTHING
            # We must stop all potential zram managers to release the device lock
            systemctl stop rpi-swap.service 2>/dev/null || true
            systemctl stop zramswap.service 2>/dev/null || true
            systemctl stop systemd-zram-generator 2>/dev/null || true
            swapoff -a 2>/dev/null || true
            
            if [ "$CHOICE" = "1" ]; then
                apt-get purge -y rpi-swap zram-tools 2>/dev/null || true
                apt-get autoremove -y -q
                modprobe -r zram 2>/dev/null || true
                CHOICE_SWAP="[ DISABLED ]"
            else
                # 2. Install/Prepare zram-tools
                apt-get install -y zram-tools
                
                # 3. CRITICAL: Stop the service immediately after install
                # APT starts it with default (512MB) settings; we must kill it to resize
                systemctl stop zramswap.service 2>/dev/null || true
                swapoff /dev/zram0 2>/dev/null || true

                local alloc_size=1024

                # 4. Configure zram-tools
                # We set MAX_SIZE to 2048 to stop the Pi 5 from capping at 512MB
                cat << EOF > /etc/default/zramswap
PERCENTAGE=
ALLOCATION=$alloc_size
MAX_SIZE=2048
PRIORITY=100
ALGO=lzo-rle
EOF

                # 5. THE NUCLEAR RESET (Fixes "Resource Busy")
                # If zramctl reset fails, we yank the module out of the kernel
                zramctl --reset /dev/zram0 2>/dev/null || true
                modprobe -r zram 2>/dev/null || true
                sleep 2
                modprobe zram num_devices=1
                sleep 1

                # 6. THE HAMMER (Manual Initialization)
                # We initialize 1024MB manually so it is active RIGHT NOW
                zramctl /dev/zram0 --algorithm lzo-rle --size "${alloc_size}M"
                mkswap /dev/zram0
                swapon /dev/zram0 -p 100
                
                # 7. Persistence
                # Start the service so it stays 1GB after a reboot
                systemctl restart zramswap.service || true
                
                ACTUAL_SIZE=$(zramctl --noheadings --output DISKSIZE | xargs)
                CHOICE_SWAP="[ ENABLED ($ACTUAL_SIZE ZRAM) ]"
            fi
            ;;
        *)
            CHOICE_SWAP="[ UNCHANGED ]"
            ;;
    esac
}

offer_scraper_setup() {
    if dialog --title "Media Scraper" --yesno "Enable Media Scraper (5am daily)?\n\nThis automatically downloads movie art, movie synopsis, and movie ratings for your library." 10 60; then
        CHOICE_SCRAPER="[ ENABLED ]"
        # Scraper setup logic...
        setup_media_scraper
    fi
}

setup_media_scraper() {
    dialog --infobox "Setting up Media Scraper Service and Metadata directories..." 5 60
    
     	mkdir -p /home/pi/scraper
        cp $BASE_DIR/scraper.py /home/pi/scraper/ 2>/dev/null || true 
    # 1. Install system dependencies
    # Added python3-pil as a system safety measure
    apt-get update
    apt-get install -y python3-venv python3-full python3-pil
    
    # 2. Setup Metadata directory structure
    mkdir -p /var/lib/minidlna/.metadata/posters
    
    # Permissions logic
    usermod -a -G minidlna "$CURRENT_USER"
    chown -R minidlna:minidlna /var/lib/minidlna/.metadata
    chmod -R 775 /var/lib/minidlna/.metadata
    chmod g+s /var/lib/minidlna/.metadata/posters
    
    # 3. Setup Scraper application directory
    local SCRAPER_DIR="/home/$CURRENT_USER/scraper"
    mkdir -p "$SCRAPER_DIR"
    
    if [ -f "$BASE_DIR/scraper.py" ]; then
    cp "$BASE_DIR/scraper.py" "$SCRAPER_DIR/"
else
    dialog --msgbox "Error: $BASE_DIR/scraper.py not found!" 8 60
fi
    # 4. Create Virtual Environment and install packages
    # ADDED: beautifulsoup4
    cd "$SCRAPER_DIR"
    python3 -m venv venv
    ./venv/bin/pip install requests parse-torrent-title ddgs Pillow beautifulsoup4
    chown -R "$CURRENT_USER:$CURRENT_USER" "$SCRAPER_DIR"

    # 5. Create the Systemd Service
    # ENSURED: ExecStart points to scraper.py
    cat << EOF > /etc/systemd/system/media-scraper.service
[Unit]
Description=Media Metadata Scraper
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=$CURRENT_USER
WorkingDirectory=$SCRAPER_DIR
ExecStartPre=/bin/bash -c 'ping -c 1 8.8.8.8 > /dev/null 2>&1'

ExecStart=$SCRAPER_DIR/venv/bin/python3 scraper.py
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

    # 6. Create the Systemd Timer (5am)
    cat << EOF > /etc/systemd/system/media-scraper.timer
[Unit]
Description=Run Media Scraper daily at 5am

[Timer]
OnCalendar=*-*-* 05:00:00
Persistent=true
Unit=media-scraper.service

[Install]
WantedBy=timers.target
EOF

    # 7. Enable and Start
    systemctl daemon-reload
    systemctl enable media-scraper.timer
    systemctl start media-scraper.timer

    dialog --msgbox "Media Scraper installed.\n\nPath: $SCRAPER_DIR\nPosters & Synopsis: /var/lib/minidlna/.metadata/posters\nTimer: 5:00 AM" 12 60
}

setup_mkv_conversion_service() {
    SERVICE_FILE="/etc/systemd/system/mkv-conversion.service"
    TIMER_FILE="/etc/systemd/system/mkv-conversion.timer"
    
    # FIX: Use the explicitly defined $CONFIG_DIR instead of the undefined $SCRIPT_DIR
    MKV_CONVERT_ABS_PATH="/usr/local/bin/mkv-2-mp4.sh"

    # Safety check: Ensure the source file exists before trying to enable the service
    if [ ! -f "$CONFIG_DIR/mkv-2-mp4.sh" ]; then
        dialog --msgbox "MKV conversion script $MKV_CONVERT_ABS_PATH not found.\n\nChecked in: $CONFIG_DIR" 10 70
        return
    fi

    dialog --infobox "Configuring MKV conversion service..." 5 60

    cat << EOF > $SERVICE_FILE
[Unit]
Description=MKV to MP4 Conversion Service at midnight
After=network.target

[Service]
Type=oneshot
# Use absolute path to bash for systemd stability
ExecStart=/bin/bash $MKV_CONVERT_ABS_PATH
User=root
Group=root
WorkingDirectory=/var/lib/minidlna/Video
RemainAfterExit=no
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF

    cat << EOF > $TIMER_FILE
[Unit]
Description=Run MKV to MP4 conversion daily at midnight

[Timer]
OnCalendar=*-*-* 00:00:00
Persistent=true
Unit=mkv-conversion.service

[Install]
WantedBy=timers.target
EOF

    systemctl daemon-reload
    systemctl enable mkv-conversion.timer
    systemctl start mkv-conversion.timer
    
    if systemctl is-active --quiet mkv-conversion.timer; then
        local status="ACTIVE"
    else
        local status="FAILED TO START"
    fi

    dialog --msgbox "MKV conversion timer has been set up.\n\nIt will run daily at midnight.\nLocation: $MKV_CONVERT_ABS_PATH" 12 60
}

offer_mkv_conversion() {
    if dialog --title "Auto MKV to MP4 Conversion" --defaultno --yesno \
    "Do you want to set up a batch conversion script?\n\nThis will re-encode / remux at midnight any MKV file to MP4 in your Video directory to ensure maximum compatibility with all media players." 10 70; then
        setup_mkv_conversion_service
        CHOICE_MKV="[ ENABLED ]"  # Set the variable here if they say yes
    else
        CHOICE_MKV="[ DISABLED ]" # (Optional) Ensure it stays disabled if they say no
    fi
}

show_final_summary() {
    # Initialise variables to avoid empty display if Wi-Fi wasn't configured
    local ap_details=""
    
    # Check if the config file exists and read it
    if [ -f "/etc/raspi-ap.conf" ] && [ "$CHOICE_WIFI" = "[ ENABLED ]" ]; then
        # Source the file to get AP_SSID and AP_PASS
        . /etc/raspi-ap.conf
        ap_details="\n    - Wi-Fi SSID:             $AP_SSID\n    - Wi-Fi Password:         $AP_PASS"
    fi

    local msg="Setup Complete! Your Mini-Pi Server is configured to run:\n\n\
    - User Account:            $CURRENT_USER\n\
    - Samba Access:            [ CONFIGURED ]\n\
    - Remote Server Sync:      $CHOICE_SYNC\n\
    - Wi-Fi/AP:                $CHOICE_WIFI$ap_details\n\
    - Media Scraper:           $CHOICE_SCRAPER\n\
    - MKV Conversion:          $CHOICE_MKV\n\
    - Swap Setting:            $CHOICE_SWAP\n\n\
The system will now reboot."

    dialog --title "Installation Summary" --msgbox "$msg" 18 60
}

finalize_setup() {
    # Calls explicit paths for sub-scripts
    if dialog --yesno "Setup Remote Server Sync?" 8 60; then
        CHOICE_SYNC="[ ENABLED ]"
        sudo bash "$BASE_DIR/configure_server_sync.sh"
    fi

    if dialog --title "Reconfigure WiFi and Access point" --yesno "NOTE: This script has only been tested on a Pi Zero 2W. Proceed at your own risk.\n\nDo you want to reconfigure Wi-Fi/Access Point?" 10 60; then
    sudo bash "$BASE_DIR/reconfigure-wifi.sh"
        
        # Now verify if the config was actually created/updated
        if [ -f "/etc/raspi-ap.conf" ]; then
            CHOICE_WIFI="[ ENABLED ]"
        fi
    fi

    offer_scraper_setup
    offer_mkv_conversion
    offer_swap_option
    show_final_summary
    reboot
}

# --- Run ---
display_header
check_files
install_packages
copy_configs
set_minidlna_friendly_name
configure_samba
finalize_setup
