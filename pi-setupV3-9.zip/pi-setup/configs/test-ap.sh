#!/usr/bin/env bash
# test-ap.sh
# Test tool to swap to Access Point mode for 5 minutes with Captive Portal and Dashboard Sync.

set -euo pipefail

VAR_FILE="/etc/raspi-ap.conf"
HTACCESS="/var/www/html/.htaccess"
MODE_FILE="/var/www/html/current_mode.txt"

require_root() {
  [[ $EUID -eq 0 ]] || { echo "This script must be run as 'nohup sudo $0 > test.log 2>&1 &'"; exit 1; }
}

log() { echo "[test-access-point] $(date '+%F %T') $*"; }

require_root
[[ -f "$VAR_FILE" ]] || { echo "Missing $VAR_FILE — run ./reconfigure-wifi.sh script first"; exit 1; }
. "$VAR_FILE"

# --- YOUR ORIGINAL WARNING MESSAGES ---
echo "**************************************************************************************" > /dev/tty
echo "** Test script: Dropping WiFi and enabling Access Point with REDIRECT logic.        **" > /dev/tty
echo "** look for a wifi network named $AP_SSID on other devices                      **" > /dev/tty
echo "** This test will keep the access point up for 5 minutes.                           **" > /dev/tty
echo "**************************************************************************************" > /dev/tty
sleep 5

# Record current SSID to restore later
CURRENT_SSID=$(nmcli -t -f NAME,DEVICE connection show --active | grep ":$WLAN_IF$" | cut -d: -f1 || true)

# --- START AP MODE ---
log "Enabling AP Mode and updating Dashboard status"
echo "AP" > "$MODE_FILE" # This makes index.html show "AP Mode"

log "Disabling network managers"
systemctl stop NetworkManager || true
systemctl stop dhcpcd || true

log "Resetting $WLAN_IF"
ip link set "$WLAN_IF" down || true
ip addr flush dev "$WLAN_IF" || true
ip link set "$WLAN_IF" up
ip addr add "$AP_IP" dev "$WLAN_IF"

# 1. Generate temporary hostapd config
TMP_HOSTAPD_CONF=$(mktemp)
cat > "$TMP_HOSTAPD_CONF" <<EOF
interface=$WLAN_IF
ssid=$AP_SSID
hw_mode=g
channel=6
wpa=2
wpa_passphrase=$AP_PASS
EOF

# 2. Generate temporary dnsmasq config with DNS Redirection
TMP_DNSMASQ_CONF=$(mktemp)
cat > "$TMP_DNSMASQ_CONF" <<EOF
interface=$WLAN_IF
dhcp-range=$AP_DHCP_START,$AP_DHCP_END,255.255.255.0,12h
address=/#/192.168.50.1
EOF

# 3. Create Temporary Apache Redirect (.htaccess)
# This forces the tablet to see your status page automatically
log "Setting up temporary Apache redirect (.htaccess)"
cat > "$HTACCESS" <<EOF
RewriteEngine On
RewriteBase /
RewriteCond %{REQUEST_URI} ^/status.html$ [NC]
RewriteCond %{HTTP_HOST} ^192\\.168\.50\.1$ [NC]
RewriteRule ^ - [L]
RewriteRule ^ http://192.168.50.1/status.html [R=302,L]
EOF
chown www-data:www-data "$HTACCESS" || true

log "Starting AP mode: SSID=$AP_SSID"
hostapd -B "$TMP_HOSTAPD_CONF"
dnsmasq -C "$TMP_DNSMASQ_CONF"

log "AP mode active — Dashboard should now show 'AP Mode'"
sleep 300  # 5 minutes

# --- RESTORE HOME MODE ---
log "Stopping AP mode and CLEANING UP"
echo "WIFI" > "$MODE_FILE" # Restore Dashboard status
rm -f "$HTACCESS"        # Restore Media Server access

killall hostapd || true
killall dnsmasq || true
rm -f "$TMP_HOSTAPD_CONF" "$TMP_DNSMASQ_CONF"

log "Restoring $WLAN_IF to normal mode"
ip link set "$WLAN_IF" down || true
ip addr flush dev "$WLAN_IF" || true
ip link set "$WLAN_IF" up

log "Re-enabling network managers"
systemctl start NetworkManager || true
systemctl start dhcpcd || true
nmcli radio wifi on || true

if [[ -n "$CURRENT_SSID" ]]; then
  log "Reconnecting to previous Wi-Fi: $CURRENT_SSID"
  nmcli connection up "$CURRENT_SSID" || true
fi

log "Done — Home Wi-Fi restored and Dashboard synced."
