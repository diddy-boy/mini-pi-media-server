<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
ini_set('error_log', '/var/log/php_errors.log');

// Configuration
$base_dir = '/var/lib/minidlna';
$web_base = '/files';

// Get current directory from URL path
$request_uri = $_SERVER['REQUEST_URI'] ?? '/files/';
$path_parts = parse_url($request_uri, PHP_URL_PATH);
if (!$path_parts) {
    $path_parts = '/files/';
}
$relative_path = trim(str_replace($web_base, '', $path_parts), '/');
$current_dir = $base_dir . ($relative_path ? '/' . $relative_path : '');

// Security check
$real_base = realpath($base_dir);
$real_current = realpath($current_dir);
$debug_info = [
    'request_uri' => $request_uri,
    'path_parts' => $path_parts,
    'relative_path' => $relative_path,
    'current_dir' => $current_dir,
    'real_base' => $real_base ?: 'null',
    'real_current' => $real_current ?: 'null',
    'timestamp' => date('Y-m-d H:i:s')
];

if (!$real_base) {
    http_response_code(500);
    die('Server configuration error: Base directory not found');
}

if (!$real_current || strpos($real_current, $real_base) !== 0) {
    $current_dir = $base_dir;
    $relative_path = '';
    $debug_info['security_fallback'] = 'Reset to root directory';
}

// File extensions
$image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
$video_extensions = ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm'];
$audio_extensions = ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'];
$hidden_extensions = ['php', 'env', 'srt', 'm3u', 'db'];

function get_file_extension($filename) {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

function format_file_size($bytes) {
    if ($bytes === false) return 'Unknown';
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

function get_web_path($file_path, $base_dir, $web_base) {
    $relative = trim(str_replace($base_dir, '', $file_path), '/');
    return $web_base . ($relative ? '/' . $relative : '');
}

// Function to determine directory icon based on content
function get_directory_icon($dir_path, $image_extensions, $video_extensions, $audio_extensions, $hidden_extensions) {
    $items = @scandir($dir_path);
    if ($items === false) {
        return '📁'; // Default folder icon if directory cannot be read
    }

    $has_images = false;
    $has_videos = false;
    $has_audio = false;
    $has_other = false;

    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item[0] === '.') continue;
        $item_path = $dir_path . '/' . $item;
        $extension = get_file_extension($item);
        if (in_array($extension, $hidden_extensions)) continue;

        if (is_dir($item_path)) {
            continue; // Skip subdirectories for icon determination
        } elseif (in_array($extension, $image_extensions)) {
            $has_images = true;
        } elseif (in_array($extension, $video_extensions)) {
            $has_videos = true;
        } elseif (in_array($extension, $audio_extensions)) {
            $has_audio = true;
        } else {
            $has_other = true;
        }
    }

    // Determine icon based on content
    if ($has_images && !$has_videos && !$has_audio && !$has_other) {
        return '📷'; // Camera icon for image-only directories
    } elseif ($has_videos && !$has_images && !$has_audio && !$has_other) {
        return '🎥'; // Video camera icon for video-only directories
    } elseif ($has_audio && !$has_images && !$has_videos && !$has_other) {
        return '🎵'; // Music note icon for audio-only directories
    } else {
        return '📁'; // Default folder icon for mixed or other content
    }
}

// Get directories and files
$directories = [];
$files = [];
if (is_dir($current_dir) && is_readable($current_dir)) {
    $items = @scandir($current_dir);
    if ($items !== false) {
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || $item[0] === '.') continue;
            $item_path = $current_dir . '/' . $item;
            $extension = get_file_extension($item);
            if (in_array($extension, $hidden_extensions)) {
                continue;
            }
            if (is_dir($item_path)) {
                $icon = get_directory_icon($item_path, $image_extensions, $video_extensions, $audio_extensions, $hidden_extensions);
                $directories[] = [
                    'name' => $item,
                    'path' => $item_path,
                    'is_dir' => true,
                    'web_path' => get_web_path($item_path, $base_dir, $web_base),
                    'icon' => $icon
                ];
            } else {
                $size = @filesize($item_path);
                if ($size === false) {
                    continue;
                }
                $files[] = [
                    'name' => $item,
                    'path' => $item_path,
                    'is_dir' => false,
                    'web_path' => get_web_path($item_path, $base_dir, $web_base),
                    'size' => format_file_size($size),
                    'extension' => $extension,
                ];
            }
        }
    }
}

// Sort directories and files
usort($directories, function($a, $b) {
    return strcasecmp($a['name'], $b['name']);
});
usort($files, function($a, $b) {
    return strcasecmp($a['name'], $b['name']);
});

// Build breadcrumb navigation
$breadcrumb_parts = [];
$breadcrumb_parts[] = '<a href="/index.html" class="home-title">Home</a>'; 
$breadcrumb_parts[] = '<a href="#" class="main-directory-link">Main Directory</a>';
$breadcrumb = implode(' / ', $breadcrumb_parts);

// Dynamic page title
$page_title = 'Mini-Pi Media Server - ' . ($relative_path ? htmlspecialchars($relative_path) : 'Main Directory');

// Parent directory URL (server-side fallback)
$parent_segments = array_filter(explode('/', $relative_path));
$parent_segments = array_slice($parent_segments, 0, -1);
$parent_url = $web_base . ($parent_segments ? '/' . implode('/', $parent_segments) : '');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <link rel="icon" type="image/png" href="/popcorn.png">
    <link href="https://fonts.googleapis.com/css2?family=SF+Pro+Display:wght@400;500;600;700&family=Cinzel:wght@400;700&display=stylesheet">
   <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Cinzel', serif;
    }

    body {
        background: #000000;
        color: #f4e9cd; 
        min-height: 100vh;
        /* Change overflow from hidden to auto/clip to allow internal scrolling */
        overflow: auto; 
    }

    .parallax {
        perspective: 1px;
        min-height: 100vh;
        /* Ensure it doesn't trap the touch scroll */
        overflow-x: hidden;
        overflow-y: auto;
        position: relative;
        display: flex;
        align-items: flex-start;
        justify-content: center;
        opacity: 0;
        animation: fadeIn 0.8s ease-out forwards;
        -webkit-overflow-scrolling: touch; /* Smooth scroll for iOS */
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .background {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-size: cover;
        background-position: center;
        transform: translateZ(-1px) scale(2);
        filter: blur(12px) brightness(0.4);
        z-index: -1;
    }

    .container {
        max-width: 1800px;
        height: 95vh;
        margin-top: 2vh;
        padding: 20px;
        z-index: 1;
        display: flex;
        gap: 25px;
        width: 100%;
        overflow: hidden;
    }

    /* Glass Panels */
    .file-list, .preview {
    background: rgba(255, 255, 255, 0.08); /* Darker/thinner base */
    backdrop-filter: blur(20px) saturate(180%); /* Stronger blur for premium feel */
    border: 1px solid rgba(255, 255, 255, 0.15);
    box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.8);
    border-radius: 18px;
}

    .file-list {
        flex: 0 0 50%; 
        padding: 25px;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    /* --- NAVIGATION HEADER --- */
    .nav-header {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 30px;
        flex-wrap: wrap;
    }

    .btn, .home-title, .breadcrumb a {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-family: 'Cinzel', serif;
        text-transform: uppercase;
        text-decoration: none;
        letter-spacing: 2px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        border-radius: 12px;
        color: #ffffff !important;
        background: rgba(255, 255, 255, 0.12) !important; 
        border: 1px solid rgba(255, 255, 255, 0.3) !important;
        backdrop-filter: blur(15px) !important;
        -webkit-backdrop-filter: blur(15px) !important;
    }

    .home-title { font-size: 1.6rem; padding: 12px 30px; }
    .breadcrumb a, .btn { padding: 10px 20px; font-size: 1rem; }

    .btn:hover, .home-title:hover, .breadcrumb a:hover {
        background: rgba(255, 255, 255, 0.35) !important; 
        box-shadow: 0 0 25px rgba(255, 255, 255, 0.5) !important;
        transform: translateY(-3px);
    }

    .nav-separator {
        color: rgba(255, 255, 255, 0.5);
        font-size: 1.4rem;
        margin: 0 10px;
    }

    /* --- FILE GRID --- */
    #directory-list, #file-list {
        display: grid;
        gap: 30px;
        grid-template-columns: repeat(3, 1fr);
        align-content: start; 
        overflow-y: auto;
        padding-right: 15px;
        flex-grow: 1;
	touch-action: pan-y; 
        -webkit-overflow-scrolling: touch;
    }

    .file-item {
        /* Keep the layout from the first block */
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;
        padding: 15px;
        border-radius: 18px;
        height: 190px; 
        cursor: pointer;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.6);
        margin: 5px;
    }

    .file-item:hover {
        /* Button Style Background & Blur */
        background: rgba(255, 255, 255, 0.35) !important; 
        backdrop-filter: blur(15px) !important;
        -webkit-backdrop-filter: blur(15px) !important;
        
        /* Button Style Border & Glow */
        border: 1px solid rgba(255, 255, 255, 0.5) !important;
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.8), 0 0 25px rgba(255, 255, 255, 0.5) !important;
        
        /* Keep your existing raised effect */
        transform: translateY(-5px);
    }

    .file-item img {
        width: 100%;
        height: 80px;
        object-fit: cover;
        border-radius: 8px;
    }

    .file-icon { font-size: 2.5rem; margin-bottom: 5px; }

    /* --- THE FIX FOR MISSING NAMES --- */
    .file-name {
        font-size: 0.85rem;
        color: #f4e9cd !important; /* Cream color from index.html */
        font-weight: 700;
        text-align: center;
        width: 100%;
        margin-top: 8px;
        /* Ensure text is visible and wraps properly */
        display: block !important;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: normal;
        display: -webkit-box !important;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        line-height: 1.2;
    }

    .file-info {
        font-size: 0.7rem;
        color: rgba(244, 233, 205, 0.6);
        margin-top: 4px;
    }

    /* --- PREVIEW --- */
    .preview { 
        flex: 1; 
        padding: 30px; 
        display: flex; 
        flex-direction: column; 
        align-items: center; 
        justify-content: center; 
        text-align: center; 
    }

    /* Add this to lock the content wrapper to the center */
    #preview-content {
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    #preview-content img, #preview-content video { 
        max-width: 100%; 
        max-height: 55vh; 
        border-radius: 15px; 
        box-shadow: 0 25px 60px rgba(0,0,0,0.8); 
        display: block; /* Removes baseline shifting */
        margin: 0 auto;
    }
    
    .preview audio { width: 90%; filter: invert(1) brightness(1.5); margin: 25px auto; display: block; }
    .preview-info h3 { color: #c9a550; margin-top: 20px; }
    
    /* 1. Standard Mobile (Portrait) - Fixes scrolling and tightens gaps */
    @media screen and (max-width: 768px) {
        body {
            overflow: auto; /* Ensures the whole page can scroll */
        }

        .parallax {
            height: auto; /* Removes the "locked" height */
            min-height: 100vh;
        }

        .container {
            flex-direction: column; 
            height: auto; 
            min-height: 100vh;
            padding: 10px;
            gap: 15px;
        }

        .file-list { 
            height: auto; 
            width: 100%; 
            padding: 15px;
        }

        #directory-list, #file-list { 
            grid-template-columns: repeat(2, 1fr) !important; /* Two columns for better fit */
            gap: 12px !important; /* Tightens the wide gap you noticed */
            padding-right: 0;
            overflow-y: visible; /* Allows the main page to handle the scroll */
        }

        .file-item {
            height: 160px; /* Slimmer boxes for mobile */
            margin: 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
        }
        
        .preview {
            order: 1;
            min-height: 250px;
            padding: 15px;
        }
    }

    /* 2. Targets Mobile Landscape (Keeps things tight when phone is sideways) */
    @media screen and (max-height: 500px) and (orientation: landscape) {
        .container { flex-direction: column; height: auto; }
        .file-list { height: auto; width: 100%; }
        #directory-list, #file-list { 
            grid-template-columns: repeat(3, 1fr) !important;
            gap: 12px; /* Tightened gap for landscape too */
        }
        .preview { min-height: 300px; }
    }
</style>
</head>
<body>
    <div class="parallax">
        <div class="background"></div>
        <div class="container">
            <div class="file-list">
    <div class="nav-header">
    <a href="/index.html" class="home-title">Home</a>
    <div class="breadcrumb">
        <?php
        echo '<a href="#" class="main-directory-link">Main Directory</a>';
        if (!empty($relative_path)) {
            $parts = explode('/', trim($relative_path, '/'));
            $accumulated_path = '';
            foreach ($parts as $part) {
                $accumulated_path .= ($accumulated_path ? '/' : '') . $part;
                echo '<span class="nav-separator"> / </span>'; 
                echo '<a href="' . $web_base . '/' . $accumulated_path . '/">' . htmlspecialchars($part) . '</a>';
            }
        }
        ?>
    </div>
</div>
                <div class="controls">
                    <button id="play-all-btn" class="btn" style="display: none;" onclick="playAllAudio()">Play All Audio</button>
                    <button id="cycle-images-btn" class="btn" style="display: none;" onclick="cycleImages()">Start Slideshow</button>
                </div>
                <h1>Directories</h1>
                <div id="directory-list">
                    <?php if (empty($directories)): ?>
                        <p>No directories found in <?php echo htmlspecialchars($current_dir); ?></p>
                    <?php else: ?>
                        <?php foreach ($directories as $item): ?>
                            <div class="file-item directory" data-path="<?php echo htmlspecialchars($item['web_path']); ?>">
                                <div class="file-content">
                                    <div class="file-icon"><?php echo $item['icon']; ?></div>
                                </div>
                                <div class="file-name"><?php echo htmlspecialchars($item['name']); ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div id="file-list" style="display: none;">
                    <?php if (!empty($files)): ?>
                        <?php foreach ($files as $item): ?>
                            <div class="file-item" 
                                 data-path="<?php echo htmlspecialchars($item['web_path']); ?>" 
                                 data-type="<?php 
                                    $ext = $item['extension'];
                                    $isImage = in_array($ext, $image_extensions);
                                    $isVideo = in_array($ext, $video_extensions);
                                    $isAudio = in_array($ext, $audio_extensions);
                                    echo $isImage ? 'image' : ($isVideo ? 'video' : ($isAudio ? 'audio' : 'other'));
                                 ?>">
                                <div class="file-content">
                                    <?php if (in_array($ext, $image_extensions)): ?>
                                        <img src="<?php echo htmlspecialchars($item['web_path']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" loading="lazy">
                                    <?php elseif (in_array($ext, $video_extensions)): ?>
                                        <img src="/movie.png" alt="Video icon" class="file-icon">
                                    <?php elseif (in_array($ext, $audio_extensions)): ?>
                                        <img src="/music.png" alt="Audio icon" class="file-icon">
                                    <?php else: ?>
                                        <div class="file-icon">📄</div>
                                    <?php endif; ?>
                                </div>
                                <div class="file-name"><?php echo htmlspecialchars($item['name']); ?></div>
                                <div class="file-info"><?php echo $item['size']; ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="preview">
                <p>Select a directory to view files. Click to play</p>
                <div id="preview-content"></div>
            </div>
        </div>
    </div>

   <script>
    let audioPlaylist = [];
    let currentTrackIndex = -1;
    let audioElement = null;
    let imagePlaylist = [];
    let currentImageIndex = -1;
    let imageCycleInterval = null;
    let currentDirectoryPath = '<?php echo htmlspecialchars($relative_path ? $web_base . '/' . $relative_path : $web_base); ?>';
    let backgrounds = []; // Will be populated via fetch from get_backgrounds.php

    // Function to set the background
    function setBackground(index = 0) {
        if (backgrounds.length === 0) {
            console.warn('No backgrounds available, using default gradient');
            const bgDiv = document.querySelector('.background');
            bgDiv.style.backgroundImage = 'linear-gradient(135deg, #000000, #1a1a1a)';
            bgDiv.style.backgroundSize = 'cover';
            return;
        }

        const background = backgrounds[index % backgrounds.length];
        const bgDiv = document.querySelector('.background');
        const bgVideo = document.querySelector('.background-video');

        if (background.type === 'gradient') {
            if (bgVideo) {
                bgVideo.pause();
                bgVideo.style.display = 'none';
            }
            bgDiv.style.backgroundImage = 'linear-gradient(135deg, #000000, #1a1a1a)';
            bgDiv.style.backgroundSize = 'cover';
        } else if (background.type === 'video') {
            bgDiv.style.backgroundImage = 'none';
            if (!bgVideo) {
                const video = document.createElement('video');
                video.className = 'background-video';
                video.style.cssText = `
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100vw;
                    height: 100vh;
                    object-fit: cover;
                    z-index: -1;
                    filter: blur(8px) brightness(0.9);
                `;
                video.muted = true;
                video.loop = true;
                video.autoplay = true;
                document.body.appendChild(video);
            }
            const video = document.querySelector('.background-video');
            video.src = background.src;
            video.style.display = 'block';
            video.play().catch(e => console.log('Video autoplay failed:', e));
        } else if (background.type === 'image') {
            if (bgVideo) {
                bgVideo.pause();
                bgVideo.style.display = 'none';
            }
            const img = new Image();
            img.src = background.src;
            img.onload = () => {
                bgDiv.style.backgroundImage = `url('${background.src}')`;
                bgDiv.style.backgroundSize = 'cover';
            };
            img.onerror = () => {
                console.warn('Failed to load background image, using default gradient');
                bgDiv.style.backgroundImage = 'linear-gradient(135deg, #000000, #1a1a1a)';
            };
        }
    }

    // Fetch backgrounds from get_backgrounds.php
    function loadBackgrounds() {
        fetch('/get_backgrounds.php')
            .then(response => {
                if (!response.ok) throw new Error('Failed to fetch backgrounds: ' + response.statusText);
                return response.json();
            })
            .then(data => {
                if (!data.success) {
                    throw new Error('Background fetch unsuccessful');
                }
                backgrounds = data.backgrounds; // Populate backgrounds array
                const savedIndex = Math.max(0, Math.min(parseInt(localStorage.getItem('backgroundIndex')) || 0, backgrounds.length - 1));
                console.log('Backgrounds loaded:', backgrounds, 'Applying index:', savedIndex);
                setBackground(savedIndex);
            })
            .catch(error => {
                console.error('Error fetching backgrounds:', error);
                // Fallback to default gradient
                backgrounds = [{ type: 'gradient', src: 'gradient', name: 'Default Gradient' }];
                setBackground(0);
            });
    }

    // Initialize backgrounds and other functionality on page load
    window.addEventListener('load', () => {
        loadBackgrounds(); // Fetch and set backgrounds first

        document.querySelectorAll('.file-item.directory').forEach(item => {
            const path = item.getAttribute('data-path');
            item.addEventListener('click', (e) => {
                e.stopPropagation();
                console.log('Initial directory clicked:', path);
                loadFiles(path);
            });
        });

        console.log('Initial load for:', '<?php echo htmlspecialchars($relative_path ? $web_base . '/' . $relative_path : $web_base); ?>');
        loadFiles('<?php echo htmlspecialchars($relative_path ? $web_base . '/' . $relative_path : $web_base); ?>');
    });

    function updateBreadcrumbAndBackButton(path) {
    console.log('Updating breadcrumb for:', path);
    const webBase = '<?php echo $web_base; ?>';
    
    // Select ONLY the breadcrumb div, not the whole nav-header
    const breadcrumbContainer = document.querySelector('.breadcrumb');
    
    // Start with ONLY Main Directory (The "Home" button is already there in HTML)
    let html = `<a href="#" class="main-directory-link">Main Directory</a>`;
    
    const relative = path.replace(webBase, '').replace(/^\/|\/$/g, '');
    if (relative) {
        const segments = relative.split('/');
        let currentPath = webBase;
        segments.forEach(segment => {
            currentPath += '/' + segment;
            // Add the separator with the specific class for spacing
            html += `<span class="nav-separator"> / </span>`;
            html += `<a href="#" class="breadcrumb-segment" data-path="${currentPath}">${segment}</a>`;
        });
    }

    breadcrumbContainer.innerHTML = html;

    // Re-attach listeners for the dynamic links
    breadcrumbContainer.querySelectorAll('.breadcrumb-segment').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            loadFiles(link.getAttribute('data-path'));
        });
    });

    // Handle the Main Directory click specifically
    const mainDirLink = breadcrumbContainer.querySelector('.main-directory-link');
    if (mainDirLink) {
        mainDirLink.addEventListener('click', (e) => {
            e.preventDefault();
            loadFiles(webBase);
        });
    }

    const segments = path.replace(webBase, '').split('/').filter(segment => segment);
    const parentSegments = segments.slice(0, -1);
    return parentSegments.length ? `${webBase}/${parentSegments.join('/')}` : webBase;
}

    function goBack() {
        const webBase = '<?php echo $web_base; ?>';
        const segments = currentDirectoryPath.replace(webBase, '').split('/').filter(segment => segment);
        const parentSegments = segments.slice(0, -1);
        const parentPath = parentSegments.length ? `${webBase}/${parentSegments.join('/')}` : webBase;
        console.log('Going back to:', parentPath);
        loadFiles(parentPath);
        document.querySelector('#back-button-link').blur();
    }

    function loadFiles(directoryPath) {
        console.log('Loading files for:', directoryPath);
        currentDirectoryPath = directoryPath;
        history.pushState({ path: directoryPath }, '', directoryPath);
        updateBreadcrumbAndBackButton(directoryPath);
        
        if (imageCycleInterval) {
            clearInterval(imageCycleInterval);
            imageCycleInterval = null;
            document.getElementById('cycle-images-btn').textContent = 'Start Slideshow';
        }
        
        fetch('/files/get_files.php?path=' + encodeURIComponent(directoryPath))
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok: ' + response.statusText);
                return response.json();
            })
            .then(data => {
                console.log('Files received:', data);
                if (data.error) {
                    console.error('Server error:', data.error, data.debug);
                    throw new Error(data.error);
                }
                const fileList = document.getElementById('file-list');
                const directoryList = document.getElementById('directory-list');
                const playAllBtn = document.getElementById('play-all-btn');
                const cycleImagesBtn = document.getElementById('cycle-images-btn');
                const h1Title = document.querySelector('.file-list h1');
                
                directoryList.innerHTML = '';
                fileList.innerHTML = '';
                
                let hasAudioFiles = false;
                let hasImageFiles = false;
                let hasDirectories = data.directories && data.directories.length > 0;
                let hasFiles = data.files && data.files.length > 0;
                
                directoryList.style.display = 'none';
                fileList.style.display = 'none';
                
                imagePlaylist = [];
                data.files && data.files.forEach(item => {
                    const ext = item.extension.toLowerCase();
                    if (<?php echo json_encode($image_extensions); ?>.includes(ext)) {
                        imagePlaylist.push({ path: item.web_path, name: item.name });
                    }
                });
                imagePlaylist.sort((a, b) => a.name.localeCompare(b.name, undefined, {numeric: true}));
                
                if (hasDirectories) {
                    data.directories.forEach(item => {
                        const div = document.createElement('div');
                        div.className = 'file-item directory';
                        div.setAttribute('data-path', item.web_path);
                        div.innerHTML = `
                            <div class="file-content">
                                <div class="file-icon">${item.icon || '📁'}</div>
                            </div>
                            <div class="file-name">${item.name}</div>
                        `;
                        div.addEventListener('click', (e) => {
                            e.stopPropagation();
                            console.log('Clicked directory:', item.web_path);
                            loadFiles(item.web_path);
                        });
                        directoryList.appendChild(div);
                    });
                }
                
                if (hasFiles) {
                    data.files.forEach(item => {
                        const ext = item.extension.toLowerCase();
                        const isImage = <?php echo json_encode($image_extensions); ?>.includes(ext);
                        const isVideo = <?php echo json_encode($video_extensions); ?>.includes(ext);
                        const isAudio = <?php echo json_encode($audio_extensions); ?>.includes(ext);
                        const isMedia = isImage || isVideo || isAudio;
                        if (isAudio) hasAudioFiles = true;
                        if (isImage) hasImageFiles = true;

                        const div = document.createElement('div');
                        div.className = 'file-item';
                        div.setAttribute('data-path', item.web_path);
                        div.setAttribute('data-type', isImage ? 'image' : (isVideo ? 'video' : (isAudio ? 'audio' : 'other')));
                        div.addEventListener('click', (e) => {
                            e.stopPropagation();
                            console.log('Clicked file:', item.web_path, 'Type:', isMedia ? (isImage ? 'image' : (isVideo ? 'video' : 'audio')) : 'other');
                            if (isMedia) {
                                showPreview(item.web_path, isImage ? 'image' : (isVideo ? 'video' : 'audio'), item.name);
                            } else {
                                window.open(item.web_path);
                            }
                        });

                        let content = '';
                        if (isImage) {
                            content = `<img src="${item.web_path}" alt="${item.name}" loading="lazy">`;
                        } else if (isVideo) {
                            content = item.thumbnail ? 
                                `<img src="${item.thumbnail}" alt="Video thumbnail" class="file-icon">` : 
                                `<img src="/movie.png" alt="Video icon" class="file-icon">`;
                        } else if (isAudio) {
                            content = `<img src="/music.png" alt="Audio icon" class="file-icon">`;
                        } else {
                            content = `<div class="file-icon">📄</div>`;
                        }

                        div.innerHTML = `
                            <div class="file-content">${content}</div>
                            <div class="file-name">${item.name}</div>
                            <div class="file-info">${item.size}</div>
                        `;
                        fileList.appendChild(div);
                    });
                }
                
                if (hasDirectories && !hasFiles) {
                    directoryList.style.display = 'grid';
                    h1Title.textContent = 'Directory List';
                } else if (!hasDirectories && hasFiles) {
                    fileList.style.display = 'grid';
                    h1Title.textContent = 'File List';
                } else if (hasDirectories && hasFiles) {
                    data.files.forEach(item => {
                        const ext = item.extension.toLowerCase();
                        const isImage = <?php echo json_encode($image_extensions); ?>.includes(ext);
                        const isVideo = <?php echo json_encode($video_extensions); ?>.includes(ext);
                        const isAudio = <?php echo json_encode($audio_extensions); ?>.includes(ext);
                        const isMedia = isImage || isVideo || isAudio;

                        const div = document.createElement('div');
                        div.className = 'file-item';
                        div.setAttribute('data-path', item.web_path);
                        div.setAttribute('data-type', isImage ? 'image' : (isVideo ? 'video' : (isAudio ? 'audio' : 'other')));
                        div.addEventListener('click', (e) => {
                            e.stopPropagation();
                            console.log('Clicked file:', item.web_path, 'Type:', isMedia ? (isImage ? 'image' : (isVideo ? 'video' : 'audio')) : 'other');
                            if (isMedia) {
                                showPreview(item.web_path, isImage ? 'image' : (isVideo ? 'video' : 'audio'), item.name);
                            } else {
                                window.open(item.web_path);
                            }
                        });

                        let content = '';
                        if (isImage) {
                            content = `<img src="${item.web_path}" alt="${item.name}" loading="lazy">`;
                        } else if (isVideo) {
                            content = item.thumbnail ? 
                                `<img src="${item.thumbnail}" alt="Video thumbnail" class="file-icon">` : 
                                `<img src="/movie.png" alt="Video icon" class="file-icon">`;
                        } else if (isAudio) {
                            content = `<div class="file-icon">🎵</div>`;
                        } else {
                            content = `<div class="file-icon">📄</div>`;
                        }

                        div.innerHTML = `
                            <div class="file-content">${content}</div>
                            <div class="file-name">${item.name}</div>
                            <div class="file-info">${item.size}</div>
                        `;
                        directoryList.appendChild(div);
                    });
                    
                    directoryList.style.display = 'grid';
                    h1Title.textContent = 'Browse';
                } else {
                    directoryList.innerHTML = '<p>No files or directories found</p>';
                    directoryList.style.display = 'block';
                    h1Title.textContent = 'Empty';
                }

                playAllBtn.style.display = hasAudioFiles ? 'inline-block' : 'none';
                cycleImagesBtn.style.display = hasImageFiles ? 'inline-block' : 'none';
                
                document.querySelectorAll('.file-item').forEach(item => item.classList.remove('selected'));
                const previewContent = document.getElementById('preview-content');
		const isMediaPlaying = previewContent.querySelector('video, audio');

		// Only reset the text if there isn't a video/audio currently active
		if (!isMediaPlaying) {
    		previewContent.innerHTML = hasFiles ? 
        	'<p>Select a file to preview</p>' : 
        	(hasDirectories ? '<p>Select a directory to browse</p>' : '<p>Empty directory</p>');
		}
            })
            .then(() => {
                document.querySelectorAll('.file-item.directory').forEach(item => {
                    const path = item.getAttribute('data-path');
                    item.addEventListener('click', (e) => {
                        e.stopPropagation();
                        console.log('Directory clicked after fetch:', path);
                        loadFiles(path);
                    });
                });
            })
            .catch(error => {
                console.error('Error loading file list:', error);
                const directoryList = document.getElementById('directory-list');
                const fileList = document.getElementById('file-list');
                directoryList.style.display = 'none';
                fileList.innerHTML = '<p>Error loading file list</p>';
                fileList.style.display = 'block';
            });
    }

    function showPreview(file, type, filename) {
        console.log('Showing preview for:', file, 'Type:', type);
        const previewContent = document.getElementById('preview-content');
        
        if (imageCycleInterval) {
            clearInterval(imageCycleInterval);
            imageCycleInterval = null;
            document.getElementById('cycle-images-btn').textContent = 'Start Slideshow';
        }
        
        if (audioElement) {
            audioElement.pause();
            audioElement = null;
        }
        
        if (type === 'image') {
            currentImageIndex = imagePlaylist.findIndex(img => img.path === file);
            if (currentImageIndex === -1) {
                imagePlaylist = [{ path: file, name: filename }];
                currentImageIndex = 0;
            }
        } else {
            currentImageIndex = -1;
        }
        
        if (type === 'image') {
            const imageNumber = currentImageIndex + 1;
            const totalImages = imagePlaylist.length;
            previewContent.innerHTML = `
                <img src="${file}" alt="Preview">
                <div class="preview-info">
                    <h3>${filename}</h3>
                    <p>Image ${imageNumber} of ${totalImages}. Use ←/→ for prev/next, Enter for full screen</p>
                </div>
            `;
        } else if (type === 'video') {
            previewContent.innerHTML = `
                <video controls autoplay>
                    <source src="${file}" type="video/${file.split('.').pop()}">
                    Your browser does not support the video tag.
                </video>
                <div class="preview-info">
                    <h3>${filename}</h3>
                    <p>Video file. Seek using cursor keys. Vol up/down. Press 'F' for full screen</p>
                </div>
            `;
        } else if (type === 'audio') {
            previewContent.innerHTML = `
                <audio controls autoplay id="audio-player">
                    <source src="${file}" type="audio/${file.split('.').pop()}">
                    Your browser does not support the audio tag.
                </audio>
                <div class="preview-info">
                    <h3>${filename}</h3>
                    <p>Audio file. Seek using cursor keys. Vol up/down. space to pause</p>
                </div>
            `;
            audioElement = document.getElementById('audio-player');
            audioPlaylist = [file];
            currentTrackIndex = 0;
        }
        
        document.querySelectorAll('.file-item').forEach(item => item.classList.remove('selected'));
        if (event && event.currentTarget) {
            event.currentTarget.classList.add('selected');
        }
    }

    function playAllAudio() {
        const audioFiles = [];
        document.querySelectorAll('#file-list .file-item, #directory-list .file-item').forEach(item => {
            const type = item.getAttribute('data-type');
            if (type === 'audio') {
                const path = item.getAttribute('data-path');
                if (path) {
                    audioFiles.push(path);
                }
            }
        });

        if (audioFiles.length === 0) {
            alert('No audio files found in this directory');
            return;
        }

        audioFiles.sort((a, b) => {
            const nameA = a.split('/').pop();
            const nameB = b.split('/').pop();
            return nameA.localeCompare(nameB, undefined, {numeric: true});
        });

        audioPlaylist = audioFiles;
        currentTrackIndex = 0;
        playTrack(currentTrackIndex);
    }

    function cycleImages() {
        if (imageCycleInterval) {
            clearInterval(imageCycleInterval);
            imageCycleInterval = null;
            document.getElementById('cycle-images-btn').textContent = 'Start Slideshow';
            return;
        }

        const imageFiles = [];
        document.querySelectorAll('#file-list .file-item, #directory-list .file-item').forEach(item => {
            const type = item.getAttribute('data-type');
            if (type === 'image') {
                const path = item.getAttribute('data-path');
                const name = item.querySelector('.file-name').textContent;
                if (path) {
                    imageFiles.push({ path: path, name: name });
                }
            }
        });

        if (imageFiles.length === 0) {
            alert('No image files found in this directory');
            return;
        }

        imageFiles.sort((a, b) => a.name.localeCompare(b.name, undefined, {numeric: true}));

        imagePlaylist = imageFiles;
        currentImageIndex = 0;
        
        showImageSlide(currentImageIndex);
        
        document.getElementById('cycle-images-btn').textContent = 'Stop Slideshow';
        
        imageCycleInterval = setInterval(() => {
            currentImageIndex = (currentImageIndex + 1) % imagePlaylist.length;
            showImageSlide(currentImageIndex);
        }, 29500);
    }

    function showImageSlide(index) {
        if (index >= imagePlaylist.length || index < 0) return;

        const imageData = imagePlaylist[index];
        const previewContent = document.getElementById('preview-content');
        const isInFullscreen = document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement;
        
        const updateImage = (imgElement) => {
            imgElement.src = imageData.path;
            imgElement.alt = imageData.name;
            imgElement.classList.remove('fade-out');
            imgElement.classList.add('fade-in');
            setTimeout(() => {
                imgElement.classList.remove('fade-in');
            }, 800);
        };

        const updatePreviewInfo = () => {
            const info = previewContent.querySelector('.preview-info') || document.createElement('div');
            info.className = 'preview-info';
            info.innerHTML = `
                <h3>${imageData.name}</h3>
                <p>Image ${index + 1} of ${imagePlaylist.length} - Auto-cycling every 30 seconds</p>
            `;
            if (!previewContent.contains(info)) {
                previewContent.appendChild(info);
            }
        };

        if (isInFullscreen && isInFullscreen.tagName === 'IMG') {
            isInFullscreen.classList.add('fade-out');
            setTimeout(() => {
                updateImage(isInFullscreen);
                updatePreviewInfo();
            }, 400);
        } else {
            const currentImg = previewContent.querySelector('img');
            if (currentImg && imageCycleInterval) {
                currentImg.classList.add('fade-out');
                setTimeout(() => {
                    previewContent.innerHTML = `
                        <img src="${imageData.path}" alt="Preview" class="fade-in">
                        <div class="preview-info">
                            <h3>${imageData.name}</h3>
                            <p>Image ${index + 1} of ${imagePlaylist.length} - Auto-cycling every 30 seconds</p>
                        </div>
                    `;
                    const newImg = previewContent.querySelector('img');
                    setTimeout(() => {
                        if (newImg) newImg.classList.remove('fade-in');
                    }, 800);
                }, 400);
            } else {
                previewContent.innerHTML = `
                    <img src="${imageData.path}" alt="Preview">
                    <div class="preview-info">
                        <h3>${imageData.name}</h3>
                        <p>Image ${index + 1} of ${imagePlaylist.length} - Auto-cycling every 30 seconds</p>
                    </div>
                `;
            }
        }
        
        document.querySelectorAll('#file-list .file-item, #directory-list .file-item').forEach(item => {
            item.classList.remove('selected');
            if (item.getAttribute('data-path') === imageData.path) {
                item.classList.add('selected');
            }
        });
    }

    function playTrack(index) {
    if (index >= audioPlaylist.length || index < 0) {
        audioPlaylist = [];
        currentTrackIndex = -1;
        document.getElementById('preview-content').innerHTML = '<p>Finished playing all tracks</p>';
        document.querySelectorAll('.file-item').forEach(item => item.classList.remove('selected'));
        audioElement = null;
        return;
    }

    const file = audioPlaylist[index];
    const fileName = file.split('/').pop();
    const previewContent = document.getElementById('preview-content');
    
    // 1. First, create the audio element in the DOM
    previewContent.innerHTML = `
        <audio controls autoplay id="audio-player">
            <source src="${file}" type="audio/${file.split('.').pop()}">
            Your browser does not support the audio tag.
        </audio>
        <div class="preview-info">
            <h3>${fileName}</h3>
            <p>Playing track ${index + 1} of ${audioPlaylist.length}</p>
        </div>
    `;
    
    audioElement = document.getElementById('audio-player');
    
    // 2. Update the UI highlights
    document.querySelectorAll('#file-list .file-item, #directory-list .file-item').forEach(item => {
        item.classList.remove('selected');
        if (item.getAttribute('data-path') === file) {
            item.classList.add('selected');
        }
    });

    // 3. NOW set the Media Session because the 'audioElement' actually exists
    if ('mediaSession' in navigator) {
        navigator.mediaSession.metadata = new MediaMetadata({
            title: fileName,
            artist: 'My Media Server',
            album: currentDirectoryPath.split('/').pop() || 'Root',
            artwork: [
                { src: '/movie.png', sizes: '96x96', type: 'image/png' },
                { src: '/popcorn.png', sizes: '512x512', type: 'image/png' }
            ]
        });

        navigator.mediaSession.setActionHandler('play', () => audioElement.play());
        navigator.mediaSession.setActionHandler('pause', () => audioElement.pause());
        navigator.mediaSession.setActionHandler('nexttrack', () => {
            currentTrackIndex++;
            playTrack(currentTrackIndex);
        });
        navigator.mediaSession.setActionHandler('previoustrack', () => {
            currentTrackIndex = Math.max(0, currentTrackIndex - 1);
            playTrack(currentTrackIndex);
        });
    }

    // 4. Set up the event listeners for the next track
    audioElement.onended = () => {
        currentTrackIndex++;
        setTimeout(() => playTrack(currentTrackIndex), 500);
    };

    audioElement.onerror = () => {
        console.error('Error playing:', file);
        currentTrackIndex++;
        setTimeout(() => playTrack(currentTrackIndex), 500);
    };
}

    window.addEventListener('popstate', (event) => {
        const path = event.state ? event.state.path : '<?php echo $web_base; ?>';
        console.log('Popstate event, loading path:', path);
        loadFiles(path);
    });

    document.addEventListener('keydown', (e) => {
        const t = e.target;
        if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;

        const media = document.querySelector('#preview-content video, #preview-content audio');
        const image = document.querySelector('#preview-content img');

        if (image && !imageCycleInterval) {
            switch (e.code) {
                case 'ArrowRight':
                    e.preventDefault();
                    if (currentImageIndex < imagePlaylist.length - 1) {
                        currentImageIndex++;
                        showPreview(imagePlaylist[currentImageIndex].path, 'image', imagePlaylist[currentImageIndex].name);
                    }
                    break;
                case 'ArrowLeft':
                    e.preventDefault();
                    if (currentImageIndex > 0) {
                        currentImageIndex--;
                        showPreview(imagePlaylist[currentImageIndex].path, 'image', imagePlaylist[currentImageIndex].name);
                    }
                    break;
                case 'Enter':
                case 'KeyF':
                    e.preventDefault();
                    if (image.requestFullscreen) {
                        image.requestFullscreen();
                    } else if (image.webkitRequestFullscreen) {
                        image.webkitRequestFullscreen();
                    } else if (image.msRequestFullscreen) {
                        image.msRequestFullscreen();
                    }
                    break;
            }
        } else if (media) {
            // This block now handles both <video> and <audio> elements
            switch (e.code) {
                case 'KeyF':
                    e.preventDefault();
                    if (media.tagName === 'VIDEO') {
                        if (!document.fullscreenElement) {
                            if (media.requestFullscreen) media.requestFullscreen();
                            else if (media.webkitRequestFullscreen) media.webkitRequestFullscreen();
                        } else {
                            if (document.exitFullscreen) document.exitFullscreen();
                        }
                    }
                    break;
                case 'Space':
                    e.preventDefault();
                    if (media.paused) media.play(); else media.pause();
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    media.currentTime = Math.min(media.currentTime + 5, media.duration || media.currentTime);
                    break;
                case 'ArrowLeft':
                    e.preventDefault();
                    media.currentTime = Math.max(media.currentTime - 5, 0);
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    // Increases volume by 10% increments
                    media.volume = Math.min((media.volume || 0) + 0.1, 1);
                    break;
                case 'ArrowDown':
                    e.preventDefault();
                    // Decreases volume by 10% increments
                    media.volume = Math.max((media.volume || 0) - 0.1, 0);
                    break;
            }
        }
    });

    document.addEventListener('dblclick', (e) => {
        const img = e.target;
        if (img.tagName === 'IMG' && img.closest('#preview-content')) {
            if (img.requestFullscreen) {
                img.requestFullscreen();
            } else if (img.webkitRequestFullscreen) {
                img.webkitRequestFullscreen();
            } else if (img.msRequestFullscreen) {
                img.msRequestFullscreen();
            }
        }
    });

    document.addEventListener('fullscreenchange', () => {
        if (!document.fullscreenElement && imagePlaylist.length > 0 && currentImageIndex >= 0) {
            const imageData = imagePlaylist[currentImageIndex];
            const previewContent = document.getElementById('preview-content');
            previewContent.innerHTML = `
                <img src="${imageData.path}" alt="Preview">
                <div class="preview-info">
                    <h3>${imageData.name}</h3>
                    <p>Image ${currentImageIndex + 1} of ${imagePlaylist.length}. Use ←/→ for prev/next, Enter for full screen</p>
                </div>
            `;
        }
    });

    document.addEventListener('webkitfullscreenchange', () => {
        if (!document.webkitFullscreenElement && imagePlaylist.length > 0 && currentImageIndex >= 0) {
            const imageData = imagePlaylist[currentImageIndex];
            const previewContent = document.getElementById('preview-content');
            previewContent.innerHTML = `
                <img src="${imageData.path}" alt="Preview">
                <div class="preview-info">
                    <h3>${imageData.name}</h3>
                    <p>Image ${currentImageIndex + 1} of ${imagePlaylist.length}. Use ←/→ for prev/next, Enter for full screen</p>
                </div>
            `;
        }
    });
</script>
</body>
</html>
