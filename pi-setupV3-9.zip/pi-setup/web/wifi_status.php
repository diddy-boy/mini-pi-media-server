<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache');

function getWifiConnections() {
    $mode_file = '/var/www/html/current_mode.txt';
    
    // --- START OF ADDED MANUAL MODE CHECK ---
    $manual_mode = file_exists($mode_file) ? trim(file_get_contents($mode_file)) : '';

    if ($manual_mode === 'WIFI') {
        return [
            'connected_devices' => 0,
            'access_point_active' => false,
            'interface' => 'wlan0',
            'error' => null
        ];
    }
    // --- END OF ADDED MANUAL MODE CHECK ---

    $mode_status = file_exists($mode_file) ? trim(file_get_contents($mode_file)) : 'WIFI';

    $result = [
        'connected_devices' => 0,
        // If the mode file says AP, or hostapd is active, we are in AP mode
        'access_point_active' => ($mode_status === 'AP'),
        'interface' => 'wlan0',
        'error' => null
    ];

    if ($result['access_point_active']) {
        // Count connected clients using iw
        $iw_output = shell_exec("sudo iw dev wlan0 station dump 2>/dev/null | grep -c 'Station'");
        $result['connected_devices'] = intval(trim($iw_output));
    }

    return $result;
}

echo json_encode(getWifiConnections());
?>
