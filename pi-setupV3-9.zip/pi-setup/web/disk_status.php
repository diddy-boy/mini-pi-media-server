<?php
header('Content-Type: application/json');

// 1. Get disk space information
$free_space = disk_free_space("/");
$total_space = disk_total_space("/");
$free_percentage = ($total_space > 0) ? ($free_space / $total_space) * 100 : 0;

// 2. Get CPU Temperature
$temp = shell_exec("cat /sys/class/thermal/thermal_zone0/temp");
$temp_c = round($temp / 1000, 1);

// 3. Get CPU Usage (%)
// sys_getloadavg returns the average number of processes waiting for CPU.
$cpu_now = shell_exec("vmstat 1 6 | tail -1 | awk '{print 100 - $15}'");
$cpu_usage = (float)trim($cpu_now);

// 4. Helper function to count media files
function count_files($path) {
    if (!is_dir($path)) return 0;
    // Uses the Linux 'find' command to count files in the directory
    $output = shell_exec("find " . escapeshellarg($path) . " -type f | wc -l");
    return intval(trim($output));
}

// 5. Prepare the JSON response
$response = [
    'low_disk' => $free_percentage < 5,
    'free_percentage' => floor($free_percentage),
    'cpu_temp' => $temp_c,
    'cpu_usage' => $cpu_usage, 
    'counts' => [
        'Music' => count_files('/var/lib/minidlna/Music'),
        'Pictures' => count_files('/var/lib/minidlna/Pictures'),
        'Video' => count_files('/var/lib/minidlna/Video')
    ]
];

echo json_encode($response);
?>
