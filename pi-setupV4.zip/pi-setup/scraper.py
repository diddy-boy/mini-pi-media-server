import os
import requests
import PTN
import time
import random  # Added for randomized delays
import re
import argparse
from pathlib import Path
from ddgs import DDGS
from PIL import Image
from bs4 import BeautifulSoup
import io

# --- CONFIG ---
MOVIE_DIR = "/var/lib/minidlna/Video"
POSTER_DIR = "/var/lib/minidlna/.metadata/posters"
VIDEO_EXTS = ['.mp4', '.avi', '.mov', '.wmv']
THUMBNAIL_SIZE = (300, 450)

def clean_text(text):
    """Removes Wikipedia citations [1] and cleans whitespace."""
    if not text: return None
    text = re.sub(r'\[\d+\]|\[\w+\]', '', text)
    return text.strip()

def get_wikipedia_plot(title, year):
    """Specifically targets the 'Plot' section of a Wikipedia page."""
    try:
        with DDGS() as ddgs:
            query = f"site:en.wikipedia.org {title} {year if year else ''} film"
            results = ddgs.text(query, max_results=3)
            
            # --- DELAY 1: After search engine hit ---
            time.sleep(random.uniform(1.5, 3.5))
            
            if not results: return None
            
            wiki_url = None
            for r in results:
                if 'en.wikipedia.org/wiki/' in r['href']:
                    wiki_url = r['href']
                    break
            
            if not wiki_url: return None

        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(wiki_url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')

        plot_header = soup.find('span', id=lambda x: x and x.lower() in ['plot', 'synopsis', 'premise'])
        if not plot_header:
            plot_header = soup.find(['h2', 'h3'], string=re.compile(r'Plot|Synopsis|Premise', re.I))

        if plot_header:
            plot_text = []
            current_node = plot_header.parent if plot_header.name == 'span' else plot_header
            
            for sibling in current_node.find_all_next():
                if sibling.name in ['h2', 'h3']: 
                    break
                if sibling.name == 'p':
                    para = clean_text(sibling.get_text())
                    if len(para) > 30:
                        plot_text.append(para)
                if len(plot_text) >= 2:
                    break
            
            full_plot = " ".join(plot_text)
            sentences = re.split(r'(?<=[.!?]) +', full_plot)
            return " ".join(sentences[:4])
    except Exception as e:
        print(f"    Wiki Error: {e}")
    return None

def download_and_resize_image(url, save_path):
    try:
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(url, headers=headers, timeout=15)
        img = Image.open(io.BytesIO(response.content))
        if img.mode in ("RGBA", "P"):
            img = img.convert("RGB")
        img.thumbnail(THUMBNAIL_SIZE)
        img.save(save_path, "JPEG", optimize=True, quality=85)
        return True
    except Exception as e:
        print(f"    Img Error: {e}")
        return False

def run_scraper(force=False):
    print("--- Script Started ---")
    try:
        requests.get("https://8.8.8.8", timeout=3)
    except:
        print("--- No internet connection. ---")
        return
    
    Path(POSTER_DIR).mkdir(parents=True, exist_ok=True)
    count = 0

    for root, dirs, files in os.walk(MOVIE_DIR):
        if '.metadata' in root: continue
        
        for file in files:
            if any(file.lower().endswith(ext) for ext in VIDEO_EXTS):
                info = PTN.parse(file)
                title = info.get('title')
                year = info.get('year')
                
                base_name = os.path.splitext(file)[0]
                img_path = os.path.join(POSTER_DIR, f"{base_name}.jpg")
                txt_path = os.path.join(POSTER_DIR, f"{base_name}.txt")
                
                if not force and os.path.exists(img_path) and os.path.exists(txt_path):
                    continue

                print(f"Processing: {title}")
                
                # 1. Get Poster (DuckDuckGo hit)
                poster_url = None
                try:
                    with DDGS() as ddgs:
                        img_res = ddgs.images(f"{title} {year} movie poster", max_results=1)
                        if img_res: poster_url = img_res[0]['image']
                except: pass

                # --- DELAY 2: After DDG Image search (3 to 6 seconds) ---
                time.sleep(random.uniform(3.0, 6.0))

                # 2. Get Wikipedia Plot (Includes internal Delay 1)
                synopsis = get_wikipedia_plot(title, year)
                
                # --- DELAY 3: After Wikipedia access (2 to 4 seconds) ---
                time.sleep(random.uniform(2.0, 4.0))
                
                if synopsis:
                    with open(txt_path, 'w', encoding='utf-8') as f:
                        f.write(synopsis)
                    print("    ✅ Synopsis updated")

                if poster_url:
                    if download_and_resize_image(poster_url, img_path):
                        print("    ✅ Poster updated")
                        count += 1
                        # Small final buffer between movies
                        time.sleep(random.uniform(1.0, 2.0))

    print(f"--- Finished. Updated {count} items. ---")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--force', action='store_true')
    args = parser.parse_args()
    run_scraper(force=args.force)
