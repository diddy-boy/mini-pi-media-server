#!/usr/bin/env bash
#
# NOTE: This script is only intended for Raspberry PI pc's as some wifi cards will not act as an access ponint
# WiFi/AP Setup Script - only run if you have no intention of using the PI over ethernet
#
# This script will configure your Raspberry Pi as:
#   A Wi-Fi client at home
#   A password-protected Access Point when away from home
#
# Requirements: network-manager, hostapd, dnsmasq, iw, iproute2
# Main mini-pi-setup.sh will Install  network-manager hostapd dnsmasq iw iproute2 whiptail 
#
# config file gets generated at /etc/raspi-ap.conf
# generated switching script is generated from this and placed at /usr/local/bin/wifi-or-ap-onboot.sh
# Operation - if the pi starts up and does NOT find the home wifi after 50 seconds, then the wifi card turns into an access point until next reboot.
# Users can connect to the access point that the user names with this script and with a password.

#
# NOTE: This script is only intended for Raspberry PI pc's as some wifi cards will not act as an access point
# WiFi/AP Setup Script - only run if you have no intention of using the PI over ethernet

# the web server will be on ip address 192.168.50.1
#
# This script will configure your Raspberry Pi as:
#   A Wi-Fi client at home
#   A password-protected Access Point when away from home
#   Includes a temporary Captive Portal redirect in AP mode using .htaccess file.

set -euo pipefail

CONFIG_FILE="/etc/raspi-ap.conf"
LOG_FILE="/var/log/wifi-or-ap.log"
AP_IP="192.168.50.1/24"
AP_NET="192.168.50.0/24"
AP_DHCP_START="192.168.50.10"
AP_DHCP_END="192.168.50.50"
WLAN_IF="wlan0"
HTACCESS="/var/www/html/.htaccess"

# Ensure dependencies including Apache rewrite module
sudo a2enmod rewrite >/dev/null 2>&1 || true

########################
# Utility functions
########################

require_root() {
  [[ $EUID -eq 0 ]] || { echo "This script must be run as root"; exit 1; }
}

have() { command -v "$1" >/dev/null 2>&1; }

check_requirements() {
  local missing=()
  for c in nmcli hostapd dnsmasq iw ip whiptail apache2; do
    have "$c" || missing+=("$c")
  done
  if ((${#missing[@]})); then
    echo "Missing required commands: ${missing[*]}"
    exit 1
  fi
}

ensure_logfile() {
  : >"$LOG_FILE" 2>/dev/null || { echo "Check permissions on $LOG_FILE"; exit 1; }
  chmod 644 "$LOG_FILE" 2>/dev/null || true
}

log() { echo "[wifi-or-ap] $(date '+%F %T') $*" | tee -a "$LOG_FILE"; }

########################
# Config functions
########################

make_or_update_config() {
  if [[ -f "$CONFIG_FILE" ]]; then
    . "$CONFIG_FILE"
    whiptail --title "Existing Config Found" --msgbox "Updating existing $CONFIG_FILE." 10 60
  else
    COUNTRY="GB"
    HOME_SSID=""
    HOME_PASS=""
    AP_SSID="PiAP-$(hostname)"
    AP_PASS="ChangeMe1234"
  fi

  COUNTRY=$(whiptail --inputbox "Enter WiFi Country Code:" 10 60 "${COUNTRY:-GB}" 3>&1 1>&2 2>&3) || exit 1

  nmcli device wifi rescan >/dev/null 2>&1 || true
  sleep 2
  mapfile -t wifi_list < <(nmcli -t -f SSID,SIGNAL device wifi list | sort -t: -k2 -nr | grep -v "^:")

  menu_items=()
  for i in "${!wifi_list[@]}"; do
    IFS=':' read -r ssid signal <<< "${wifi_list[$i]}"
    menu_items+=("$i" "$ssid (Signal ${signal}%)")
  done

  selection=$(whiptail --title "WiFi Networks" --menu "Select your Home WiFi:" 20 70 10 "${menu_items[@]}" 3>&1 1>&2 2>&3) || true
  if [[ -n "$selection" ]]; then
    HOME_SSID=$(echo "${wifi_list[$selection]}" | cut -d: -f1)
  fi

  HOME_PASS=$(whiptail --passwordbox "Enter WiFi Password for $HOME_SSID:" 10 60 "${HOME_PASS:-}" 3>&1 1>&2 2>&3) || exit 1
  AP_SSID=$(whiptail --inputbox "Access Point SSID:" 10 60 "${AP_SSID:-PiAP-$(hostname)}" 3>&1 1>&2 2>&3) || exit 1
  AP_PASS=$(whiptail --passwordbox "Access Point Password (min 8 chars):" 10 60 "${AP_PASS:-}" 3>&1 1>&2 2>&3) || exit 1

  # Save config
  install -m 600 /dev/null "$CONFIG_FILE"
  cat >"$CONFIG_FILE" <<EOF
COUNTRY="$COUNTRY"
HOME_SSID="$HOME_SSID"
HOME_PASS="$HOME_PASS"
AP_SSID="$AP_SSID"
AP_PASS="$AP_PASS"
WLAN_IF="$WLAN_IF"
AP_IP="$AP_IP"
AP_NET="$AP_NET"
AP_DHCP_START="$AP_DHCP_START"
AP_DHCP_END="$AP_DHCP_END"
EOF
}

########################
# AP config
########################

write_ap_configs() {
  mkdir -p /etc/hostapd /etc/dnsmasq.d
  . "$CONFIG_FILE"

  cat > /etc/hostapd/hostapd.conf <<EOF
country_code=$COUNTRY
interface=$WLAN_IF
driver=nl80211
ssid=$AP_SSID
hw_mode=g
channel=3
wmm_enabled=1
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase=$AP_PASS
wpa_key_mgmt=WPA-PSK
rsn_pairwise=CCMP
ieee80211w=0
EOF

  sed -i 's|^#\?\s*DAEMON_CONF=.*|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd 2>/dev/null || true

  cat > /etc/dnsmasq.d/raspi-ap.conf <<EOF
interface=$WLAN_IF
bind-interfaces
dhcp-range=$AP_DHCP_START,$AP_DHCP_END,255.255.255.0,24h
address=/#/192.168.50.1
EOF
}

########################
# Boot script
########################

install_boot_script() {
  cat > /usr/local/bin/wifi-or-ap-onboot.sh <<'EOS'
#!/usr/bin/env bash
set -euo pipefail

CONFIG_FILE="/etc/raspi-ap.conf"
LOG_FILE="/var/log/wifi-or-ap.log"
HTACCESS="/var/www/html/.htaccess"
log(){ echo "[wifi-or-ap] $(date '+%F %T') $*" | tee -a "$LOG_FILE"; }

[[ -f "$CONFIG_FILE" ]] || { log "Missing $CONFIG_FILE"; exit 1; }
. "$CONFIG_FILE"

# Reset hardware
rmmod brcmfmac >/dev/null 2>&1 || true
modprobe brcmfmac >/dev/null 2>&1 || true
rfkill unblock wifi || true
ip link set "$WLAN_IF" down || true
ip addr flush dev "$WLAN_IF" || true
ip link set "$WLAN_IF" up || true
iw reg set "$COUNTRY" || true

systemctl stop hostapd dnsmasq 2>/dev/null || true
systemctl start NetworkManager 2>/dev/null || true
nmcli radio wifi on 2>/dev/null || true

# Try connecting to Home WiFi
for i in $(seq 1 20); do
  nmcli device wifi rescan >/dev/null 2>&1 || true
  if nmcli -t -f SSID device wifi list | grep -Fxq "$HOME_SSID"; then
    log "Home WiFi visible. Attempting connection..."
    if nmcli connection up "$HOME_SSID" >/dev/null 2>&1; then
      log "Connected to $HOME_SSID. Removing redirects."
      
      # 1. Remove the captive portal redirect file
      rm -f "$HTACCESS" || true
      
      # 2. UPDATE MODE FILE: Tells index.html/wifi_status.php we are at Home
      echo "WIFI" > "/var/www/html/current_mode.txt"
      
      MODE="Wi-Fi Mode"
      IP_ADDR=$(nmcli -t -f IP4.ADDRESS device show "$WLAN_IF" | cut -d/ -f1)
      break
    fi
  fi
  sleep 5
done

# AP Mode Fallback
if [[ -z "${IP_ADDR:-}" ]]; then
  log "Switching to AP mode"
  systemctl stop NetworkManager 2>/dev/null || true
  echo "AP" > "/var/www/html/current_mode.txt"
  ip link set "$WLAN_IF" down || true
  ip addr flush dev "$WLAN_IF" || true
  ip addr add "$AP_IP" dev "$WLAN_IF"
  ip link set "$WLAN_IF" up || true
  systemctl restart hostapd
  dnsmasq -C /etc/dnsmasq.d/raspi-ap.conf
  
  # CREATE REDIRECTS FOR AP MODE (Safe for Media Server)
  cat > "$HTACCESS" <<EOF
RewriteEngine On
RewriteBase /
# If request is for the status page or the Pi's IP, do nothing (allow it)
RewriteCond %{REQUEST_URI} ^/status.html$ [NC]
RewriteCond %{HTTP_HOST} ^192\.168\.50\.1$ [NC]
RewriteRule ^ - [L]
# Everything else gets sent to status.html
RewriteRule ^ http://192.168.50.1/status.html [R=302,L]
EOF
  chown www-data:www-data "$HTACCESS" || true

  MODE="Access Point Mode"
  IP_ADDR="192.168.50.1"
fi

# Generate Status Page
cat > "/var/www/html/status.html" <<EOF
<!DOCTYPE html><html><head><title>Pi Status</title></head>
<body style="text-align:center; font-family:sans-serif; background:#f0f0f0; padding:50px;">
<div style="background:#fff; padding:20px; border-radius:10px; display:inline-block;">
<h1>Pi Status</h1>
<p>Mode: <b>$MODE</b></p>
<p>IP: <b>$IP_ADDR</b></p>
<p><a href="http://192.168.50.1">Go to Media Server</a></p>
</div></body></html>
EOF
EOS

  chmod +x /usr/local/bin/wifi-or-ap-onboot.sh
}

########################
# Systemd & Main
########################

install_systemd_service() {
  cat > /etc/systemd/system/wifi-or-ap-onboot.service <<'EOF'
[Unit]
Description=Wifi-AP Switcher
After=NetworkManager.service
[Service]
Type=oneshot
ExecStart=/usr/local/bin/wifi-or-ap-onboot.sh
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable wifi-or-ap-onboot.service
}

main() {
  require_root
  check_requirements
  ensure_logfile
  make_or_update_config
  write_ap_configs
  install_boot_script
  install_systemd_service
  sudo systemctl restart apache2
  echo "Setup finished. Please reboot to test."
}

main "$@"
