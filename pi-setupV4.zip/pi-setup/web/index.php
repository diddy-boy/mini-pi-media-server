<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
ini_set('error_log', '/var/log/php_errors.log');

// Configuration
$base_dir = '/var/lib/minidlna';
$web_base = '/files';
// Folder where posters are stored
$poster_base = '/files/.metadata/posters'; 

// Get current directory from URL path
$request_uri = $_SERVER['REQUEST_URI'] ?? '/files/';
$path_parts = parse_url($request_uri, PHP_URL_PATH);
if (!$path_parts) {
    $path_parts = '/files/';
}
$relative_path = trim(str_replace($web_base, '', $path_parts), '/');
$current_dir = $base_dir . ($relative_path ? '/' . $relative_path : '');

// Security check
$real_base = realpath($base_dir);
$real_current = realpath($current_dir);

if (!$real_base) {
    http_response_code(500);
    die('Server configuration error: Base directory not found');
}

if (!$real_current || strpos($real_current, $real_base) !== 0) {
    $current_dir = $base_dir;
    $relative_path = '';
}

// File extensions
$image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
$video_extensions = ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm'];
$audio_extensions = ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'];
$hidden_extensions = ['php', 'env', 'srt', 'm3u', 'db'];

function get_file_extension($filename) {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

// PHP Helper to check for a poster file locally
function get_poster_url($filename, $poster_base) {
    $name_only = pathinfo($filename, PATHINFO_FILENAME);
    $local_check = $_SERVER['DOCUMENT_ROOT'] . $poster_base . '/' . $name_only . '.jpg';
    
    if (file_exists($local_check)) {
        return $poster_base . '/' . $name_only . '.jpg';
    }
    return '/movie.png'; 
}

function format_file_size($bytes) {
    if ($bytes === false) return 'Unknown';
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    elseif ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    elseif ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    else return $bytes . ' bytes';
}

function get_web_path($file_path, $base_dir, $web_base) {
    $relative = trim(str_replace($base_dir, '', $file_path), '/');
    return $web_base . ($relative ? '/' . $relative : '');
}

function get_directory_icon($dir_path, $image_extensions, $video_extensions, $audio_extensions, $hidden_extensions) {
    $items = @scandir($dir_path);
    if ($items === false) return '📁';
    $has_images = $has_videos = $has_audio = $has_other = false;
    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item[0] === '.') continue;
        $extension = get_file_extension($item);
        if (in_array($extension, $hidden_extensions)) continue;
        if (is_dir($dir_path . '/' . $item)) continue;
        if (in_array($extension, $image_extensions)) $has_images = true;
        elseif (in_array($extension, $video_extensions)) $has_videos = true;
        elseif (in_array($extension, $audio_extensions)) $has_audio = true;
        else $has_other = true;
    }
    if ($has_images && !$has_videos && !$has_audio && !$has_other) return '📷';
    if ($has_videos && !$has_images && !$has_audio && !$has_other) return '🎥';
    if ($has_audio && !$has_images && !$has_videos && !$has_other) return '🎵';
    return '📁';
}

$directories = [];
$files = [];
if (is_dir($current_dir) && is_readable($current_dir)) {
    $items = @scandir($current_dir);
    if ($items !== false) {
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || $item[0] === '.') continue;
            $item_path = $current_dir . '/' . $item;
            $extension = get_file_extension($item);
            if (in_array($extension, $hidden_extensions)) continue;
            
            if (is_dir($item_path)) {
                $directories[] = [
                    'name' => $item,
                    'web_path' => get_web_path($item_path, $base_dir, $web_base),
                    'icon' => get_directory_icon($item_path, $image_extensions, $video_extensions, $audio_extensions, $hidden_extensions)
                ];
            } else {
                $size = @filesize($item_path);
                if ($size === false) continue;
                $files[] = [
                    'name' => $item,
                    'web_path' => get_web_path($item_path, $base_dir, $web_base),
                    'size' => format_file_size($size),
                    'extension' => $extension,
                    'poster' => in_array($extension, $video_extensions) ? get_poster_url($item, $poster_base) : null
                ];
            }
        }
    }
}

usort($directories, fn($a, $b) => strcasecmp($a['name'], $b['name']));
usort($files, fn($a, $b) => strcasecmp($a['name'], $b['name']));

$page_title = 'Pi Media - ' . ($relative_path ? htmlspecialchars($relative_path) : 'Main');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini-Pi Media Browser</title>
    <link rel="icon" type="image/png" href="/popcorn.png" />
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Cinzel', serif; }
    body { background: #000; color: #f4e9cd; overflow: auto; }
    .parallax { min-height: 100vh; position: relative; display: flex; justify-content: center; animation: fadeIn 0.8s ease-out; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .background { position: fixed; top: 0; left: 0; width: 100%; height: 100%; filter: blur(2px) brightness(0.7); z-index: -1; background-size: cover; }
    .background-video { position: absolute; top: 0; left: 0; width: 100vw; height: 100vh; object-fit: cover; filter: blur(2px) brightness(0.7); }
    .container { max-width: 1800px; width: 100%; display: flex; gap: 25px; padding: 20px; margin-top: 2vh; height: 95vh; }
    .file-list, .preview { background: rgba(255, 255, 255, 0.08); backdrop-filter: blur(20px); border: 1px solid rgba(255, 255, 255, 0.15); border-radius: 18px; box-shadow: 0 8px 32px rgba(0,0,0,0.8); }
    .file-list { flex: 0 0 50%; padding: 25px; display: flex; flex-direction: column; overflow: hidden; }
    .nav-header { display: flex; align-items: center; gap: 10px; margin-bottom: 20px; }
    .home-title, .breadcrumb a, .btn { background: rgba(255, 255, 255, 0.12); border: 1px solid rgba(255, 255, 255, 0.3); color: #fff; padding: 8px 15px; text-decoration: none; border-radius: 10px; font-size: 0.9rem; }
    #directory-list, #file-list { display: grid; gap: 20px; grid-template-columns: repeat(3, 1fr); overflow-y: auto; flex-grow: 1; padding-bottom: 20px; }
    .file-item { display: flex; flex-direction: column; align-items: center; padding: 10px; background: rgba(255,255,255,0.05); border-radius: 15px; transition: 0.3s; height: 240px; text-align: center; width: 100%;
    box-sizing: border-box; overflow: hidden;}
    .file-item:hover { background: rgba(255,255,255,0.2); transform: translateY(-5px); }
    .file-icon { width: 100%; height: 120px; object-fit: contain; border-radius: 8px; margin-bottom: 8px; background: #000; }
    .file-poster {
        width: 100%;
        height: 160px; /* Area for the image */
        object-fit: contain; /* THIS IS KEY: It shows the whole image without cropping */
        background: rgba(0,0,0,0.2); /* Adds a subtle dark box behind weirdly shaped images */
        border-radius: 6px;
        margin-bottom: 10px;
    }
    .file-name { ffont-size: 0.85rem; 
        font-weight: bold; 
        color: #f4e9cd;
        word-wrap: break-word;
        overflow: hidden; 
        display: -webkit-box; 
        -webkit-line-clamp: 2; /* Shows up to 2 lines of text */
        -webkit-box-orient: vertical;
        line-height: 1.2; }
    .file-info { font-size: 0.7rem; opacity: 0.6; margin-top: 5px; }
    .preview { flex: 1; padding: 30px; display: flex; flex-direction: column; align-items: stretch; justify-content: center; }
    #preview-content img, #preview-content video { max-width: 100%; max-height: 60vh; border-radius: 15px; box-shadow: 0 20px 50px #000; }
    @media (max-width: 768px) {
        .container { flex-direction: column; height: auto; }
        #directory-list, #file-list { grid-template-columns: repeat(2, 1fr); }
    }
</style>
</head>
<body>
    <div class="parallax">
        <div class="background"></div> 
        <div class="container">
            <div class="file-list">
                <div class="nav-header">
                    <a href="/index.html" class="home-title">Home</a>
                    <div class="breadcrumb">
                        <a href="#" class="main-directory-link">Main Directory</a>
                        <?php
                        if ($relative_path) {
                            $parts = explode('/', $relative_path);
                            $acc = '';
                            foreach ($parts as $p) {
                                $acc .= ($acc ? '/' : '') . $p;
                                echo ' <span style="opacity:0.5">/</span> <a href="'.$web_base.'/'.$acc.'/">'.htmlspecialchars($p).'</a>';
                            }
                        }
                        ?>
                    </div>
                </div>
                <h1 id="list-title" style="margin-bottom:15px; font-size:1.2rem;">Browse</h1>
                <div id="directory-list">
                    <?php foreach ($directories as $d): ?>
                        <div class="file-item directory" data-path="<?php echo $d['web_path']; ?>">
                            <div style="font-size:3.5rem;"><?php echo $d['icon']; ?></div>
                            <div class="file-name"><?php echo htmlspecialchars($d['name']); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div id="file-list" style="display: none;"></div>
            </div>
            <div class="preview">
                <div id="preview-content"><p>choose a Directory or select a file to play</p></div>
            </div>
        </div>
    </div>

<script>
    let backgrounds = [];
    let currentPath = '<?php echo $web_base . ($relative_path ? '/' . $relative_path : ''); ?>';
    let audioElement = null;
    let imagePlaylist = [];
    let currentImageIndex = -1;
    let selectedIndex = -1;
    let imageCycleInterval = null; // Defined to satisfy original logic check

    // 1. Background Handling
    function setBackground(index = 0) {
    const bgDiv = document.querySelector('.background');
    if (backgrounds.length === 0) {
        bgDiv.style.background = 'linear-gradient(135deg, #000, #1a1a1a)';
        bgDiv.innerHTML = ''; // Clear any existing video
        return;
    }

    const background = backgrounds[index % backgrounds.length];
    
    // 1. Remove any existing video if we are switching backgrounds
    bgDiv.innerHTML = '';

    if (background.type === 'video') {
        // 2. Clear image background and create video element
        bgDiv.style.backgroundImage = 'none';
        
        const video = document.createElement('video');
        video.className = 'background-video';
        video.src = background.src;
        video.muted = true;
        video.loop = true;
        video.autoplay = true;
        video.playsInline = true; // Better mobile support
        
        bgDiv.appendChild(video);
        video.play().catch(e => console.log('Autoplay blocked:', e));
    } else if (background.type === 'image') {
        // 3. Set image background as usual
        bgDiv.style.backgroundImage = `url('${background.src}')`;
    }
}

    // Fetch backgrounds from get_backgrounds.php
    function loadBackgrounds() {
        fetch('/get_backgrounds.php')
            .then(response => {
                if (!response.ok) throw new Error('Failed to fetch backgrounds: ' + response.statusText);
                return response.json();
            })
            .then(data => {
                if (!data.success) {
                    throw new Error('Background fetch unsuccessful');
                }
                backgrounds = data.backgrounds; // Populate backgrounds array
                const savedIndex = Math.max(0, Math.min(parseInt(localStorage.getItem('backgroundIndex')) || 0, backgrounds.length - 1));
                console.log('Backgrounds loaded:', backgrounds, 'Applying index:', savedIndex);
                setBackground(savedIndex);
            })
            .catch(error => {
                console.error('Error fetching backgrounds:', error);
                // Fallback to default gradient
                backgrounds = [{ type: 'gradient', src: 'gradient', name: 'Default Gradient' }];
                setBackground(0);
            });
    }

    // 2. Main File & Directory Loader
    function loadFiles(path) {
        currentPath = path;
        history.pushState({path: path}, '', path);
        
        fetch('/files/get_files.php?path=' + encodeURIComponent(path))
            .then(res => res.json())
            .then(data => {
                const dirList = document.getElementById('directory-list');
                dirList.innerHTML = '';
                selectedIndex = -1; 
                imagePlaylist = []; 
                
                const allItems = [];
                if (data.directories) data.directories.forEach(d => allItems.push({...d, isDir: true}));
                if (data.files) data.files.forEach(f => allItems.push({...f, isDir: false}));

                allItems.forEach((item, index) => {
                    const div = document.createElement('div');
                    div.className = 'file-item';
                    
                    let thumbHtml;
                    let fileType = 'other';

                    if (item.isDir) {
                        fileType = 'directory';
                        thumbHtml = `<div style="font-size:3.5rem;">${item.icon || '📁'}</div>`;
                        div.onclick = () => loadFiles(item.web_path);
                    } else {
                        const ext = item.extension.toLowerCase();
                        const videoExts = <?php echo json_encode($video_extensions); ?>;
                        const audioExts = <?php echo json_encode($audio_extensions); ?>;
                        const isVideo = videoExts.includes(ext);
                        const isAudio = audioExts.includes(ext);
                        const isImage = <?php echo json_encode($image_extensions); ?>.includes(ext);

                        if (isImage) imagePlaylist.push({path: item.web_path, name: item.name});

                        if (isVideo) {
                            fileType = 'video';
                            const posterName = item.name.substring(0, item.name.lastIndexOf('.')) || item.name;
                            thumbHtml = `<img src="/files/.metadata/posters/${encodeURIComponent(posterName)}.jpg" onerror="this.onerror=null;this.src='/movie.png';" class="file-poster">`;
                        } else if (isImage) {
                            fileType = 'image';
                            thumbHtml = `<img src="${item.web_path}" class="file-poster" style="object-fit:cover;">`;
                        } else if (isAudio) {
                            fileType = 'audio';
                            thumbHtml = `<div style="font-size:3.5rem;">🎵</div>`;
                        } else {
                            thumbHtml = `<div style="font-size:3.5rem;">📄</div>`;
                        }
                        
                        div.onclick = (event) => {
                            selectedIndex = index;
                            showPreview(item.web_path, fileType, item.name, event);
                        };
                    }

                    div.innerHTML = `${thumbHtml}<div class="file-name">${item.name}</div>`;
                    dirList.appendChild(div);
                });
            }).catch(err => console.error("Error loading files:", err));
    }

    // 3. Preview Function
    function showPreview(file, type, filename, event) {
        const previewContent = document.getElementById('preview-content');
        if (audioElement) { audioElement.pause(); audioElement = null; }
        
        if (type === 'image') {
            currentImageIndex = imagePlaylist.findIndex(img => img.path === file);
            previewContent.innerHTML = `
                <img src="${file}" alt="Preview" style="max-width:100%; border-radius:15px;">
                <div class="preview-info" style="margin-top:15px; text-align:center;">
                    <h3>${filename}</h3>
                    <p>Image ${currentImageIndex + 1} of ${imagePlaylist.length}. Use ←/→ for prev/next, Enter for full screen</p>
                </div>`;
        } else if (type === 'video') {
    previewContent.innerHTML = `
        <video controls autoplay style="width:100%; border-radius:15px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
            <source src="${file}" type="video/${file.split('.').pop()}">
            Your browser does not support the video tag.
        </video>
        <div class="preview-info" style="margin-top:20px; text-align:center;">
            <h3 style="margin-bottom:10px; color: #f4e9cd;">${filename}</h3>
            <p style="opacity: 0.6; font-size: 0.9rem; line-height: 1.5; color: #f4e9cd;">
                Video file. Seek using cursor keys. Vol up/down.<br>
                Press <strong>'F'</strong> or <strong>'Enter'</strong> for full screen.
            </p>
            
           <div id="movie-synopsis" style="
    margin-top:20px; 
    padding:18px; 
    background: rgba(0, 0, 0, 0.5); 
    border-radius:12px; 
    box-shadow: 0 20px 50px #000; 
    color: #f4e9cd; 
    font-size:1.05rem; 
    line-height:1.5; 
    text-align:left;
    display: -webkit-box;
    -webkit-line-clamp: 4;
    -webkit-box-orient: vertical;  
    overflow: hidden;
    text-overflow: ellipsis;">
</div>
        </div>`;

    const nameOnly = filename.substring(0, filename.lastIndexOf('.')) || filename;
    const synopsisUrl = `/files/.metadata/posters/${encodeURIComponent(nameOnly)}.txt`;
    const synopsisBox = document.getElementById('movie-synopsis');

    fetch(synopsisUrl)
        .then(response => {
            if (!response.ok) throw new Error('No synopsis');
            return response.text();
        })
        .then(text => {
            // Remove Wikipedia citations like [1] or [6][7] before displaying
            synopsisBox.innerText = text.replace(/\[\d+\]/g, '');
            synopsisBox.style.display = 'block';
        })
        .catch(err => {
            synopsisBox.style.display = 'none';
        });
        
        } else if (type === 'audio') {
    previewContent.innerHTML = `
        <div style="width: 100%; text-align: center;">
            <div style="font-size:8rem; margin-bottom:30px; filter: drop-shadow(0 0 20px rgba(244, 233, 205, 0.4));">🎵</div>
            
            <div style="width: 100%; display: flex; justify-content: center; padding: 0 20px;">
                <audio controls autoplay id="audio-player" style="width: 100%; max-width: 800px; height: 60px;">
                    <source src="${file}" type="audio/${file.split('.').pop()}">
                    Your browser does not support the audio tag.
                </audio>
            </div>

            <div class="preview-info" style="margin-top:25px;">
                <h3 style="font-size: 1.5rem; margin-bottom: 10px;">${filename}</h3>
                <p style="opacity: 0.7; font-size: 0.9rem; line-height: 1.5;">
                    Audio file. Seek using cursor keys. Vol up/down.<br>
                    Press <strong>Space</strong> to pause/play.
                </p>
            </div>
        </div>`;
    audioElement = document.getElementById('audio-player');
}
        document.querySelectorAll('.file-item').forEach(item => item.style.border = 'none');
        if (event && event.currentTarget) { 
            event.currentTarget.style.border = '2px solid #f4e9cd'; 
        }
    }

    // 4. Integrated Keyboard Navigation & Media Controls
    document.addEventListener('keydown', (e) => {
        const t = e.target;
        if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;

        const items = document.querySelectorAll('.file-item');
        const media = document.querySelector('#preview-content video, #preview-content audio');
        const image = document.querySelector('#preview-content img');

        // NAVIGATION LOGIC
        if (['ArrowRight', 'ArrowLeft', 'ArrowUp', 'ArrowDown'].includes(e.code)) {
            // Case A: Navigating Images in Preview
            if (image && !imageCycleInterval && (e.code === 'ArrowRight' || e.code === 'ArrowLeft')) {
                e.preventDefault();
                if (e.code === 'ArrowRight' && currentImageIndex < imagePlaylist.length - 1) {
                    currentImageIndex++;
                } else if (e.code === 'ArrowLeft' && currentImageIndex > 0) {
                    currentImageIndex--;
                }
                showPreview(imagePlaylist[currentImageIndex].path, 'image', imagePlaylist[currentImageIndex].name);
            } 
            // Case B: Seek / Volume for Media
            else if (media && (e.code === 'ArrowRight' || e.code === 'ArrowLeft' || e.code === 'ArrowUp' || e.code === 'ArrowDown')) {
                e.preventDefault();
                if (e.code === 'ArrowRight') media.currentTime = Math.min(media.currentTime + 5, media.duration || media.currentTime);
                if (e.code === 'ArrowLeft') media.currentTime = Math.max(media.currentTime - 5, 0);
                if (e.code === 'ArrowUp') media.volume = Math.min((media.volume || 0) + 0.1, 1);
                if (e.code === 'ArrowDown') media.volume = Math.max((media.volume || 0) - 0.1, 0);
            }
            // Case C: Navigate File Grid
            else if (items.length > 0) {
                if (selectedIndex === -1) selectedIndex = 0;
                else if (e.code === 'ArrowRight') selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
                else if (e.code === 'ArrowLeft') selectedIndex = Math.max(selectedIndex - 1, 0);
                else if (e.code === 'ArrowUp') selectedIndex = Math.max(selectedIndex - 3, 0); 
                else if (e.code === 'ArrowDown') selectedIndex = Math.min(selectedIndex + 3, items.length - 1);

                items[selectedIndex].scrollIntoView({ behavior: 'smooth', block: 'center' });
                items[selectedIndex].click();
                e.preventDefault();
            }
        }

        // FULLSCREEN & PLAYBACK LOGIC
        if (e.code === 'Enter' || e.code === 'KeyF') {
            e.preventDefault();
            if (image) {
                if (image.requestFullscreen) image.requestFullscreen();
                else if (image.webkitRequestFullscreen) image.webkitRequestFullscreen();
            } else if (media && media.tagName === 'VIDEO') {
                if (!document.fullscreenElement) {
                    if (media.requestFullscreen) media.requestFullscreen();
                } else {
                    if (document.exitFullscreen) document.exitFullscreen();
                }
            } else if (selectedIndex !== -1) {
                items[selectedIndex].click();
            }
        }

        if (e.code === 'Space' && media) {
            e.preventDefault();
            media.paused ? media.play() : media.pause();
        }
    });

    // Fullscreen Listeners
    const handleExitFullscreen = () => {
        if (!document.fullscreenElement && !document.webkitFullscreenElement && imagePlaylist.length > 0 && currentImageIndex >= 0) {
            const imageData = imagePlaylist[currentImageIndex];
            showPreview(imageData.path, 'image', imageData.name);
        }
    };

    document.addEventListener('fullscreenchange', handleExitFullscreen);
    document.addEventListener('webkitfullscreenchange', handleExitFullscreen);
    document.addEventListener('dblclick', (e) => {
        if (e.target.tagName === 'IMG' && e.target.closest('#preview-content')) {
            if (e.target.requestFullscreen) e.target.requestFullscreen();
            else if (e.target.webkitRequestFullscreen) e.target.webkitRequestFullscreen();
        }
    });

    window.onload = () => { loadBackgrounds(); loadFiles(currentPath); };
    document.querySelector('.main-directory-link').onclick = (e) => { e.preventDefault(); loadFiles('<?php echo $web_base; ?>'); };
</script>
</body>
</html>
