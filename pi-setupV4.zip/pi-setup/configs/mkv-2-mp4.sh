#!/bin/bash
# RESTORED: Uses exact logic from mkv-2-mp4-orig.sh with clean logging and power-loss protection

SOURCE_DIR="/var/lib/minidlna/Video"
LOCK_FILE="/tmp/mkv2mp4.lock"
ENCODER_HW="h264_v4l2m2m"
ENCODER_SW="libx264"

# Original Hardware Settings from mkv-2-mp4-orig.sh
HW_BITRATE="2M"
HW_MAXRATE="3M"
HW_BUFSIZE="6M"
HW_GOP="30"
HW_KEYINT_MIN="30"

if [ -f "$LOCK_FILE" ]; then
    echo "Another MKV conversion process is already running. Exiting."
    exit 1
fi
touch "$LOCK_FILE"
cleanup() { rm -f "$LOCK_FILE"; }
trap cleanup EXIT

# Detect hardware acceleration
modprobe bcm2835-v4l2 2>/dev/null
if [ -e /dev/video10 ]; then
    HW_ACCEL_AVAILABLE=true
else
    HW_ACCEL_AVAILABLE=false
fi

# helper functions exactly as per mkv-2-mp4-orig.sh
get_video_bitrate() { ffprobe -v quiet -select_streams v:0 -show_entries stream=bit_rate -of csv=p=0 "$1" 2>/dev/null; }
get_audio_codec() { ffprobe -v quiet -select_streams a:0 -show_entries stream=codec_name -of csv=p=0 "$1" 2>/dev/null; }
get_video_codec() { ffprobe -v quiet -select_streams v:0 -show_entries stream=codec_name -of csv=p=0 "$1" 2>/dev/null; }

get_audio_settings() {
    local audio_codec="$1"
    case "$audio_codec" in
        "aac") echo "-c:a copy"; return 0 ;;
        *) echo "-c:a aac -b:a 128k"; return 1 ;;
    esac
}

get_video_settings() {
    local video_codec="$1"
    local hw_available="$2"
    case "$video_codec" in
        "h264") echo "-c:v copy"; return 0 ;;
        *)
            if [ "$hw_available" = true ]; then
                echo "-c:v $ENCODER_HW -pix_fmt yuv420p -b:v $HW_BITRATE -maxrate $HW_MAXRATE -bufsize $HW_BUFSIZE -g $HW_GOP -keyint_min $HW_KEYINT_MIN"
            else
                echo "-c:v $ENCODER_SW -preset ultrafast -tune fastdecode -threads 2 -b:v 1500k -vf scale=960:540:flags=fast_bilinear -movflags +faststart"
            fi
            return 1
            ;;
    esac
}

# Process MKV files
for input in "$SOURCE_DIR"/*.mkv; do
    [ -e "$input" ] || continue
    
    base_name=$(basename "$input" .mkv)
    output="$SOURCE_DIR/$base_name.mp4"
    # Temporary working file for power-loss protection
    working_file="$SOURCE_DIR/CONVERTING_$base_name.mp4"

    # Redundancy: Clean up any partial files from a previous interrupted run
    [ -f "$working_file" ] && rm -f "$working_file"
    
    if [ -f "$output" ] && [ -s "$output" ]; then
        echo "** Skipping: $base_name.mp4 already exists. **"
        continue
    fi
    
    echo "** Starting conversion: $base_name.mkv **"
    
    SOURCE_BITRATE=$(get_video_bitrate "$input")
    VIDEO_CODEC=$(get_video_codec "$input")
    AUDIO_CODEC=$(get_audio_codec "$input")
    
    AUDIO_SETTINGS=$(get_audio_settings "$AUDIO_CODEC" "$HW_ACCEL_AVAILABLE")
    VIDEO_SETTINGS=$(get_video_settings "$VIDEO_CODEC" "$HW_ACCEL_AVAILABLE")
    VIDEO_COPY=$?

    # Restore adaptive bitrate logic exactly
    if [ "$VIDEO_COPY" -ne 0 ] && [ "$HW_ACCEL_AVAILABLE" = true ] && [[ "$SOURCE_BITRATE" =~ ^[0-9]+$ ]]; then
        ADAPTIVE_BITRATE=$((SOURCE_BITRATE * 70 / 100))
        [ "$ADAPTIVE_BITRATE" -lt 1500000 ] && ADAPTIVE_BITRATE="1500000"
        [ "$ADAPTIVE_BITRATE" -gt 4000000 ] && ADAPTIVE_BITRATE="4000000"
        HW_BITRATE_VAL="${ADAPTIVE_BITRATE}"
        HW_MAXRATE_VAL=$((ADAPTIVE_BITRATE * 150 / 100))
        HW_BUFSIZE_VAL=$((HW_MAXRATE_VAL * 2))
        VIDEO_SETTINGS="-c:v $ENCODER_HW -pix_fmt yuv420p -b:v $HW_BITRATE_VAL -maxrate $HW_MAXRATE_VAL -bufsize $HW_BUFSIZE_VAL -g $HW_GOP -keyint_min $HW_KEYINT_MIN"
    fi

    # Create a temp log file to keep the main log clean
    TEMP_LOG=$(mktemp)

    # Convert to the CONVERTING_ file and hide the chatter in TEMP_LOG
    ffmpeg -hide_banner -y -threads 2 -i "$input" $VIDEO_SETTINGS $AUDIO_SETTINGS "$working_file" 2> "$TEMP_LOG"
    FFMPEG_STATUS=$?
    
    # Fallback logic if Hardware failed
    if [ $FFMPEG_STATUS -ne 0 ] && [ "$VIDEO_COPY" -ne 0 ] && [ "$HW_ACCEL_AVAILABLE" = true ]; then
        echo "* Hardware failed. Falling back to software... *"
        rm -f "$working_file"
        VIDEO_SETTINGS=$(get_video_settings "$VIDEO_CODEC" false)
        AUDIO_SETTINGS=$(get_audio_settings "$AUDIO_CODEC" false)
        ffmpeg -hide_banner -y -threads 2 -i "$input" $VIDEO_SETTINGS $AUDIO_SETTINGS "$working_file" 2> "$TEMP_LOG"
        FFMPEG_STATUS=$?
    fi
    
    # Finalize: Rename temp file to final .mp4 only on success
    if [ $FFMPEG_STATUS -eq 0 ] && [ -s "$working_file" ]; then
        # Extract FPS for the clean log entry
        FPS=$(grep -o 'fps=[0-9]*\.[0-9]*\|fps=[0-9]*' "$TEMP_LOG" | tail -1 | cut -d'=' -f2)
        [ -z "$FPS" ] && FPS="unknown"
        
        mv "$working_file" "$output"
        OUTPUT_SIZE=$(du -h "$output" | cut -f1)
        echo "** Successfully converted: $base_name.mp4 ($FPS fps, Size: $OUTPUT_SIZE) **"
        rm -f "$input"
    else
        echo "* Failed to convert: $base_name.mkv *"
        rm -f "$working_file"
    fi
    
    rm -f "$TEMP_LOG"
done

# Optimized permission reset - only touches the Video folder
chmod -R 775 "$SOURCE_DIR"
chown -R minidlna:minidlna "$SOURCE_DIR"
echo "*** MKV to MP4 conversion complete. ***"
