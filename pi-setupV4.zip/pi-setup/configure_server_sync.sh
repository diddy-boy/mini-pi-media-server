#!/usr/bin/env bash

# Script to configure multiple server_sync_<folder_share>.sh scripts in /usr/local/bin/
# Located in /home/pi/pi-setup, generates /usr/local/bin/server_sync_<folder_share>.sh.
# Users can setup the server location to sync from and select a destination directory to sync to.
# Users can select to manage a set up sync service as well, change or remove a setup service.
# Sets up a system timer even to run every day at a set time by the user that calls a generated script.
# user can check any set up sync timer and check its all valid.
# So any changes on the server can be synced down to the local directory set by the user for minidlna.

set -euo pipefail

# Define constants
SCRIPT_DIR="/usr/local/bin"
CREDENTIALS_DIR="/etc/samba"
LOG_FILE="/var/log/server_sync.log"
DIALOG_HEIGHT=10
DIALOG_WIDTH=60

# Function to log messages
log_message() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE" 2>/dev/null || echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >&2
}

# Function to check if dialog is installed
check_dialog() {
  if ! command -v dialog >/dev/null 2>&1; then
    echo "** Error: 'dialog' is not installed. Please install it (e.g., 'sudo apt-get install dialog'). **" >&2
    log_message "Error: 'dialog' not installed."
    exit 1
  fi
}

# Function to derive paths and names from share
derive_paths() {
  local share="$1"
  # Extract the last folder name from the share path
  local folder_name=$(basename "$share" | tr '-' '_')
  if [ -z "$folder_name" ]; then
    dialog --msgbox "** Error: Could not extract folder name from $share. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: Could not extract folder name from $share."
    return 1
  fi
  SCRIPT_PATH="$SCRIPT_DIR/server_sync_${folder_name}.sh"
  CREDENTIALS_FILE="$CREDENTIALS_DIR/credentials_${folder_name}"
  SERVICE_NAME="server-sync-${folder_name}"
  LOCK_FILE="/var/run/server_sync_${folder_name}.lock"
  MOUNT_POINT="/mnt/${folder_name}"
  FOLDER_NAME="$folder_name"
  return 0
}

# Function to create destination directory
create_destination_dir() {
  local dest_dir="$1"
  if [ ! -d "$dest_dir" ]; then
    if ! sudo mkdir -p "$dest_dir"; then
      dialog --msgbox "** Error: Failed to create $dest_dir. Check permissions or disk space. **" $DIALOG_HEIGHT $DIALOG_WIDTH
      log_message "Error: Failed to create $dest_dir."
      return 1
    fi
    sudo chown root:root "$dest_dir"
    sudo chmod 755 "$dest_dir"
    log_message "Created destination directory $dest_dir."
  fi
}

# Function to set systemd timer
set_systemd_timer() {
  local service_name="$1"
  local script_path="$2"
  local schedule="$3"

  if ! command -v systemctl >/dev/null 2>&1; then
    dialog --msgbox "** Error: systemctl not found. Ensure systemd is installed and running. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: systemctl not found."
    return 1
  fi

  if [ "$(ps -p 1 -o comm=)" != "systemd" ]; then
    dialog --msgbox "** Error: systemd is not the init system. This script requires systemd. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: systemd is not the init system."
    return 1
  fi

  sudo bash -c "cat > /etc/systemd/system/${service_name}.service << 'EOF'
[Unit]
Description=Server Sync Service for ${service_name}
After=network-online.target

[Service]
Type=oneshot
ExecStart=${script_path}
User=root
EOF"
  if [ $? -ne 0 ]; then
    dialog --msgbox "** Error: Failed to create /etc/systemd/system/${service_name}.service. Check permissions or disk space. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Failed to create ${service_name}.service."
    return 1
  fi

  sudo bash -c "cat > /etc/systemd/system/${service_name}.timer << 'EOF'
[Unit]
Description=Run Server Sync for ${service_name} at ${schedule}

[Timer]
OnCalendar=${schedule}
Persistent=true
Unit=${service_name}.service

[Install]
WantedBy=timers.target
EOF"
  if [ $? -ne 0 ]; then
    dialog --msgbox "** Error: Failed to create /etc/systemd/system/${service_name}.timer. Check permissions or disk space. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Failed to create ${service_name}.timer."
    return 1
  fi

  if ! sudo systemctl daemon-reload 2>/tmp/systemd_err; then
    error_msg=$(cat /tmp/systemd_err 2>/dev/null || echo "No error details available. Check systemd logs with 'journalctl -xe'.")
    dialog --msgbox "** Error: Failed to reload systemd. Details: $error_msg **" $DIALOG_HEIGHT $((DIALOG_WIDTH+20))
    log_message "Failed to reload systemd: $error_msg"
    rm -f /tmp/systemd_err
    return 1
  fi
  rm -f /tmp/systemd_err

  if ! sudo systemctl enable "${service_name}.timer" 2>/tmp/systemd_err; then
    error_msg=$(cat /tmp/systemd_err 2>/dev/null || echo "No error details available. Check systemd logs with 'journalctl -xe'.")
    dialog --msgbox "** Error: Failed to enable ${service_name}.timer. Details: $error_msg **" $DIALOG_HEIGHT $((DIALOG_WIDTH+20))
    log_message "Failed to enable ${service_name}.timer: $error_msg"
    rm -f /tmp/systemd_err
    return 1
  fi
  rm -f /tmp/systemd_err

  if ! sudo systemctl start "${service_name}.timer" 2>/tmp/systemd_err; then
    error_msg=$(cat /tmp/systemd_err 2>/dev/null || echo "No error details available. Check systemd logs with 'journalctl -xe'.")
    dialog --msgbox "** Error: Failed to start ${service_name}.timer. Details: $error_msg **" $DIALOG_HEIGHT $((DIALOG_WIDTH+20))
    log_message "Failed to start ${service_name}.timer: $error_msg"
    rm -f /tmp/systemd_err
    return 1
  fi
  rm -f /tmp/systemd_err

  if ! sudo systemctl is-active --quiet "${service_name}.timer"; then
    dialog --msgbox "** Error: ${service_name}.timer is not active. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "${service_name}.timer is not active."
    return 0
  fi

  dialog --msgbox "Systemd timer set to run ${script_path} daily at ${schedule#*-*-* }." $DIALOG_HEIGHT $DIALOG_WIDTH
  log_message "Systemd timer set to run ${script_path} daily at ${schedule#*-*-* }."
  return 0
}

# Function to validate Samba share
validate_mount() {
  local share="$1"
  if [[ ! "$share" =~ ^//[a-zA-Z0-9.-]+(/[a-zA-Z0-9._-]+)+$ ]]; then
    dialog --msgbox "** Error: Invalid server share format. Use: //server_IP/folder[/subfolder] (e.g., //192.168.8.50/Dave/Music). Hyphens and underscores are allowed in folder names. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Invalid Samba share format: $share"
    return 0
  fi
  if ! derive_paths "$share"; then
    return 0
  fi
  return 0
}

# Function to validate schedule time
validate_schedule() {
  local time="$1"
  if [[ ! "$time" =~ ^[0-2][0-9]:[0-5][0-9]$ ]]; then
    dialog --msgbox "** Error: Invalid time format. Use HH:MM (e.g., 03:30). **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Invalid time format: $time"
    return 1
  fi
  SCHEDULE="*-*-* $time:00"
  return 0
}

# Function to list available scripts using select with improved formatting
list_scripts() {
  local scripts=()
  local i=1
  # Check if directory is readable
  if [ ! -r "$SCRIPT_DIR" ]; then
    dialog --msgbox "** Error: Cannot read $SCRIPT_DIR. Check permissions with 'sudo chmod 755 $SCRIPT_DIR'. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: Cannot read $SCRIPT_DIR."
    return 1
  fi
  # Debug: Log the glob pattern result
  log_message "Scanning for scripts in $SCRIPT_DIR/server_sync_*.sh"
  shopt -s nullglob
  local script_list=("$SCRIPT_DIR"/server_sync_*.sh)
  if [ ${#script_list[@]} -eq 0 ]; then
    dialog --msgbox "No server sync scripts found in $SCRIPT_DIR. Please create a new sync using option 1." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "No server sync scripts found in $SCRIPT_DIR."
    shopt -u nullglob
    return 1
  fi
  for script in "${script_list[@]}"; do
    if [ -f "$script" ]; then
      folder_name=$(basename "$script" | sed 's/^server_sync_//;s/\.sh$//')
      if [ -n "$folder_name" ]; then
        scripts+=("$folder_name")
        ((i++))
      else
        log_message "Warning: Invalid script name format for $script"
      fi
    fi
  done
  shopt -u nullglob
  if [ ${#scripts[@]} -eq 0 ]; then
    dialog --msgbox "No valid server sync scripts found in $SCRIPT_DIR. Please create a new sync using option 1." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "No valid server sync scripts found in $SCRIPT_DIR."
    return 1
  fi
  log_message "Found ${#scripts[@]} scripts: ${scripts[*]}"
  # Display styled select menu
  clear
  echo "========================================"
  echo "    Select a server sync script:        "
  echo "========================================"
  for ((j=0; j<${#scripts[@]}; j++)); do
    printf "%-4s %s\n" "$((j+1)))" "${scripts[j]}"
  done
  printf "%-4s %s\n" "$((j+1)))" "Cancel"
  echo "========================================"
  echo "Enter number (1-$(( ${#scripts[@]}+1 ))): "
  select folder_name in "${scripts[@]}" "Cancel"; do
    if [ -z "$folder_name" ] || [ "$folder_name" = "Cancel" ]; then
      dialog --msgbox "Script selection cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
      log_message "Script selection cancelled by user."
      clear
      return 1
    fi
    SELECTED_FOLDER="$folder_name"
    derive_paths "//dummy/$SELECTED_FOLDER"
    log_message "Selected script for folder: $SELECTED_FOLDER"
    clear
    return 0
  done
}

# Function to create server_sync_<folder_share>.sh and credentials
create_script() {
  samba_share=$(dialog --inputbox "Enter the server share to mount (e.g., //192.168.8.10/music or //192.168.1.90/Dave/Music):" $DIALOG_HEIGHT $DIALOG_WIDTH 3>&1 1>&2 2>&3)
  if [ $? -ne 0 ]; then
    dialog --msgbox "Cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
    return 0
  fi
  if ! validate_mount "$samba_share"; then
    return 0
  fi
  if [ -f "$SCRIPT_PATH" ]; then
    dialog --msgbox "** Error: $SCRIPT_PATH already exists. Use option 2 to edit or 3 to delete. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: $SCRIPT_PATH already exists."
    return 0
  fi

  schedule_time=$(dialog --inputbox "Enter sync schedule time (HH:MM, e.g., 02:00):" $DIALOG_HEIGHT $DIALOG_WIDTH "02:00" 3>&1 1>&2 2>&3)
  if [ $? -ne 0 ]; then
    dialog --msgbox "Cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
    return 0
  fi
  if ! validate_schedule "$schedule_time"; then
    return 0
  fi

  username=$(dialog --inputbox "Enter a username for the server share:" $DIALOG_HEIGHT $DIALOG_WIDTH 3>&1 1>&2 2>&3)
  if [ $? -ne 0 ]; then
    dialog --msgbox "Cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
    return 0
  fi
  if [ -z "$username" ]; then
    dialog --msgbox "** Error: Username cannot be empty. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: Username empty."
    return 0
  fi

  password=$(dialog --passwordbox "Enter password for the server share:" $DIALOG_HEIGHT $DIALOG_WIDTH 3>&1 1>&2 2>&3)
  if [ $? -ne 0 ]; then
    dialog --msgbox "Cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
    return 0
  fi
  if [ -z "$password" ]; then
    dialog --msgbox "** Error: Password cannot be empty. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: Password empty."
    return 0
  fi

  dest_choice=$(dialog --menu "Select destination folder for rsync:" $((DIALOG_HEIGHT+5)) $DIALOG_WIDTH 2 \
    1 "/var/lib/minidlna/Video" \
    2 "/var/lib/minidlna/Music" \
    3>&1 1>&2 2>&3)
  if [ $? -ne 0 ]; then
    dialog --msgbox "Cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
    return 0
  fi
  case $dest_choice in
    1) DEST_DIR="/var/lib/minidlna/Video" ;;
    2) DEST_DIR="/var/lib/minidlna/Music" ;;
    *) dialog --msgbox "** Error: Invalid destination selection. **" $DIALOG_HEIGHT $DIALOG_WIDTH
       log_message "Error: Invalid destination selection."
       return 0 ;;
  esac

  sudo mkdir -p "$CREDENTIALS_DIR"
  if ! echo -e "username=$username\npassword=$password" | sudo tee "$CREDENTIALS_FILE" > /dev/null; then
    dialog --msgbox "** Error: Failed to create $CREDENTIALS_FILE. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Failed to create $CREDENTIALS_FILE."
    return 0
  fi
  sudo chmod 600 "$CREDENTIALS_FILE"
  log_message "Created credentials file at $CREDENTIALS_FILE."

  if ! create_destination_dir "$DEST_DIR"; then
    return 0
  fi

  samba_share_escaped=$(printf '%q' "$samba_share")
  dest_dir_escaped=$(printf '%q' "$DEST_DIR")
  mount_point_escaped=$(printf '%q' "$MOUNT_POINT")
  credentials_file_escaped=$(printf '%q' "$CREDENTIALS_FILE")
  lock_file_escaped=$(printf '%q' "$LOCK_FILE")

  sudo bash -c "cat > \"$SCRIPT_PATH\" << 'EOF'
#!/usr/bin/env bash

# Script to mount a server share and sync to a specified destination directory, preventing multiple instances

set -euo pipefail

# Define variables
DEST=\"$dest_dir_escaped/\"
MOUNT_POINT=\"$mount_point_escaped\"
SHARE_PATH=\"$samba_share_escaped\"
SHARE_TYPE=\"cifs\"
CIFS_CREDENTIALS=\"$credentials_file_escaped\"
LOCK_FILE=\"$lock_file_escaped\"
LOG_FILE=\"/var/log/server_sync.log\"

# Function to log messages
log_message() {
  echo \"\$(date '+%Y-%m-%d %H:%M:%S') - [$FOLDER_NAME] \$1\" >> \"\$LOG_FILE\" 2>/dev/null || echo \"\$(date '+%Y-%m-%d %H:%M:%S') - [$FOLDER_NAME] \$1\" >&2
}

# Function to unmount share if mounted
cleanup_mount() {
  if mount | grep -E \"(^| )\$MOUNT_POINT( |\$)\" > /dev/null; then
    sync
    sleep 1
    umount \"\$MOUNT_POINT\" 2>/dev/null && log_message \"Server share unmounted from \$MOUNT_POINT.\" || { log_message \"Error: Failed to unmount \$MOUNT_POINT.\"; echo \"** Error: Failed to unmount \$MOUNT_POINT. **\" >&2; }
  fi
}

# Ensure line-buffered output for systemd journal
stdbuf -oL bash

# Check if script is run with sudo
if [ \"\$EUID\" -ne 0 ]; then
  log_message \"Error: Script not run with sudo.\"
  echo \"** Error: Please run this script with sudo. **\" >&2
  exit 1
fi

# Check if destination directory exists
if [ ! -d \"\$DEST\" ]; then
  log_message \"Error: Destination directory \$DEST does not exist.\"
  echo \"** Error: Destination directory \$DEST does not exist. **\" >&2
  exit 1
fi

# Check for lock file to prevent multiple instances
if [ -f \"\$LOCK_FILE\" ]; then
  pid=\$(cat \"\$LOCK_FILE\")
  if ps -p \"\$pid\" > /dev/null 2>&1; then
    log_message \"Error: Another instance of the script is running (PID: \$pid).\"
    echo \"** Error: Another instance of the script is running (PID: \$pid). Exiting. **\" >&2
    exit 1
  else
    log_message \"Stale lock file found for PID \$pid. Removing it.\"
    rm -f \"\$LOCK_FILE\"
  fi
fi

# Create lock file with current PID
echo \$\$ > \"\$LOCK_FILE\"
if [ \$? -ne 0 ]; then
  log_message \"Error: Failed to create lock file \$LOCK_FILE.\"
  echo \"** Error: Failed to create lock file \$LOCK_FILE. **\" >&2
  exit 1
fi

# Ensure lock file is removed and share unmounted on script exit
trap 'rm -f \"\$LOCK_FILE\"; cleanup_mount; exit' EXIT INT TERM

# Create mount point if it doesn't exist
if [ -d \"\$MOUNT_POINT\" ]; then
  log_message \"Mount point \$MOUNT_POINT already exists.\"
else
  mkdir -p \"\$MOUNT_POINT\" || { log_message \"Error: Failed to create mount point \$MOUNT_POINT.\"; echo \"** Error: Failed to create mount point \$MOUNT_POINT. **\" >&2; exit 1; }
fi

# Check if mount point is already mounted
if mount | grep -E \"(^| )\$MOUNT_POINT( |\$)\" > /dev/null; then
  log_message \"Mount point \$MOUNT_POINT is already mounted. Proceeding without mounting.\"
else
  # Verify network connectivity to the server
  server_ip=\$(echo \"\$SHARE_PATH\" | cut -d'/' -f3)
  if [ -z \"\$server_ip\" ]; then
    log_message \"Error: Could not extract server IP from \$SHARE_PATH.\"
    echo \"** Error: Could not extract server IP from \$SHARE_PATH. **\" >&2
    exit 1
  fi
  if ! ping -c 1 \"\$server_ip\" > /dev/null 2>&1; then
    log_message \"Error: Cannot reach server \$server_ip.\"
    echo \"** Error: Cannot reach server \$server_ip. **\" >&2
    exit 1
  fi

  # Check if cifs-utils is installed
  if ! command -v mount.cifs > /dev/null 2>&1; then
    log_message \"Error: cifs-utils is not installed.\"
    echo \"** Error: cifs-utils is not installed. Install it with 'sudo apt install cifs-utils' or equivalent. **\" >&2
    exit 1
  fi

  # Check if credentials file exists
  if [ ! -f \"\$CIFS_CREDENTIALS\" ]; then
    log_message \"Error: Credentials file \$CIFS_CREDENTIALS does not exist.\"
    echo \"** Error: Credentials file \$CIFS_CREDENTIALS does not exist. **\" >&2
    exit 1
  fi

  # Mount the server share
  if [ \"\$SHARE_TYPE\" = \"cifs\" ]; then
    mount -t cifs \"\$SHARE_PATH\" \"\$MOUNT_POINT\" -o credentials=\"\$CIFS_CREDENTIALS\",uid=1000,gid=1000,vers=3.0 2>/tmp/mount_err
    if [ \$? -ne 0 ]; then
      error_msg=\$(cat /tmp/mount_err)
      log_message \"Error: Failed to mount \$SHARE_PATH to \$MOUNT_POINT: \$error_msg\"
      echo \"** Error: Failed to mount \$SHARE_PATH to \$MOUNT_POINT. Details: \$error_msg **\" >&2
      rm -f /tmp/mount_err
      exit 1
    fi
    rm -f /tmp/mount_err
    log_message \"Server share mounted at \$MOUNT_POINT.\"
    echo \"********** Server share mounted at \$MOUNT_POINT. **********\"
    echo \"****               Starting syncronisation           ****\"
  else
    log_message \"Error: Unsupported share type \$SHARE_TYPE.\"
    echo \"** Error: Unsupported share type \$SHARE_TYPE. Use 'cifs'. **\" >&2
    exit 1
  fi
fi

# Define source directory
SOURCE=\"\$MOUNT_POINT/\"

# Check if source directory exists
if [ ! -d \"\$SOURCE\" ]; then
  log_message \"Error: Source directory \$SOURCE does not exist.\"
  echo \"** Error: Source directory \$SOURCE does not exist. **\" >&2
  cleanup_mount
  exit 1
fi

# Perform rsync: sync only relevant directory based on destination, skip identical files
log_message \"Syncing from \$SOURCE to \$DEST.\"
echo \"**** Syncing from \$SOURCE to \$DEST... ****\"
stdbuf -oL rsync -rtv --update --exclude='*.mkv' --no-links \"\$SOURCE/\" \"\$DEST\" 2>/tmp/rsync_err | grep -vE '^(sending|total size|delta-transmission|[/])\$' | stdbuf -oL sed 's/^/Synced: /'
rsync_exit=\$?

# Check rsync exit status
if [ \$rsync_exit -ne 0 ]; then
  error_msg=\$(cat /tmp/rsync_err 2>/dev/null || echo \"No error details available.\")
  log_message \"Error: Sync failed: \$error_msg\"
  echo \"** Error: Sync failed: \$error_msg **\" >&2
  rm -f /tmp/rsync_err
  cleanup_mount
  exit 1
fi
rm -f /tmp/rsync_err
log_message \"syncronisation from server completed successfully.\"
echo \"********** syncronisation from server completed successfully. **********\"

# Unmount the server share
cleanup_mount

#set permission back
chmod -R 775 /var/lib/minidlna
chgrp minidlna -R /var/lib/minidlna

# Rescan minidlna
if command -v minidlnad >/dev/null 2>&1; then
  minidlnad -R && log_message \"minidlna database rescanned.\" || log_message \"Warning: minidlna rescan failed.\"
else
  log_message \"Warning: minidlnad not installed, skipping rescan.\"
fi

exit 0
EOF"
  if ! sudo chmod +x "$SCRIPT_PATH"; then
    dialog --msgbox "** Error: Failed to set executable permissions on $SCRIPT_PATH. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Failed to set executable permissions on $SCRIPT_PATH."
    return 0
  fi

  dialog --msgbox "Created $SCRIPT_PATH successfully with destination: $DEST_DIR and mount point: $MOUNT_POINT." $DIALOG_HEIGHT $DIALOG_WIDTH
  log_message "Created $SCRIPT_PATH with server share $samba_share, mount point $MOUNT_POINT, and destination $DEST_DIR."
  set_systemd_timer "$SERVICE_NAME" "$SCRIPT_PATH" "$SCHEDULE"
  return $?
}

# Function to edit server_sync_<folder_share>.sh and credentials
edit_script() {
  if ! list_scripts; then
    dialog --msgbox "No scripts available to edit." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "No scripts available to edit."
    return 0
  fi

  current_share=$(grep "^SHARE_PATH=" "$SCRIPT_PATH" | cut -d'=' -f2 | sed 's/^"//;s/"$//')
  current_mount_point=$(grep "^MOUNT_POINT=" "$SCRIPT_PATH" | cut -d'=' -f2 | sed 's/^"//;s/"$//')
  current_dest=$(grep "^DEST=" "$SCRIPT_PATH" | cut -d'=' -f2 | sed 's/^"//;s/"$//')
  current_username=$(grep "^username=" "$CREDENTIALS_FILE" | cut -d'=' -f2)
  current_schedule=$(grep "^OnCalendar=" "/etc/systemd/system/${SERVICE_NAME}.timer" | cut -d'=' -f2 | sed 's/.* \([0-9][0-9]:[0-9][0-9]\):00/\1/' 2>/dev/null || echo "02:00")

  samba_share=$(dialog --inputbox "Enter the server share to mount (current: $current_share, press OK to keep):" $DIALOG_HEIGHT $DIALOG_WIDTH "$current_share" 3>&1 1>&2 2>&3)
  if [ $? -ne 0 ]; then
    dialog --msgbox "Cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
    return 0
  fi
  samba_share=${samba_share:-$current_share}
  if ! validate_mount "$samba_share"; then
    return 0
  fi

  schedule_time=$(dialog --inputbox "Enter sync schedule time (HH:MM, e.g., 02:00, current: $current_schedule):" $DIALOG_HEIGHT $DIALOG_WIDTH "$current_schedule" 3>&1 1>&2 2>&3)
  if [ $? -ne 0 ]; then
    dialog --msgbox "Cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
    return 0
  fi
  if ! validate_schedule "$schedule_time"; then
    return 0
  fi

  username=$(dialog --inputbox "Enter username for the server share (current: $current_username, press OK to keep):" $DIALOG_HEIGHT $DIALOG_WIDTH "$current_username" 3>&1 1>&2 2>&3)
  if [ $? -ne 0 ]; then
    dialog --msgbox "Cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
    return 0
  fi
  username=${username:-$current_username}
  if [ -z "$username" ]; then
    dialog --msgbox "** Error: Username cannot be empty. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: Username empty."
    return 0
  fi

  password=$(dialog --passwordbox "Enter password for the server share (press OK to keep current):" $DIALOG_HEIGHT $DIALOG_WIDTH 3>&1 1>&2 2>&3)
  if [ $? -ne 0 ]; then
    dialog --msgbox "Cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
    return 0
  fi

  dest_choice=$(dialog --menu "Select destination folder for rsync (current: ${current_dest%/*}):" $((DIALOG_HEIGHT+5)) $DIALOG_WIDTH 2 \
    1 "/var/lib/minidlna/Video" \
    2 "/var/lib/minidlna/Music" \
    3>&1 1>&2 2>&3)
  if [ $? -ne 0 ]; then
    dialog --msgbox "Cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
    return 0
  fi
  case $dest_choice in
    1) DEST_DIR="/var/lib/minidlna/Video" ;;
    2) DEST_DIR="/var/lib/minidlna/Music" ;;
    *) dialog --msgbox "** Error: Invalid destination selection. **" $DIALOG_HEIGHT $DIALOG_WIDTH
       log_message "Error: Invalid destination selection."
       return 0 ;;
  esac

  if [ -n "$password" ]; then
    if ! echo -e "username=$username\npassword=$password" | sudo tee "$CREDENTIALS_FILE" > /dev/null; then
      dialog --msgbox "** Error: Failed to update $CREDENTIALS_FILE. **" $DIALOG_HEIGHT $DIALOG_WIDTH
      log_message "Failed to update $CREDENTIALS_FILE."
      return 0
    fi
    log_message "Updated password in $CREDENTIALS_FILE."
  else
    if ! sudo sed -i "s/^username=.*/username=$username/" "$CREDENTIALS_FILE"; then
      dialog --msgbox "** Error: Failed to update username in $CREDENTIALS_FILE. **" $DIALOG_HEIGHT $DIALOG_WIDTH
      log_message "Failed to update username in $CREDENTIALS_FILE."
      return 0
    fi
    log_message "Updated username in $CREDENTIALS_FILE."
  fi
  sudo chmod 600 "$CREDENTIALS_FILE"

  if ! create_destination_dir "$DEST_DIR"; then
    return 0
  fi

  samba_share_escaped=$(printf '%q' "$samba_share")
  dest_dir_escaped=$(printf '%q' "$DEST_DIR")
  mount_point_escaped=$(printf '%q' "$MOUNT_POINT")
  credentials_file_escaped=$(printf '%q' "$CREDENTIALS_FILE")
  lock_file_escaped=$(printf '%q' "$LOCK_FILE")

  sudo bash -c "cat > \"$SCRIPT_PATH\" << 'EOF'
#!/usr/bin/env bash

# Script to mount a server share and sync to a specified destination directory, preventing multiple instances

set -euo pipefail

# Define variables
DEST=\"$dest_dir_escaped/\"
MOUNT_POINT=\"$mount_point_escaped\"
SHARE_PATH=\"$samba_share_escaped\"
SHARE_TYPE=\"cifs\"
CIFS_CREDENTIALS=\"$credentials_file_escaped\"
LOCK_FILE=\"$lock_file_escaped\"
LOG_FILE=\"/var/log/server_sync.log\"

# Function to log messages
log_message() {
  echo \"\$(date '+%Y-%m-%d %H:%M:%S') - [$FOLDER_NAME] \$1\" >> \"\$LOG_FILE\" 2>/dev/null || echo \"\$(date '+%Y-%m-%d %H:%M:%S') - [$FOLDER_NAME] \$1\" >&2
}

# Function to unmount share if mounted
cleanup_mount() {
  if mount | grep -E \"(^| )\$MOUNT_POINT( |\$)\" > /dev/null; then
    sync
    sleep 1
    umount \"\$MOUNT_POINT\" 2>/dev/null && log_message \"Server share unmounted from \$MOUNT_POINT.\" || { log_message \"Error: Failed to unmount \$MOUNT_POINT.\"; echo \"** Error: Failed to unmount \$MOUNT_POINT. **\" >&2; }
  fi
}

# Ensure line-buffered output for systemd journal
stdbuf -oL bash

# Check if script is run with sudo
if [ \"\$EUID\" -ne 0 ]; then
  log_message \"Error: Script not run with sudo.\"
  echo \"** Error: Please run this script with sudo. **\" >&2
  exit 1
fi

# Check if destination directory exists
if [ ! -d \"\$DEST\" ]; then
  log_message \"Error: Destination directory \$DEST does not exist.\"
  echo \"** Error: Destination directory \$DEST does not exist. **\" >&2
  exit 1
fi

# Check for lock file to prevent multiple instances
if [ -f \"\$LOCK_FILE\" ]; then
  pid=\$(cat \"\$LOCK_FILE\")
  if ps -p \"\$pid\" > /dev/null 2>&1; then
    log_message \"Error: Another instance of the script is running (PID: \$pid).\"
    echo \"** Error: Another instance of the script is running (PID: \$pid). Exiting. **\" >&2
    exit 1
  else
    log_message \"Stale lock file found for PID \$pid. Removing it.\"
    rm -f \"\$LOCK_FILE\"
  fi
fi

# Create lock file with current PID
echo \$\$ > \"\$LOCK_FILE\"
if [ \$? -ne 0 ]; then
  log_message \"Error: Failed to create lock file \$LOCK_FILE.\"
  echo \"** Error: Failed to create lock file \$LOCK_FILE. **\" >&2
  exit 1
fi

# Ensure lock file is removed and share unmounted on script exit
trap 'rm -f \"\$LOCK_FILE\"; cleanup_mount; exit' EXIT INT TERM

# Create mount point if it doesn't exist
if [ -d \"\$MOUNT_POINT\" ]; then
  log_message \"Mount point \$MOUNT_POINT already exists.\"
else
  mkdir -p \"\$MOUNT_POINT\" || { log_message \"Error: Failed to create mount point \$MOUNT_POINT.\"; echo \"** Error: Failed to create mount point \$MOUNT_POINT. **\" >&2; exit 1; }
fi

# Check if mount point is already mounted
if mount | grep -E \"(^| )\$MOUNT_POINT( |\$)\" > /dev/null; then
  log_message \"Mount point \$MOUNT_POINT is already mounted. Proceeding without mounting.\"
else
  # Verify network connectivity to the server
  server_ip=\$(echo \"\$SHARE_PATH\" | cut -d'/' -f3)
  if [ -z \"\$server_ip\" ]; then
    log_message \"Error: Could not extract server IP from \$SHARE_PATH.\"
    echo \"** Error: Could not extract server IP from \$SHARE_PATH. **\" >&2
    exit 1
  fi
  if ! ping -c 1 \"\$server_ip\" > /dev/null 2>&1; then
    log_message \"Error: Cannot reach server \$server_ip.\"
    echo \"** Error: Cannot reach server \$server_ip. **\" >&2
    exit 1
  fi

  # Check if cifs-utils is installed
  if ! command -v mount.cifs > /dev/null 2>&1; then
    log_message \"Error: cifs-utils is not installed.\"
    echo \"** Error: cifs-utils is not installed. Install it with 'sudo apt install cifs-utils' or equivalent. **\" >&2
    exit 1
  fi

  # Check if credentials file exists
  if [ ! -f \"\$CIFS_CREDENTIALS\" ]; then
    log_message \"Error: Credentials file \$CIFS_CREDENTIALS does not exist.\"
    echo \"** Error: Credentials file \$CIFS_CREDENTIALS does not exist. **\" >&2
    exit 1
  fi

  # Mount the server share
  if [ \"\$SHARE_TYPE\" = \"cifs\" ]; then
    mount -t cifs \"\$SHARE_PATH\" \"\$MOUNT_POINT\" -o credentials=\"\$CIFS_CREDENTIALS\",uid=1000,gid=1000,vers=3.0 2>/tmp/mount_err
    if [ \$? -ne 0 ]; then
      error_msg=\$(cat /tmp/mount_err)
      log_message \"Error: Failed to mount \$SHARE_PATH to \$MOUNT_POINT: \$error_msg\"
      echo \"** Error: Failed to mount \$SHARE_PATH to \$MOUNT_POINT. Details: \$error_msg **\" >&2
      rm -f /tmp/mount_err
      exit 1
    fi
    rm -f /tmp/mount_err
    log_message \"Server share mounted at \$MOUNT_POINT.\"
    echo \"********** Server share mounted at \$MOUNT_POINT. **********\"
    echo \"****               Starting syncronisation           ****\"
  else
    log_message \"Error: Unsupported share type \$SHARE_TYPE.\"
    echo \"** Error: Unsupported share type \$SHARE_TYPE. Use 'cifs'. **\" >&2
    exit 1
  fi
fi

# Define source directory
SOURCE=\"\$MOUNT_POINT/\"

# Check if source directory exists
if [ ! -d \"\$SOURCE\" ]; then
  log_message \"Error: Source directory \$SOURCE does not exist.\"
  echo \"** Error: Source directory \$SOURCE does not exist. **\" >&2
  cleanup_mount
  exit 1
fi

# Perform rsync: sync only relevant directory based on destination, skip identical files
log_message \"Syncing from \$SOURCE to \$DEST.\"
echo \"**** Syncing from \$SOURCE to \$DEST... ****\"
stdbuf -oL rsync -rtv --update--exclude='*.mkv' --no-links \"\$SOURCE/\" \"\$DEST\" 2>/tmp/rsync_err | grep -vE '^(sending|total size|delta-transmission|[/])\$' | stdbuf -oL sed 's/^/Synced: /'
rsync_exit=\$?

# Check rsync exit status
if [ \$rsync_exit -ne 0 ]; then
  error_msg=\$(cat /tmp/rsync_err 2>/dev/null || echo \"No error details available.\")
  log_message \"Error: Sync failed: \$error_msg\"
  echo \"** Error: Sync failed: \$error_msg **\" >&2
  rm -f /tmp/rsync_err
  cleanup_mount
  exit 1
fi
rm -f /tmp/rsync_err
log_message \"syncronisation from server completed successfully.\"
echo \"********** syncronisation from server completed successfully. **********\"

# Unmount the server share
cleanup_mount

chmod -R 775 /var/lib/minidlna
    chown -R minidlna:minidlna /var/lib/minidlna
# Rescan minidlna
if command -v minidlnad >/dev/null 2>&1; then
  minidlnad -R && log_message \"minidlna database rescanned.\" || log_message \"Warning: minidlna rescan failed.\"
else
  log_message \"Warning: minidlnad not installed, skipping rescan.\"
fi

exit 0
EOF"
  if ! sudo chmod +x "$SCRIPT_PATH"; then
    dialog --msgbox "** Error: Failed to set executable permissions on $SCRIPT_PATH. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Failed to set executable permissions on $SCRIPT_PATH."
    return 0
  fi

  dialog --msgbox "Updated $SCRIPT_PATH and $CREDENTIALS_FILE successfully with mount point: $MOUNT_POINT and destination: $DEST_DIR." $DIALOG_HEIGHT $DIALOG_WIDTH
  log_message "Updated $SCRIPT_PATH with server share $samba_share, mount point $MOUNT_POINT, and destination $DEST_DIR."
  set_systemd_timer "$SERVICE_NAME" "$SCRIPT_PATH" "$SCHEDULE"
  return $?
}

# Function to delete server_sync_<folder_share>.sh, credentials, and systemd timer
delete_script() {
  if ! list_scripts; then
    dialog --msgbox "No scripts available to delete." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "No scripts available to delete."
    return 0
  fi

  dialog --defaultno --yesno "Are you sure you want to delete $SCRIPT_PATH, $CREDENTIALS_FILE, and associated systemd timer?" $DIALOG_HEIGHT $DIALOG_WIDTH
  if [ $? -ne 0 ]; then
    dialog --msgbox "Deletion cancelled. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Deletion cancelled by user for $SCRIPT_PATH."
    return 0
  fi

  if [ -f "/etc/systemd/system/${SERVICE_NAME}.timer" ]; then
    sudo systemctl stop "${SERVICE_NAME}.timer" 2>/dev/null
    sudo systemctl disable "${SERVICE_NAME}.timer" 2>/dev/null
    sudo rm -f "/etc/systemd/system/${SERVICE_NAME}.timer"
    if [ $? -eq 0 ]; then
      log_message "Removed ${SERVICE_NAME}.timer."
      dialog --msgbox "Removed ${SERVICE_NAME}.timer." $DIALOG_HEIGHT $DIALOG_WIDTH
    else
      dialog --msgbox "** Error: Failed to remove ${SERVICE_NAME}.timer. **" $DIALOG_HEIGHT $DIALOG_WIDTH
      log_message "Failed to remove ${SERVICE_NAME}.timer."
      return 0
    fi
  else
    dialog --msgbox "${SERVICE_NAME}.timer does not exist." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "${SERVICE_NAME}.timer does not exist."
  fi

  if [ -f "/etc/systemd/system/${SERVICE_NAME}.service" ]; then
    sudo rm -f "/etc/systemd/system/${SERVICE_NAME}.service"
    if [ $? -eq 0 ]; then
      log_message "Removed ${SERVICE_NAME}.service."
      dialog --msgbox "Removed ${SERVICE_NAME}.service." $DIALOG_HEIGHT $DIALOG_WIDTH
    else
      dialog --msgbox "** Error: Failed to remove ${SERVICE_NAME}.service. **" $DIALOG_HEIGHT $DIALOG_WIDTH
      log_message "Failed to remove ${SERVICE_NAME}.service."
      return 0
    fi
  else
    dialog --msgbox "${SERVICE_NAME}.service does not exist." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "${SERVICE_NAME}.service does not exist."
  fi

  sudo systemctl daemon-reload 2>/dev/null
  sudo systemctl reset-failed 2>/dev/null

  if [ -f "$SCRIPT_PATH" ]; then
    if ! sudo rm -f "$SCRIPT_PATH"; then
      dialog --msgbox "** Error: Failed to delete $SCRIPT_PATH. **" $DIALOG_HEIGHT $DIALOG_WIDTH
      log_message "Failed to delete $SCRIPT_PATH."
      return 0
    fi
    dialog --msgbox "Deleted $SCRIPT_PATH." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Deleted $SCRIPT_PATH."
  else
    dialog --msgbox "$SCRIPT_PATH does not exist." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "$SCRIPT_PATH does not exist."
  fi

  if [ -f "$CREDENTIALS_FILE" ]; then
    if ! sudo rm -f "$CREDENTIALS_FILE"; then
      dialog --msgbox "** Error: Failed to delete $CREDENTIALS_FILE. **" $DIALOG_HEIGHT $DIALOG_WIDTH
      log_message "Failed to delete $CREDENTIALS_FILE."
      return 0
    fi
    dialog --msgbox "Deleted $CREDENTIALS_FILE." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Deleted $CREDENTIALS_FILE."
  else
    dialog --msgbox "$CREDENTIALS_FILE does not exist." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "$CREDENTIALS_FILE does not exist."
  fi

  dialog --msgbox "Deletion completed for $SELECTED_FOLDER. Returning to main menu." $DIALOG_HEIGHT $DIALOG_WIDTH
  log_message "Deletion completed for $SELECTED_FOLDER."
  return 0
}

# Function to test server_sync_<folder_share>.sh
test_script() {
  if ! list_scripts; then
    dialog --msgbox "No scripts available to test." $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "No scripts available to test."
    return 0
  fi

  if [ ! -f "$SCRIPT_PATH" ]; then
    dialog --msgbox "** Error: $SCRIPT_PATH does not exist. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: $SCRIPT_PATH does not exist."
    return 0
  fi

  if [ ! -f "$CREDENTIALS_FILE" ]; then
    dialog --msgbox "** Error: $CREDENTIALS_FILE does not exist. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: $CREDENTIALS_FILE does not exist."
    return 0
  fi

  samba_share=$(grep "^SHARE_PATH=" "$SCRIPT_PATH" | cut -d'=' -f2 | sed 's/^"//;s/"$//')
  if [ -z "$samba_share" ]; then
    dialog --msgbox "** Error: Could not read Samba share from $SCRIPT_PATH. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: Could not read Samba share from $SCRIPT_PATH."
    return 0
  fi

  mount_point=$(grep "^MOUNT_POINT=" "$SCRIPT_PATH" | cut -d'=' -f2 | sed 's/^"//;s/"$//')
  if [ -z "$mount_point" ]; then
    dialog --msgbox "** Error: Could not read mount point from $SCRIPT_PATH. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: Could not read mount point from $SCRIPT_PATH."
    return 0
  fi

  dest_dir=$(grep "^DEST=" "$SCRIPT_PATH" | cut -d'=' -f2 | sed 's/^"//;s/"$//')
  if [ -z "$dest_dir" ]; then
    dialog --msgbox "** Error: Could not read destination directory from $SCRIPT_PATH. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: Could not read destination directory from $SCRIPT_PATH."
    return 0
  fi

  timer_status=""
  if [ -f "/etc/systemd/system/${SERVICE_NAME}.timer" ]; then
    on_calendar=$(grep "^OnCalendar=" "/etc/systemd/system/${SERVICE_NAME}.timer" | cut -d'=' -f2 | xargs)
    timer_status="Systemd timer: Set to run at '$on_calendar'\n"
    if sudo systemctl is-enabled --quiet "${SERVICE_NAME}.timer"; then
      timer_status="$timer_status Timer status: Enabled\n"
    else
      timer_status="$timer_status Timer status: Disabled\n"
      log_message "Warning: ${SERVICE_NAME}.timer is disabled."
    fi
    if sudo systemctl is-active --quiet "${SERVICE_NAME}.timer"; then
      timer_status="$timer_status Timer Scheduled sync state: Active\n"
    else
      timer_status="$timer_status Timer Scheduled sync state: Inactive\n"
      log_message "Warning: ${SERVICE_NAME}.timer is inactive."
    fi
  else
    timer_status="Scheduled sync Systemd timer: Not found\n"
    log_message "Error: ${SERVICE_NAME}.timer does not exist."
  fi

  if ! command -v mount.cifs >/dev/null 2>&1; then
    dialog --msgbox "** Error: cifs-utils is not installed. Install it with 'sudo apt install cifs-utils' or equivalent. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: cifs-utils not installed."
    return 0
  fi

  if [ ! -d "$mount_point" ]; then
    if ! sudo mkdir -p "$mount_point"; then
      dialog --msgbox "** Error: Failed to create mount point $mount_point. **" $DIALOG_HEIGHT $DIALOG_WIDTH
      log_message "Failed to create mount point $mount_point."
      return 0
    fi
  fi

  if mount | grep -E "(^| )$mount_point( |\$)" >/dev/null; then
    if ! sudo umount "$mount_point" 2>/tmp/umount_err; then
      error_msg=$(cat /tmp/umount_err 2>/dev/null || echo "No error details available.")
      dialog --msgbox "** Error: Failed to unmount $mount_point. Details: $error_msg. Please unmount manually. **" $DIALOG_HEIGHT $((DIALOG_WIDTH+20))
      log_message "Failed to unmount $mount_point: $error_msg"
      rm -f /tmp/umount_err
      return 0
    fi
    rm -f /tmp/umount_err
    log_message "Successfully unmounted $mount_point for testing."
  fi

  server_ip=$(echo "$samba_share" | cut -d'/' -f3)
  if [ -z "$server_ip" ]; then
    dialog --msgbox "** Error: Could not extract server IP from $samba_share. **" $DIALOG_HEIGHT $DIALOG_WIDTH
    log_message "Error: Could not extract server IP from $samba_share."
    return 0
  fi
  if ! ping -c 1 "$server_ip" >/dev/null 2>&1; then
    if ! nc -z -w 5 "$server_ip" 445 >/dev/null 2>&1; then
      dialog --msgbox "** Error: Cannot reach server $server_ip (ping and port 445 unreachable). **" $DIALOG_HEIGHT $DIALOG_WIDTH
      log_message "Error: Cannot reach server $server_ip (ping and port 445 unreachable)."
      return 0
    else
      log_message "Warning: Ping to $server_ip failed, but port 445 is reachable."
    fi
  fi

  if ! sudo mount -t cifs "$samba_share" "$mount_point" -o credentials="$CREDENTIALS_FILE",uid=1000,gid=1000,vers=3.0 2>/tmp/mount_err; then
    error_msg=$(cat /tmp/mount_err)
    dialog --msgbox "** Error: Failed to mount $samba_share to $mount_point. Details: $error_msg **" $DIALOG_HEIGHT $((DIALOG_WIDTH+20))
    log_message "Failed to mount $samba_share to $mount_point: $error_msg"
    rm -f /tmp/mount_err
    return 0
  fi
  rm -f /tmp/mount_err
  log_message "Successfully mounted $samba_share to $mount_point for testing."

  folder_status="\nSamba share $samba_share: Mounted successfully"
  if [ -d "$mount_point" ]; then
    folder_status="$folder_status\nMount point $mount_point: Exists"
  else
    folder_status="$folder_status\nMount point $mount_point: Not found"
  fi
  folder_status="$folder_status\nDestination directory: ${dest_dir%/*}"

  if mount | grep -E "(^| )$mount_point( |\$)" >/dev/null; then
    if ! sudo umount "$mount_point" 2>/tmp/umount_err; then
      error_msg=$(cat /tmp/umount_err 2>/dev/null || echo "No error details available.")
      dialog --msgbox "** Error: Failed to unmount $mount_point after test. Details: $error_msg. Please unmount manually. **" $DIALOG_HEIGHT $((DIALOG_WIDTH+20))
      log_message "Failed to unmount $mount_point after test: $error_msg"
      rm -f /tmp/umount_err
      return 0
    fi
    rm -f /tmp/umount_err
    log_message "Successfully unmounted $mount_point after test."
  fi

  dialog --msgbox "Test completed successfully for $SELECTED_FOLDER.\nMounted $samba_share to $mount_point.\n$folder_status\n$timer_status" $((DIALOG_HEIGHT+10)) $((DIALOG_WIDTH+20))
  log_message "Test successful for $SELECTED_FOLDER. Folder status: $folder_status Timer status: $timer_status"
  return 0
}

# Main menu using dialog
check_dialog
while true; do
  choice=$(dialog --default-item 1 --menu "Server Sync Configuration Tool" $((DIALOG_HEIGHT+6)) $DIALOG_WIDTH 6 \
    1 "Create a new server syncronisation" \
    2 "Edit an existing server syncronisation" \
    3 "Delete a server syncronisation" \
    4 "Test a server syncronisation setup" \
    5 "List available server sync scripts" \
    6 "Exit" \
    3>&1 1>&2 2>&3)
  if [ $? -ne 0 ]; then
    dialog --msgbox "Exiting..." $DIALOG_HEIGHT $DIALOG_WIDTH
    clear
    exit 0
  fi

  case $choice in
    1)
      create_script
      ;;
    2)
      edit_script
      ;;
    3)
      delete_script
      ;;
    4)
      test_script
      ;;
    5)
      if list_scripts; then
        dialog --msgbox "Selected script: $SELECTED_FOLDER\nScript path: $SCRIPT_PATH" $DIALOG_HEIGHT $DIALOG_WIDTH
      fi
      ;;
    6)
      dialog --msgbox "Exiting..." $DIALOG_HEIGHT $DIALOG_WIDTH
      clear
      exit 0
      ;;
  esac
done
