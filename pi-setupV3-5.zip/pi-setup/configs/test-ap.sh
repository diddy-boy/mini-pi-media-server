#!/usr/bin/env bash
# test-ap.sh
# this is a test tool for the wifi card to change to an access point (setup via reconfigure-wifi.sh)
# to test that the wifi connection drops wifi and swaps over to a wifi Acess Point with configuration from 
# /etc/raspi-ap.conf file 5 minutes as a test, then restore Wi-Fi
# Usage:
#  nohup sudo /home/pi/pi-setup/configs/test-ap.sh >/home/pi/pi-setup/configs/test-access-point.log 2>&1 &

set -euo pipefail
#config file
VAR_FILE="/etc/raspi-ap.conf"

require_root() {
  [[ $EUID -eq 0 ]] || { echo "This script must be run as 'nohup sudo /home/pi/pi-setup/configs/test-ap.sh >/home/pi/pi-setup/configs/test-access-point.log 2>&1 &'"; exit 1; }
}
log() { echo "[test-access-point] $(date '+%F %T') $*"; }

require_root
[[ -f "$VAR_FILE" ]] || { echo "Missing $VAR_FILE — run ./reconfigure-wifi.sh script first"; exit 1; }
. "$VAR_FILE"

echo "**************************************************************************************"> /dev/tty
echo "** Test script to drop wifi and turn on access point. you WILL loose SSH connection **"> /dev/tty
echo "**             look for a wifi network named $AP_SSID on other devices              **"> /dev/tty
echo "**              this test will keep the access point up for 5 minutes               **"> /dev/tty
echo "**************************************************************************************"> /dev/tty
sleep 5  # wait 5 seconds before continuing

# Record current SSID
CURRENT_SSID=$(nmcli -t -f NAME,DEVICE connection show --active | grep ":$WLAN_IF$" | cut -d: -f1 || true)

log "Disabling network managers"
systemctl stop NetworkManager || true
systemctl stop dhcpcd || true

log "Resetting $WLAN_IF"
ip link set "$WLAN_IF" down || true
ip addr flush dev "$WLAN_IF" || true
ip link set "$WLAN_IF" up

# Assign static IP to wlan0 for AP
log "Assigning static IP $AP_IP to $WLAN_IF"
ip addr add "$AP_IP" dev "$WLAN_IF"

# Generate temporary hostapd config
TMP_HOSTAPD_CONF=$(mktemp)
cat > "$TMP_HOSTAPD_CONF" <<EOF
interface=$WLAN_IF
ssid=$AP_SSID
hw_mode=g
channel=6
wpa=2
wpa_passphrase=$AP_PASS
EOF

# Generate temporary dnsmasq config
TMP_DNSMASQ_CONF=$(mktemp)
cat > "$TMP_DNSMASQ_CONF" <<EOF
interface=$WLAN_IF
dhcp-range=$AP_DHCP_START,$AP_DHCP_END,255.255.255.0,12h
EOF

log "Starting AP mode: SSID=$AP_SSID PASS=$AP_PASS"
hostapd -B "$TMP_HOSTAPD_CONF"
dnsmasq -C "$TMP_DNSMASQ_CONF"

log "AP mode active — expect SSH to disconnect if using $WLAN_IF"
sleep 300  # 5 minutes

log "Stopping AP mode"
killall hostapd || true
killall dnsmasq || true
rm -f "$TMP_HOSTAPD_CONF" "$TMP_DNSMASQ_CONF"

log "Restoring $WLAN_IF to normal mode"
ip link set "$WLAN_IF" down || true
ip addr flush dev "$WLAN_IF" || true
ip link set "$WLAN_IF" up

log "Re-enabling network managers"
systemctl start NetworkManager || true
systemctl start dhcpcd || true
nmcli radio wifi on || true

if [[ -n "$CURRENT_SSID" ]]; then
  log "Reconnecting to previous Wi-Fi: $CURRENT_SSID"
  nmcli connection up "$CURRENT_SSID" || true
else
  log "No previous SSID detected — reconnect manually."
fi

log "Done — Wi-Fi should be restored"

