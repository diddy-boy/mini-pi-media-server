<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache');

function getWifiConnections() {
    $result = [
        'connected_devices' => 0,
        'access_point_active' => false,
        'interface' => 'wlan0',
        'error' => null,
        'debug' => []
    ];

    try {
        // Detect wireless interface (default wlan0)
        $interfaces = shell_exec("iwconfig 2>/dev/null | grep -o '^[a-zA-Z0-9]*' | head -n 5");
        $interface_list = array_filter(explode("\n", trim($interfaces ?? '')));

        $wireless_interface = 'wlan0'; // default
        foreach ($interface_list as $iface) {
            $check = shell_exec("iwconfig $iface 2>/dev/null | grep 'Mode:Master'");
            if ($check) {
                $wireless_interface = trim($iface);
                break;
            }
        }
        $result['interface'] = $wireless_interface;
        $result['debug'][] = "Using interface: $wireless_interface";

        // Check if hostapd is running
        $hostapd_status = trim(shell_exec('systemctl is-active hostapd 2>/dev/null'));
        if ($hostapd_status === 'active') {
            $result['access_point_active'] = true;
            $result['debug'][] = "hostapd is active";

            // Method 1: hostapd_cli list_sta
            $clients_cmd = "sudo hostapd_cli -i $wireless_interface list_sta 2>/dev/null";
            $clients = shell_exec($clients_cmd);
            $result['debug'][] = "hostapd_cli command: $clients_cmd";

            if ($clients && !empty(trim($clients))) {
                $client_list = array_filter(explode("\n", trim($clients)));
                $valid_clients = array_filter($client_list, function($line) {
                    return preg_match('/^[a-fA-F0-9:]{17}$/', trim($line));
                });
                $result['connected_devices'] = count($valid_clients);
                $result['debug'][] = "Found " . count($valid_clients) . " clients via hostapd_cli list_sta";
            }

            // Method 2: hostapd_cli all_sta (only if no devices found)
            if ($result['connected_devices'] === 0) {
                $all_sta = shell_exec("sudo hostapd_cli -i $wireless_interface all_sta 2>/dev/null");
                if ($all_sta && !empty(trim($all_sta))) {
                    $mac_count = preg_match_all('/^[a-fA-F0-9:]{17}/m', $all_sta);
                    $result['connected_devices'] = $mac_count;
                    $result['debug'][] = "Found $mac_count clients via hostapd_cli all_sta";
                }
            }

            // Method 3: iw station dump (if still 0)
            if ($result['connected_devices'] === 0) {
                $iw_output = shell_exec("sudo iw dev $wireless_interface station dump 2>/dev/null | grep -c 'Station'");
                if ($iw_output !== null && intval(trim($iw_output)) > 0) {
                    $result['connected_devices'] = intval(trim($iw_output));
                    $result['debug'][] = "Found " . $result['connected_devices'] . " clients via iw station dump";
                }
            }

            // Method 4: ARP table (if still 0) — FIXED (no subtraction)
            if ($result['connected_devices'] === 0) {
                $ip_info = shell_exec("ip addr show $wireless_interface 2>/dev/null | grep 'inet '");
                if ($ip_info && preg_match('/inet (\d+\.\d+\.\d+)\./', $ip_info, $matches)) {
                    $subnet = $matches[1];
                    $arp_output = shell_exec("arp -a | grep '$subnet\\.' | grep -v 'incomplete' | wc -l 2>/dev/null");
                    if ($arp_output !== null) {
                        $arp_count = intval(trim($arp_output)); // Removed -1 subtraction
                        $result['connected_devices'] = $arp_count;
                        $result['debug'][] = "Found $arp_count clients via ARP table (subnet: $subnet)";
                    }
                }
            }

            // Method 5: DHCP leases (last fallback)
            if ($result['connected_devices'] === 0) {
                $lease_files = [
                    '/var/lib/dhcp/dhcpd.leases',
                    '/var/lib/dhcpcd5/dhcpcd.leases',
                    '/tmp/dhcp.leases'
                ];

                foreach ($lease_files as $lease_file) {
                    if (file_exists($lease_file)) {
                        $dhcp_leases = shell_exec("grep 'binding state active' $lease_file 2>/dev/null | wc -l");
                        if ($dhcp_leases !== null && intval(trim($dhcp_leases)) > 0) {
                            $result['connected_devices'] = intval(trim($dhcp_leases));
                            $result['debug'][] = "Found " . $result['connected_devices'] . " clients via DHCP leases ($lease_file)";
                            break;
                        }
                    }
                }
            }

        } else {
            $result['debug'][] = "hostapd is not active: $hostapd_status";
        }

    } catch (Exception $e) {
        $result['error'] = 'Unable to check WiFi status: ' . $e->getMessage();
    }

    return $result;
}

$wifi_data = getWifiConnections();

// Remove debug info for production
// unset($wifi_data['debug']);

echo json_encode($wifi_data);
?>
