#!/bin/bash

# Script to mount a server share and sync only Video and Music folders to /var/lib/minidlna, preventing multiple instances

# Define variables
DEST="/var/lib/minidlna/"
MOUNT_POINT="/mnt/store"
SHARE_PATH="//192.168.8.98/store"
SHARE_TYPE="cifs"
CIFS_CREDENTIALS="/etc/samba/credentials"
LOCK_FILE="/var/run/server_sync.lock"

# Determine the current user and their UID/GID
if [ -n "$SUDO_USER" ]; then
  CURRENT_USER="$SUDO_USER"
else
  echo "** Error: This script must be run with sudo. No SUDO_USER detected. **" >&2
  exit 1
fi

# Validate user existence and get UID/GID
if ! id "$CURRENT_USER" >/dev/null 2>&1; then
  echo "** Error: User '$CURRENT_USER' does not exist. **" >&2
  exit 1
fi
USER_UID=$(id -u "$CURRENT_USER")
USER_GID=$(id -g "$CURRENT_USER")

# Function to unmount share if mounted
cleanup_mount() {
  if mount | grep "$MOUNT_POINT" > /dev/null; then
    sync
    sleep 1
    umount "$MOUNT_POINT" 2>/dev/null && echo "********** Server share unmounted from $MOUNT_POINT. **********" || echo "** Error: Failed to unmount $MOUNT_POINT. **" >&2
  fi
}

# Ensure line-buffered output for systemd journal
stdbuf -oL bash

# Check if script is run with sudo
if [ "$EUID" -ne 0 ]; then
  echo "** Error: Please run this script with sudo. **" >&2
  exit 1
fi

# Check if destination directory exists
if [ ! -d "$DEST" ]; then
  echo "** Error: Destination directory $DEST does not exist. **" >&2
  exit 1
fi

# Check for lock file to prevent multiple instances
if [ -f "$LOCK_FILE" ]; then
  pid=$(cat "$LOCK_FILE")
  if ps -p "$pid" > /dev/null 2>&1; then
    echo "** Error: Another instance of the script is running (PID: $pid). Exiting. **" >&2
    exit 1
  else
    echo "Stale lock file found for PID $pid. Removing it."
    rm -f "$LOCK_FILE"
  fi
fi

# Create lock file with current PID
echo $$ > "$LOCK_FILE"
if [ $? -ne 0 ]; then
  echo "** Error: Failed to create lock file $LOCK_FILE. **" >&2
  exit 1
fi

# Ensure lock file is removed and share unmounted on script exit
trap 'rm -f "$LOCK_FILE"; cleanup_mount; exit' EXIT INT TERM

# Create mount point if it doesn't exist
if [ -d "$MOUNT_POINT" ]; then
  echo "Mount point $MOUNT_POINT already exists."
else
  mkdir -p "$MOUNT_POINT" || { echo "** Error: Failed to create mount point $MOUNT_POINT. **" >&2; exit 1; }
fi

# Check if mount point is already mounted
if mount | grep "$MOUNT_POINT" > /dev/null; then
  echo "** Mount point $MOUNT_POINT is already mounted. Proceeding without mounting. **"
else
  # Verify network connectivity to the server
  ping -c 1 192.168.8.98 > /dev/null 2>&1
  if [ $? -ne 0 ]; then
    echo "** Error: Cannot reach server **" >&2
    exit 1
  fi

  # Check if cifs-utils is installed
  if ! command -v mount.cifs > /dev/null 2>&1; then
    echo "** Error: cifs-utils is not installed. Install it with 'sudo apt install cifs-utils' or equivalent. **" >&2
    exit 1
  fi

  # Check if credentials file exists
  if [ ! -f "$CIFS_CREDENTIALS" ]; then
    echo "** Error: Credentials file $CIFS_CREDENTIALS does not exist. **" >&2
    exit 1
  fi

  # Mount the server share
  if [ "$SHARE_TYPE" = "cifs" ]; then
    mount -t cifs "$SHARE_PATH" "$MOUNT_POINT" -o credentials="$CIFS_CREDENTIALS",uid="$USER_UID",gid="$USER_GID",vers=3.0 2>/tmp/mount_err
    if [ $? -ne 0 ]; then
      echo "** Error: Failed to mount $SHARE_PATH to $MOUNT_POINT. Details: **" >&2
      cat /tmp/mount_err >&2
      rm -f /tmp/mount_err
      exit 1
    fi
    rm -f /tmp/mount_err
    echo "********** Server share mounted at $MOUNT_POINT. **********"
    echo "****                Starting synchronisation            ****"
  elif [ "$SHARE_TYPE" = "nfs" ]; then
    mount -t nfs "$SHARE_PATH" "$MOUNT_POINT" 2>/tmp/mount_err
    if [ $? -ne 0 ]; then
      echo "** Error: Failed to mount $SHARE_PATH to $MOUNT_POINT. Details: **" >&2
      cat /tmp/mount_err >&2
      rm -f /tmp/mount_err
      exit 1
    fi
    rm -f /tmp/mount_err
    echo "********** Server share mounted at $MOUNT_POINT. **********"
  else
    echo "** Error: Unsupported share type $SHARE_TYPE. Use 'nfs' or 'cifs'. **" >&2
    exit 1
  fi
fi

# Define source directory
SOURCE="$MOUNT_POINT"
INCLUDE_FOLDERS=("Video" "Music")

# Check if source directory exists
if [ ! -d "$SOURCE" ]; then
  echo "** Error: Source directory $SOURCE does not exist. **" >&2
  cleanup_mount
  exit 1
fi

# Check if at least one of the specified folders exists
FOLDERS_FOUND=0
for folder in "${INCLUDE_FOLDERS[@]}"; do
  if [ -d "$SOURCE/$folder" ]; then
    FOLDERS_FOUND=1
    break
  fi
done

if [ $FOLDERS_FOUND -eq 0 ]; then
  echo "** Error: None of the specified folders (${INCLUDE_FOLDERS[*]}) found in $SOURCE. **" >&2
  cleanup_mount
  exit 1
fi

# Perform rsync: sync only Video and Music folders, add or update files, do not delete
echo "**** Syncing Video and Music folders from $SOURCE to $DEST... ****"
stdbuf -oL rsync -r -v --update --no-links --include='Video/' --include='Video/**' --include='Music/' --include='Music/**' --exclude='*' "$SOURCE/" "$DEST" 2>/dev/null | grep -vE '^(sending|total size|delta-transmission|[/])$' | stdbuf -oL sed 's/^/Synced: /'

# Check rsync exit status
if [ $? -eq 0 ]; then
  echo "********** Synchronisation has completed successfully. **********"
else
  echo "** Error: Sync failed. **" >&2
  cleanup_mount
  exit 1
fi

# Ensure permissions for minidlna user
chown -R minidlna:minidlna "$DEST"
chmod -R 775 "$DEST"

# Unmount the server share
cleanup_mount

# Rescan minidlna
minidlnad -R && echo "minidlna database rescanned."

exit 0
