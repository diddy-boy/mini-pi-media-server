#!/bin/bash
# rclone-setup.sh for Mini-Pi Media Server v5.4

# 1. Root Check
if [[ $EUID -ne 0 ]]; then
   echo "Error: This script must be run with sudo"
   exit 1
fi

PI_USER="pi"
SYNC_DIR="/var/lib/minidlna/Video/Web"
SERVICE_NAME="rclone-sync"
REMOTE_NAME="cloud_media"

# 2. Setup Environment & Install Rclone
setup_rclone() {
    clear
	echo "************************************************"
	echo "         Multi cloud service sync setup"
	echo "************************************************"
    echo "--- STEP 1: Provider Selection ---"
	echo "  ONLY SELECT ONE CLOUD PROVIDER"
    echo "1) Google Drive (15GB free default storage)"
    echo "2) Microsoft OneDrive (5GB free default storage)"
    echo "3) MEGA (20GB free default storage)"
    echo -n "Select [1-3]: "
    read cloud_choice

    case $cloud_choice in
        2) CLOUD_TYPE="onedrive" ;;
        3) CLOUD_TYPE="mega" ;;
        *) CLOUD_TYPE="drive" ;;
    esac

    echo "--- Installing Software ---"
    chmod a+x /var/lib /var/lib/minidlna /var/lib/minidlna/Video
    mkdir -p "$SYNC_DIR"
    
    if ! command -v rclone &> /dev/null; then
        curl https://rclone.org/install.sh | sudo bash
    fi

    echo ""
    if [[ "$CLOUD_TYPE" == "drive" ]]; then
    echo "INSTRUCTIONS:"
    echo "1. Log into your Google Drive in a web browser."
    echo "2. Create a folder named 'Video'."
    echo "3. Open that 'Video' folder in the web browser."
    echo "4. Copy the long string of letters/numbers at the end of the URL after the last /."
    echo ""
    echo "Note: It's good practice to save this locally for use on other Mini-Pi servers."
    echo ""
    echo -n "Paste your Folder ID here and press Enter: "
        read FOLDER_ID
        export FOLDER_ID
    
    elif [[ "$CLOUD_TYPE" == "onedrive" ]]; then
        echo "ONEDRIVE INSTRUCTIONS:"
        echo "1. Create a folder named 'Video' in your OneDrive root."
        echo "2. In the next step [Auth], Rclone will provide a login link."
        read -p "Press Enter to continue..."
    
    elif [[ "$CLOUD_TYPE" == "mega" ]]; then
        echo "MEGA INSTRUCTIONS:"
        echo "1. Create a folder named 'Video' in your MEGA account."
        read -p "Press Enter to continue..."
    fi
}

# 3. Configure Remote (The Authentication Step)
configure_remote() {
    if [[ -z "$CLOUD_TYPE" ]]; then
        echo "Error: Please run Step 1 (Setup) first!"
        sleep 2
        return
    fi

    clear
    echo "--- STEP 2: Authenticating $CLOUD_TYPE ---"
    
    if [[ "$CLOUD_TYPE" == "drive" ]]; then
            clear
    echo "--- Step 2: Google Drive Authentication ---"
    echo "To get your token:"
    echo "1. Visit: https://rclone.org/commands/rclone_authorize/ (or use rclone authorize 'drive')"
    echo "2. Follow the Google login prompts."
    echo "3. Copy the JSON block starting with '{' and ending with '}'."
    echo ""
    echo "Note: It's good practice to save this locally for use on other Mini-Pi servers."
    echo ""
    echo "Paste Token (Right-click or Ctrl+Shift+V to paste):"
    read USER_TOKEN
	
	# We manually create the config using the captured token
        rclone config create $REMOTE_NAME drive \
            scope drive \
            root_folder_id "$FOLDER_ID" \
            token "$USER_TOKEN" \
            allow_teammates false
            
    elif [[ "$CLOUD_TYPE" == "onedrive" ]]; then
        echo "ONEDRIVE AUTHENTICATION:"
        echo "-------------------------------------------------------"
        echo "1. Rclone will now provide a URL."
        echo "2. Copy/Paste that URL into your PC's browser."
        echo "3. Log in, then COPY the code provided by the website."
        echo "4. PASTE that code back into the 'result' prompt below."
        echo "-------------------------------------------------------"
        sleep 2
        
        # This triggers the interactive prompt for the code
        rclone config create $REMOTE_NAME onedrive config_is_local false
        
    elif [[ "$CLOUD_TYPE" == "mega" ]]; then
        echo -n "Enter MEGA Email: "
        read mega_user
        echo -n "Enter MEGA Password: "
        read -s mega_pass
        echo ""
        rclone config create $REMOTE_NAME mega user "$mega_user" pass $(rclone obscure "$mega_pass")
    fi
}

# 4. Service Installation
install_sync_service() {
    if [[ -z "$CLOUD_TYPE" ]]; then
        echo "Error: Please run Step 1 and 2 first!"
        sleep 2
        return
    fi

    clear
    echo "--- STEP 3: Installing Sync Service ---"
    
    if [[ "$CLOUD_TYPE" == "drive" ]]; then
        SYNC_SOURCE="${REMOTE_NAME}:"
    else
        SYNC_SOURCE="${REMOTE_NAME}:Video"
    fi

    cat <<EOF > /etc/systemd/system/${SERVICE_NAME}.service
[Unit]
Description=Rclone Sync Service ($CLOUD_TYPE)
After=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/rclone sync "$SYNC_SOURCE" "$SYNC_DIR" --delete-during
Restart=always
RestartSec=1800
User=root

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable ${SERVICE_NAME}.service
    systemctl start ${SERVICE_NAME}.service
    
    echo "-------------------------------------------------------"
    echo "            SERVICE INSTALLED SUCCESSFULLY"
    echo "-------------------------------------------------------"
    sleep 5
}

# 5. Service Removal
remove_sync_service() {
    clear
    echo "--- Removing Sync Service ---"
    echo "Stopping and disabling $SERVICE_NAME..."
    systemctl stop ${SERVICE_NAME}.service
    systemctl disable ${SERVICE_NAME}.service
    rm -f /etc/systemd/system/${SERVICE_NAME}.service
    systemctl daemon-reload
    
    echo "Removing rclone configuration for $REMOTE_NAME..."
    rclone config delete $REMOTE_NAME
    
    echo "-------------------------------------------------------"
    echo "             SERVICE REMOVED SUCCESSFULLY"
    echo "-------------------------------------------------------"
    sleep 3
}

# --- Main Menu Loop ---
while true; do
    clear
    echo "======================================================="
    echo "            Mini-Pi Multi-Cloud Sync Setup           "
    echo "======================================================="
    echo "Selected Provider: ${CLOUD_TYPE:-None}"
    echo ""
    echo "1) [Setup] Choose Provider & Folder ID"
    echo "2) [Auth]  Login & Paste Auth Token/Code"
    echo "3) [Start] Enable 30-Minute Sync Service"
    echo "4) [View]  Check Sync Logs"
    echo "5) [Remove] Uninstall Sync Service & Config"
    echo "6) Exit"
    echo ""
    echo -n "Select an option: "
    read opt

    case $opt in
        1) setup_rclone ;;
        2) configure_remote ;;
        3) install_sync_service ;;
        4) journalctl -u $SERVICE_NAME -f ;;
        5) remove_sync_service ;;
        6) exit 0 ;;
        *) echo "Invalid option."; sleep 1 ;;
    esac
done