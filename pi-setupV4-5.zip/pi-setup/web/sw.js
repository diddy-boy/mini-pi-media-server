const CACHE_NAME = 'mini-pi-cache-v1';
const urlsToCache = [
  '/1.gif', '/2.gif', '/3.gif', '/4.gif', '/5.gif',
  '/6.gif', '/7.gif', '/8.gif', '/9.gif',
  '/10.jpg', '/11.jpg', '/12.jpg', '/popcorn.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('Opened cache');
      return cache.addAll(urlsToCache);
    })
  );
});

self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (!cacheWhitelist.includes(cacheName)) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Skip caching video files
  if (url.pathname.match(/\.(mp4|webm|mkv|avi|mov)$/)) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then(response => {
      return response || fetch(event.request);
    })
  );
});

