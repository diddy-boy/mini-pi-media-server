<?php
// get_files.php - Cleaned & Synchronized Version
error_reporting(E_ALL);
ini_set('display_errors', 0); 
ini_set('log_errors', 1);
ini_set('error_log', '/var/log/php_errors.log'); 

// Configuration
$base_dir = '/var/lib/minidlna';
$web_base = '/files';
$hidden_extensions = ['php', 'env', 'srt', 'db', 'm3u', 'txt', 'nfo', 'DS_Store', 'thumbs'];

// File extensions
$image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
$video_extensions = ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm'];
$audio_extensions = ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'];

// Path logic
$dir_path = isset($_GET['path']) ? $_GET['path'] : '';
$relative_path = trim(str_replace($web_base, '', $dir_path), '/');
$current_dir = $base_dir . ($relative_path ? '/' . $relative_path : '');

/**
 * Helper Functions
 */
function get_file_extension($filename) {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

function format_file_size($bytes) {
    if ($bytes === false) return 'Unknown';
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    elseif ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    elseif ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' bytes';
}

function get_web_path($file_path, $base_dir, $web_base) {
    $relative = trim(str_replace($base_dir, '', $file_path), '/');
    return $web_base . ($relative ? '/' . $relative : '');
}

function get_thumbnail_path($video_path, $base_dir, $web_base) {
    $thumbnail_dir = dirname($video_path) . '/.thumbnails/';
    $filename = pathinfo($video_path, PATHINFO_FILENAME);
    $thumbnail_path = $thumbnail_dir . $filename . '.jpg';
    if (file_exists($thumbnail_path) && is_readable($thumbnail_path)) {
        return get_web_path($thumbnail_path, $base_dir, $web_base);
    }
    return null;
}

/**
 * The Priority Icon Function
 * Ensures Music and Picture folders show their respective icons 
 * even if they contain subfolders or metadata files.
 */
function get_directory_icon($dir_path, $image_extensions, $video_extensions, $audio_extensions, $hidden_extensions) {
    // Cinema-Grade UI SVGs
    $svgs = [
        // VIDEO: The Clapperboard (Your Favorite)
        'video' => '<svg viewBox="0 0 100 100" width="80" height="80" style="display:block;margin:auto;">
            <defs><linearGradient id="gold" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" style="stop-color:#FFD700"/><stop offset="100%" style="stop-color:#B8860B"/></linearGradient></defs>
            <path d="M15,35 L85,35 L85,80 Q85,85 80,85 L20,85 Q15,85 15,80 Z" fill="#000" stroke="url(#gold)" stroke-width="2.5"/>
            <path d="M15,35 L85,22 L85,35 L15,48 Z" fill="#111" stroke="url(#gold)" stroke-width="2.5"/>
            <path d="M50,55 L70,67 L50,79 Z" fill="url(#gold)"/>
        </svg>',
        
        // PICTURES: Matching Gold-Bordered Square Gallery Icon
        'picture' => '<svg viewBox="0 0 100 100" width="80" height="80" style="display:block;margin:auto;">
            <rect x="15" y="20" width="70" height="60" rx="8" fill="#000" stroke="url(#gold)" stroke-width="2.5"/>
            <path d="M25,70 L42,50 L55,65 L68,52 L75,70" fill="none" stroke="url(#gold)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="65" cy="40" r="5" fill="url(#gold)"/>
        </svg>',
        
        // MUSIC: Matching Gold-Bordered Vinyl Record
        'audio' => '<svg viewBox="0 0 100 100" width="80" height="80" style="display:block;margin:auto;">
            <circle cx="50" cy="50" r="42" fill="#000" stroke="url(#gold)" stroke-width="2.5"/>
            <circle cx="50" cy="50" r="30" fill="none" stroke="url(#gold)" stroke-width="0.5" opacity="0.4"/>
            <circle cx="50" cy="50" r="18" fill="none" stroke="url(#gold)" stroke-width="0.5" opacity="0.4"/>
            <circle cx="50" cy="50" r="10" fill="url(#gold)"/>
            <circle cx="50" cy="50" r="2" fill="#000"/>
        </svg>',

        // GENERIC FOLDER: Minimalist Black & Gold
        'folder' => '<svg viewBox="0 0 100 100" width="75" height="75" style="display:block;margin:auto;">
            <path d="M15,30 L40,30 L50,38 L85,38 L85,80 Q85,85 80,85 L20,85 Q15,85 15,80 Z" fill="#000" stroke="url(#gold)" stroke-width="2" opacity="0.8"/>
        </svg>'
    ];

    $folder_name = strtolower(basename($dir_path));
    if ($folder_name === 'pictures' || $folder_name === 'photos') return $svgs['picture'];
    if ($folder_name === 'video' || $folder_name === 'videos' || $folder_name === 'movies') return $svgs['video'];
    if ($folder_name === 'music') return $svgs['audio'];

    // Fallback logic remains the same...
    $items = @scandir($dir_path);
    if ($items === false) return $svgs['folder'];
    
    $has_images = $has_videos = $has_audio = false;
    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item[0] === '.') continue;
        $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
        if (in_array($ext, $video_extensions)) $has_videos = true;
        elseif (in_array($ext, $audio_extensions)) $has_audio = true;
        elseif (in_array($ext, $image_extensions)) $has_images = true;
    }

    if ($has_videos) return $svgs['video'];
    if ($has_audio)  return $svgs['audio'];
    if ($has_images) return $svgs['picture'];
    
    return $svgs['folder'];
}

/**
 * Security & Execution
 */
$real_base = realpath($base_dir);
$real_current = realpath($current_dir);

if (!$real_base || !$real_current || strpos($real_current, $real_base) !== 0) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid directory path']);
    exit;
}

$directories = [];
$files = [];

if (is_dir($current_dir)) {
    $items = @scandir($current_dir);
    if ($items !== false) {
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || $item[0] === '.') continue;
            
            $item_path = $current_dir . '/' . $item;
            $extension = get_file_extension($item);
            if (in_array($extension, $hidden_extensions)) continue;
            
            if (is_dir($item_path)) {
                $directories[] = [
                    'name' => $item,
                    'web_path' => get_web_path($item_path, $base_dir, $web_base),
                    'is_dir' => true,
                    'icon' => get_directory_icon($item_path, $image_extensions, $video_extensions, $audio_extensions, $hidden_extensions)
                ];
            } else {
                $size = @filesize($item_path);
                $files[] = [
                    'name' => $item,
                    'web_path' => get_web_path($item_path, $base_dir, $web_base),
                    'size' => format_file_size($size),
                    'extension' => $extension,
                    'thumbnail' => in_array($extension, $video_extensions) ? get_thumbnail_path($item_path, $base_dir, $web_base) : null,
                    'is_dir' => false
                ];
            }
        }
    }
}

// Sort
usort($directories, fn($a, $b) => strcasecmp($a['name'], $b['name']));
usort($files, fn($a, $b) => strcasecmp($a['name'], $b['name']));

// Output
header('Content-Type: application/json');
echo json_encode([
    'directories' => $directories, 
    'files' => $files
], JSON_PRETTY_PRINT);