<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');

function getNetworkStatus($withCreds = false) {
    clearstatcache();

    // 1. Check for Ethernet Carrier
    $eth_path = '/sys/class/net/eth0/carrier';
    $is_eth = (file_exists($eth_path) && trim(@file_get_contents($eth_path)) === '1');

    // 2. Get Ethernet IP
    $eth_ip = 'Disconnected';
    if ($is_eth) {
        $eth_ip = trim(shell_exec("ip -4 addr show eth0 | grep -oP '(?<=inet\s)\d+(\.\d+){3}'") ?? '');
    }

    $status = [
        'mode' => $is_eth ? 'LAN' : 'WIFI',
        'text' => $is_eth ? 'Connected via LAN' : 'Access Point only',
        'eth_ip' => $eth_ip ?: 'Disconnected',
        'ap_ip' => '192.168.50.1'
    ];

    // 3. WiFi SSID and password of the Mini-Pi's own hotspot.
    // Only done when asked for (Easy Connect calls wifi_status.php?creds=1): the page polls this
    // script every few seconds for the LAN/AP mode, and that poll doesn't need the passphrase.
    //
    // Reading a Wi-Fi passphrase needs root, so this goes through a small root-owned helper that
    // mini-pi-setup.sh installs (see /etc/sudoers.d/mini-pi-wifi). The helper only answers when
    // wlan0 is an access point, so this can never reveal the password of a normal Wi-Fi network.
    if ($withCreds) {
        $ssid = "Mini-Pi-Server";
        $password = "";

        $out = shell_exec("sudo -n /usr/local/bin/mini-pi-wifi-info 2>/dev/null");
        if ($out) {
            // Line 1 = SSID, line 2 = passphrase (empty if none is stored)
            $lines = preg_split('/\R/', rtrim($out, "\r\n"));
            if (!empty($lines[0])) $ssid = $lines[0];
            $password = $lines[1] ?? '';
        }

        $status['ssid'] = $ssid;
        $status['password'] = $password;
    }

    return $status;
}

echo json_encode(getNetworkStatus(isset($_GET['creds'])));
