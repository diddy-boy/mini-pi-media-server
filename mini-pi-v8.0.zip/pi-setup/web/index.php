<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
ini_set('error_log', '/var/log/php_errors.log');

// 1. Configuration
$base_dir = '/var/lib/minidlna';
$web_base = '/files';

// 2. Upload Logic (TRANSLATION FIX)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['media_upload'])) {
    $raw_target = $_POST['upload_to'] ?? $web_base; 
    
    // Convert Web Path (/files/Music) to System Path (/var/lib/minidlna/Music)
    $relative_part = trim(str_replace($web_base, '', $raw_target), '/');
    $target_dir = $base_dir . ($relative_part ? '/' . $relative_part : '');
    
    $filename = basename($_FILES['media_upload']['name']);
    $target_file = rtrim($target_dir, '/') . '/' . $filename;
    
    if ($filename === 'index.php') {
        die("Error: Cannot overwrite system files.");
    }

    // Security check and folder validation
    if (strpos(realpath($target_dir), realpath($base_dir)) === 0) {
        if (move_uploaded_file($_FILES['media_upload']['tmp_name'], $target_file)) {
            chmod($target_file, 0664);
            @chgrp($target_file, 'minidlna');
            
            // Return 200 OK for the XHR upload handler (no redirect needed)
            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
            exit;
        } else {
            die("Error: Failed to move file. Check permissions on " . $target_dir);
        }
    } else {
        die("Error: Invalid destination path.");
    }
}


// ── Cross-device resume: self-install save_progress.php if missing or outdated ─
$save_progress_path = __DIR__ . '/save_progress.php';
$save_progress_version = 'v4'; // bump this to force regeneration on next page load
$needs_install = !file_exists($save_progress_path) ||
    strpos(file_get_contents($save_progress_path), $save_progress_version) === false;
if ($needs_install) {
    $save_progress_code = <<<'SAVEPHP'
<?php
// save_progress.php — Cross-device resume position store — v4
// Created automatically by index.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$progress_dir = __DIR__ . '/.progress';
if (!is_dir($progress_dir)) {
    mkdir($progress_dir, 0755, true);
}

// Normalise path to a pure relative form before hashing so that web paths
// (/files/Movies/Foo.mp4) and system paths (/var/lib/minidlna/Movies/Foo.mp4)
// both resolve to the same key. md5 avoids basename() collisions between files
// with the same name in different subdirectories.
function make_key($file_path) {
    $normalized = str_replace(['/var/lib/minidlna', '/files'], '', $file_path);
    $normalized = trim($normalized, '/');
    return md5($normalized) . '.json';
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $body    = json_decode(file_get_contents('php://input'), true);
    $file     = $body['file']     ?? '';
    $time     = floatval($body['time'] ?? 0);
    $duration = floatval($body['duration'] ?? 0);
    $updated  = intval($body['updated'] ?? time());

    if ($file === '' || !isset($body['time'])) {
        http_response_code(400);
        echo json_encode(['error' => 'missing file or time']);
        exit;
    }

    $key      = make_key($file);
    $data_path = $progress_dir . '/' . $key;

    $is_reset = isset($body['reset']) && $body['reset'] === true;

    // Allow explicit resets through regardless of existing value.
    // For normal saves, only update if the incoming data is chronologically
    // newer than what is on disk (compare wall-clock time, not playhead).
    $existing_updated = 0;
    if (!$is_reset && file_exists($data_path)) {
        $existing = json_decode(file_get_contents($data_path), true);
        $existing_updated = intval($existing['updated'] ?? 0);
    }

    if ($is_reset || $updated >= $existing_updated) {
        file_put_contents($data_path, json_encode([
            'file'     => $file,
            'time'     => $time,
            'duration' => $duration,
            'reset'    => $is_reset,
            'updated'  => $updated
        ]), LOCK_EX);
    }

    echo json_encode(['ok' => true, 'saved' => $time]);

} elseif ($method === 'GET') {
    $file = $_GET['file'] ?? '';
    if (!$file) {
        http_response_code(400);
        echo json_encode(['error' => 'missing file']);
        exit;
    }

    $key       = make_key($file);
    $data_path = $progress_dir . '/' . $key;

    if (file_exists($data_path)) {
        echo file_get_contents($data_path);
    } else {
        echo json_encode(['time' => 0]);
    }

} elseif ($method === 'DELETE') {
    $file = $_GET['file'] ?? '';
    if ($file) {
        $key       = make_key($file);
        $data_path = $progress_dir . '/' . $key;
        if (file_exists($data_path)) unlink($data_path);
    }
    echo json_encode(['ok' => true]);

} else {
    http_response_code(405);
    echo json_encode(['error' => 'method not allowed']);
}
SAVEPHP;
    file_put_contents($save_progress_path, $save_progress_code);
    chmod($save_progress_path, 0644);
}
// ─────────────────────────────────────────────────────────────────────────────

// ── Self-install get_progress_bulk.php if missing or outdated ────────────────
$bulk_progress_path    = __DIR__ . '/get_progress_bulk.php';
$bulk_progress_version = 'v1';
$bulk_needs_install = !file_exists($bulk_progress_path) ||
    strpos(file_get_contents($bulk_progress_path), $bulk_progress_version) === false;
if ($bulk_needs_install) {
    $bulk_progress_code = <<<'BULKPHP'
<?php
// get_progress_bulk.php — Batch progress lookup for file list overlay — v1
// Created automatically by index.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$progress_dir = __DIR__ . '/.progress';

$body  = json_decode(file_get_contents('php://input'), true);
$files = $body['files'] ?? [];

if (!is_array($files) || count($files) === 0) {
    echo json_encode([]);
    exit;
}

function make_key($file_path) {
    $normalized = str_replace(['/var/lib/minidlna', '/files'], '', $file_path);
    $normalized = trim($normalized, '/');
    return md5($normalized) . '.json';
}

$result = [];

foreach ($files as $webPath) {
    $key       = make_key($webPath);
    $data_path = $progress_dir . '/' . $key;

    if (file_exists($data_path)) {
        $data     = json_decode(file_get_contents($data_path), true);
        $time     = floatval($data['time']     ?? 0);
        $duration = floatval($data['duration'] ?? 0);
        $reset    = isset($data['reset']) && $data['reset'] === true;

        if (!$reset && $time > 5 && $duration > 0) {
            $pct = min(100, round(($time / $duration) * 100));
            $result[$webPath] = ['time' => $time, 'duration' => $duration, 'pct' => $pct];
        }
    }
}

echo json_encode($result);
BULKPHP;
    file_put_contents($bulk_progress_path, $bulk_progress_code);
    chmod($bulk_progress_path, 0644);
}
// ─────────────────────────────────────────────────────────────────────────────

// File extensions (fed into APP_CONFIG below for the JS to use)
$image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
$video_extensions = ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm'];
$audio_extensions = ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'];

// Note: directory/file listing is handled at runtime by get_files.php via JS fetch (loadFiles()).
// get_files.php carries its own copies of the format/icon/path helpers it needs — this file
// only needs the extension lists above, to hand to the browser via APP_CONFIG.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini-Pi Media Browser</title>
    <link rel="icon" type="image/png" href="/logo.png" />
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/style.css?v=5">
</head>
<body>
    <!-- Icon sprite for the nav buttons (Feather-style line icons) -->
    <svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">
        <symbol id="i-home" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></symbol>
        <symbol id="i-folder" viewBox="0 0 24 24"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></symbol>
        <symbol id="i-upload" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></symbol>
    </svg>
    <div id="page-fade"></div>
    <div class="parallax">
        <div class="background"></div> 
        <div class="container">
            <div class="file-list">
                <!-- Auto-scroll zones for Fire TV remote cursor -->
                <div class="scroll-zone scroll-zone-up" id="scroll-zone-up">
                    <div class="zone-indicator"><svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M12 8l-6 6h12z"/></svg></div>
                </div>
                <div class="scroll-zone scroll-zone-down" id="scroll-zone-down">
                    <div class="zone-indicator"><svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M12 16l6-6H6z"/></svg></div>
                </div>
                <div class="nav-header" style="display: flex; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 20px;">
                    <a href="/index.html" class="home-title"><svg class="nav-ico" width="18" height="18" fill="none" stroke="#ff9142" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><use href="#i-home"/></svg>Home</a>
                    <div class="breadcrumb" style="display: flex; align-items: center; gap: 8px;">
    <a href="#" class="main-directory-link"><svg class="nav-ico" width="18" height="18" fill="none" stroke="#ff9142" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><use href="#i-folder"/></svg>Main Directory</a>
    
    <div id="upload-section" style="display: none; margin-left: 10px;">
    <form id="uploadForm" action="<?php echo $web_base; ?>/index.php" method="POST" enctype="multipart/form-data" style="display:inline;">
        <input type="hidden" name="upload_to" id="upload_to_path" value="">
        <input type="file" id="media_upload" name="media_upload" style="display:none;">
        <button type="button" class="btn" onclick="document.getElementById('media_upload').click()">
            <svg class="nav-ico" width="18" height="18" fill="none" stroke="#ff9142" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><use href="#i-upload"/></svg>Upload File
        </button>
    </form>
</div>
                    </div>
                </div>
                            <div style="margin-bottom: 15px; padding: 0 5px;">
    <input type="text" id="fileSearch" placeholder="SEARCH..." 
           style="width: 100%; background: rgba(255,255,255,0.05); border: 1px solid rgba(255, 145, 66, 0.55);
           padding: 12px; border-radius: 10px; color: #ffffff; font-family: 'Manrope', sans-serif; outline: none; font-size: 0.8rem; text-transform: uppercase;">
</div>

<h1 id="list-title" style="margin-bottom:15px; font-size:1.08rem; color:#ff9142; letter-spacing:3px; display:flex; align-items:center; gap:12px;">Browse <span style="flex:1; height:1px; background:linear-gradient(to right, rgba(255,145,66,0.4), transparent); display:inline-block;"></span></h1>
                <div id="directory-list" tabindex="0">
                    <!-- populated at runtime by loadFiles() via get_files.php -->
                </div>
                <div id="file-list" tabindex="0" style="display: none;"></div>
                <div id="recently-played-section">
                    <h4>Recently Played</h4>
                    <div id="recently-played-list"></div>
                </div>
            </div>
            <div class="preview">
    <div id="preview-content" class="preview-wrapper">
        <p style="text-align: center;">Choose a Directory or select a file to play</p>
    		</div>
	</div>
    </div>

                <div class="help-container">
                    <div class="help-icon">?</div>
                    <div class="help-tooltip">
                        <div class="help-header">Controls</div>
                        <div class="help-row"><span>ARROWS UP/DN</span> <span>VOLUME</span></div>
                        <div class="help-row"><span>ARROWS L/R</span> <span>SEEK / NAV</span></div>
                        <div class="help-row"><span>SPACE</span> <span>PLAY / PAUSE</span></div>
                        <div class="help-row"><span>ENTER / F</span> <span>FULLSCREEN</span></div>
                        <div class="help-row"><span>A</span> <span>ASPECT RATIO</span></div>
                        <div class="help-row"><span>ESC</span> <span>EXIT VIEW</span></div>
                    </div>
                </div>
            </div> </div> </div>



<script>
    // Values that only the server knows (paths, allowed extensions) — handed to app.js.
    const APP_CONFIG = {
        webBase:   '<?php echo $web_base; ?>',
        baseDir:   '<?php echo $base_dir; ?>',
        videoExts: <?php echo json_encode($video_extensions); ?>,
        audioExts: <?php echo json_encode($audio_extensions); ?>,
        imageExts: <?php echo json_encode($image_extensions); ?>
    };
</script>
<script src="/app.js?v=1"></script>
<script>
    // Home: fade to black + unfocus (same exit as the main buttons on index.html),
    // then navigate. Styling lives in style.css under "Exit: fade to black".
    (function () {
        var EXIT_MS = 1100;
        var home = document.querySelector('.home-title');
        if (!home) return;
        var savedVolumes = [];

        // Ease any playing audio/video down so the sound fades with the picture
        function fadeOutMedia(ms) {
            var els = document.querySelectorAll('video, audio');
            var start = Date.now();
            savedVolumes = [];
            Array.prototype.forEach.call(els, function (m) { savedVolumes.push([m, m.volume]); });
            (function step() {
                var t = Math.min(1, (Date.now() - start) / ms);
                savedVolumes.forEach(function (p) { try { p[0].volume = p[1] * (1 - t); } catch (e) {} });
                if (t < 1) requestAnimationFrame(step);
            })();
        }

        home.addEventListener('click', function (e) {
            // Let ctrl/cmd/shift-click and middle-click behave normally
            if (e.defaultPrevented || e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            if (document.body.classList.contains('leaving')) return;
            var url = this.href;
            document.body.classList.add('leaving');
            fadeOutMedia(900);
            setTimeout(function () { window.location.href = url; }, EXIT_MS);
        });

        // Back button can restore this page from the back/forward cache mid-exit: undo it
        window.addEventListener('pageshow', function (e) {
            if (!e.persisted) return;
            document.body.classList.remove('leaving');
            savedVolumes.forEach(function (p) { try { p[0].volume = p[1]; } catch (err) {} });
        });
    })();
</script>

<!-- Upload Progress Overlay -->
<div id="upload-overlay">
    <div id="upload-modal">
        <div id="upload-modal-title">Uploading</div>
        <div id="upload-modal-filename"></div>
        <div id="upload-progress-track">
            <div id="upload-progress-bar"></div>
        </div>
        <div id="upload-progress-pct">0%</div>
    </div>
</div>

</body>
</html>