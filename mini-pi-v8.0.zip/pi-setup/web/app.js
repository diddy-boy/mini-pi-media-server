    // ── Silk / Fire TV detection — add body class to enable performance CSS ──
    (function() {
        if (/Silk/i.test(navigator.userAgent)) {
            document.body.classList.add('is-silk');
        }
    })();
    // ─────────────────────────────────────────────────────────────────────────

    let backgrounds = [];
    let currentPath = APP_CONFIG.webBase;
    let audioElement = null;
    let imagePlaylist = [];
    let currentImageIndex = -1;
    let selectedIndex = -1;
    let imageCycleInterval = null;

    // ── Fire TV / Silk remote D-pad scroll support ─────────────────────────
    // ONLY intercepts Up/Down arrows when focus is on the list container itself
    // or a .file-item card inside it. If the user D-pads to an audio slider,
    // button, video player, or any other control this does nothing — those
    // elements handle their own arrow keys normally.
    document.addEventListener('keydown', function(e) {
        if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;

        const active = document.activeElement;
        if (!active) return;

        const fileList = document.getElementById('file-list');
        const dirList  = document.getElementById('directory-list');

        // Which list is visible right now?
        const scrollTarget = (fileList && fileList.style.display !== 'none') ? fileList : dirList;
        if (!scrollTarget) return;

        // Only act if focus is the container itself or a child card inside it
        const focusIsInList = (active === scrollTarget) || scrollTarget.contains(active);
        if (!focusIsInList) return;

        // Let real interactive elements keep their own arrow-key behaviour
        const interactiveTags = ['BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'VIDEO', 'AUDIO', 'A'];
        if (interactiveTags.includes(active.tagName)) return;

        e.preventDefault();
        const SCROLL_STEP = 220; // px — roughly one card row
        scrollTarget.scrollBy({ top: e.key === 'ArrowDown' ? SCROLL_STEP : -SCROLL_STEP, behavior: 'smooth' });
    });
    // ──────────────────────────────────────────────────────────────────────

    // ── Auto-scroll zones for Fire TV remote cursor ───────────────────────
    // When the cursor hovers over the top or bottom strip of the file-list
    // panel, the directory list scrolls continuously until the cursor leaves.
    (function() {
        let scrollTimer = null;
        const INTERVAL = 16;  // ms per tick (~60fps)
        const SPEED    = 10;  // px per tick — increase to scroll faster

        function getScrollTarget() {
            const fl = document.getElementById('file-list');
            const dl = document.getElementById('directory-list');
            return (fl && fl.style.display !== 'none') ? fl : dl;
        }

        function startScroll(direction) {
            if (scrollTimer) return;
            scrollTimer = setInterval(function() {
                const target = getScrollTarget();
                if (target) target.scrollTop += direction * SPEED;
            }, INTERVAL);
        }

        function stopScroll() {
            if (scrollTimer) { clearInterval(scrollTimer); scrollTimer = null; }
        }

        document.addEventListener('DOMContentLoaded', function() {
            const zoneUp   = document.getElementById('scroll-zone-up');
            const zoneDown = document.getElementById('scroll-zone-down');
            if (zoneUp) {
                zoneUp.addEventListener('mouseenter', () => startScroll(-1));
                zoneUp.addEventListener('mouseleave', stopScroll);
                zoneUp.addEventListener('touchstart', () => startScroll(-1), { passive: true });
                zoneUp.addEventListener('touchend',   stopScroll);
            }
            if (zoneDown) {
                zoneDown.addEventListener('mouseenter', () => startScroll(1));
                zoneDown.addEventListener('mouseleave', stopScroll);
                zoneDown.addEventListener('touchstart', () => startScroll(1), { passive: true });
                zoneDown.addEventListener('touchend',   stopScroll);
            }
        });
    })();
    // ──────────────────────────────────────────────────────────────────────

    function stripExt(name) {
        return name.includes('.') ? name.substring(0, name.lastIndexOf('.')) : name;
    }

    // ── Recently Played (localStorage, max 3) ──────────────────────────────
    const RECENT_KEY = 'recentlyPlayed';
    const RECENT_MAX = 3;
    const WEB_BASE   = APP_CONFIG.webBase;

    function getRecentlyPlayed() {
        try { return JSON.parse(localStorage.getItem(RECENT_KEY)) || []; }
        catch(e) { return []; }
    }

    function addRecentlyPlayed(filePath, fileName, fileType) {
        let list = getRecentlyPlayed();
        // Remove existing entry for same file so it moves to top
        list = list.filter(item => item.path !== filePath);
        list.unshift({ path: filePath, name: fileName, type: fileType });
        if (list.length > RECENT_MAX) list = list.slice(0, RECENT_MAX);
        try { localStorage.setItem(RECENT_KEY, JSON.stringify(list)); }
        catch(e) { /* storage full – silently ignore */ }
    }

    function renderRecentlyPlayed() {
        const section = document.getElementById('recently-played-section');
        const listEl  = document.getElementById('recently-played-list');
        const list    = getRecentlyPlayed().slice(0, RECENT_MAX);
        const isRoot  = (currentPath === WEB_BASE || currentPath === WEB_BASE + '/');

        if (!isRoot || list.length === 0) {
            section.style.display = 'none';
            return;
        }

        const icons = { video: '🎬', audio: '🎵', image: '🖼️', other: '📄' };
        listEl.innerHTML = '';
        list.forEach(item => {
            const div = document.createElement('div');
            div.className = 'recent-item';
            div.innerHTML = `<span class="recent-item-icon">${icons[item.type] || icons.other}</span>
                             <span class="recent-item-name">${stripExt(item.name)}</span>`;
            div.onclick = (event) => {
                // Clear highlight on all recent items first
                document.querySelectorAll('.recent-item').forEach(el => el.style.border = '');
                // Highlight this one
                div.style.border = '2px solid #ff9142';
                showPreview(item.path, item.type, item.name, event);
            };
            listEl.appendChild(div);
        });
        section.style.display = 'block';
    }
    // ──────────────────────────────────────────────────────────────────────

    // 1. Background Handling
    function setBackground(index = 0) {
    const bgDiv = document.querySelector('.background');
    if (backgrounds.length === 0) {
        bgDiv.style.background = 'linear-gradient(135deg, #000, #1a1a1a)';
        bgDiv.innerHTML = '';
        return;
    }

    const background = backgrounds[index % backgrounds.length];
    bgDiv.innerHTML = '';

    if (background.type === 'video') {
        // 2. Clear image background and create video element
        bgDiv.style.backgroundImage = 'none';
        
        const video = document.createElement('video');
        video.className = 'background-video';
        video.src = background.src;
        video.muted = true;
        video.loop = true;
        video.autoplay = true;
        video.playsInline = true;
        
        bgDiv.appendChild(video);
        video.play().catch(e => console.log('Autoplay blocked:', e));
    } else if (background.type === 'image') {
        // 3. Set image background as usual
        bgDiv.style.backgroundImage = `url('${background.src}')`;
    }
}

    // Fetch backgrounds from get_backgrounds.php
    function loadBackgrounds() {
        fetch('/get_backgrounds.php')
            .then(response => {
                if (!response.ok) throw new Error('Failed to fetch backgrounds: ' + response.statusText);
                return response.json();
            })
            .then(data => {
                if (!data.success) {
                    throw new Error('Background fetch unsuccessful');
                }
                backgrounds = data.backgrounds;
                const savedIndex = Math.max(0, Math.min(parseInt(localStorage.getItem('backgroundIndex')) || 0, backgrounds.length - 1));
                console.log('Backgrounds loaded:', backgrounds, 'Applying index:', savedIndex);
                setBackground(savedIndex);
            })
            .catch(error => {
                console.error('Error fetching backgrounds:', error);
                // Fallback to default gradient
                backgrounds = [{ type: 'gradient', src: 'gradient', name: 'Default Gradient' }];
                setBackground(0);
            });
    } 

    // 2. Main File & Directory Loader
    let __isFirstLoadFiles = true; // page's own initial load shouldn't stack a history entry
    function loadFiles(path) {
        currentPath = path;
        if (__isFirstLoadFiles) {
            // This call happens automatically on page load (window.onload), before
            // any real navigation — replace the current entry instead of pushing a
            // new one, or the browser/remote back button needs two presses to
            // actually leave the page (first press just undoes this rewrite).
            history.replaceState({path: path}, '', path);
            __isFirstLoadFiles = false;
        } else {
            history.pushState({path: path}, '', path);
        }
        document.getElementById('fileSearch').value = '';
        resumeBackgroundVideo();
        // --- NEW PATH CALCULATION FOR UPLOADS ---
    const baseDir = APP_CONFIG.baseDir;
    const webBase = APP_CONFIG.webBase;
    const systemPath = baseDir + path.replace(webBase, '');
    
    const pathInput = document.getElementById('upload_to_path');
    if (pathInput) pathInput.value = systemPath;
    // ----------------------------------------
        
        fetch('/files/get_files.php?path=' + encodeURIComponent(path))
            .then(res => res.json())
            .then(data => {
                const uploadSection = document.getElementById('upload-section');
                 const folderName = path.split('/').filter(Boolean).pop()?.toLowerCase() || '';
                const allowed = ['music', 'pictures', 'photos', 'video', 'videos', 'movies'];

                if (allowed.includes(folderName)) {
                uploadSection.style.display = 'block';
                // Essential: Update the hidden input with the current web path
                document.getElementById('upload_to_path').value = path; 
                } else {
                uploadSection.style.display = 'none';
                }
    
                if (allowed.includes(folderName)) {
        uploadSection.style.display = 'block';
                } else {
        uploadSection.style.display = 'none';
                }
                const dirList = document.getElementById('directory-list');
                dirList.innerHTML = '';
                selectedIndex = -1; 
                imagePlaylist = []; 
                
                const allItems = [];
                if (data.directories) data.directories.forEach(d => allItems.push({...d, isDir: true}));
                if (data.files) data.files.forEach(f => allItems.push({...f, isDir: false}));

                const isRoot = (path === webBase || path === webBase + '/');

                // At root: use a compact single-row layout for the 3 top-level folders
                if (isRoot && data.directories && data.directories.length > 0 && (!data.files || data.files.length === 0)) {
                    dirList.style.display = 'flex';
                    dirList.style.flexDirection = 'row';
                    dirList.style.gridTemplateColumns = '';
                    dirList.style.gap = '12px';
                    dirList.classList.add('root-row');
                } else {
                    dirList.style.display = '';
                    dirList.style.flexDirection = '';
                    dirList.style.gridTemplateColumns = '';
                    dirList.style.gap = '';
                    dirList.classList.remove('root-row');
                }

                allItems.forEach((item, index) => {
                    const div = document.createElement('div');
                    div.className = 'file-item';
                    
                    let thumbHtml;
                    let fileType = 'other';

                    if (item.isDir) {
                fileType = 'directory';
                const isMobile = isRoot && !document.body.classList.contains('is-silk') && (window.innerWidth <= 768 || (window.innerHeight <= 500 && window.innerWidth > window.innerHeight));
                // Desktop root: normal sized icon, auto height card with label
                // Mobile root: scaled-down icon, compact card, no label
                const svgW = 48;
                const svgH = 48;
                const iconBoxH = isMobile ? '56px' : '120px';
                const svgScaled = item.icon
                    .replace(/width="48"/g, 'width="' + svgW + '"')
                    .replace(/height="48"/g, 'height="' + svgH + '"');
                const scaleStyle = isMobile ? 'transform:scale(0.65);transform-origin:center center;' : '';
                thumbHtml = '<div style="width:100%;height:' + iconBoxH + ';display:flex;align-items:center;justify-content:center;' + scaleStyle + '">' + svgScaled + '</div>';
                if (isRoot) {
                    div.style.height = 'auto';
                    div.style.minHeight = '0';
                    div.style.padding = isMobile ? '8px 4px' : '14px 10px';
                    div.style.flex = '1';
                }
                div.onclick = () => loadFiles(item.web_path);
                } else {
                        const ext = item.extension.toLowerCase();
                        const videoExts = APP_CONFIG.videoExts;
                        const audioExts = APP_CONFIG.audioExts;
                        const isVideo = videoExts.includes(ext);
                        const isAudio = audioExts.includes(ext);
                        const isImage = APP_CONFIG.imageExts.includes(ext);

                        if (isImage) imagePlaylist.push({path: item.web_path, name: item.name});

                        if (isVideo) {
                            fileType = 'video';
                            const posterName = item.name.substring(0, item.name.lastIndexOf('.')) || item.name;
                            thumbHtml = `<img src="/files/.metadata/posters/${encodeURIComponent(posterName)}.jpg" onerror="this.onerror=null;this.src='/movie.png';" class="file-poster">`;
                            div.setAttribute('data-webpath', item.web_path);
                        } else if (isImage) {
                            fileType = 'image';
                            thumbHtml = `<img src="${item.web_path}" class="file-poster" style="object-fit:cover;">`;
                        } else if (isAudio) {
                            fileType = 'audio';
                            thumbHtml = `<div style="font-size:3.5rem;">🎵</div>`;
                        } else {
                            thumbHtml = `<div style="font-size:3.5rem;">📄</div>`;
                        }
                        
                        div.onclick = (event) => {
                            selectedIndex = index;
                            showPreview(item.web_path, fileType, item.name, event);
                        };
                    }

                    const labelHtml = '<div class="file-name">' + stripExt(item.name) + '</div>'; div.innerHTML = thumbHtml + labelHtml;

                    // Fire TV / Silk: make each card focusable by the D-pad remote
                    // and scroll it into view when the remote lands on it
                    div.setAttribute('tabindex', '0');
                    div.addEventListener('focus', function() {
                        this.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                    });
                    // Allow Enter/Select button to trigger the card
                    div.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            this.click();
                        }
                    });

                    dirList.appendChild(div);
                });

                // ── Bulk progress overlay ─────────────────────────────────
                // Collect web paths for video files only, then fire ONE fetch
                // to get all saved progress. No video elements probed.
                // Silk-safe: a single XHR, pure CSS width, zero decoder use.
                (function() {
                    var videoPaths = [];
                    allItems.forEach(function(item) {
                        if (!item.isDir) {
                            var ext = item.extension.toLowerCase();
                            var videoExts = APP_CONFIG.videoExts;
                            if (videoExts.includes(ext)) {
                                videoPaths.push(item.web_path);
                            }
                        }
                    });
                    if (videoPaths.length === 0) return;

                    fetch('/files/get_progress_bulk.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ files: videoPaths })
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(progressMap) {
                        // Walk the rendered cards and stamp progress bars
                        var cards = dirList.querySelectorAll('.file-item[data-webpath]');
                        cards.forEach(function(card) {
                            var wp = card.getAttribute('data-webpath');
                            if (progressMap[wp]) {
                                var pct = progressMap[wp].pct;
                                var wrap = document.createElement('div');
                                wrap.className = 'card-progress-wrap';
                                var bar = document.createElement('div');
                                bar.className = 'card-progress-bar';
                                bar.style.width = pct + '%';
                                wrap.appendChild(bar);
                                card.appendChild(wrap);
                            }
                        });
                    })
                    .catch(function() {}); // silent fail — progress bars are cosmetic
                })();
                // ─────────────────────────────────────────────────────────

                // Show recently played only at root
                renderRecentlyPlayed();

                // Fire TV / Silk: force grid reflow to prevent 2-column flash bug.
                // Silk sometimes miscalculates the grid container width on initial
                // paint; toggling display forces a proper reflow before it renders.
                // This is a no-op on desktop/mobile as it completes before any paint.
                if (!isRoot) {
                    dirList.style.display = 'none';
                    void dirList.offsetHeight;
                    dirList.style.display = '';
                }

                // Fire TV / Silk: auto-focus the list so D-pad remote can scroll it
                if (!isRoot) {
                    setTimeout(() => { dirList.focus({ preventScroll: true }); }, 100);
                }

            }).catch(err => console.error("Error loading files:", err));
    }

    // ── Background video unload/reload (fully frees decoder on Silk/FireStick) ──
    function pauseBackgroundVideo() {
        const bgVid = document.querySelector('.background video');
        if (bgVid && !bgVid.dataset.unloadedByPlayer) {
            // Save src so we can restore it later
            const source = bgVid.querySelector('source');
            bgVid.dataset.savedSrc = source ? source.src : (bgVid.src || '');
            // Set cinema fallback image so the div never goes black
            const bgDiv = document.querySelector('.background');
            bgDiv.style.backgroundImage = `url('/Pictures/20.jpg')`;
            // Fade out smoothly first, then unload after transition
            bgVid.style.transition = 'opacity 0.8s ease';
            bgVid.style.opacity = '0';
            setTimeout(() => {
                bgVid.pause();
                if (source) source.removeAttribute('src');
                bgVid.removeAttribute('src');
                bgVid.load();
            }, 800);
            bgVid.dataset.unloadedByPlayer = '1';
        }
    }

    function resumeBackgroundVideo() {
        const bgVid = document.querySelector('.background video');
        if (bgVid && bgVid.dataset.unloadedByPlayer === '1') {
            const savedSrc = bgVid.dataset.savedSrc || '';
            if (savedSrc) {
                const source = bgVid.querySelector('source');
                if (source) {
                    source.src = savedSrc;
                } else {
                    bgVid.src = savedSrc;
                }
                bgVid.load();
                bgVid.play().catch(() => {});
                // Fade back in once playing, then clear the static fallback
                bgVid.addEventListener('playing', function fadeIn() {
                    bgVid.style.transition = 'opacity 1.2s ease';
                    bgVid.style.opacity = '1';
                    // Clear static fallback after video is fully visible
                    setTimeout(() => {
                        document.querySelector('.background').style.backgroundImage = 'none';
                    }, 1200);
                    bgVid.removeEventListener('playing', fadeIn);
                });
            }
            delete bgVid.dataset.unloadedByPlayer;
            delete bgVid.dataset.savedSrc;
        }
    }
    // ──────────────────────────────────────────────────────────────────────

    // 3. Preview Function
    function showPreview(file, type, filename, event) {
    const previewContent = document.getElementById('preview-content');
    
    // Track recently played (only for media files, not directories)
    if (type !== 'directory' && type !== 'other') {
        addRecentlyPlayed(file, filename, type);
    }

    // --- ANIMATION RESET LOGIC ---
    previewContent.style.animation = 'none';
    previewContent.offsetHeight;
    previewContent.style.animation = null; 
    // -----------------------------

    if (audioElement) { audioElement.pause(); audioElement = null; }
    
    if (type === 'image') {
        showImagePreview(previewContent, file, filename);
    } else if (type === 'video') {
        showVideoPreview(previewContent, file, filename);
    } else if (type === 'audio') {
        showAudioPreview(previewContent, file, filename);
    }

    // Border highlight for selected item
    document.querySelectorAll('.file-item').forEach(item => item.style.border = 'none');
    document.querySelectorAll('.recent-item').forEach(item => item.style.border = '');
    if (event && event.currentTarget) { 
        event.currentTarget.style.border = '2px solid #f3efe6'; 
    }
    }

    function showImagePreview(previewContent, file, filename) {
    currentImageIndex = imagePlaylist.findIndex(img => img.path === file);
    previewContent.innerHTML = `
        <img src="${file}" alt="Preview" style="max-width:100%; border-radius:15px;">
        <div class="preview-info" style="margin-top:15px; text-align:center;">
            <h3>${stripExt(filename)}</h3>
            <p>Image ${currentImageIndex + 1} of ${imagePlaylist.length}. Use ←/→ for prev/next, Enter for full screen</p>
        </div>`;
    }

    function showVideoPreview(previewContent, file, filename) {
    pauseBackgroundVideo();
    const nameOnly = filename.substring(0,      filename.lastIndexOf('.')) || filename;
    const baseUrl = `/files/.metadata/posters/${encodeURIComponent(nameOnly)}`;

    previewContent.innerHTML = `
    <div style="position: relative; width: 100%;">
    <div id="resume-ui" class="resume-overlay" style="display: none;">
        <div class="resume-box">
            <h4>RESUME FROM <span id="resume-time-display">00:00</span>?</h4>
            <div class="resume-buttons">
                <button id="btn-resume-yes" class="resume-btn resume-yes">YES</button>
                <button id="btn-resume-no" class="resume-btn resume-no">START OVER</button>
            </div>
        </div>
    </div>
    <video id="video-player" controls
        onerror="document.getElementById('video-error-msg').style.display='block'; this.style.display='none';">
        <source src="${file}" type="video/${file.split('.').pop()}">
    </video>
    <div id="video-error-msg" style="display:none; padding:30px; text-align:center; color:rgba(243,239,230,0.6); font-family:'Manrope',sans-serif; font-size:0.97rem; letter-spacing:2px;">
        ⚠ MEDIA FILE CANNOT BE PLAYED
    </div>
    </div>
    <div id="acb-toggle-pill"><i class="acb-pill-chevron">▾</i> EQ &amp; FX</div>
    <div id="audio-controls-bar" style="margin-top:4px; flex-direction: column; gap: 0;">
    <div class="acb-main-row">
        <label for="eq-bass">BASS</label>
        <input type="range" id="eq-bass" min="-12" max="12" step="1" value="0">
        <span class="acb-val" id="bass-val">0dB</span>
        <label for="eq-treble">TREBLE</label>
        <input type="range" id="eq-treble" min="-12" max="12" step="1" value="0">
        <span class="acb-val" id="treble-val">0dB</span>
        <button id="btn-adv-toggle" class="acb-adv-toggle" title="Advanced audio effects">ADV ▾</button>
    </div>
    <div id="acb-advanced" class="acb-advanced-row" style="display:none;">
        <button id="btn-normalise" title="Apply dynamic compression to even out volume">◎ NORM</button>
        <button id="btn-night" class="acb-adv-btn" title="Cuts low-end rumble — good for late night viewing">🌙 NIGHT</button>
        <button id="btn-dialogue" class="acb-adv-btn" title="Boosts speech frequencies — helps voices cut through">💬 DIALOGUE</button>
        <button id="btn-subtitles" class="acb-adv-btn" title="Toggle subtitles on/off">🔤 SUBS</button>
        <button id="btn-aspect" class="acb-adv-btn" title="Cycle video fit: Fit (letterbox) → Fill (crop) → Stretch">⛶ FIT</button>
    </div>
    </div>
    <div class="preview-info" style="margin-top:12px; text-align:center;">
    <div style="display: flex; justify-content: space-between; align-items: center; gap: 15px; margin-bottom: 10px; width: 100%; min-width: 0;">
        <h3 title="${stripExt(filename)}" style="margin: 0; color: #f3efe6; font-size: 1.5rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; min-width: 0; text-align: left;">
            ${stripExt(filename)}
        </h3>
        <div class="rating-container">
            <span id="imdb-rating" class="preview-rating" style="display:none;"></span>
            <span id="rt-rating" class="preview-rt-rating" style="display:none;"></span>
        </div>
    </div>


            <a id="wiki-link" href="javascript:void(0)" target="_blank" style="text-decoration: none; color: inherit; pointer-events: none;">
                <div id="movie-synopsis" style="margin-top:20px; padding:18px; background: rgba(0, 0, 0, 0.5); border-radius:12px; color: #f3efe6; font-size:1.12rem; line-height:1.5; text-align:left; display: none; height: 140px; overflow-y: auto;"></div>
            </a>
            <p id="wiki-hint" style="opacity: 0.3; font-size: 0.7rem; margin-top: 10px; display:none;">(Click synopsis for Wikipedia)</p>
        </div>`;

    // --- 1. CROSS-DEVICE RESUME FEATURE LOGIC ---
    const video = document.getElementById('video-player');
    const resumeUI = document.getElementById('resume-ui');
    const resumeTimeDisplay = document.getElementById('resume-time-display');
    const storageKey = 'resume_' + btoa(encodeURIComponent(file));
    const localTime    = parseFloat(localStorage.getItem(storageKey) || '0');

    // Fetch server-side position (written by any device), compare with local.
    // autoplay is intentionally removed from the <video> tag — we always
    // call video.play() manually once we know whether to resume or not.

    // Helper: POST a reset (time:0) to the server so other devices know
    // a conscious "Start Over" was chosen, overriding their localStorage.
    const resetProgress = () => {
        localStorage.removeItem(storageKey);
        fetch('/files/save_progress.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ file: file, time: 0, updated: Math.floor(Date.now() / 1000), reset: true })
        }).catch(() => {});
    };

    fetch('/files/save_progress.php?file=' + encodeURIComponent(file))
        .then(r => r.json())
        .then(data => {
            const serverTime    = parseFloat(data.time || '0');
            const serverUpdated = parseInt(data.updated || '0', 10);
            const localUpdated  = parseInt(localStorage.getItem(storageKey + '_updated') || '0', 10);
            const wasReset      = data.reset === true;
            // Mirror the PHP logic: trust whichever save is chronologically newer,
            // not whichever playhead position is further along.
            const bestTime = wasReset ? 0 : (serverUpdated >= localUpdated ? serverTime : localTime);
            if (bestTime > 15) {
                // Show resume prompt — do NOT play yet
                const timeString = new Date(bestTime * 1000).toISOString().substr(11, 8);
                resumeTimeDisplay.innerText = timeString;
                resumeUI.style.display = 'flex';

                document.getElementById('btn-resume-yes').onclick = () => {
                    video.currentTime = bestTime;
                    resumeUI.style.display = 'none';
                    video.play();
                };

                document.getElementById('btn-resume-no').onclick = () => {
                    resetProgress();
                    resumeUI.style.display = 'none';
                    video.play();
                };
            } else {
                // No saved position (or explicit reset) — just play from the start
                video.play();
            }
        })
        .catch(() => {
            // Server unavailable — fall back to localStorage only
            if (localTime > 15) {
                const timeString = new Date(localTime * 1000).toISOString().substr(11, 8);
                resumeTimeDisplay.innerText = timeString;
                resumeUI.style.display = 'flex';
                document.getElementById('btn-resume-yes').onclick = () => {
                    video.currentTime = localTime;
                    resumeUI.style.display = 'none';
                    video.play();
                };
                document.getElementById('btn-resume-no').onclick = () => {
                    localStorage.removeItem(storageKey);
                    resumeUI.style.display = 'none';
                    video.play();
                };
            } else {
                // No saved position and server unreachable — just play
                video.play();
            }
        });

    if ('mediaSession' in navigator) {
        navigator.mediaSession.metadata = new MediaMetadata({
            title: stripExt(filename),
            artist: 'Mini-Pi Media'
        });
    }

    let lastServerSave = 0;

    // Unconditional save — used on pause and page exit.
    // No end-of-film guard so pausing near the end always writes correctly.
    const saveToServer = () => {
        if (video.currentTime > 15) {
            const nowSec = Math.floor(Date.now() / 1000);
            localStorage.setItem(storageKey, video.currentTime);
            localStorage.setItem(storageKey + '_updated', nowSec);
            fetch('/files/save_progress.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ file: file, time: video.currentTime, duration: video.duration || 0, updated: nowSec })
            }).catch(() => {});
            lastServerSave = Date.now();
        }
    };

    video.ontimeupdate = () => {
        // Throttled background save every 10s — guard the last 60s to avoid
        // writing a near-end position that would trigger a spurious resume prompt.
        if (video.currentTime > 15 && (video.duration - video.currentTime > 60)) {
            const now = Date.now();
            const nowSec = Math.floor(now / 1000);
            localStorage.setItem(storageKey, video.currentTime);
            localStorage.setItem(storageKey + '_updated', nowSec);
            if (now - lastServerSave > 10000) {
                lastServerSave = now;
                fetch('/files/save_progress.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ file: file, time: video.currentTime, duration: video.duration || 0, updated: nowSec })
                }).catch(() => {});
            }
        }
    };

    // ── Refresh the progress bar on the file-list card for this video ──
    function refreshCardProgressBar() {
        const card = document.querySelector('.file-item[data-webpath="' + file + '"]');
        if (!card || !video.duration) return;
        const pct = Math.min(100, Math.round((video.currentTime / video.duration) * 100));
        if (pct < 1) return;
        let wrap = card.querySelector('.card-progress-wrap');
        if (!wrap) {
            wrap = document.createElement('div');
            wrap.className = 'card-progress-wrap';
            const bar = document.createElement('div');
            bar.className = 'card-progress-bar';
            wrap.appendChild(bar);
            card.appendChild(wrap);
        }
        wrap.querySelector('.card-progress-bar').style.width = pct + '%';
    }
    // ────────────────────────────────────────────────────────────────────

    // Save immediately on pause and tab close — no waiting for the 10s throttle
    video.addEventListener('pause', saveToServer);
    video.addEventListener('pause', refreshCardProgressBar);

    // On page exit use sendBeacon — unlike fetch(), the browser guarantees
    // delivery even when the Home button is pressed or the tab is killed.
    // pagehide covers Fire TV / Silk which sometimes skips beforeunload entirely.
    const saveBeacon = () => {
        if (video.currentTime > 15 && (video.duration - video.currentTime > 5)) {
            const nowSec = Math.floor(Date.now() / 1000);
            localStorage.setItem(storageKey, video.currentTime);
            localStorage.setItem(storageKey + '_updated', nowSec);
            const payload = JSON.stringify({
                file: file,
                time: video.currentTime,
                duration: video.duration || 0,
                updated: nowSec
            });
            navigator.sendBeacon(
                '/files/save_progress.php',
                new Blob([payload], { type: 'application/json' })
            );
        }
    };
    window.addEventListener('beforeunload', saveBeacon);
    window.addEventListener('pagehide', saveBeacon);

    // Remote-cast exit: called when the movie is done, whether or not the
    // browser's 'ended' event actually fires (some TV/WebView video
    // stacks are unreliable about it). Guarded so it only runs once.
    let __castExited = false;
    const exitRemoteCastIfNeeded = () => {
        if (!window.__isRemoteCast || __castExited) return;
        __castExited = true;
        if (document.fullscreenElement) {
            document.exitFullscreen().catch(() => {});
        }
        document.body.classList.remove('remote-cast-mode');
        setTimeout(() => { window.location.href = '/index.html'; }, 500);
    };

    video.onended = () => {
        window.removeEventListener('beforeunload', saveBeacon);
        window.removeEventListener('pagehide', saveBeacon);
        resetProgress();
        resumeBackgroundVideo();
        exitRemoteCastIfNeeded();
    };

    // Watchdog: some devices never fire 'ended' reliably. Poll actual
    // playback position instead and treat "within half a second of the
    // known duration" as finished. No-op unless this is a remote cast.
    if (window.__isRemoteCast) {
        const __endWatchdog = setInterval(() => {
            if (__castExited) { clearInterval(__endWatchdog); return; }
            if (video.duration && !isNaN(video.duration) &&
                (video.duration - video.currentTime) < 0.5) {
                clearInterval(__endWatchdog);
                video.onended();
            }
        }, 1000);
    }

    // --- BACKGROUND VIDEO PAUSE/RESUME ON PLAYER PAUSE/PLAY ---
    let bgResumeTimer = null;

    video.addEventListener('pause', () => {
        // After 5 seconds of the movie being paused, softly bring the background back
        bgResumeTimer = setTimeout(() => resumeBackgroundVideo(), 5000);
    });

    video.addEventListener('play', () => {
        // If the user resumes before the 5s timer fires, cancel it and re-pause background
        clearTimeout(bgResumeTimer);
        pauseBackgroundVideo();
    });
    // ──────────────────────────────────────────────────────────────────

    // --- SUBTITLE (VTT) DETECTION & TOGGLE ---
    const vttUrl = file.substring(0, file.lastIndexOf('.')) + '.vtt';
    let subsOn = localStorage.getItem('subsOn') === '1';

    // Attach VTT track if one exists alongside the video
    fetch(vttUrl, { method: 'HEAD' })
        .then(res => {
            if (!res.ok) return;
            const track = document.createElement('track');
            track.kind    = 'subtitles';
            track.label   = 'English';
            track.srclang = 'en';
            track.src     = vttUrl;
            track.default = false;
            video.appendChild(track);
            // Apply saved subtitle preference once track is ready
            video.addEventListener('loadedmetadata', () => {
                if (video.textTracks[0]) {
                    video.textTracks[0].mode = subsOn ? 'showing' : 'hidden';
                }
            });
        })
        .catch(() => {});

    // SUBS button — always visible, only has effect if a track was attached
    const subsBtn = document.getElementById('btn-subtitles');
    if (subsBtn) {
        subsBtn.classList.toggle('active', subsOn);
        subsBtn.onclick = () => {
            subsOn = !subsOn;
            if (video.textTracks[0]) {
                video.textTracks[0].mode = subsOn ? 'showing' : 'hidden';
            }
            subsBtn.classList.toggle('active', subsOn);
            localStorage.setItem('subsOn', subsOn ? '1' : '0');
        };
    }
    // --- END SUBTITLE LOGIC ---


    const ratingBadge = document.getElementById('imdb-rating');
    fetch(`${baseUrl}.rating`)
        .then(res => res.text())
        .then(rating => {
            const cleanRating = rating.trim();
            if (cleanRating && cleanRating.length < 6 && !cleanRating.includes('<')) {
                ratingBadge.innerText = "IMDb " + cleanRating;
                ratingBadge.style.display = 'inline-block';
            } else {
                ratingBadge.style.display = 'none';
            }
        }).catch(() => { ratingBadge.style.display = 'none'; });
        // --- 3. ROTTEN TOMATOES RATING FETCH ---
	const rtBadge = document.getElementById('rt-rating');
	fetch(`${baseUrl}.rt`)
    	.then(res => res.text())
    	.then(rtData => {
    const cleanRt = rtData.trim();
    // Check if data exists and isn't an HTML error page
    if (cleanRt && !cleanRt.includes('<')) {
        const criticsMatch = cleanRt.match(/Critics: (\d+)%/);
        const audienceMatch = cleanRt.match(/Audience: (\d+)%/);
        let displayHtml = "RT ";
        
        if (criticsMatch) {
            displayHtml += (parseInt(criticsMatch[1]) >= 60 ? '👍 ' : '👎 ') + criticsMatch[1] + '%';
        }
        if (audienceMatch) {
            displayHtml += ' / ' + (parseInt(audienceMatch[1]) >= 60 ? '👍 ' : '👎 ') + audienceMatch[1] + '%';
        }
        
        rtBadge.innerHTML = displayHtml;
        rtBadge.style.display = 'inline-block';
    }
    }).catch(() => { rtBadge.style.display = 'none'; });

    // --- 4. WIKIPEDIA URL FETCH ---
    const wikiLink = document.getElementById('wiki-link');
    const wikiHint = document.getElementById('wiki-hint');
    fetch(`${baseUrl}.url`)
        .then(res => res.text())
        .then(url => {
            const cleanUrl = url.trim();
            if (cleanUrl.startsWith('http')) {
                wikiLink.href = cleanUrl;
                wikiLink.style.pointerEvents = 'auto';
                wikiLink.style.cursor = 'pointer';
                wikiHint.style.display = 'block';
            }
        }).catch(() => { wikiLink.style.pointerEvents = 'none'; });

        // --- 5. MOVIE SYNOPSIS FETCH ---
const synopsisBox = document.getElementById('movie-synopsis');

// Add a timestamp to bypass browser caching
const cacheBuster = "?t=" + new Date().getTime();

fetch(`${baseUrl}.txt${cacheBuster}`) 
    .then(res => res.text())
    .then(text => {
    const cleanText = text.trim();
    const isHTML = cleanText.startsWith('<');
    
    if (!isHTML && cleanText.length > 10) {
        // It's a real synopsis 
        synopsisBox.innerText = cleanText.replace(/\[\d+\]/g, '');
        if (wikiHint) wikiHint.style.display = 'block';
        synopsisBox.style.display = 'block';
        setTimeout(() => {
            synopsisBox.style.opacity = '1';
        }, 10);
    } else {
        synopsisBox.style.display = 'none';
        if (wikiHint) wikiHint.style.display = 'none';
    }
    }).catch(() => { 
    synopsisBox.style.display = 'none'; 
    if (wikiHint) wikiHint.style.display = 'none';
    });
    }

    function showAudioPreview(previewContent, file, filename) {
    previewContent.innerHTML = `
        <div style="width: 100%; text-align: center;">
            <div style="font-size:8rem; margin-bottom:30px; filter: drop-shadow(0 0 20px rgba(243, 239, 230, 0.4));">🎵</div>
            <div style="width: 100%; display: flex; justify-content: center; padding: 0 20px;">
                <audio controls autoplay id="audio-player" style="width: 100%; max-width: 800px; height: 60px;"
                    onerror="document.getElementById('audio-error-msg').style.display='block'; this.style.display='none';">
                    <source src="${file}" type="audio/${file.split('.').pop()}">
                    Your browser does not support the audio tag.
                </audio>
                <div id="audio-error-msg" style="display:none; padding:20px; text-align:center; color:rgba(243,239,230,0.6); font-family:'Manrope',sans-serif; font-size:0.97rem; letter-spacing:2px;">
                    ⚠ MEDIA FILE CANNOT BE PLAYED
                </div>
            </div>
            <div style="width:100%; display:flex; justify-content:center; padding: 4px 20px 0 20px;">
                <div id="acb-toggle-pill" style="display:none;"><i class="acb-pill-chevron">▾</i> EQ &amp; FX</div>
            </div>
            <div style="width:100%; display:flex; justify-content:center; padding: 6px 20px 0 20px;">
                <div id="audio-controls-bar" style="width:100%; max-width:800px; flex-direction: column; gap: 0;">
                    <div class="acb-main-row">
                        <label for="eq-bass">BASS</label>
                        <input type="range" id="eq-bass" min="-12" max="12" step="1" value="0">
                        <span class="acb-val" id="bass-val">0dB</span>
                        <label for="eq-treble">TREBLE</label>
                        <input type="range" id="eq-treble" min="-12" max="12" step="1" value="0">
                        <span class="acb-val" id="treble-val">0dB</span>
                        <button id="btn-adv-toggle" class="acb-adv-toggle" title="Advanced audio effects">ADV ▾</button>
                    </div>
                    <div id="acb-advanced" class="acb-advanced-row" style="display:none;">
                        <button id="btn-normalise" title="Apply dynamic compression to even out volume">◎ NORM</button>
                        <button id="btn-night" class="acb-adv-btn" title="Cuts low-end rumble — good for late night viewing">🌙 NIGHT</button>
                        <button id="btn-dialogue" class="acb-adv-btn" title="Boosts speech frequencies — helps voices cut through">💬 DIALOGUE</button>
                    </div>
                </div>
            </div>
            <div class="preview-info" style="margin-top:15px;">
                <h3 style="font-size: 1.5rem; margin-bottom: 10px;">${stripExt(filename)}</h3>

            </div>
        </div>`;
    audioElement = document.getElementById('audio-player');

    if ('mediaSession' in navigator) {
        navigator.mediaSession.metadata = new MediaMetadata({
            title: stripExt(filename),
            artist: 'Mini-Pi Media'
        });
    }
    }

// 4. Integrated Keyboard Navigation & Media Controls
    document.addEventListener('keydown', (e) => {
        const t = e.target;
        if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;

        const items = document.querySelectorAll('.file-item');
        const media = document.querySelector('#video-player, #audio-player');
        const image = document.querySelector('#preview-content img');

        if (['ArrowRight', 'ArrowLeft', 'ArrowUp', 'ArrowDown'].includes(e.code)) {
            if (image && (e.code === 'ArrowRight' || e.code === 'ArrowLeft')) {
                e.preventDefault();
                if (e.code === 'ArrowRight' && currentImageIndex < imagePlaylist.length - 1) currentImageIndex++;
                else if (e.code === 'ArrowLeft' && currentImageIndex > 0) currentImageIndex--;
                showPreview(imagePlaylist[currentImageIndex].path, 'image', imagePlaylist[currentImageIndex].name);
            } 
            else if (media) {
                e.preventDefault();
                if (e.code === 'ArrowRight') media.currentTime = Math.min(media.currentTime + 5, media.duration || media.currentTime);
                if (e.code === 'ArrowLeft') media.currentTime = Math.max(media.currentTime - 5, 0);
                if (e.code === 'ArrowUp') media.volume = Math.min((media.volume || 0) + 0.1, 1);
                if (e.code === 'ArrowDown') media.volume = Math.max((media.volume || 0) - 0.1, 0);
            }
            else if (items.length > 0) {
                if (selectedIndex === -1) selectedIndex = 0;
                else if (e.code === 'ArrowRight') selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
                else if (e.code === 'ArrowLeft') selectedIndex = Math.max(selectedIndex - 1, 0);
                else if (e.code === 'ArrowUp') selectedIndex = Math.max(selectedIndex - 3, 0); 
                else if (e.code === 'ArrowDown') selectedIndex = Math.min(selectedIndex + 3, items.length - 1);

                items[selectedIndex].scrollIntoView({ behavior: 'smooth', block: 'center' });
                items[selectedIndex].click();
                e.preventDefault();
            }
        }

        if (e.code === 'Enter' || e.code === 'KeyF') {
            e.preventDefault();
            if (image) {
                if (image.requestFullscreen) image.requestFullscreen();
                else if (image.webkitRequestFullscreen) image.webkitRequestFullscreen();
            } else if (media && media.tagName === 'VIDEO') {
                if (!document.fullscreenElement) {
                    if (media.requestFullscreen) media.requestFullscreen();
                } else {
                    if (document.exitFullscreen) document.exitFullscreen();
                }
            } else if (selectedIndex !== -1) {
                items[selectedIndex].click();
            }
        }

        if (e.code === 'Space' && media) {
            e.preventDefault();
            media.paused ? media.play() : media.pause();
        }

        if (e.code === 'KeyA') {
            const video = document.getElementById('video-player');
            if (video) { e.preventDefault(); cycleAspect(); }
        }
    });

    // 5. Fullscreen Listeners & Initialization
    const handleExitFullscreen = () => {
        if (!document.fullscreenElement && !document.webkitFullscreenElement && imagePlaylist.length > 0 && currentImageIndex >= 0) {
            const imageData = imagePlaylist[currentImageIndex];
            showPreview(imageData.path, 'image', imageData.name);
        }
    };

    document.addEventListener('webkitfullscreenchange', handleExitFullscreen);

    // Fix: clicking the native fullscreen control button leaves browser focus
    // on that button, which causes ArrowLeft/ArrowRight to be swallowed by the
    // browser (navigating between native control buttons) instead of reaching
    // our document-level keydown handler for seeking. Blurring the video once
    // it enters fullscreen releases that focus so seek keys work as expected.
    document.addEventListener('fullscreenchange', () => {
        const video = document.getElementById('video-player');
        if (video && document.fullscreenElement === video) {
            video.blur();
        }
    });
    
    document.addEventListener('dblclick', (e) => {
        if (e.target.tagName === 'IMG' && e.target.closest('#preview-content')) {
            if (e.target.requestFullscreen) e.target.requestFullscreen();
            else if (e.target.webkitRequestFullscreen) e.target.webkitRequestFullscreen();
        }
    });

    // Essential: Page Load initialization
    window.onload = () => { 
        // Capture ?autoplay= BEFORE loadFiles() below calls history.pushState()
        // and rewrites the address bar to the plain /files path, which would
        // otherwise wipe this query string out from under us.
        var __autoplayParams = new URLSearchParams(window.location.search);
        var __autoplayPath = __autoplayParams.get('autoplay');

        loadBackgrounds(); 
        loadFiles(currentPath);

        // -- Remote cast: auto-play a file pushed from remote.html --
        // Called as /files/index.php?autoplay=<web path>, e.g.
        // /files/index.php?autoplay=/files/Video/Movies/Foo.mkv
        (function() {
            var autoplayPath = __autoplayPath;
            if (!autoplayPath) { return; }

            var filename = autoplayPath.split('/').pop();
            var ext = (filename.split('.').pop() || '').toLowerCase();
            var videoExts = APP_CONFIG.videoExts;
            var audioExts = APP_CONFIG.audioExts;

            var type = null;
            if (videoExts.indexOf(ext) !== -1) { type = 'video'; }
            else if (audioExts.indexOf(ext) !== -1) { type = 'audio'; }

            if (type) {
                // Mark this as a remote-cast session so the video player knows to
                // go fullscreen (CSS-based, since there's no click gesture here)
                // and to auto-return to index.html once the movie finishes.
                window.__isRemoteCast = true;

                setTimeout(function() {
                    showPreview(autoplayPath, type, filename);

                    if (type === 'video') {
                        document.body.classList.add('remote-cast-mode');

                        var vp = document.getElementById('video-player');
                        if (vp) {
                            // .preview / .file-list use backdrop-filter, which on
                            // several browser engines (including Fire TV Silk)
                            // creates a CSS containing block for position:fixed
                            // descendants — clipping our "fullscreen" video to
                            // that panel instead of the real viewport. Moving
                            // the element straight under <body> sidesteps that
                            // entirely; it keeps playing uninterrupted since
                            // it's the same element, just relocated in the DOM.
                            document.body.appendChild(vp);
                            vp.style.position   = 'fixed';
                            vp.style.top        = '0';
                            vp.style.left       = '0';
                            vp.style.width      = '100vw';
                            vp.style.height     = '100vh';
                            vp.style.maxHeight  = 'none';
                            vp.style.margin     = '0';
                            vp.style.borderRadius = '0';
                            vp.style.zIndex     = '999999';
                            vp.style.background = '#000';

                            // Try the real Fullscreen API too, in case this
                            // browser allows it without a user gesture. Harmless
                            // no-op if blocked — the styles above already cover
                            // the visual fullscreen either way.
                            var __fsAttempts = 0;
                            var __fsTimer = setInterval(function() {
                                __fsAttempts++;
                                if (vp.readyState > 0) {
                                    clearInterval(__fsTimer);
                                    var req = vp.requestFullscreen || vp.webkitRequestFullscreen;
                                    if (req) { req.call(vp).catch(function(){ /* blocked — inline styles still apply */ }); }
                                } else if (__fsAttempts > 30) { // ~3s safety timeout
                                    clearInterval(__fsTimer);
                                }
                            }, 100);
                        }
                    }

                    // A remote cast is a deliberate "play this now" action —
                    // don't leave the Resume/Start Over prompt sitting there
                    // waiting for someone to navigate it with a TV remote.
                    // Just resume automatically if it shows up.
                    var attempts = 0;
                    var autoResumeTimer = setInterval(function() {
                        attempts++;
                        var resumeUI = document.getElementById('resume-ui');
                        var resumeYes = document.getElementById('btn-resume-yes');
                        if (resumeUI && resumeYes && resumeUI.style.display === 'flex') {
                            resumeYes.click();
                            clearInterval(autoResumeTimer);
                        } else if (attempts > 50) { // ~5s safety timeout
                            clearInterval(autoResumeTimer);
                        }
                    }, 100);
                }, 300);
            }
        })();

        // -- XHR Upload with Progress Bar --
        const fileInput = document.getElementById('media_upload');
        const overlay   = document.getElementById('upload-overlay');
        const bar       = document.getElementById('upload-progress-bar');
        const pct       = document.getElementById('upload-progress-pct');
        const fnameEl   = document.getElementById('upload-modal-filename');

        if (fileInput && overlay) {
            fileInput.addEventListener('change', function() {
                const file = this.files[0];
                if (!file) return;

                const formData = new FormData();
                formData.append('media_upload', file);
                formData.append('upload_to', document.getElementById('upload_to_path').value);

                fnameEl.textContent = file.name;
                bar.style.width = '0%';
                pct.textContent = '0%';
                overlay.classList.add('active');

                const xhr = new XMLHttpRequest();

                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percent = Math.round((e.loaded / e.total) * 100);
                        bar.style.width = percent + '%';
                        pct.textContent = percent + '%';
                    }
                });

                xhr.addEventListener('load', function() {
                    bar.style.width = '100%';
                    pct.textContent = '100%';
                    setTimeout(function() {
                        overlay.classList.remove('active');
                        fileInput.value = '';
                        loadFiles(currentPath);
                    }, 600);
                });

                xhr.addEventListener('error', function() {
                    overlay.classList.remove('active');
                    alert('Upload failed. Please try again.');
                    fileInput.value = '';
                });

                xhr.open('POST', APP_CONFIG.webBase + '/index.php');
                xhr.send(formData);
            });
        }
        // ──────────────────────────────────────────────────────────────────
    };

    document.querySelector('.main-directory-link').onclick = (e) => { 
        e.preventDefault();
        document.getElementById('fileSearch').value = '';
        loadFiles(APP_CONFIG.webBase); 
    };
document.getElementById('fileSearch').addEventListener('input', function(e) {
    const term = e.target.value.toLowerCase();
    const items = document.querySelectorAll('.file-item');

    items.forEach(item => {
        const nameElement = item.querySelector('.file-name');
        if (nameElement) {
            const name = nameElement.textContent.toLowerCase();
            // Toggles visibility based on the search term
            item.style.display = name.includes(term) ? 'flex' : 'none';
        }
    });
});


// ── Aspect Ratio (shared — used by initBar button AND KeyA shortcut) ────────
const aspectModes  = ['fit', 'fill', 'stretch'];
const aspectLabels = { fit: '⛶ FIT', fill: '⛶ FILL', stretch: '⛶ STRETCH' };
const aspectFit    = { fit: 'contain', fill: 'cover', stretch: 'fill' };
let aspectMode = localStorage.getItem('aspectMode') || 'fit';

function applyAspect() {
    const videoEl = document.getElementById('video-player');
    if (videoEl) videoEl.style.objectFit = aspectFit[aspectMode];
    const aspectBtn = document.getElementById('btn-aspect');
    if (aspectBtn) {
        aspectBtn.textContent = aspectLabels[aspectMode];
        aspectBtn.classList.toggle('active', aspectMode !== 'fit');
    }
}

function cycleAspect() {
    aspectMode = aspectModes[(aspectModes.indexOf(aspectMode) + 1) % aspectModes.length];
    localStorage.setItem('aspectMode', aspectMode);
    applyAspect();
}
// ──────────────────────────────────────────────────────────────────────────

// ── Web Audio: Normalise + EQ ──────────────────────────────────────────────
(function() {
    let audioCtx = null, sourceNode = null, compressor = null, bassFilter = null, trebleFilter = null;
    let nightFilter = null, dialogueFilter = null, splitter = null, merger = null;
    let normLevel = parseInt(localStorage.getItem('normLevel') || '0'); // 0=off, 1=gentle, 2=heavy
    let bassVal  = parseFloat(localStorage.getItem('eqBass')   || '0');
    let trebleVal = parseFloat(localStorage.getItem('eqTreble') || '0');
    let nightOn    = localStorage.getItem('nightOn')    === '1';
    let dialogueOn = localStorage.getItem('dialogueOn') === '1';
    let wiredElement = null;

    const normPresets = [
        null, // 0 = off
        { threshold: -18, knee: 20, ratio: 4,  attack: 0.01,  release: 0.3  }, // 1 = gentle
        { threshold: -24, knee: 30, ratio: 12, attack: 0.003, release: 0.25 }  // 2 = heavy
    ];
    const normLabels = ['◎ NORM', '✓ GENTLE', '✓ HEAVY'];
    const normTitles = ['Off — click for gentle compression', 'Gentle — mild dynamic control, good for music', 'Heavy — strong levelling, good for films'];

    function applyNormPreset() {
        if (!compressor) return;
        const p = normPresets[normLevel];
        if (p) {
            compressor.threshold.value = p.threshold;
            compressor.knee.value      = p.knee;
            compressor.ratio.value     = p.ratio;
            compressor.attack.value    = p.attack;
            compressor.release.value   = p.release;
        }
    }

    function buildChain(mediaEl) {
        if (wiredElement === mediaEl) return;
        if (audioCtx) { try { audioCtx.close(); } catch(e){} }
        audioCtx   = new (window.AudioContext || window.webkitAudioContext)();
        sourceNode = audioCtx.createMediaElementSource(mediaEl);

        // EQ chain
        bassFilter   = audioCtx.createBiquadFilter();
        bassFilter.type = 'lowshelf';
        bassFilter.frequency.value = 150;
        bassFilter.gain.value = bassVal;

        trebleFilter = audioCtx.createBiquadFilter();
        trebleFilter.type = 'highshelf';
        trebleFilter.frequency.value = 8000;
        trebleFilter.gain.value = trebleVal;

        // Night mode — high-pass to cut rumble
        nightFilter = audioCtx.createBiquadFilter();
        nightFilter.type = 'highpass';
        nightFilter.frequency.value = nightOn ? 120 : 20;
        nightFilter.Q.value = 0.7;

        // Dialogue enhancer — peaking boost in speech band
        dialogueFilter = audioCtx.createBiquadFilter();
        dialogueFilter.type = 'peaking';
        dialogueFilter.frequency.value = 2500;
        dialogueFilter.Q.value = 0.8;
        dialogueFilter.gain.value = dialogueOn ? 4 : 0;

        // Stereo splitter/merger for future use — pass-through for now
        splitter = audioCtx.createChannelSplitter(2);
        merger   = audioCtx.createChannelMerger(2);

        compressor = audioCtx.createDynamicsCompressor();
        applyNormPreset();

        // Connect: source → bass → treble → night → dialogue → merger → (compressor →) destination
        sourceNode.connect(bassFilter);
        bassFilter.connect(trebleFilter);
        trebleFilter.connect(nightFilter);
        nightFilter.connect(dialogueFilter);
        dialogueFilter.connect(merger, 0, 0);
        dialogueFilter.connect(merger, 0, 1);

        if (normLevel > 0) {
            merger.connect(compressor);
            compressor.connect(audioCtx.destination);
        } else {
            merger.connect(audioCtx.destination);
        }

        wiredElement = mediaEl;
        if (audioCtx.state === 'suspended') audioCtx.resume();
    }

    function reconnect() {
        if (!audioCtx || !merger || !compressor) return;
        applyNormPreset();
        merger.disconnect();
        compressor.disconnect();
        if (normLevel > 0) {
            merger.connect(compressor);
            compressor.connect(audioCtx.destination);
        } else {
            merger.connect(audioCtx.destination);
        }
    }

    function updateSliderFill(slider, min, max) {
        const pct = ((parseFloat(slider.value) - min) / (max - min)) * 100;
        slider.style.backgroundImage =
            `linear-gradient(to right, #ff9142 ${pct}%, rgba(255,255,255,0.1) ${pct}%)`;
    }

    function initBar() {
        const bar  = document.getElementById('audio-controls-bar');
        const btn  = document.getElementById('btn-normalise');
        const bSlider = document.getElementById('eq-bass');
        const tSlider = document.getElementById('eq-treble');
        const bVal    = document.getElementById('bass-val');
        const tVal    = document.getElementById('treble-val');
        if (!bar || !btn || !bSlider || !tSlider) return;

        // Restore saved state
        btn.classList.toggle('active', normLevel > 0);
        btn.textContent = normLabels[normLevel];
        btn.title = normTitles[normLevel];
        bSlider.value = bassVal;
        tSlider.value = trebleVal;
        bVal.textContent  = (bassVal >= 0 ? '+' : '')  + bassVal   + 'dB';
        tVal.textContent  = (trebleVal >= 0 ? '+' : '') + trebleVal + 'dB';
        bVal.classList.toggle('at-zero', bassVal === 0);
        tVal.classList.toggle('at-zero', trebleVal === 0);
        updateSliderFill(bSlider, -12, 12);
        updateSliderFill(tSlider, -12, 12);

        // ── Advanced panel toggle ──────────────────────────────────────────
        const advToggle = document.getElementById('btn-adv-toggle');
        const advPanel  = document.getElementById('acb-advanced');
        const nightBtn  = document.getElementById('btn-night');
        const dlgBtn    = document.getElementById('btn-dialogue');
        const aspectBtn = document.getElementById('btn-aspect');
        if (!advToggle || !advPanel) return;

        // Aspect cycle: fit → fill → stretch
        applyAspect(); // Restore on load

        if (aspectBtn) aspectBtn.onclick = () => { cycleAspect(); };

        // Restore advanced state
        if (nightBtn)  { nightBtn.classList.toggle('active', nightOn); }
        if (dlgBtn)    { dlgBtn.classList.toggle('active', dialogueOn); }

        // Re-open panel if any advanced setting is active
        const anyAdvActive = nightOn || dialogueOn || aspectMode !== 'fit';
        if (anyAdvActive) {
            advPanel.style.display = 'flex';
            advToggle.textContent = 'ADV ▴';
            advToggle.classList.add('open');
        }

        advToggle.onclick = () => {
            const open = advPanel.style.display === 'flex';
            advPanel.style.display = open ? 'none' : 'flex';
            advToggle.textContent  = open ? 'ADV ▾' : 'ADV ▴';
            advToggle.classList.toggle('open', !open);
        };

        if (nightBtn) nightBtn.onclick = () => {
            nightOn = !nightOn;
            nightBtn.classList.toggle('active', nightOn);
            localStorage.setItem('nightOn', nightOn ? '1' : '0');
            if (nightFilter) nightFilter.frequency.value = nightOn ? 120 : 20;
        };

        if (dlgBtn) dlgBtn.onclick = () => {
            dialogueOn = !dialogueOn;
            dlgBtn.classList.toggle('active', dialogueOn);
            localStorage.setItem('dialogueOn', dialogueOn ? '1' : '0');
            if (dialogueFilter) dialogueFilter.gain.value = dialogueOn ? 4 : 0;
        };

        // Show pill, hide bar by default (unless already had it open)
        const pill = document.getElementById('acb-toggle-pill');
        if (pill) {
            pill.style.display = 'flex';
            const barOpen = localStorage.getItem('acbOpen') === '1';
            if (barOpen) {
                bar.style.display = 'flex';
                pill.classList.add('open');
            }
            pill.onclick = () => {
                const isOpen = bar.style.display === 'flex';
                if (isOpen) {
                    bar.style.display = 'none';
                    pill.classList.remove('open');
                    localStorage.setItem('acbOpen', '0');
                } else {
                    bar.style.display = 'flex';
                    pill.classList.add('open');
                    localStorage.setItem('acbOpen', '1');
                }
            };
        }

        // Wire up to whatever media element is present
        const mediaEl = document.getElementById('video-player') || document.getElementById('audio-player');
        if (mediaEl) {
            const wireOnce = () => { buildChain(mediaEl); mediaEl.removeEventListener('play', wireOnce); };
            if (!mediaEl.paused) { buildChain(mediaEl); }
            else { mediaEl.addEventListener('play', wireOnce); }
        }

        btn.onclick = () => {
            normLevel = (normLevel + 1) % 3;
            localStorage.setItem('normLevel', normLevel);
            btn.classList.toggle('active', normLevel > 0);
            btn.textContent = normLabels[normLevel];
            btn.title = normTitles[normLevel];
            reconnect();
        };

        bSlider.oninput = () => {
            bassVal = parseFloat(bSlider.value);
            bVal.textContent = (bassVal >= 0 ? '+' : '') + bassVal + 'dB';
            bVal.classList.toggle('at-zero', bassVal === 0);
            localStorage.setItem('eqBass', bassVal);
            if (bassFilter) bassFilter.gain.value = bassVal;
            updateSliderFill(bSlider, -12, 12);
        };
        const snapToZero = (slider, onUpdate) => {
            slider.addEventListener('change', () => {
                if (Math.abs(parseFloat(slider.value)) <= 1) {
                    slider.value = 0;
                    onUpdate();
                }
            });
        };
        snapToZero(bSlider, () => bSlider.dispatchEvent(new Event('input')));
        snapToZero(tSlider, () => tSlider.dispatchEvent(new Event('input')));

        tSlider.oninput = () => {
            trebleVal = parseFloat(tSlider.value);
            tVal.textContent = (trebleVal >= 0 ? '+' : '') + trebleVal + 'dB';
            tVal.classList.toggle('at-zero', trebleVal === 0);
            localStorage.setItem('eqTreble', trebleVal);
            if (trebleFilter) trebleFilter.gain.value = trebleVal;
            updateSliderFill(tSlider, -12, 12);
        };
    }

    // Hook into showPreview — observe DOM changes to detect when new player lands
    const observer = new MutationObserver(() => {
        const pill = document.getElementById('acb-toggle-pill');
        const bar  = document.getElementById('audio-controls-bar');
        if (bar && pill && pill.style.display !== 'flex') { initBar(); }
    });
    observer.observe(document.getElementById('preview-content') || document.body, { childList: true, subtree: true });
})();
// ──────────────────────────────────────────────────────────────────────────

// --- AMAZON FIRESTICK MEDIA KEY HANDLER ---
// Catches the play/pause button on the FireStick remote (and standard keyboards)
document.addEventListener('keydown', function(e) {
    // MediaPlayPause (keyCode 179) = physical play/pause button on FireStick remote
    // Space (keyCode 32) = spacebar on keyboard, also natural play/pause
    if (e.keyCode === 179 || e.code === 'MediaPlayPause') {
        const video = document.getElementById('video-player');
        const audio = document.getElementById('audio-player');
        const media = video || audio;
        if (media) {
            e.preventDefault();
            media.paused ? media.play() : media.pause();
        }
    }
});
