#!/bin/bash
#
# MKV to MP4 batch converter script to work on /var/lib/minidlna/Video. 
# Can be ran via bash or by the systemd mkv-converison timer.
# MKV to MP4 Converter with Hardware Acceleration and Auto Fallback to software encoding
#
# For Raspberry Pi (Zero 2 W and pi 4 using hardware GPU or PI 5 using software encoding).
# The MKV files if present in /var/lib/minidlna/Video folder will be batch process
# Once the MKV has been converted, it is removed as the converted MP4 file takes place of the MKV.
# Performance expected :-
# Pi zero with hardware encoding 2 threads to MP4 is about 8fps - if software encoding about 2fps.
# Pi 5 software encoding 2 threads is about 50fps - good for background encoding.
#
SOURCE_DIR="/var/lib/minidlna/Video"
LOCK_FILE="/tmp/mkv2mp4.lock"
ENCODER_HW="h264_v4l2m2m"
ENCODER_SW="libx264"

# Optimized quality settings for hardware encoder (based on testing)
HW_BITRATE="2M"           # Target bitrate 
HW_MAXRATE="3M"           # Maximum bitrate
HW_BUFSIZE="6M"           # Buffer size 
HW_GOP="30"               # Keyframe interval
HW_KEYINT_MIN="30"        # Minimum keyframe interval

# Prevent multiple instances
if [ -f "$LOCK_FILE" ]; then
    echo "Another MKV conversion process is already running. Exiting."
    exit 1
fi
touch "$LOCK_FILE"

cleanup() {
    rm -f "$LOCK_FILE"
}
trap cleanup EXIT

# Detect hardware acceleration
modprobe bcm2835-v4l2
if [ -e /dev/video10 ]; then
    HW_ACCEL_AVAILABLE=true
else
    HW_ACCEL_AVAILABLE=false
fi

# Function to get video bitrate for adaptive quality
get_video_bitrate() {
    local input_file="$1"
    ffprobe -v quiet -select_streams v:0 -show_entries stream=bit_rate -of csv=p=0 "$input_file" 2>/dev/null
}

# Function to get audio codec
get_audio_codec() {
    local input_file="$1"
    ffprobe -v quiet -select_streams a:0 -show_entries stream=codec_name -of csv=p=0 "$input_file" 2>/dev/null
}

# Function to get video codec
get_video_codec() {
    local input_file="$1"
    ffprobe -v quiet -select_streams v:0 -show_entries stream=codec_name -of csv=p=0 "$input_file" 2>/dev/null
}

# Function to determine audio encoding settings
get_audio_settings() {
    local audio_codec="$1"
    local hw_available="$2"
    case "$audio_codec" in
        "aac")
            echo "-c:a copy"
            return 0
            ;;
        *)
            if [ "$hw_available" = true ]; then
                # Use optimized AAC settings for hardware encoding
                echo "-c:a aac -b:a 128k"
            else
                # Software fallback - same bitrate for consistency
                echo "-c:a aac -b:a 128k"
            fi
            return 1
            ;;
    esac
}

# Function to determine video encoding settings
get_video_settings() {
    local video_codec="$1"
    local hw_available="$2"
    case "$video_codec" in
        "h264")
            echo "-c:v copy"
            return 0
            ;;
        *)
            if [ "$hw_available" = true ]; then
                # Optimized hardware encoding settings (no scaling for max performance)
                echo "-c:v $ENCODER_HW -pix_fmt yuv420p -b:v $HW_BITRATE -maxrate $HW_MAXRATE -bufsize $HW_BUFSIZE -g $HW_GOP -keyint_min $HW_KEYINT_MIN"
            else
                # SPEED OPTIMIZED software encoding with better quality - fixed bitrate for consistency
                echo "-c:v $ENCODER_SW -preset ultrafast -tune fastdecode -threads 2 -b:v 1500k -vf scale=960:540:flags=fast_bilinear -movflags +faststart"
            fi
            return 1
            ;;
    esac
}

# Process MKV files
for input in "$SOURCE_DIR"/*.mkv; do
    [ -e "$input" ] || continue
    
    base_name=$(basename "$input" .mkv)
    output="$SOURCE_DIR/$base_name.mp4"
    
    if [ -f "$output" ]; then
        echo "** Skipping: $base_name.mp4 already exists. **"
        continue
    fi
    
    echo "** Starting conversion: $base_name.mkv **"
    
    # Get source bitrate for adaptive encoding
    SOURCE_BITRATE=$(get_video_bitrate "$input")
    
    # Detect video and audio codecs
    VIDEO_CODEC=$(get_video_codec "$input")
    AUDIO_CODEC=$(get_audio_codec "$input")
    
    # Determine encoding strategies
    AUDIO_SETTINGS=$(get_audio_settings "$AUDIO_CODEC" "$HW_ACCEL_AVAILABLE")
    AUDIO_COPY=$?
    
    VIDEO_SETTINGS=$(get_video_settings "$VIDEO_CODEC" "$HW_ACCEL_AVAILABLE")
    VIDEO_COPY=$?
    
    # Display codec information
    if [ $VIDEO_COPY -eq 0 ]; then
        echo "* Video codec: $VIDEO_CODEC (copying stream - no re-encoding) *"
    else
        if [ "$HW_ACCEL_AVAILABLE" = true ]; then
            echo "* Video codec: $VIDEO_CODEC (re-encoding with optimized hardware encoder - no scaling) *"
        else
            echo "* Video codec: $VIDEO_CODEC (re-encoding with ULTRAFAST software encoder and scaling to 540p - fixed bitrate for better quality) *"
        fi
    fi
    
    if [ $AUDIO_COPY -eq 0 ]; then
        echo "* Audio codec: $AUDIO_CODEC (copying stream) *"
    else
        echo "* Audio codec: $AUDIO_CODEC (re-encoding to AAC 128k) *"
    fi
    
    # Adjust hardware encoding bitrate based on source (only if re-encoding with hardware)
    if [ "$VIDEO_COPY" -ne 0 ] && [ "$HW_ACCEL_AVAILABLE" = true ] && [ -n "$SOURCE_BITRATE" ] && [ "$SOURCE_BITRATE" != "N/A" ]; then
        # Check if SOURCE_BITRATE is numeric
        if [[ "$SOURCE_BITRATE" =~ ^[0-9]+$ ]]; then
            # Use 70% of source bitrate, with minimum of 1.5M and maximum of 4M
            ADAPTIVE_BITRATE=$((SOURCE_BITRATE * 70 / 100))
            if [ "$ADAPTIVE_BITRATE" -lt 1500000 ]; then
                ADAPTIVE_BITRATE="1500000"
            elif [ "$ADAPTIVE_BITRATE" -gt 4000000 ]; then
                ADAPTIVE_BITRATE="4000000"
            fi
            HW_BITRATE="${ADAPTIVE_BITRATE}"
            HW_MAXRATE=$((ADAPTIVE_BITRATE * 150 / 100))
            HW_BUFSIZE=$((HW_MAXRATE * 2))
            
            # Update video settings with new bitrate (hardware only)
            VIDEO_SETTINGS="-c:v $ENCODER_HW -pix_fmt yuv420p -b:v $HW_BITRATE -maxrate $HW_MAXRATE -bufsize $HW_BUFSIZE -g $HW_GOP -keyint_min $HW_KEYINT_MIN"
            echo "* Adaptive bitrate: ${HW_BITRATE}bps (source: ${SOURCE_BITRATE}bps) *"
        else
            echo "* Warning: Invalid bitrate ($SOURCE_BITRATE) for $base_name.mkv, using default bitrate *"
        fi
    fi
    
    # Temporary file to capture FFmpeg output
    TEMP_LOG=$(mktemp)
    
    # Single FFmpeg command with determined settings
    ffmpeg -hide_banner -y -threads 2 -i "$input" \
        $VIDEO_SETTINGS \
        $AUDIO_SETTINGS \
        "$output" 2> "$TEMP_LOG"
        
    if [ $? -ne 0 ] && [ "$VIDEO_COPY" -ne 0 ] && [ "$HW_ACCEL_AVAILABLE" = true ]; then
        echo "* Hardware encoding failed for $base_name.mkv. FFmpeg error log:"
        cat "$TEMP_LOG"
        echo "* Falling back to software encoding. *"
        rm -f "$output"
        VIDEO_SETTINGS=$(get_video_settings "$VIDEO_CODEC" false)
        AUDIO_SETTINGS=$(get_audio_settings "$AUDIO_CODEC" false)
        ffmpeg -hide_banner -y -threads 2 -i "$input" \
            $VIDEO_SETTINGS \
            $AUDIO_SETTINGS \
            "$output" 2> "$TEMP_LOG"
    fi
    
    if [ $? -eq 0 ]; then
        # Extract the final fps value from FFmpeg output using a more compatible method
        FPS=$(grep -o 'fps=[0-9]*\.[0-9]*\|fps=[0-9]*' "$TEMP_LOG" | tail -1 | cut -d'=' -f2)
        if [ -z "$FPS" ]; then
            FPS="unknown"
        fi
        
        # Get output file size for quality assessment
        OUTPUT_SIZE=$(du -h "$output" | cut -f1)
        echo "** Successfully converted: $base_name.mkv to $base_name.mp4 at an average $FPS fps (Size: $OUTPUT_SIZE) **"
        rm -f "$input"
    else
        echo "* Failed to convert: $base_name.mkv *"
        [ -f "$output" ] && rm -f "$output"
    fi
    
    # Clean up temporary log file
    rm -f "$TEMP_LOG"
done

chmod -R 775 /var/lib/minidlna
chown -R minidlna:minidlna /var/lib/minidlna
echo "*** MKV to MP4 conversion complete for all files. ***"
