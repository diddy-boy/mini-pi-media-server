<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');

$picturesDir = '/var/lib/minidlna/Pictures';
$webPath = '/Pictures'; // This should match your Apache alias for the Pictures directory

// Supported image and video formats
$imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
$videoExtensions = ['mp4', 'webm', 'ogg', 'mov', 'avi', 'mkv'];

$backgrounds = [];

// Add default gradient background
$backgrounds[] = [
    'src' => 'gradient',
    'type' => 'gradient',
    'name' => 'Default Gradient'
];

try {
    if (!is_dir($picturesDir)) {
        throw new Exception("Pictures directory not found: $picturesDir");
    }

    // Get all files from the Pictures directory
    $files = scandir($picturesDir);
    
    if ($files === false) {
        throw new Exception("Could not scan Pictures directory");
    }

    foreach ($files as $file) {
        // Skip hidden files and directories
        if ($file === '.' || $file === '..' || $file[0] === '.') {
            continue;
        }
        
        $filePath = $picturesDir . '/' . $file;
        
        // Only process regular files
        if (!is_file($filePath)) {
            continue;
        }
        
        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $fileName = pathinfo($file, PATHINFO_FILENAME);
        
        if (in_array($extension, $imageExtensions)) {
            $backgrounds[] = [
                'src' => $webPath . '/' . $file,
                'type' => 'image',
                'name' => $fileName
            ];
        } elseif (in_array($extension, $videoExtensions)) {
            $backgrounds[] = [
                'src' => $webPath . '/' . $file,
                'type' => 'video',
                'name' => $fileName
            ];
        }
    }
    
    // Sort backgrounds by name (keeping gradient first)
    $gradient = array_shift($backgrounds);
    usort($backgrounds, function($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
    array_unshift($backgrounds, $gradient);
    
} catch (Exception $e) {
    error_log("Error loading backgrounds: " . $e->getMessage());
    // Return only the gradient background if there's an error
}

echo json_encode([
    'success' => true,
    'backgrounds' => $backgrounds,
    'count' => count($backgrounds)
]);
