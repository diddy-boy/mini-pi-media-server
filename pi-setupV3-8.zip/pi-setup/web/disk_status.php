<?php
header('Content-Type: application/json');

// Get disk space information
$free_space = disk_free_space("/");
$total_space = disk_total_space("/");
$free_percentage = ($total_space > 0) ? ($free_space / $total_space) * 100 : 0;

// Get CPU Temperature (Works on Zero 2 W, Pi 4, and Pi 5)
$temp = shell_exec("cat /sys/class/thermal/thermal_zone0/temp");
$temp_c = round($temp / 1000, 1);

function count_files($path) {
    if (!is_dir($path)) return 0;
    $output = shell_exec("find " . escapeshellarg($path) . " -type f | wc -l");
    return intval(trim($output));
}

$response = [
    'low_disk' => $free_percentage < 5,
    'free_percentage' => floor($free_percentage),
    'cpu_temp' => $temp_c, // Added temperature to response
    'counts' => [
        'Music' => count_files('/var/lib/minidlna/Music'),
        'Pictures' => count_files('/var/lib/minidlna/Pictures'),
        'Video' => count_files('/var/lib/minidlna/Video')
    ]
];

echo json_encode($response);
?>
