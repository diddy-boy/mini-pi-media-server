<?php
// get_files.php - DEBUG VERSION
error_reporting(E_ALL);
ini_set('display_errors', 0); // Prevent PHP errors from breaking JSON
ini_set('log_errors', 1);
ini_set('error_log', '/var/log/php_errors.log'); // Adjust path as needed

// Start debugging
$debug_info = [];
$debug_info['script_running'] = true;
$debug_info['request_uri'] = $_SERVER['REQUEST_URI'];
$debug_info['get_params'] = $_GET;
$debug_info['timestamp'] = date('Y-m-d H:i:s');

// Configuration
$base_dir = '/var/lib/minidlna';
$web_base = '/files';
$hidden_extensions = ['php', 'env', 'srt', 'db', 'm3u'];

// Debug the paths
$dir_path = isset($_GET['path']) ? $_GET['path'] : '';
$relative_path = trim(str_replace($web_base, '', $dir_path), '/');
$current_dir = $base_dir . ($relative_path ? '/' . $relative_path : '');
$debug_info['dir_path_from_get'] = $dir_path;
$debug_info['relative_path'] = $relative_path;
$debug_info['current_dir_calculated'] = $current_dir;
$debug_info['current_dir_exists'] = is_dir($current_dir);
$debug_info['current_dir_readable'] = is_readable($current_dir);

// File extensions
$image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
$video_extensions = ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm'];
$audio_extensions = ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'];

function get_file_extension($filename) {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

function format_file_size($bytes) {
    if ($bytes === false) return 'Unknown';
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

function get_web_path($file_path, $base_dir, $web_base) {
    $relative = trim(str_replace($base_dir, '', $file_path), '/');
    return $web_base . ($relative ? '/' . $relative : '');
}

function get_thumbnail_path($video_path) {
    $thumbnail_dir = dirname($video_path) . '/.thumbnails/';
    $filename = pathinfo($video_path, PATHINFO_FILENAME);
    $thumbnail_path = $thumbnail_dir . $filename . '.jpg';
    if (file_exists($thumbnail_path) && is_readable($thumbnail_path)) {
        return get_web_path($thumbnail_path, $GLOBALS['base_dir'], $GLOBALS['web_base']);
    }
    return null;
}

function get_directory_icon($dir_path, $image_extensions, $video_extensions, $audio_extensions, $hidden_extensions) {
    $items = @scandir($dir_path);
    if ($items === false) {
        $GLOBALS['debug_info']['directory_icon_error'] = "Failed to scan directory for icon: $dir_path";
        error_log("get_files.php - Failed to scan directory for icon: $dir_path");
        return '📁';
    }

    $has_images = false;
    $has_videos = false;
    $has_audio = false;
    $has_other = false;

    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item[0] === '.') continue;
        $item_path = $dir_path . '/' . $item;
        $extension = get_file_extension($item);
        if (in_array($extension, $hidden_extensions)) continue;

        if (is_dir($item_path)) {
            continue;
        } elseif (in_array($extension, $image_extensions)) {
            $has_images = true;
        } elseif (in_array($extension, $video_extensions)) {
            $has_videos = true;
        } elseif (in_array($extension, $audio_extensions)) {
            $has_audio = true;
        } else {
            $has_other = true;
        }
    }

    $debug_info = [
        'dir_path' => $dir_path,
        'has_images' => $has_images,
        'has_videos' => $has_videos,
        'has_audio' => $has_audio,
        'has_other' => $has_other
    ];
    $GLOBALS['debug_info']['directory_icon_checks'][] = $debug_info;

    if ($has_images && !$has_videos && !$has_audio && !$has_other) {
        return '📷';
    } elseif ($has_videos && !$has_images && !$has_audio && !$has_other) {
        return '🎥';
    } elseif ($has_audio && !$has_images && !$has_videos && !$has_other) {
        return '🎵';
    } else {
        return '📁';
    }
}

// Security check
$real_base = realpath($base_dir);
$real_current = realpath($current_dir);
$debug_info['real_base'] = $real_base ?: 'null';
$debug_info['real_current'] = $real_current ?: 'null';

if (!$real_base) {
    $debug_info['error'] = 'Base directory does not exist or is not resolvable';
    error_log("get_files.php - Base directory not resolvable: $base_dir");
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Server configuration error', 'debug' => $debug_info]);
    exit;
}

if (!$real_current || strpos($real_current, $real_base) !== 0) {
    $debug_info['security_check'] = 'failed';
    error_log("get_files.php - Security check failed: Current dir $current_dir not within $real_base");
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid directory', 'debug' => $debug_info]);
    exit;
}

// Get both directories and files
$directories = [];
$files = [];

if (is_dir($current_dir)) {
    $items = @scandir($current_dir);
    if ($items === false) {
        $debug_info['error'] = 'Failed to scan directory';
        error_log("get_files.php - Failed to scan directory: $current_dir");
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Unable to read directory', 'debug' => $debug_info]);
        exit;
    }
    
    $debug_info['items_found'] = count($items);
    $debug_info['skipped_files'] = [];
    
    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item[0] === '.') {
            $debug_info['skipped_files'][] = "Skipping hidden file/dir: $item (dot-prefixed)";
            error_log("get_files.php - Skipping hidden file/dir: $item (dot-prefixed)");
            continue;
        }
        $item_path = $current_dir . '/' . $item;
        $extension = get_file_extension($item);
        if (in_array($extension, $hidden_extensions)) {
            $debug_info['skipped_files'][] = "Skipping hidden file: $item (Extension: $extension)";
            error_log("get_files.php - Skipping hidden file: $item (Extension: $extension)");
            continue;
        }
        
        if (is_dir($item_path)) {
            $icon = get_directory_icon($item_path, $image_extensions, $video_extensions, $audio_extensions, $hidden_extensions);
            $directories[] = [
                'name' => $item,
                'web_path' => get_web_path($item_path, $base_dir, $web_base),
                'is_dir' => true,
                'icon' => $icon
            ];
        } else {
            $size = @filesize($item_path);
            if ($size === false) {
                $debug_info['skipped_files'][] = "Skipping file due to filesize error: $item";
                error_log("get_files.php - Failed to get filesize: $item_path");
                continue;
            }
            $files[] = [
                'name' => $item,
                'web_path' => get_web_path($item_path, $base_dir, $web_base),
                'size' => format_file_size($size),
                'extension' => $extension,
                'thumbnail' => in_array($extension, $video_extensions) ? get_thumbnail_path($item_path) : null,
                'is_dir' => false
            ];
        }
    }
    
    $debug_info['directories_found'] = count($directories);
    $debug_info['files_found'] = count($files);
} else {
    $debug_info['error'] = 'Directory does not exist or is not readable';
    error_log("get_files.php - Directory not found or unreadable: $current_dir");
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Directory not found', 'debug' => $debug_info]);
    exit;
}

// Sort directories and files
usort($directories, function($a, $b) {
    return strcasecmp($a['name'], $b['name']);
});
usort($files, function($a, $b) {
    return strcasecmp($a['name'], $b['name']);
});

header('Content-Type: application/json');
$response = [
    'directories' => $directories, 
    'files' => $files,
    'debug' => $debug_info
];

$json_output = json_encode($response, JSON_PRETTY_PRINT);
if ($json_output === false) {
    $debug_info['error'] = 'Failed to encode JSON';
    error_log("get_files.php - JSON encoding failed: " . json_last_error_msg());
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Server error: JSON encoding failed', 'debug' => $debug_info]);
    exit;
}

echo $json_output;
?>
