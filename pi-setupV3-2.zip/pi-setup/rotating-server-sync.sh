#!/bin/bash
#
# Server Media Sync with dialog and progress bar
#
# Syncs media files modified within a user-specified number of months from a Samba server share
# to a local minidlna folder (flat structure). Deletes local files older than that range.
# Uses dialog for user interaction and shows rsync output during sync.
#

# Configuration file path (relative to script directory)
SCRIPT_DIR="$(dirname "$(realpath "$0")")"
CONFIG_FILE="$SCRIPT_DIR/.samba_film_sync.conf"

# Default config values
SAMBA_SHARE="//192.168.8.10/Films"
SAMBA_USER="username"
SAMBA_PASS=""
DEST_DIR="/var/lib/minidlna/Video"
MONTHS=3
MOUNT_POINT="/mnt/samba_share"

# Check dependencies
if ! command -v rsync &>/dev/null; then
    dialog --msgbox "'rsync' is not installed. Please install it before running." 7 50
    exit 1
fi

if ! command -v mount.cifs &>/dev/null; then
    dialog --msgbox "'cifs-utils' is not installed. Please install it before running." 7 60
    exit 1
fi

# Load config
load_config() {
    if [ -f "$CONFIG_FILE" ]; then
        source "$CONFIG_FILE"
    fi
}

# Save config
save_config() {
    cat > "$CONFIG_FILE" << EOF
SAMBA_SHARE="$SAMBA_SHARE"
SAMBA_USER="$SAMBA_USER"
SAMBA_PASS="$SAMBA_PASS"
DEST_DIR="$DEST_DIR"
MONTHS=$MONTHS
EOF
    chmod 600 "$CONFIG_FILE"
}

# Configure setup menu
configure_setup() {
    while true; do
        CHOICE=$(dialog --clear --backtitle "Rotational Server Media Sync - Configure Setup" \
            --menu "Current Configuration:\n
Samba Share: $SAMBA_SHARE
Username: $SAMBA_USER
Password: [hidden]
Destination: $DEST_DIR
Months to Keep: $MONTHS

Select option to edit:" 15 90 7 \
            1 "Server Share Path" \
            2 "Server Username" \
            3 "Server Password" \
            4 "Local Destination Directory" \
            5 "How many months back do you want to sync Media from" \
            0 "Save and continue" \
            3>&1 1>&2 2>&3)

        case $CHOICE in
            1)
                input=$(dialog --inputbox "Enter Server Share Path (e.g., //192.168.8.10/Films):" 10 60 "$SAMBA_SHARE" 3>&1 1>&2 2>&3)
                if [ -n "$input" ]; then SAMBA_SHARE="$input"; fi
                ;;
            2)
                input=$(dialog --inputbox "Enter a Username to access this server:" 10 50 "$SAMBA_USER" 3>&1 1>&2 2>&3)
                if [ -n "$input" ]; then SAMBA_USER="$input"; fi
                ;;
            3)
                input=$(dialog --insecure --passwordbox "What Password is used to access this server:" 10 50 3>&1 1>&2 2>&3)
                if [ -n "$input" ]; then SAMBA_PASS="$input"; fi
                ;;
            4)
                dest_choice=$(dialog --menu "Select destination directory:" 10 50 3 \
                    1 "/var/lib/minidlna/Video" \
                    2 "/var/lib/minidlna/Music" \
                    3 "/var/lib/minidlna/Pictures" \
                    3>&1 1>&2 2>&3)
                case $dest_choice in
                    1) DEST_DIR="/var/lib/minidlna/Video" ;;
                    2) DEST_DIR="/var/lib/minidlna/Music" ;;
                    3) DEST_DIR="/var/lib/minidlna/Pictures" ;;
                esac
                ;;
            5)
                input=$(dialog --inputbox "How many months back do you want to syncronise media files from :" 8 50 "$MONTHS" 3>&1 1>&2 2>&3)
                if [[ "$input" =~ ^[1-9][0-9]*$ ]]; then
                    MONTHS="$input"
                else
                    dialog --msgbox "Invalid input. Please enter a number of months to sync within" 10 60
                fi
                ;;
            0)
                save_config
                # Show summary of user options
    		summary="Syncronise files from server: $SAMBA_SHARE\nWith a Username of: $SAMBA_USER\nTo the Destination Directory of: $DEST_DIR\nOnly syncronise media in the past: $MONTHS Months"
    		dialog --title "Summary of Settings" --msgbox "$summary" 15 60
                dialog --yesno "Run synchronisation now?" 10 60
                if [ $? -eq 0 ]; then
                    run_sync
                fi
                break
                ;;
            *)
                ;;
        esac
    done
}

# Run sync with rsync output
run_sync() {
    # Calculate days from months (approximate)
    DAYS=$(echo "$MONTHS * 30.42" | bc | cut -d. -f1)
    if ! [[ "$DAYS" =~ ^[0-9]+$ ]] || [ "$DAYS" -lt 1 ]; then
        DAYS=91
    fi

    mkdir -p "$MOUNT_POINT"
    mkdir -p "$DEST_DIR"

    # Check write permissions
    if [ ! -w "$DEST_DIR" ]; then
        dialog --msgbox "No write permission to $DEST_DIR. Run with sudo or fix permissions." 10 60
        return 1
    fi

    # Mount Samba share
    if mountpoint -q "$MOUNT_POINT"; then
        mounted=1
    else
        # Create temp credentials file
        CRED_FILE=$(mktemp)
        echo -e "username=$SAMBA_USER\npassword=$SAMBA_PASS" > "$CRED_FILE"
        chmod 600 "$CRED_FILE"
        sudo mount -t cifs "$SAMBA_SHARE" "$MOUNT_POINT" -o credentials="$CRED_FILE",vers=3.0,nounix,iocharset=utf8
        status=$?
        rm -f "$CRED_FILE"
        if [ $status -ne 0 ]; then
            dialog --msgbox "Failed to mount Server share. Check credentials and network." 10 60
            return 1
        fi
        mounted=0
    fi

    # Check mount is readable and has files
    if [ ! -r "$MOUNT_POINT" ] || [ -z "$(ls -A "$MOUNT_POINT")" ]; then
        dialog --msgbox "Mount point $MOUNT_POINT is unreadable or empty. Aborting." 10 60
        if [ $mounted -eq 0 ]; then
            sudo umount "$MOUNT_POINT"
        fi
        return 1
    fi

    # Delete old files
    dialog --title "Cleanup" --infobox "Deleting files older than $MONTHS months ($DAYS days) in $DEST_DIR..." 10 60
    find "$DEST_DIR" -type f -mtime +"$DAYS" -exec rm -f {} \;

    # Find files modified within DAYS on the mounted share
    mapfile -d '' files < <(find "$MOUNT_POINT" -type f -mtime -"$DAYS" -print0)

    total_files=${#files[@]}
    if [ "$total_files" -eq 0 ]; then
        dialog --msgbox "No files found on server modified within $MONTHS months." 10 60
        [ $mounted -eq 0 ] && sudo umount "$MOUNT_POINT"
        return 0
    fi
	clear
    for src_file in "${files[@]}"; do
        filename=$(basename "$src_file")
        rsync -av --progress --inplace --ignore-existing -z --exclude='.*' --exclude='*.mkv' --ignore-existing "$src_file" "$DEST_DIR/$filename"
    done

    [ $mounted -eq 0 ] && sudo umount "$MOUNT_POINT"

    dialog --title "Sync Complete" --msgbox "Synchronisation completed successfully." 10 60
}

# Main menu
load_config
while true; do
    choice=$(dialog --clear --backtitle "Rotational Server Media Sync" --menu "Select an option:" 12 50 4 \
        1 "Create/Edit Setup" \
        2 "Run Synchronisation Now" \
        3 "Exit" \
        3>&1 1>&2 2>&3)

    case $choice in
        1) configure_setup ;;
        2) run_sync ;;
        3) clear; exit 0 ;;
        *) dialog --msgbox "Invalid option. Please choose 1-3." 10 60 ;;
    esac
done
