#!/bin/bash
#
# USB-to-MiniDLNA Sync Script
# Detects, mounts, and syncs files from a USB drive to /var/lib/minidlna
# Skips existing files and refreshes MiniDLNA after sync
#

# Config
DEST="/var/lib/minidlna/"
MOUNT_POINT="/media/usb"

# Ensure root privileges
if [ "$EUID" -ne 0 ]; then
  echo "** Error: Please run this script with sudo. **"
  exit 1
fi

# Check destination exists
if [ ! -d "$DEST" ]; then
  echo "** Error: Destination directory $DEST does not exist. **"
  exit 1
fi

# Create mount point if needed
mkdir -p "$MOUNT_POINT" || { echo "** Error: Cannot create mount point $MOUNT_POINT. **"; exit 1; }

# Wait briefly for USB device enumeration
sleep 2

# Detect USB storage device (removable or USB transport, exclude root device)
USB_DEVICE=$(lsblk -d -o NAME,RM,TRAN | awk '
  ($2 == "1" || $3 == "usb") && $1 !~ /^loop/ {print $1}
' | grep -vE "mmcblk|nvme" | while read -r disk; do
    if ! mount | grep -q "/dev/$disk on / "; then
        echo "$disk"
    fi
done | head -n 1)

if [ -z "$USB_DEVICE" ]; then
  echo "** Error: No USB device detected. **"
  exit 1
fi
USB_DEVICE="/dev/$USB_DEVICE"
echo "Detected USB device: $USB_DEVICE"

# Detect first supported partition
USB_PARTITION=$(lsblk -l -o NAME,FSTYPE | grep "^${USB_DEVICE##*/}[0-9]" \
  | grep -E "vfat|exfat|ext[2-4]|ntfs" | awk '{print $1}' | head -n 1)

if [ -z "$USB_PARTITION" ] || [ ! -b "/dev/$USB_PARTITION" ]; then
  echo "** Error: No valid partitions found. **"
  exit 1
fi
USB_PARTITION="/dev/$USB_PARTITION"

# Check if already mounted elsewhere
if mount | grep -q "$USB_PARTITION" && ! mountpoint -q "$MOUNT_POINT"; then
  echo "** Error: Partition $USB_PARTITION is already mounted elsewhere. **"
  exit 1
fi

# Filesystem check (non-destructive)
fsck -n "$USB_PARTITION" >/dev/null 2>&1 || {
  echo "** Filesystem errors detected. Repairing... **"
  fsck -y "$USB_PARTITION" || { echo "** Error: Filesystem repair failed. **"; exit 1; }
}

# Mount if not already
if ! mountpoint -q "$MOUNT_POINT"; then
  mount "$USB_PARTITION" "$MOUNT_POINT" || { echo "** Error: Failed to mount $USB_PARTITION. **"; exit 1; }
  echo "********** Mounted $USB_PARTITION at $MOUNT_POINT **********"
fi

# Verify source has content
if [ -z "$(ls -A "$MOUNT_POINT")" ]; then
  echo "** Error: Source $MOUNT_POINT is empty. **"
  umount "$MOUNT_POINT" 2>/dev/null
  exit 1
fi

# Sync with progress
echo "Syncing files from $MOUNT_POINT to $DEST..."
rsync -av --progress --inplace --whole-file --ignore-existing --exclude='.*' --info=NAME,PROGRESS2 "$MOUNT_POINT/" "$DEST" \
  | stdbuf -oL sed 's/^/Synced: /'

if [ ${PIPESTATUS[0]} -eq 0 ]; then
  echo "********** Sync completed successfully. **********"
else
  echo "** Error: Sync failed. **"
  umount "$MOUNT_POINT" 2>/dev/null
  exit 1
fi

# Unmount
sync
sleep 1
if umount "$MOUNT_POINT"; then
  echo "********** Unmounted from $MOUNT_POINT. SAFE TO REMOVE USB. **********"
else
  echo "** Error: Failed to unmount $MOUNT_POINT. **"
fi

# Refresh MiniDLNA
systemctl restart minidlna && echo "MiniDLNA refreshed."

exit 0
