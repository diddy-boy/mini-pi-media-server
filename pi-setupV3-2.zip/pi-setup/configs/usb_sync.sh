#!/bin/bash
#
# USB-to-MiniDLNA Sync Script (Raspberry Pi Fixed)
# Detects, mounts, and syncs files from a USB drive to /var/lib/minidlna
# Skips existing files and refreshes MiniDLNA after sync
#
# Config
DEST="/var/lib/minidlna/"
MOUNT_POINT="/media/usb"

# Ensure root privileges
if [ "$EUID" -ne 0 ]; then
  echo "** Error: Please run this script with sudo. **"
  exit 1
fi

# Check destination exists
if [ ! -d "$DEST" ]; then
  echo "** Error: Destination directory $DEST does not exist. **"
  exit 1
fi

# Create mount point if needed
mkdir -p "$MOUNT_POINT" || { echo "** Error: Cannot create mount point $MOUNT_POINT. **"; exit 1; }

# Wait briefly for USB device enumeration
sleep 2

echo "Scanning for USB devices..."

# More reliable USB detection for Raspberry Pi (handles NVMe boot drives)
# Method 1: Find USB storage devices, excluding the boot device
USB_DEVICE=""

# Get the boot device (where root filesystem is mounted)
BOOT_DEVICE=$(mount | grep ' on / ' | cut -d' ' -f1 | sed 's/[0-9]*$//')
echo "Boot device detected: $BOOT_DEVICE"

# Find all USB-connected storage devices
for device in /sys/block/sd*; do
    if [ -e "$device" ]; then
        device_name=$(basename "$device")
        device_path="/dev/$device_name"
        
        # Skip if this is the boot device
        if [ "$device_path" = "$BOOT_DEVICE" ]; then
            echo "Skipping boot device: $device_path"
            continue
        fi
        
        # Check if this device is connected via USB
        if [ -L "/sys/block/$device_name" ]; then
            device_sysfs_path=$(readlink -f "/sys/block/$device_name")
            if echo "$device_sysfs_path" | grep -q "/usb"; then
                USB_DEVICE="$device_path"
                echo "Found USB device via sysfs: $USB_DEVICE (not boot device)"
                break
            fi
        fi
    fi
done

# Method 2: If Method 1 didn't work, try removable device detection
if [ -z "$USB_DEVICE" ]; then
    echo "Trying alternative USB detection..."
    
    # Look for mass storage devices that are removable and not the boot device
    for device in /dev/sd*; do
        if [ -b "$device" ] && [[ "$device" =~ /dev/sd[a-z]$ ]]; then
            device_name=$(basename "$device")
            
            # Skip boot device
            if [ "$device" = "$BOOT_DEVICE" ]; then
                echo "Skipping boot device: $device"
                continue
            fi
            
            # Check if it's removable
            if [ -f "/sys/block/$device_name/removable" ]; then
                removable=$(cat "/sys/block/$device_name/removable")
                if [ "$removable" = "1" ]; then
                    USB_DEVICE="$device"
                    echo "Found removable device: $USB_DEVICE (not boot device)"
                    break
                fi
            fi
        fi
    done
fi

# Method 3: Manual detection prompt if automatic methods fail
if [ -z "$USB_DEVICE" ]; then
    echo "Automatic USB detection failed. Available block devices:"
    lsblk -d -o NAME,SIZE,TRAN,TYPE,MOUNTPOINT,RM | grep -v "loop"
    echo ""
    echo "Boot device: $BOOT_DEVICE"
    echo ""
    echo "Available storage devices (excluding boot device):"
    for dev in /dev/sd*; do
        if [ -b "$dev" ] && [[ "$dev" =~ /dev/sd[a-z]$ ]] && [ "$dev" != "$BOOT_DEVICE" ]; then
            echo "  $dev - $(lsblk -dno SIZE,MODEL "$dev" 2>/dev/null || echo "Unknown")"
        fi
    done
    echo ""
    echo "Please check if your USB drive is properly connected and try again."
    echo "If you see your USB drive listed above, there might be an issue with automatic detection."
    exit 1
fi

echo "Selected USB device: $USB_DEVICE"

# Detect first supported partition
USB_PARTITION=$(lsblk -l -o NAME,FSTYPE "$USB_DEVICE" 2>/dev/null | grep "^${USB_DEVICE##*/}[0-9]" \
  | grep -E "vfat|exfat|ext[2-4]|ntfs" | awk '{print $1}' | head -n 1)

if [ -z "$USB_PARTITION" ]; then
    echo "** Error: No valid partitions found on $USB_DEVICE **"
    echo "Partition table:"
    lsblk "$USB_DEVICE" 2>/dev/null || fdisk -l "$USB_DEVICE" 2>/dev/null
    exit 1
fi

USB_PARTITION="/dev/$USB_PARTITION"
echo "Using partition: $USB_PARTITION"

# Check filesystem type
FS_TYPE=$(lsblk -no FSTYPE "$USB_PARTITION" 2>/dev/null)
echo "Filesystem type: $FS_TYPE"

# Check if already mounted elsewhere
if mount | grep -q "$USB_PARTITION" && ! mountpoint -q "$MOUNT_POINT"; then
  echo "** Error: Partition $USB_PARTITION is already mounted elsewhere: **"
  mount | grep "$USB_PARTITION"
  exit 1
fi

# Filesystem check (non-destructive) - skip for some filesystems
case "$FS_TYPE" in
    "vfat"|"exfat"|"ntfs")
        echo "Skipping fsck for $FS_TYPE filesystem"
        ;;
    *)
        fsck -n "$USB_PARTITION" >/dev/null 2>&1 || {
            echo "** Filesystem errors detected. Repairing... **"
            fsck -y "$USB_PARTITION" || { echo "** Error: Filesystem repair failed. **"; exit 1; }
        }
        ;;
esac

# Mount if not already
if ! mountpoint -q "$MOUNT_POINT"; then
    echo "Mounting $USB_PARTITION at $MOUNT_POINT..."
    mount "$USB_PARTITION" "$MOUNT_POINT" || { 
        echo "** Error: Failed to mount $USB_PARTITION. **"
        echo "Trying with specific filesystem type..."
        if [ -n "$FS_TYPE" ]; then
            mount -t "$FS_TYPE" "$USB_PARTITION" "$MOUNT_POINT" || {
                echo "** Error: Mount failed even with -t $FS_TYPE. **"
                exit 1
            }
        else
            exit 1
        fi
    }
    echo "********** Mounted $USB_PARTITION at $MOUNT_POINT **********"
fi

# Show what's on the USB drive
echo "Contents of USB drive:"
ls -la "$MOUNT_POINT/"

# Verify source has content
if [ -z "$(ls -A "$MOUNT_POINT" 2>/dev/null)" ]; then
  echo "** Error: Source $MOUNT_POINT is empty or unreadable. **"
  umount "$MOUNT_POINT" 2>/dev/null
  exit 1
fi

# Look specifically for the Video directory structure you mentioned
if [ -d "$MOUNT_POINT/Video" ]; then
    echo "Found Video directory on USB. Contents:"
    find "$MOUNT_POINT/Video" -type d | head -10
else
    echo "** Warning: No 'Video' directory found on USB drive **"
    echo "Available directories:"
    find "$MOUNT_POINT" -maxdepth 2 -type d | head -10
fi

# Sync with progress (using --update instead of --ignore-existing)
echo "Syncing files from $MOUNT_POINT to $DEST..."
rsync -av --progress --inplace --whole-file --update --exclude='.*' --info=NAME,PROGRESS2 "$MOUNT_POINT/" "$DEST" \
  | stdbuf -oL sed 's/^/Synced: /'

if [ ${PIPESTATUS[0]} -eq 0 ]; then
  echo "********** Sync completed successfully. **********"
  echo "Files synced to destination:"
  find "$DEST" -name "Test-Vids" -type d 2>/dev/null || echo "Test-Vids directory not found in destination"
else
  echo "** Error: Sync failed. **"
  umount "$MOUNT_POINT" 2>/dev/null
  exit 1
fi

# Unmount
sync
sleep 1
if umount "$MOUNT_POINT"; then
  echo "********** Unmounted from $MOUNT_POINT. SAFE TO REMOVE USB. **********"
else
  echo "** Error: Failed to unmount $MOUNT_POINT. **"
fi

# Refresh MiniDLNA
systemctl restart minidlna && echo "MiniDLNA refreshed."
exit 0
