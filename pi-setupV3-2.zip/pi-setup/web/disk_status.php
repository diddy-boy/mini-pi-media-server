<?php
header('Content-Type: application/json');

// Get disk space information for the root directory (/)
$free_space = disk_free_space("/");
$total_space = disk_total_space("/");
$free_percentage = ($total_space > 0) ? ($free_space / $total_space) * 100 : 0;

$response = [
    'low_disk' => $free_percentage < 5,
    'free_percentage' => floor($free_percentage) // Round down to nearest integer
];

echo json_encode($response);
?>
