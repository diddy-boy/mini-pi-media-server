<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
ini_set('error_log', '/var/log/php_errors.log'); // Adjust path as needed

// Configuration
$base_dir = '/var/lib/minidlna';
$web_base = '/files';

// Get current directory from URL path
$request_uri = $_SERVER['REQUEST_URI'] ?? '/files/';
$path_parts = parse_url($request_uri, PHP_URL_PATH);
if (!$path_parts) {
    $path_parts = '/files/';
}
$relative_path = trim(str_replace($web_base, '', $path_parts), '/');
$current_dir = $base_dir . ($relative_path ? '/' . $relative_path : '');

// Security check
$real_base = realpath($base_dir);
$real_current = realpath($current_dir);
$debug_info = [
    'request_uri' => $request_uri,
    'path_parts' => $path_parts,
    'relative_path' => $relative_path,
    'current_dir' => $current_dir,
    'real_base' => $real_base ?: 'null',
    'real_current' => $real_current ?: 'null',
    'timestamp' => date('Y-m-d H:i:s')
];

if (!$real_base) {
    http_response_code(500);
    die('Server configuration error: Base directory not found');
}

if (!$real_current || strpos($real_current, $real_base) !== 0) {
    $current_dir = $base_dir;
    $relative_path = '';
    $debug_info['security_fallback'] = 'Reset to root directory';
}

// File extensions
$image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
$video_extensions = ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm'];
$audio_extensions = ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'];
$hidden_extensions = ['php', 'env', 'srt', 'm3u', 'db'];

function get_file_extension($filename) {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

function format_file_size($bytes) {
    if ($bytes === false) return 'Unknown';
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

function get_web_path($file_path, $base_dir, $web_base) {
    $relative = trim(str_replace($base_dir, '', $file_path), '/');
    return $web_base . ($relative ? '/' . $relative : '');
}

// Get directories and files
$directories = [];
$files = [];
if (is_dir($current_dir) && is_readable($current_dir)) {
    $items = @scandir($current_dir);
    if ($items !== false) {
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || $item[0] === '.') continue;
            $item_path = $current_dir . '/' . $item;
            $extension = get_file_extension($item);
            if (in_array($extension, $hidden_extensions)) {
                continue;
            }
            if (is_dir($item_path)) {
                $directories[] = [
                    'name' => $item,
                    'path' => $item_path,
                    'is_dir' => true,
                    'web_path' => get_web_path($item_path, $base_dir, $web_base)
                ];
            } else {
                $size = @filesize($item_path);
                if ($size === false) {
                    continue;
                }
                $files[] = [
                    'name' => $item,
                    'path' => $item_path,
                    'is_dir' => false,
                    'web_path' => get_web_path($item_path, $base_dir, $web_base),
                    'size' => format_file_size($size),
                    'extension' => $extension,
                ];
            }
        }
    }
}

// Sort directories and files
usort($directories, function($a, $b) {
    return strcasecmp($a['name'], $b['name']);
});
usort($files, function($a, $b) {
    return strcasecmp($a['name'], $b['name']);
});

// Build breadcrumb navigation
$breadcrumb_parts = [];
$path_segments = array_filter(explode('/', $relative_path));
$current_path = '';
$breadcrumb_parts[] = '<a href="/index.html" class="home-link">Home</a>';
$breadcrumb_parts[] = '<a href="' . $web_base . '">Main Directory</a>';
foreach ($path_segments as $segment) {
    $current_path .= '/' . $segment;
    $breadcrumb_parts[] = '<a href="' . $web_base . $current_path . '">' . htmlspecialchars($segment) . '</a>';
}
$breadcrumb = implode(' / ', $breadcrumb_parts);

// Parent directory URL (server-side fallback)
$parent_segments = array_slice($path_segments, 0, -1);
$parent_url = $web_base . ($parent_segments ? '/' . implode('/', $parent_segments) : '');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini-Pi Media Server - Directories</title>
    <link rel="icon" type="image/png" href="/popcorn.png">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap" rel="stylesheet">
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Cinzel', serif;
    }
    body {
        background: #1e3a5f;
        color: #f4e9cd;
        min-height: 100vh;
        overflow-x: hidden;
    }
    .parallax {
        perspective: 1px;
        height: 100vh;
        overflow: auto;
        position: relative;
        display: flex;
        align-items: flex-start;
        justify-content: center;
        padding-top: 20px;
        animation: fadeIn 1s ease-in-out forwards;
    }
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    .background {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-size: cover;
        background-position: center;
        transform: translateZ(-1px) scale(2);
        filter: brightness(0.9);
        z-index: -1;
        transition: background-image 0.9s ease, filter 0.4s ease;
        will-change: transform, filter;
    }
    .background-video {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        transform: translateZ(-1px) scale(2);
        filter: brightness(0.9);
        z-index: -1;
        transition: filter 0.4s ease, opacity 0.9s ease;
        opacity: 0;
    }
    .background-video.active {
        opacity: 1;
    }
    .background.night-mode,
    .background-video.night-mode {
        filter: brightness(0.7) contrast(0.9);
    }
    .container {
        max-width: 1200px;
        padding: 40px 20px;
        z-index: 1;
        display: flex;
        gap: 30px;
        width: 100%;
        max-width: 100%;
    }
    .breadcrumb {
        margin-bottom: 10px;
        font-size: 1.2rem;
        grid-column: 1 / -1;
    }
    .breadcrumb a {
        color: #c9a550;
        text-decoration: none;
        transition: color 0.3s ease;
    }
    .breadcrumb a:hover {
        color: #f4e9cd;
    }
    .breadcrumb a:first-child, .breadcrumb a.home-link {
        font-size: 1.5rem;
        font-weight: 700;
    }
    .back-button {
        font-size: 1.2rem;
        padding: 10px 20px;
        background: #c9a550;
        border-radius: 50px;
        border: 2px solid #f4e9cd;
        text-align: center;
        transition: all 0.4s ease;
        margin-top: 20px;
        display: only-block;
        width: auto;
        align-self: center;
        z-index: 2;
        opacity: <?php echo $relative_path ? '1' : '0.6'; ?>;
    }
    .back-button a {
        color: #0a0a0a;
        text-decoration: none;
        font-family: 'Cinzel', serif;
        font-weight: 600;
    }
    .back-button:hover:not(.root), .back-button:focus:not(.root) {
        background: #f4e9cd;
        transform: scale(1.1);
        box-shadow: 0 0 25px rgba(201, 165, 80, 0.7);
        outline: none;
    }
    .back-button:active {
        background: #c9a550;
        transform: scale(1);
        box-shadow: none;
    }
    .back-button.root {
        cursor: default;
        opacity: 0.6;
    }
    .back-button.root:hover, .back-button.root:focus, .back-button.root:active {
        background: #c9a550;
        transform: none;
        box-shadow: none;
    }
    .file-list {
        flex: 3;
        display: flex;
        flex-direction: column;
        max-height: 700px;
        position: relative;
        z-index: 1;
        max-width: 100%;
    }
    .file-list h1 {
        margin-bottom: 20px;
        text-align: center;
        font-size: 2.5rem;
        color: #c9a550;
    }
    .controls {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
        flex-wrap: wrap;
        align-items: center;
    }
    #directory-list,
    #file-list {
        display: grid;
        gap: 15px;
        overflow-y: auto;
        overflow-x: hidden;
        max-height: 100%;
        grid-auto-rows: minmax(180px, max-content);
        align-content: start;
        position: relative;
        z-index: 2;
        max-width: 100%;
        scrollbar-width: auto;
        scrollbar-color: #c9a550 #1e3a5f;
    }
    #directory-list::-webkit-scrollbar,
    #file-list::-webkit-scrollbar {
        width: 8px;
    }
    #directory-list::-webkit-scrollbar-track,
    #file-list::-webkit-scrollbar-track {
        background: #1e3a5f;
    }
    #directory-list::-webkit-scrollbar-thumb,
    #file-list::-webkit-scrollbar-thumb {
        background: #c9a550;
        border-radius: 4px;
    }
    #directory-list::-webkit-scrollbar-thumb:hover,
    #file-list::-webkit-scrollbar-thumb:hover {
        background: #f4e9cd;
    }
    .file-item {
        background: rgba(30, 58, 95, 0.8);
        padding: 15px;
        border-radius: 8px;
        border: 2px solid #f4e9cd;
        text-align: center;
        transition: all 0.4s ease;
        position: relative;
        overflow: hidden;
        cursor: pointer;
        min-height: 180px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        z-index: 3;
    }
    .file-item::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(244, 233, 205, 0.5), transparent);
        transition: 0.6s;
        z-index: -1;
    }
    @media screen and (min-width: 769px) {
        .container {
            max-width: 1500px;
        }
        .file-list {
            flex: 4;
            min-width: 0;
        }
        #directory-list,
        #file-list {
            grid-template-columns: repeat(2, minmax(250px, 1fr));
            gap: 20px;
            grid-auto-rows: 200px;
        }
        .file-item {
            min-height: 200px;
            max-height: 200px;
        }
        .preview {
            flex: 2;
            min-width: 500px;
            margin-left: auto;
            height: 700px;
            max-height: 700px;
        }
        .file-icon {
            width: 100px;
            height: 100px;
            font-size: 5rem;
        }
    }
    @media screen and (max-width: 768px) {
        .container {
            flex-direction: column;
            gap: 20px;
            padding: 20px;
            max-width: 100%;
        }
        .file-list {
            max-height: 600px;
            min-width: 0;
            width: 100%;
            max-width: 100%;
            height: auto;
        }
        #directory-list,
        #file-list {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 15px;
            overflow-y: scroll;
            overflow-x: hidden;
            -webkit-overflow-scrolling: touch;
            max-width: 100%;
            height: 100%;
        }
        .preview {
            position: static;
            height: 250px;
            max-height: 250px;
            width: 100%;
            max-width: 100%;
            margin-top: 20px;
        }
        .back-button {
            margin-top: 20px;
            align-self: center;
        }
        .file-icon {
            width: 60px;
            height: 60px;
            font-size: 3rem;
        }
    }
    @media screen and (max-width: 400px) {
        #directory-list,
        #file-list {
            grid-template-columns: 1fr;
            gap: 15px;
        }
    }
    @media screen and (max-width: 1024px) and (orientation: landscape) {
        .container {
            padding-top: 20px;
            max-width: 100%;
            gap: 20px;
        }
        .file-list {
            flex: 3;
            min-width: 0;
            max-height: 500px;
        }
        .preview {
            flex: 1.5;
            height: 400px;
            max-height: 400px;
            min-width: 300px;
            position: static;
            top: auto;
            margin-top: 0;
        }
        #directory-list,
        #file-list {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            overflow-y: scroll;
            overflow-x: hidden;
            max-width: 100%;
            max-height: 450px;
        }
        .file-item {
            min-height: 160px;
            max-height: 160px;
        }
        .file-icon {
            width: 50px;
            height: 50px;
            font-size: 2.5rem;
        }
        .file-name {
            font-size: 0.8rem;
        }
        .preview img,
        .preview video,
        .preview audio {
            max-height: 280px;
            min-width: 300px;
            min-height: 80px;
        }
        .preview video,
        .preview audio {
            width: 100%;
            min-width: 300px;
            min-height: 80px;
            max-width: 100%;
        }
    }
    .file-item:hover::before,
    .file-item.selected::before {
        left: 100%;
    }
    .file-item:hover,
    .file-item.selected {
        background: #f4e9cd;
        color: #0a0a0a;
        transform: scale(1.05);
        box-shadow: 0 0 25px rgba(201, 165, 80, 0.7);
    }
    .file-item.directory {
        background: rgba(201, 165, 80, 0.3);
    }
    .file-item.directory:hover {
        background: #c9a550;
    }
    .file-content {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
    .file-item img,
    .file-item video {
        max-width: 100%;
        height: auto;
        max-height: 100px;
        border-radius: 4px;
        margin-bottom: 10px;
    }
    .file-icon {
        width: 80px;
        height: 80px;
        margin-bottom: 10px;
        object-fit: contain;
        font-size: 4rem;
        line-height: 1;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .file-name {
        font-size: 0.9rem;
        font-weight: 600;
        word-break: break-word;
        margin-top: auto;
        padding-top: 10px;
    }
    .file-info {
        font-size: 0.8rem;
        opacity: 0.8;
        margin-top: 5px;
    }
    .preview {
        flex: 2;
        background: rgba(30, 58, 95, 0.8);
        padding: 20px;
        border-radius: 8px;
        border: 2px solid #f4e9cd;
        height: 600px;
        max-height: 600px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        gap: 10px;
        position: sticky;
        top: 20px;
        overflow-y: auto;
        z-index: 1;
    }
    .preview img {
        max-width: 100%;
        max-height: 100%;
        min-width: 300px;
        min-height: 80px;
        border-radius: 4px;
        transition: opacity 0.8s ease-in-out;
    }
    .preview video,
    .preview audio {
        max-width: 100%;
        max-height: 100%;
        min-width: 300px;
        min-height: 80px;
        border-radius: 4px;
    }
    .preview video,
    .preview audio {
        width: 100%;
        min-width: 300px;
        min-height: 80px;
    }
    .fade-out {
        opacity: 0 !important;
    }
    .fade-in {
        opacity: 1 !important;
    }
    .preview-info {
        text-align: center;
        margin-top: 15px;
    }
    .preview-info h3 {
        color: #c9a550;
        margin-bottom: 10px;
        word-break: break-word;
    }
    .preview-info p {
        font-size: 0.9rem;
        opacity: 0.8;
    }
    .btn {
        padding: 10px 20px;
        font-size: 1rem;
        cursor: pointer;
        display: inline-block;
        text-decoration: none;
        color: #0a0a0a;
        background: #c9a550;
        border: none;
        border-radius: 50px;
        border: 2px solid #f4e9cd;
        transition: all 0.4s ease;
        position: relative;
        overflow: hidden;
    }
    .btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(244, 233, 205, 0.5), transparent);
        transition: 0.6s;
        z-index: -1;
    }
    .btn:hover::before,
    .btn:focus::before {
        left: 100%;
    }
    .btn:hover,
    .btn:focus {
        background: #f4e9cd;
        color: #0a0a0a;
        transform: scale(1.1);
        box-shadow: 0 0 25px rgba(201, 165, 80, 0.7);
        outline: none;
    }
    </style>
</head>
<body>
    <div class="parallax">
        <div class="background"></div>
        <video class="background-video" autoplay muted loop playsinline></video>
        <div class="container">
            <div class="file-list">
                <div class="breadcrumb"><?php echo $breadcrumb; ?></div>
                <div class="controls">
                    <button id="play-all-btn" class="btn" style="display: none;" onclick="playAllAudio()">Play All Audio</button>
                    <button id="cycle-images-btn" class="btn" style="display: none;" onclick="cycleImages()">Start Slideshow</button>
                </div>
                <h1>Directories</h1>
                <div id="directory-list">
                    <?php if (empty($directories)): ?>
                        <p>No directories found in <?php echo htmlspecialchars($current_dir); ?></p>
                    <?php else: ?>
                        <?php foreach ($directories as $item): ?>
                            <div class="file-item directory" data-path="<?php echo htmlspecialchars($item['web_path']); ?>">
                                <div class="file-content">
                                    <div class="file-icon">📁</div>
                                </div>
                                <div class="file-name"><?php echo htmlspecialchars($item['name']); ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div id="file-list" style="display: none;">
                    <?php if (!empty($files)): ?>
                        <?php foreach ($files as $item): ?>
                            <div class="file-item" 
                                 data-path="<?php echo htmlspecialchars($item['web_path']); ?>" 
                                 data-type="<?php 
                                    $ext = $item['extension'];
                                    $isImage = in_array($ext, $image_extensions);
                                    $isVideo = in_array($ext, $video_extensions);
                                    $isAudio = in_array($ext, $audio_extensions);
                                    echo $isImage ? 'image' : ($isVideo ? 'video' : ($isAudio ? 'audio' : 'other'));
                                 ?>">
                                <div class="file-content">
                                    <?php if (in_array($ext, $image_extensions)): ?>
                                        <img src="<?php echo htmlspecialchars($item['web_path']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" loading="lazy">
                                    <?php elseif (in_array($ext, $video_extensions)): ?>
                                        <img src="/movie.png" alt="Video icon" class="file-icon">
                                    <?php elseif (in_array($ext, $audio_extensions)): ?>
                                        <div class="file-icon">🎵</div>
                                    <?php else: ?>
                                        <div class="file-icon">📄</div>
                                    <?php endif; ?>
                                </div>
                                <div class="file-name"><?php echo htmlspecialchars($item['name']); ?></div>
                                <div class="file-info"><?php echo $item['size']; ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div class="back-button <?php echo $relative_path ? '' : 'root'; ?>">
                    <a id="back-button-link" href="#" onclick="goBack(); return false;">← Back</a>
                </div>
            </div>
            <div class="preview">
                <p>Select a directory to view files. Click to play</p>
                <div id="preview-content"></div>
            </div>
        </div>
    </div>

    <script>
        // Define backgrounds with type information (matching index.html)
        const backgrounds = [
            { src: 'gradient', type: 'gradient' },
            { src: '/1.mp4', type: 'video' },
            { src: '/2.mp4', type: 'video' },
            { src: '/3.mp4', type: 'video' },
            { src: '/4.mp4', type: 'video' },
            { src: '/5.mp4', type: 'video' },
            { src: '/6.mp4', type: 'video' },
            { src: '/7.mp4', type: 'video' },
            { src: '/8.mp4', type: 'video' },
            { src: '/9.mp4', type: 'video' },
            { src: '/10.jpg', type: 'image' },
            { src: '/11.jpg', type: 'image' },
            { src: '/12.jpg', type: 'image' },
        ];

        let audioPlaylist = [];
        let currentTrackIndex = -1;
        let audioElement = null;
        let imagePlaylist = [];
        let currentImageIndex = -1;
        let imageCycleInterval = null;
        let currentDirectoryPath = '<?php echo htmlspecialchars($relative_path ? $web_base . '/' . $relative_path : $web_base); ?>';

        function isNightTime() {
            const now = new Date();
            const hours = now.getHours();
            return hours >= 20 || hours < 7;
        }

        function setBackground(index = null) {
            const savedIndex = index !== null ? index : Math.max(0, Math.min(parseInt(localStorage.getItem('backgroundIndex')) || 0, backgrounds.length - 1));
            const background = backgrounds[savedIndex % backgrounds.length];
            const bgDiv = document.querySelector('.background');
            const bgVideo = document.querySelector('.background-video');

            // Apply night mode
            if (isNightTime()) {
                bgDiv.classList.add('night-mode');
                bgVideo.classList.add('night-mode');
            } else {
                bgDiv.classList.remove('night-mode');
                bgVideo.classList.remove('night-mode');
            }

            if (background.type === 'gradient') {
                // Hide video and show gradient
                bgVideo.classList.remove('active');
                bgVideo.pause();
                bgDiv.style.backgroundImage = 'linear-gradient(135deg, #1e3a5f, #c9a550, #f4e9cd, #4ecdc4)';
            } else if (background.type === 'video') {
                // Show video background
                bgDiv.style.backgroundImage = 'none';
                bgVideo.src = background.src;
                bgVideo.onloadeddata = () => {
                    bgVideo.classList.add('active');
                    bgVideo.play();
                };
                bgVideo.onerror = () => {
                    bgVideo.classList.remove('active');
                    bgDiv.style.backgroundImage = 'linear-gradient(135deg, #1e3a5f, #c9a550, #f4e9cd, #4ecdc4)';
                };
            } else {
                // Show image background
                bgVideo.classList.remove('active');
                bgVideo.pause();
                const img = new Image();
                img.src = background.src;
                img.onload = () => {
                    bgDiv.style.backgroundImage = `url('${background.src}')`;
                };
                img.onerror = () => {
                    bgDiv.style.backgroundImage = 'linear-gradient(135deg, #1e3a5f, #c9a550, #f4e9cd, #4ecdc4)';
                };
            }
        }

        function updateBreadcrumbAndBackButton(path) {
            console.log('Updating breadcrumb and back button for:', path);
            const webBase = '<?php echo $web_base; ?>';
            const segments = path.replace(webBase, '').split('/').filter(segment => segment);
            let breadcrumbHTML = [`<a href="/index.html" class="home-link">Home</a>`, `<a href="${webBase}">Main Directory</a>`];
            let currentPath = webBase;
            
            segments.forEach(segment => {
                currentPath += '/' + segment;
                breadcrumbHTML.push(`<a href="${currentPath}">${segment}</a>`);
            });
            
            document.querySelector('.breadcrumb').innerHTML = breadcrumbHTML.join(' / ');
            
            const parentSegments = segments.slice(0, -1);
            const parentPath = parentSegments.length ? `${webBase}/${parentSegments.join('/')}` : webBase;
            const backButton = document.querySelector('.back-button');
            backButton.classList.toggle('root', parentSegments.length === 0);
            console.log('Back button set to:', parentPath);
            return parentPath;
        }

        function goBack() {
            const webBase = '<?php echo $web_base; ?>';
            const segments = currentDirectoryPath.replace(webBase, '').split('/').filter(segment => segment);
            const parentSegments = segments.slice(0, -1);
            const parentPath = parentSegments.length ? `${webBase}/${parentSegments.join('/')}` : webBase;
            console.log('Going back to:', parentPath);
            loadFiles(parentPath);
            document.querySelector('#back-button-link').blur();
        }

        function loadFiles(directoryPath) {
            console.log('Loading files for:', directoryPath);
            currentDirectoryPath = directoryPath;
            history.pushState({ path: directoryPath }, '', directoryPath);
            updateBreadcrumbAndBackButton(directoryPath);
            
            if (imageCycleInterval) {
                clearInterval(imageCycleInterval);
                imageCycleInterval = null;
                document.getElementById('cycle-images-btn').textContent = 'Start Slideshow';
            }
            
            fetch('/files/get_files.php?path=' + encodeURIComponent(directoryPath))
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok: ' + response.statusText);
                    return response.json();
                })
                .then(data => {
                    console.log('Files received:', data);
                    if (data.error) {
                        console.error('Server error:', data.error, data.debug);
                        throw new Error(data.error);
                    }
                    const fileList = document.getElementById('file-list');
                    const directoryList = document.getElementById('directory-list');
                    const playAllBtn = document.getElementById('play-all-btn');
                    const cycleImagesBtn = document.getElementById('cycle-images-btn');
                    const h1Title = document.querySelector('.file-list h1');
                    
                    directoryList.innerHTML = '';
                    fileList.innerHTML = '';
                    
                    let hasAudioFiles = false;
                    let hasImageFiles = false;
                    let hasDirectories = data.directories && data.directories.length > 0;
                    let hasFiles = data.files && data.files.length > 0;
                    
                    directoryList.style.display = 'none';
                    fileList.style.display = 'none';
                    
                    // Build image playlist for navigation
                    imagePlaylist = [];
                    data.files && data.files.forEach(item => {
                        const ext = item.extension.toLowerCase();
                        if (<?php echo json_encode($image_extensions); ?>.includes(ext)) {
                            imagePlaylist.push({ path: item.web_path, name: item.name });
                        }
                    });
                    imagePlaylist.sort((a, b) => a.name.localeCompare(b.name, undefined, {numeric: true}));
                    
                    if (hasDirectories) {
                        data.directories.forEach(item => {
                            const div = document.createElement('div');
                            div.className = 'file-item directory';
                            div.setAttribute('data-path', item.web_path);
                            div.innerHTML = `
                                <div class="file-content">
                                    <div class="file-icon">📁</div>
                                </div>
                                <div class="file-name">${item.name}</div>
                            `;
                            div.addEventListener('click', (e) => {
                                e.stopPropagation();
                                console.log('Clicked directory:', item.web_path);
                                loadFiles(item.web_path);
                            });
                            directoryList.appendChild(div);
                        });
                    }
                    
                    if (hasFiles) {
                        data.files.forEach(item => {
                            const ext = item.extension.toLowerCase();
                            const isImage = <?php echo json_encode($image_extensions); ?>.includes(ext);
                            const isVideo = <?php echo json_encode($video_extensions); ?>.includes(ext);
                            const isAudio = <?php echo json_encode($audio_extensions); ?>.includes(ext);
                            const isMedia = isImage || isVideo || isAudio;
                            if (isAudio) hasAudioFiles = true;
                            if (isImage) hasImageFiles = true;

                            const div = document.createElement('div');
                            div.className = 'file-item';
                            div.setAttribute('data-path', item.web_path);
                            div.setAttribute('data-type', isImage ? 'image' : (isVideo ? 'video' : (isAudio ? 'audio' : 'other')));
                            div.addEventListener('click', (e) => {
                                e.stopPropagation();
                                console.log('Clicked file:', item.web_path, 'Type:', isMedia ? (isImage ? 'image' : (isVideo ? 'video' : 'audio')) : 'other');
                                if (isMedia) {
                                    showPreview(item.web_path, isImage ? 'image' : (isVideo ? 'video' : 'audio'), item.name);
                                } else {
                                    window.open(item.web_path);
                                }
                            });

                            let content = '';
                            if (isImage) {
                                content = `<img src="${item.web_path}" alt="${item.name}" loading="lazy">`;
                            } else if (isVideo) {
                                content = item.thumbnail ? 
                                    `<img src="${item.thumbnail}" alt="Video thumbnail" class="file-icon">` : 
                                    `<img src="/movie.png" alt="Video icon" class="file-icon">`;
                            } else if (isAudio) {
                                content = `<div class="file-icon">🎵</div>`;
                            } else {
                                content = `<div class="file-icon">📄</div>`;
                            }

                            div.innerHTML = `
                                <div class="file-content">${content}</div>
                                <div class="file-name">${item.name}</div>
                                <div class="file-info">${item.size}</div>
                            `;
                            fileList.appendChild(div);
                        });
                    }
                    
                    if (hasDirectories && !hasFiles) {
                        directoryList.style.display = 'grid';
                        h1Title.textContent = 'Directory List';
                    } else if (!hasDirectories && hasFiles) {
                        fileList.style.display = 'grid';
                        h1Title.textContent = 'File List';
                    } else if (hasDirectories && hasFiles) {
                        data.files.forEach(item => {
                            const ext = item.extension.toLowerCase();
                            const isImage = <?php echo json_encode($image_extensions); ?>.includes(ext);
                            const isVideo = <?php echo json_encode($video_extensions); ?>.includes(ext);
                            const isAudio = <?php echo json_encode($audio_extensions); ?>.includes(ext);
                            const isMedia = isImage || isVideo || isAudio;

                            const div = document.createElement('div');
                            div.className = 'file-item';
                            div.setAttribute('data-path', item.web_path);
                            div.setAttribute('data-type', isImage ? 'image' : (isVideo ? 'video' : (isAudio ? 'audio' : 'other')));
                            div.addEventListener('click', (e) => {
                                e.stopPropagation();
                                console.log('Clicked file:', item.web_path, 'Type:', isMedia ? (isImage ? 'image' : (isVideo ? 'video' : 'audio')) : 'other');
                                if (isMedia) {
                                    showPreview(item.web_path, isImage ? 'image' : (isVideo ? 'video' : 'audio'), item.name);
                                } else {
                                    window.open(item.web_path);
                                }
                            });

                            let content = '';
                            if (isImage) {
                                content = `<img src="${item.web_path}" alt="${item.name}" loading="lazy">`;
                            } else if (isVideo) {
                                content = item.thumbnail ? 
                                    `<img src="${item.thumbnail}" alt="Video thumbnail" class="file-icon">` : 
                                    `<img src="/movie.png" alt="Video icon" class="file-icon">`;
                            } else if (isAudio) {
                                content = `<div class="file-icon">🎵</div>`;
                            } else {
                                content = `<div class="file-icon">📄</div>`;
                            }

                            div.innerHTML = `
                                <div class="file-content">${content}</div>
                                <div class="file-name">${item.name}</div>
                                <div class="file-info">${item.size}</div>
                            `;
                            directoryList.appendChild(div);
                        });
                        
                        directoryList.style.display = 'grid';
                        h1Title.textContent = 'Browse';
                    } else {
                        directoryList.innerHTML = '<p>No files or directories found</p>';
                        directoryList.style.display = 'block';
                        h1Title.textContent = 'Empty';
                    }

                    playAllBtn.style.display = hasAudioFiles ? 'inline-block' : 'none';
                    cycleImagesBtn.style.display = hasImageFiles ? 'inline-block' : 'none';
                    
                    document.querySelectorAll('.file-item').forEach(item => item.classList.remove('selected'));
                    document.getElementById('preview-content').innerHTML = hasFiles ? 
                        '<p>Select a file to preview</p>' : 
                        (hasDirectories ? '<p>Select a directory to browse</p>' : '<p>Empty directory</p>');
                })
                .then(() => {
                    // Re-apply click event listeners to directory items after fetch
                    document.querySelectorAll('.file-item.directory').forEach(item => {
                        const path = item.getAttribute('data-path');
                        item.addEventListener('click', (e) => {
                            e.stopPropagation();
                            console.log('Directory clicked after fetch:', path);
                            loadFiles(path);
                        });
                    });
                })
                .catch(error => {
                    console.error('Error loading file list:', error);
                    const directoryList = document.getElementById('directory-list');
                    const fileList = document.getElementById('file-list');
                    directoryList.style.display = 'none';
                    fileList.innerHTML = '<p>Error loading file list</p>';
                    fileList.style.display = 'block';
                });
        }

        function showPreview(file, type, filename) {
            console.log('Showing preview for:', file, 'Type:', type);
            const previewContent = document.getElementById('preview-content');
            
            if (imageCycleInterval) {
                clearInterval(imageCycleInterval);
                imageCycleInterval = null;
                document.getElementById('cycle-images-btn').textContent = 'Start Slideshow';
            }
            
            if (audioElement) {
                audioElement.pause();
                audioElement = null;
            }
            
            // Update currentImageIndex for image navigation
            if (type === 'image') {
                currentImageIndex = imagePlaylist.findIndex(img => img.path === file);
                if (currentImageIndex === -1) {
                    imagePlaylist = [{ path: file, name: filename }];
                    currentImageIndex = 0;
                }
            } else {
                currentImageIndex = -1; // Reset for non-image previews
            }
            
            if (type === 'image') {
                const imageNumber = currentImageIndex + 1;
                const totalImages = imagePlaylist.length;
                previewContent.innerHTML = `
                    <img src="${file}" alt="Preview">
                    <div class="preview-info">
                        <h3>${filename}</h3>
                        <p>Image ${imageNumber} of ${totalImages}. Use ←/→ for prev/next, double click for full screen</p>
                    </div>
                `;
            } else if (type === 'video') {
                previewContent.innerHTML = `
                    <video controls autoplay>
                        <source src="${file}" type="video/${file.split('.').pop()}">
                        Your browser does not support the video tag.
                    </video>
                    <div class="preview-info">
                        <h3>${filename}</h3>
                        <p>Video file. Double click for full screen</p>
                    </div>
                `;
            } else if (type === 'audio') {
                previewContent.innerHTML = `
                    <audio controls autoplay id="audio-player">
                        <source src="${file}" type="audio/${file.split('.').pop()}">
                        Your browser does not support the audio tag.
                    </audio>
                    <div class="preview-info">
                        <h3>${filename}</h3>
                        <p>Audio file. Seek using cursor keys, space to pause</p>
                    </div>
                `;
                audioElement = document.getElementById('audio-player');
                audioPlaylist = [file];
                currentTrackIndex = 0;
            }
            
            document.querySelectorAll('.file-item').forEach(item => item.classList.remove('selected'));
            if (event && event.currentTarget) {
                event.currentTarget.classList.add('selected');
            }
        }

        function playAllAudio() {
            const audioFiles = [];
            document.querySelectorAll('#file-list .file-item, #directory-list .file-item').forEach(item => {
                const type = item.getAttribute('data-type');
                if (type === 'audio') {
                    const path = item.getAttribute('data-path');
                    if (path) {
                        audioFiles.push(path);
                    }
                }
            });

            if (audioFiles.length === 0) {
                alert('No audio files found in this directory');
                return;
            }

            audioFiles.sort((a, b) => {
                const nameA = a.split('/').pop();
                const nameB = b.split('/').pop();
                return nameA.localeCompare(nameB, undefined, {numeric: true});
            });

            audioPlaylist = audioFiles;
            currentTrackIndex = 0;
            playTrack(currentTrackIndex);
        }

        function cycleImages() {
            if (imageCycleInterval) {
                clearInterval(imageCycleInterval);
                imageCycleInterval = null;
                document.getElementById('cycle-images-btn').textContent = 'Start Slideshow';
                return;
            }

            const imageFiles = [];
            document.querySelectorAll('#file-list .file-item, #directory-list .file-item').forEach(item => {
                const type = item.getAttribute('data-type');
                if (type === 'image') {
                    const path = item.getAttribute('data-path');
                    const name = item.querySelector('.file-name').textContent;
                    if (path) {
                        imageFiles.push({ path: path, name: name });
                    }
                }
            });

            if (imageFiles.length === 0) {
                alert('No image files found in this directory');
                return;
            }

            imageFiles.sort((a, b) => a.name.localeCompare(b.name, undefined, {numeric: true}));

            imagePlaylist = imageFiles;
            currentImageIndex = 0;
            
            showImageSlide(currentImageIndex);
            
            document.getElementById('cycle-images-btn').textContent = 'Stop Slideshow';
            
            imageCycleInterval = setInterval(() => {
                currentImageIndex = (currentImageIndex + 1) % imagePlaylist.length;
                showImageSlide(currentImageIndex);
            }, 29500); // Adjusted to account for 500ms fade transition
        }

        function showImageSlide(index) {
            if (index >= imagePlaylist.length || index < 0) return;

            const imageData = imagePlaylist[index];
            const previewContent = document.getElementById('preview-content');
            const isInFullscreen = document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement;
            
            const updateImage = (imgElement) => {
                imgElement.src = imageData.path;
                imgElement.alt = imageData.name;
                imgElement.classList.remove('fade-out');
                imgElement.classList.add('fade-in');
                setTimeout(() => {
                    imgElement.classList.remove('fade-in');
                }, 800);
            };

            const updatePreviewInfo = () => {
                const info = previewContent.querySelector('.preview-info') || document.createElement('div');
                info.className = 'preview-info';
                info.innerHTML = `
                    <h3>${imageData.name}</h3>
                    <p>Image ${index + 1} of ${imagePlaylist.length} - Auto-cycling every 30 seconds</p>
                `;
                if (!previewContent.contains(info)) {
                    previewContent.appendChild(info);
                }
            };

            if (isInFullscreen && isInFullscreen.tagName === 'IMG') {
                isInFullscreen.classList.add('fade-out');
                setTimeout(() => {
                    updateImage(isInFullscreen);
                    updatePreviewInfo();
                }, 400);
            } else {
                const currentImg = previewContent.querySelector('img');
                if (currentImg && imageCycleInterval) {
                    currentImg.classList.add('fade-out');
                    setTimeout(() => {
                        previewContent.innerHTML = `
                            <img src="${imageData.path}" alt="Preview" class="fade-in">
                            <div class="preview-info">
                                <h3>${imageData.name}</h3>
                                <p>Image ${index + 1} of ${imagePlaylist.length} - Auto-cycling every 30 seconds</p>
                            </div>
                        `;
                        const newImg = previewContent.querySelector('img');
                        setTimeout(() => {
                            if (newImg) newImg.classList.remove('fade-in');
                        }, 800);
                    }, 400);
                } else {
                    previewContent.innerHTML = `
                        <img src="${imageData.path}" alt="Preview">
                        <div class="preview-info">
                            <h3>${imageData.name}</h3>
                            <p>Image ${index + 1} of ${imagePlaylist.length} - Auto-cycling every 30 seconds</p>
                        </div>
                    `;
                }
            }
            
            document.querySelectorAll('#file-list .file-item, #directory-list .file-item').forEach(item => {
                item.classList.remove('selected');
                if (item.getAttribute('data-path') === imageData.path) {
                    item.classList.add('selected');
                }
            });
        }

        function playTrack(index) {
            if (index >= audioPlaylist.length || index < 0) {
                audioPlaylist = [];
                currentTrackIndex = -1;
                document.getElementById('preview-content').innerHTML = '<p>Finished playing all tracks</p>';
                document.querySelectorAll('.file-item').forEach(item => item.classList.remove('selected'));
                audioElement = null;
                return;
            }

            const file = audioPlaylist[index];
            const fileName = file.split('/').pop();
            const previewContent = document.getElementById('preview-content');
            
            previewContent.innerHTML = `
                <audio controls autoplay id="audio-player">
                    <source src="${file}" type="audio/${file.split('.').pop()}">
                    Your browser does not support the audio tag.
                </audio>
                <div class="preview-info">
                    <h3>${fileName}</h3>
                    <p>Playing track ${index + 1} of ${audioPlaylist.length}</p>
                </div>
            `;
            
            audioElement = document.getElementById('audio-player');
            
            document.querySelectorAll('#file-list .file-item, #directory-list .file-item').forEach(item => {
                item.classList.remove('selected');
                if (item.getAttribute('data-path') === file) {
                    item.classList.add('selected');
                }
            });

            audioElement.onended = () => {
                currentTrackIndex++;
                setTimeout(() => playTrack(currentTrackIndex), 500);
            };

            audioElement.onerror = () => {
                console.error('Error playing:', file);
                currentTrackIndex++;
                setTimeout(() => playTrack(currentTrackIndex), 500);
            };
        }

        window.addEventListener('popstate', (event) => {
            const path = event.state ? event.state.path : '<?php echo $web_base; ?>';
            console.log('Popstate event, loading path:', path);
            loadFiles(path);
        });

        window.addEventListener('load', () => {
            setBackground();

            document.querySelectorAll('.file-item.directory').forEach(item => {
                const path = item.getAttribute('data-path');
                item.addEventListener('click', (e) => {
                    e.stopPropagation();
                    console.log('Initial directory clicked:', path);
                    loadFiles(path);
                });
            });

            console.log('Initial load for:', '<?php echo htmlspecialchars($relative_path ? $web_base . '/' . $relative_path : $web_base); ?>');
            loadFiles('<?php echo htmlspecialchars($relative_path ? $web_base . '/' . $relative_path : $web_base); ?>');
        });

        document.addEventListener('keydown', function (e) {
            const t = e.target;
            if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;

            const media = document.querySelector('#preview-content video, #preview-content audio');
            const image = document.querySelector('#preview-content img');

            if (image && !imageCycleInterval) {
                // Handle image navigation
                switch (e.code) {
                    case 'ArrowRight':
                        e.preventDefault();
                        if (currentImageIndex < imagePlaylist.length - 1) {
                            currentImageIndex++;
                            showPreview(imagePlaylist[currentImageIndex].path, 'image', imagePlaylist[currentImageIndex].name);
                        }
                        break;
                    case 'ArrowLeft':
                        e.preventDefault();
                        if (currentImageIndex > 0) {
                            currentImageIndex--;
                            showPreview(imagePlaylist[currentImageIndex].path, 'image', imagePlaylist[currentImageIndex].name);
                        }
                        break;
                }
            } else if (media) {
                // Handle video/audio controls
                switch (e.code) {
                    case 'Space':
                        e.preventDefault();
                        if (typeof media.paused !== 'undefined') {
                            if (media.paused) media.play(); else media.pause();
                        }
                        break;
                    case 'ArrowRight':
                        e.preventDefault();
                        try {
                            const dur = isFinite(media.duration) ? media.duration : media.currentTime + 5;
                            media.currentTime = Math.min((media.currentTime || 0) + 5, dur);
                        } catch (_) {}
                        break;
                    case 'ArrowLeft':
                        e.preventDefault();
                        try {
                            media.currentTime = Math.max((media.currentTime || 0) - 5, 0);
                        } catch (_) {}
                        break;
                    case 'ArrowUp':
                        e.preventDefault();
                        media.volume = Math.min((media.volume ?? 1) + 0.1, 1);
                        break;
                    case 'ArrowDown':
                        e.preventDefault();
                        media.volume = Math.max((media.volume ?? 1) - 0.1, 0);
                        break;
                }
            }
        });

        document.addEventListener('dblclick', function (e) {
            const img = e.target;
            if (img.tagName === 'IMG' && img.closest('#preview-content')) {
                if (img.requestFullscreen) {
                    img.requestFullscreen();
                } else if (img.webkitRequestFullscreen) {
                    img.webkitRequestFullscreen();
                } else if (img.msRequestFullscreen) {
                    img.msRequestFullscreen();
                }
            }
        });

        document.addEventListener('fullscreenchange', function() {
            if (!document.fullscreenElement && imagePlaylist.length > 0 && currentImageIndex >= 0) {
                const imageData = imagePlaylist[currentImageIndex];
                const previewContent = document.getElementById('preview-content');
                previewContent.innerHTML = `
                    <img src="${imageData.path}" alt="Preview">
                    <div class="preview-info">
                        <h3>${imageData.name}</h3>
                        <p>Image ${currentImageIndex + 1} of ${imagePlaylist.length}. Use ←/→ for prev/next, double click for full screen</p>
                    </div>
                `;
            }
        });

        document.addEventListener('webkitfullscreenchange', function() {
            if (!document.webkitFullscreenElement && imagePlaylist.length > 0 && currentImageIndex >= 0) {
                const imageData = imagePlaylist[currentImageIndex];
                const previewContent = document.getElementById('preview-content');
                previewContent.innerHTML = `
                    <img src="${imageData.path}" alt="Preview">
                    <div class="preview-info">
                        <h3>${imageData.name}</h3>
                        <p>Image ${currentImageIndex + 1} of ${imagePlaylist.length}. Use ←/→ for prev/next, double click for full screen</p>
                    </div>
                `;
            }
        });
    </script>
</body>
</html>
