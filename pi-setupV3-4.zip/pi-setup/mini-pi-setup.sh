#!/bin/bash
set -e

# This is the main setup script for installing and configuring the whole mini-pi media server.
#
# This script should work on Pi OS and Ubuntu based systems 20.04 and above.... not currently tested on Ubuntu though.
#
# User will be asked for a samba password to allow the PI user to access this device from across the network.
# User will be asked if they want to setup a wifi connection (using reconfigure_wifi.sh script) from a generated wifi list, if they want to setup an access point for the wifi card when away from home that users can connect to.
# User will be asked if they want to set up a timed convert MKV to MP4 batch convert on /var/lib/minidlna/Video folder every night at midnight.
# User will be asked if they want to disable or enable the swap file. good to disable on a pi 5 with 2GB of ram or more. But keep for the Pi zero 2 w.
# User is also asked if they want to set up a timed synchronization from a server. this calls configure_server_sync.sh script

# Ensure dialog is installed
apt-get install -y dialog

# Determine the current user
if [ -n "$SUDO_USER" ]; then
    CURRENT_USER="$SUDO_USER"
else
    CURRENT_USER="$USER"
fi
# Fallback to 'pi' if no user is detected
[ -z "$CURRENT_USER" ] && CURRENT_USER="pi"

# Validate user existence
if ! id "$CURRENT_USER" >/dev/null 2>&1; then
    dialog --msgbox "Error: User '$CURRENT_USER' does not exist. Please run this script as a valid user." 8 60
    exit 1
fi

# Get the user's home directory
HOME_DIR=$(getent passwd "$CURRENT_USER" | cut -d: -f6)
if [ -z "$HOME_DIR" ] || [ ! -d "$HOME_DIR" ]; then
    dialog --msgbox "Error: Home directory for user '$CURRENT_USER' not found." 8 60
    exit 1
fi

# Elevate privileges if not running as root
if [ "$EUID" -ne 0 ]; then
    if ! command -v dialog &>/dev/null; then
        sudo apt-get install -y dialog
    fi
    dialog --msgbox "This script needs root privileges. Restarting with sudo..." 8 60
    exec sudo bash "$0" "$@"
fi

display_header() {
    clear
    dialog --title "Mini-Pi Media Server Setup" \
           --msgbox "Welcome to the Mini-Pi Media Server setup script.\n\n\
This will install and configure your server for the user '$CURRENT_USER'." 10 60
}

install_packages() {
    dialog --infobox "Updating package lists..." 5 60
    sleep 2
    clear
    apt-get update -q

    dialog --infobox "Upgrading system..." 5 60
    sleep 2
    clear
    apt-get upgrade -y -q

    # Detect Debian version and upgrade PHP if on Trixie
    DEBIAN_CODENAME=$(lsb_release -sc 2>/dev/null || grep VERSION_CODENAME= /etc/os-release | cut -d= -f2)
    if [ "$DEBIAN_CODENAME" = "trixie" ]; then
        dialog --infobox "Detected Debian Trixie - adding PHP repository and installing PHP 8.3/8.2..." 6 60
        apt-get install -y ca-certificates apt-transport-https software-properties-common lsb-release wget
        wget -O /etc/apt/trusted.gpg.d/php.gpg https://packages.sury.org/php/apt.gpg
        echo "deb https://packages.sury.org/php/ $(lsb_release -sc) main" | tee /etc/apt/sources.list.d/php.list
        apt-get update -q
        apt-get install -y php8.2-cli php8.2-fpm php8.2-mysql php8.2-xml php8.2-mbstring php8.2-zip
    fi

    dialog --infobox "Installing required packages..." 5 60
    apt-get install -y -q nano preload samba neofetch minidlna exfatprogs apache2 php php-cli php-common php-mbstring cockpit expect ntfs-3g cifs-utils network-manager hostapd dnsmasq iw iproute2 bc ffmpeg

    for ini in /etc/php/*/cli/php.ini; do
        grep -q 'extension=mbstring' "$ini" || echo "extension=mbstring" >> "$ini"
        grep -q 'extension=fileinfo' "$ini" || echo "extension=fileinfo" >> "$ini"
    done

    systemctl enable cockpit.socket

    dialog --infobox "Installing Cockpit Navigator..." 5 60
    wget -q https://github.com/45Drives/cockpit-navigator/releases/download/v0.5.10/cockpit-navigator_0.5.10-1focal_all.deb
    dpkg -i ./cockpit-navigator_0.5.10-1focal_all.deb

    dialog --msgbox "All required software has been installed. Copying config files next..." 7 60
}

check_files() {
    local missing_files=()
    local required_files=(
        "./configs/usb_sync.sh"
        "./configs/99-usb-autosync.rules"
        "./configs/usb_sync.service"
        "./configs/motd"
        "./configs/smb.conf"
        "./configs/minidlna.conf"
        "./configs/000-default.conf"
        "./web/index.html"
        "./web/sync_status.php"
        "./web/disk_status.php"
        "./web/get_files.php"
        "./web/index.php"
        "./web/env"
        "./web/sw.js"
    )

    for file in "${required_files[@]}"; do
        if [ ! -f "$file" ]; then
            missing_files+=("$file")
        fi
    done

    if [ ${#missing_files[@]} -gt 0 ]; then
        dialog --title "Missing Files" \
               --msgbox "The following required files are missing:\n\n$(printf '%s\n' "${missing_files[@]}")\n\nPlease ensure all required files are present before running this script." 20 70
        exit 1
    fi
}

copy_configs() {
    # Remove existing web files (use -f to avoid errors if files don't exist)
    rm -rf /var/www/html/*
    rm -f /var/lib/minidlna/index.php
    rm -f /var/lib/minidlna/get_files.php
    
    # Create directories
    mkdir -p /var/lib/minidlna /media/usb
    
    # Copy scripts and configurations
    cp --force ./configs/usb_sync.sh /usr/local/bin
    chmod +x /usr/local/bin/usb_sync.sh
    cp --force ./configs/99-usb-autosync.rules /etc/udev/rules.d/
    cp ./configs/usb_sync.service /etc/systemd/system/
    cp ./configs/motd /etc/motd
    sed "s/SAMBA_USER/$CURRENT_USER/" ./configs/smb.conf > /etc/samba/smb.conf
    cp --force ./configs/minidlna.conf /etc/
    
    # Copy web files
    cp --force ./web/index.html /var/www/html/
    cp --force ./web/sync_status.php /var/www/html/
    cp --force ./web/disk_status.php /var/www/html/
    cp --force ./web/wifi_status.php /var/www/html/
    cp --force ./web/get_files.php /var/lib/minidlna/
    cp --force ./web/index.php /var/lib/minidlna/
    cp --force ./web/env /var/lib/minidlna/.env
    cp --force ./web/sw.js /var/www/html/
    
    # Copy media files
    cp --force ./images/{1,2,3,4,5,6,7,8,9}.mp4 ./images/popcorn.png /var/www/html/
    cp --force ./images/{10,11,12}.jpg /var/www/html/
    cp --force ./images/movie.png /var/www/html/
    
    # Copy Apache configuration
    cp --force ./configs/000-default.conf /etc/apache2/sites-enabled/
    
    # Copy branding images (use || true to continue if copy fails)
    cp --force ./images/debian-logo.png /usr/share/cockpit/branding/debian/ || true
    cp --force ./images/bg-plain.jpg /usr/share/cockpit/branding/debian/ || true
    cp --force ./images/debian-logo.png /usr/share/cockpit/branding/default/ || true
    cp --force ./images/bg-plain.jpg /usr/share/cockpit/branding/default/ || true

    # Set permissions
    chown www-data:www-data /var/www/html/*
    chmod 644 /var/www/html/*
    chown www-data:www-data /var/www/html/sync_status.php
    chmod +x /var/www/html/sync_status.php
	
    # Reload system services
    udevadm control --reload-rules
    systemctl daemon-reexec
    systemctl daemon-reload
    udevadm trigger
    a2enmod headers
    systemctl disable usb_sync.service

    # Configure Apache
    echo "ServerName localhost" | tee -a /etc/apache2/apache2.conf

    # Test Samba configuration
    if testparm -s /etc/samba/smb.conf >/dev/null 2>&1; then
        dialog --msgbox "Configuration files copied and Samba configuration is valid." 7 60
    else
        dialog --msgbox "Error: Invalid Samba configuration in /etc/samba/smb.conf." 7 60
        exit 1
    fi
}

set_minidlna_friendly_name() {
    local hostname
    hostname=$(hostname)
    if grep -q "^friendly_name=" /etc/minidlna.conf; then
        sed -i "s/^friendly_name=.*/friendly_name=$hostname/" /etc/minidlna.conf
    else
        echo "friendly_name=$hostname" >> /etc/minidlna.conf
    fi
    dialog --msgbox "This MiniDLNA server will appear to smart devices as '$hostname'." 6 60
}

configure_samba() {
    dialog --inputbox "Set Samba password for user '$CURRENT_USER':" 8 60 2> /tmp/smbpass
    if [ ! -s /tmp/smbpass ]; then
        dialog --msgbox "Error: No password provided. Please try again." 7 60
        return 1
    fi

    if ! id "$CURRENT_USER" >/dev/null 2>&1; then
        adduser --system --no-create-home "$CURRENT_USER"
    fi

    password=$(cat /tmp/smbpass)

    /usr/bin/expect << EOF
spawn smbpasswd -a $CURRENT_USER
expect {
    "New SMB password:" {
        send "$password\r"
        exp_continue
    }
    "Retype new SMB password:" {
        send "$password\r"
        exp_continue
    }
    eof
}
EOF

    usermod -aG minidlna $CURRENT_USER

    rm -f /tmp/smbpass

    mkdir -p /var/lib/minidlna/{Video,Music,Pictures}
    chmod -R 775 /var/lib/minidlna
    chown -R minidlna:minidlna /var/lib/minidlna

    SYMLINK_PATH="$HOME_DIR/minidlna-link"
    if [ -L "$SYMLINK_PATH" ]; then
        if [ "$(readlink -f "$SYMLINK_PATH")" != "/var/lib/minidlna" ]; then
            rm "$SYMLINK_PATH"
            ln -s /var/lib/minidlna "$SYMLINK_PATH"
        fi
    elif [ -e "$SYMLINK_PATH" ]; then
        dialog --msgbox "$SYMLINK_PATH exists and is not a symlink. Skipping symlink creation." 6 60
    else
        ln -s /var/lib/minidlna "$SYMLINK_PATH"
    fi
    chown "$CURRENT_USER:$CURRENT_USER" "$SYMLINK_PATH"

    dialog --msgbox "Samba user and directories configured for '$CURRENT_USER'." 7 60
}

offer_swap_option() {
    while true; do
        CHOICE=$(dialog --clear --backtitle "Swap Configuration" \
            --title "Swap Options" \
            --default-item 3 \
            --menu "Choose an option:" 15 60 4 \
            1 "Disable swap permanently" \
            2 "Enable/restore 1GB swap" \
            3 "Leave swap unchanged" \
            3>&1 1>&2 2>&3)

        case "$CHOICE" in
            1)
                swapoff -a
                sed -i.bak '/\bswap\b/d' /etc/fstab
                dialog --msgbox "Swap permanently disabled." 6 60
                break
                ;;
            2)
                if [ ! -f /swapfile ]; then
                    fallocate -l 1G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=1024
                    chmod 600 /swapfile
                    mkswap /swapfile
                fi
                grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
                swapon /swapfile
                dialog --msgbox "Swap enabled (1GB)." 6 60
                break
                ;;
            3)
                dialog --msgbox "No changes made to swap configuration." 6 60
                break
                ;;
        esac
    done
}

# ---------------- MKV Conversion Functions ----------------
setup_mkv_conversion_service() {
    SERVICE_FILE="/etc/systemd/system/mkv-conversion.service"
    TIMER_FILE="/etc/systemd/system/mkv-conversion.timer"
    
    # Get the absolute path of the current script's directory
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    MKV_CONVERT_ABS_PATH="$SCRIPT_DIR/configs/mkv-2-mp4.sh"

    if [ ! -f "$MKV_CONVERT_ABS_PATH" ]; then
        dialog --msgbox "MKV conversion script $MKV_CONVERT_ABS_PATH not found.\n\nChecked in: $SCRIPT_DIR/configs/" 10 70
        return
    fi

    sudo bash -c "cat > $SERVICE_FILE" << EOF
[Unit]
Description=MKV to MP4 Conversion Service
Before=media-sync.service

[Service]
Type=oneshot
ExecStart=/bin/bash $MKV_CONVERT_ABS_PATH
WorkingDirectory=/var/lib/minidlna/Video
RemainAfterExit=no
TimeoutStartSec=0
TimeoutStopSec=30
KillMode=mixed

[Install]
WantedBy=multi-user.target
EOF

    sudo bash -c "cat > $TIMER_FILE" << 'EOF'
[Unit]
Description=Run MKV to MP4 conversion daily at midnight

[Timer]
OnCalendar=*-*-* 00:00:00
Unit=mkv-conversion.service
Persistent=false

[Install]
WantedBy=timers.target
EOF

    sudo systemctl daemon-reload
    sudo systemctl enable mkv-conversion.timer
    sudo systemctl start mkv-conversion.timer

    if systemctl is-active --quiet mkv-conversion.timer; then
        status="ACTIVE"
    else
        status="NOT ACTIVE"
    fi

    dialog --msgbox "MKV conversion timer has been set up.\n\nIt will run daily at midnight before sync.\nStatus: $status" 12 60
}

offer_mkv_conversion() {
    if dialog --defaultno --yesno "Do you want to set up a batch conversion script on the Minidlna/Video folder ?\n\nThis will convert any MKV files to MP4 for compatibility with web streaming every night at 12am" 10 90; then
        setup_mkv_conversion_service
    fi
}

# ---------------- Final Setup ----------------
finalize_setup() {
    # Sync from remote server
    if dialog --defaultno --yesno "Do you want to set up synchronisation of Video and Music from a remote server?\nNOTE: Server must already be sharing these folders." 8 60; then
        ./configure_server_sync.sh || dialog --msgbox "Error running remote server sync configuration script." 7 60
    fi

    # Wi-Fi reconfiguration
    if dialog --defaultno --yesno "Do you want to reconfigure Wi-Fi connection and access point?\nNOTE: Only run on Pi OS." 8 60; then
        ./reconfigure-wifi.sh || dialog --msgbox "Error reconfiguring Wi-Fi, continuing setup..." 7 60
    fi

    # MKV to MP4 conversion
    offer_mkv_conversion

    # Swap configuration
    offer_swap_option || dialog --msgbox "Swap configuration step skipped." 7 60

    # Completion message
    dialog --msgbox "Setup completed successfully!\n\nMedia server is ready for user '$CURRENT_USER'.\n\nThe system will now reboot." 10 60
    reboot || dialog --msgbox "Error: Failed to reboot. Please reboot manually." 7 60
}

# ---------------- Main Execution Flow ----------------
display_header
check_files
install_packages
copy_configs
set_minidlna_friendly_name
configure_samba
finalize_setup
