#!/bin/bash
#   Mini-Pi-setup
# this is the main setup script to install and configure Apache, cockpit, samba and minidlna
# The supporting folders and files are needed in this exact folder layout in order to install.
# New versions can be downloaded by running :-
# wget -qO main.zip https://github.com/diddy-boy/mini-pi-media-server/archive/refs/heads/main.zip && unzip -o main.zip && cd mini-pi-media-server-main && unzip -o pi-setup*.zip && cp -rf pi-setup ~/ && cd ~ && rm -rf mini-pi-media-server-main main.zip && cd ~/pi-setup && chmod +x ./*.sh && sudo ./mini-pi-setup.sh


set -e
VERSION="4.6"

# --- Explicit Paths ---
BASE_DIR="/home/pi/pi-setup"
CONFIG_DIR="$BASE_DIR/configs"
WEB_DIR="$BASE_DIR/web"
IMAGE_DIR="$BASE_DIR/images"

# --- Tracking Variables for Summary ---
CHOICE_SYNC="[ DISABLED ]"
CHOICE_WIFI="[ DISABLED ]"
CHOICE_SCRAPER="[ DISABLED ]"
CHOICE_MKV="[ DISABLED ]"
OFFER_SCRAPER="[ DISABLED ]"
CHOICE_gdrive="[ DISABLED ]"


# Set user to pi explicitly based on your requirements
CURRENT_USER="pi"
HOME_DIR="/home/pi"

sudo apt-get install -y dialog

# Elevate privileges if not running as root
if [ "$EUID" -ne 0 ]; then
    dialog --msgbox "This script needs root privileges. Restarting with sudo..." 8 60
    exec sudo bash "$0" "$@"
fi

display_header() {
    clear
    dialog --title "Mini-Pi Media Server Setup - v$VERSION" \
           --msgbox "Welcome to the Mini-Pi Media Server setup script.\n\n\
This will install and configure your server for the user '$CURRENT_USER'.\n\
Working Directory: $BASE_DIR" 10 60
}

install_packages() {
    dialog --infobox "Updating and Installing Packages..." 5 60
    apt-get update -q
    apt-get upgrade -y -q
    # install required software and supporting software
    apt-get install -y -q --no-install-recommends nano preload samba fastfetch minidlna exfatprogs apache2 php php-cli php-common php-mbstring cockpit expect ntfs-3g cifs-utils network-manager hostapd dnsmasq iw iproute2 bc ffmpeg python3-minimal python3-pip

    systemctl enable cockpit.socket
    # install navigator plug in for cockpit to allow navigation of files and folders
    dialog --infobox "Installing Cockpit Navigator (remote admin)..." 5 60
    wget -q https://github.com/45Drives/cockpit-navigator/releases/download/v0.5.10/cockpit-navigator_0.5.10-1focal_all.deb
    dpkg -i ./cockpit-navigator_0.5.10-1focal_all.deb
    rm ./cockpit-navigator_0.5.10-1focal_all.deb
}

check_files() {
    dialog --infobox "Checking all files are present before setting up..." 5 60
    local missing=0
    # Check key directories
    for dir in "$CONFIG_DIR" "$WEB_DIR" "$IMAGE_DIR"; do
        if [ ! -d "$dir" ]; then
            dialog --msgbox "Error: Directory $dir not found!" 8 60
            missing=1
        fi
    done

    if [ $missing -eq 1 ]; then exit 1; fi
}

copy_configs() {
    dialog --infobox "Copying files and config files..." 5 60
    
    # Create media structure
    mkdir -p /var/lib/minidlna/{Video,Music,Pictures}
    mkdir -p /media/usb
    
    if [ ! -d "/var/lib/minidlna/Video/Web" ]; then
        mkdir -p /var/lib/minidlna/Video/Web
    fi

    # 1. CLEANUP RECURSIVE LINKS (The Fix)
    # Find and remove any symlink inside /var/lib/minidlna that points back to itself
    find /var/lib/minidlna -type l -exec sh -c '
    target=$(readlink "$1")
    [[ "$target" == *"/var/lib/minidlna"* ]] && rm "$1"
' sh {} \;


    # 2. Copy new Media files needed for Apache web backgrounds
    cp --force $IMAGE_DIR/{1,2,3,4,5,6,7,8,waves}.mp4 /var/lib/minidlna/Pictures/
    cp --force $IMAGE_DIR/{10,11,12,13,14,15,16,17,18,19,20,21,22,23}.jpg /var/lib/minidlna/Pictures/
    
    # 3. Copy System Scripts & Configs
    cp --force "$CONFIG_DIR/usb_sync.sh" /usr/local/bin/
    chmod +x /usr/local/bin/usb_sync.sh
    cp --force "$CONFIG_DIR/99-usb-autosync.rules" /etc/udev/rules.d/
    cp --force "$CONFIG_DIR/usb_sync.service" /etc/systemd/system/
    cp --force "$CONFIG_DIR/motd" /etc/motd
    sed "s/SAMBA_USER/$CURRENT_USER/" "$CONFIG_DIR/smb.conf" > /etc/samba/smb.conf
    cp --force "$CONFIG_DIR/minidlna.conf" /etc/
    cp --force "$CONFIG_DIR/mkv-2-mp4.sh" /usr/local/bin/
    chmod +x /usr/local/bin/mkv-2-mp4.sh

    # 4. clean out Apache Web Files (Apache Root)   
    rm -rf /var/www/html/*
    sleep 2
    cp --force $WEB_DIR/{index.html,sync_status.php,disk_status.php,wifi_status.php,get_backgrounds.php,sw.js} /var/www/html/
    cp --force $IMAGE_DIR/{popcorn.png,movie.png,music.png} /var/www/html/
    cp --force "$CONFIG_DIR/000-default.conf" /etc/apache2/sites-enabled/

    # 5. Web Files (MiniDLNA Overlays)
    # Using explicit file names to prevent directory-to-directory recursion
    cp --force "$WEB_DIR/get_files.php" /var/lib/minidlna/
    cp --force "$WEB_DIR/index.php" /var/lib/minidlna/
    cp --force "$WEB_DIR/env" /var/lib/minidlna/.env
    
    # 6. Set Permissions
    chown -R www-data:www-data /var/www/html
    chown -R minidlna:minidlna /var/lib/minidlna
    # Ensure standard dirs are searchable
    chmod -R 755 /var/lib/minidlna
	
    systemctl daemon-reload
    a2enmod headers
    systemctl restart apache2
}

set_minidlna_friendly_name() {
    local hostname
    hostname=$(hostname)
    if grep -q "^friendly_name=" /etc/minidlna.conf; then
        sed -i "s/^friendly_name=.*/friendly_name=$hostname/" /etc/minidlna.conf
    else
        echo "friendly_name=$hostname" >> /etc/minidlna.conf
    fi
    dialog --msgbox "This MiniDLNA server will appear to smart devices (like TV's) as '$hostname'." 6 60
}

configure_samba() {
	# Get the hostname and append .local for the hint
	LOCAL_HOSTNAME="$(hostname).local"

	# 1. Ask the user for the password once
    dialog --title "Network Sharing (Samba)" --inputbox "Set a network password for user '$CURRENT_USER'.\n\nThis allows network users to see this PC (\\\\$LOCAL_HOSTNAME) on your network to copy or watch media:" 11 70 2> /tmp/smbpass

    # 2. Check if the user entered anything
    if [ ! -s /tmp/smbpass ]; then
        dialog --msgbox "Error: No password provided. Please try again." 7 60
        return 1
    fi

    # 3. Ensure the system user exists
    if ! id "$CURRENT_USER" >/dev/null 2>&1; then
        adduser --system --no-create-home "$CURRENT_USER"
    fi

    # 4. Automate the password entry (Types it twice for the user)
    password=$(cat /tmp/smbpass)
    export SMB_PASS="$password"
    export SMB_USER="$CURRENT_USER"

    /usr/bin/expect << 'EOF'
set timeout 10
spawn smbpasswd -a $env(SMB_USER)
expect {
    "New SMB password:" {
        send "$env(SMB_PASS)\r"
        exp_continue
    }
    "Retype new SMB password:" {
        send "$env(SMB_PASS)\r"
        exp_continue
    }
    eof
}
EOF

    # 5. Cleanup sensitive data
    unset SMB_PASS
    unset SMB_USER
    rm -f /tmp/smbpass

    usermod -aG minidlna $CURRENT_USER
    chmod -R 775 /var/lib/minidlna
    chown -R minidlna:minidlna /var/lib/minidlna
    chgrp minidlna -Rv /var/lib/minidlna/

    rm -f /tmp/smbpass

    SYMLINK_PATH="$HOME_DIR/minidlna-link"
    if [ -L "$SYMLINK_PATH" ]; then
        if [ "$(readlink -f "$SYMLINK_PATH")" != "/var/lib/minidlna" ]; then
            rm "$SYMLINK_PATH"
            ln -s /var/lib/minidlna "$SYMLINK_PATH"
        fi
    elif [ -e "$SYMLINK_PATH" ]; then
        dialog --msgbox "$SYMLINK_PATH exists and is not a symlink. Skipping symlink creation." 6 60
    else
        ln -s /var/lib/minidlna "$SYMLINK_PATH"
    fi
    chown "$CURRENT_USER:$CURRENT_USER" "$SYMLINK_PATH"

    dialog --msgbox "Samba user and directories configured for '$CURRENT_USER'." 7 60
}

setup_media_scraper() {
    dialog --infobox "Setting up Media Scraper Service and Metadata directories..." 5 60
    sleep 3
    
     	mkdir -p /home/pi/scraper
        cp $BASE_DIR/scraper.py /home/pi/scraper/ 2>/dev/null || true 
    # 1. Install system dependencies for media scraper
    # Added python3-pil as a system safety measure
    apt-get update
    apt-get install -y python3-venv python3-full python3-pil
    
    # 2. Setup Metadata directory structure
    mkdir -p /var/lib/minidlna/.metadata/posters
    
    # Permissions logic
    usermod -a -G minidlna "$CURRENT_USER"
    chown -R minidlna:minidlna /var/lib/minidlna/.metadata
    chmod -R 775 /var/lib/minidlna/.metadata
    chmod g+s /var/lib/minidlna/.metadata/posters
    
    # 3. Setup Scraper application directory
    local SCRAPER_DIR="/home/$CURRENT_USER/scraper"
    mkdir -p "$SCRAPER_DIR"
    
    if [ -f "$BASE_DIR/scraper.py" ]; then
    cp "$BASE_DIR/scraper.py" "$SCRAPER_DIR/"
else
    dialog --msgbox "Error: $BASE_DIR/scraper.py not found!" 8 60
fi
    # 4. Create Virtual Environment and install packages
    # ADDED: Pillow and beautifulsoup4
    cd "$SCRAPER_DIR"
    python3 -m venv venv
    ./venv/bin/pip install requests parse-torrent-title ddgs Pillow beautifulsoup4
    chown -R "$CURRENT_USER:$CURRENT_USER" "$SCRAPER_DIR"

    # 5. Create the Systemd Service
    # ENSURED: ExecStart points to scraper.py
    cat << EOF > /etc/systemd/system/media-scraper.service
[Unit]
Description=Media Metadata Scraper
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=$CURRENT_USER
WorkingDirectory=$SCRAPER_DIR
ExecStartPre=/bin/bash -c 'ping -c 1 8.8.8.8 > /dev/null 2>&1'

ExecStart=$SCRAPER_DIR/venv/bin/python3 scraper.py
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

    # 6. Create the Systemd Timer (5am)
    cat << EOF > /etc/systemd/system/media-scraper.timer
[Unit]
Description=Run Media Scraper daily at 5am

[Timer]
OnCalendar=*-*-* 05:00:00
Persistent=true
Unit=media-scraper.service

[Install]
WantedBy=timers.target
EOF

    # 7. Enable and Start
    systemctl daemon-reload
    systemctl enable media-scraper.timer
    systemctl start media-scraper.timer
    CHOICE_SCRAPER="[ ENABLED ]"

    dialog --msgbox "Media Scraper installed.\n\nPath: $SCRAPER_DIR\nPosters & Synopsis: /var/lib/minidlna/.metadata/posters\nTimer: 5:00 AM" 12 60
}

setup_mkv_conversion_service() {
    SERVICE_FILE="/etc/systemd/system/mkv-conversion.service"
    TIMER_FILE="/etc/systemd/system/mkv-conversion.timer"
    
    # Use the explicitly defined $CONFIG_DIR instead of the undefined $SCRIPT_DIR
    MKV_CONVERT_ABS_PATH="/usr/local/bin/mkv-2-mp4.sh"

    # Safety check: Ensure the source file exists before trying to enable the service
    if [ ! -f "$CONFIG_DIR/mkv-2-mp4.sh" ]; then
        dialog --msgbox "MKV conversion script $MKV_CONVERT_ABS_PATH not found.\n\nChecked in: $CONFIG_DIR" 10 70
        return
    fi

    dialog --infobox "Configuring MKV conversion service..." 5 60

    cat << EOF > $SERVICE_FILE
[Unit]
Description=MKV to MP4 Conversion Service at midnight
After=network.target

[Service]
Type=oneshot
# Use absolute path to bash for systemd stability
ExecStart=/bin/bash $MKV_CONVERT_ABS_PATH
User=root
Group=root
WorkingDirectory=/var/lib/minidlna/Video
RemainAfterExit=no
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF

    cat << EOF > $TIMER_FILE
[Unit]
Description=Run MKV to MP4 conversion daily at midnight

[Timer]
OnCalendar=*-*-* 00:00:00
Persistent=true
Unit=mkv-conversion.service

[Install]
WantedBy=timers.target
EOF

    systemctl daemon-reload
    systemctl enable mkv-conversion.timer
    systemctl start mkv-conversion.timer
    
    if systemctl is-active --quiet mkv-conversion.timer; then
        local status="ACTIVE"
    else
        local status="FAILED TO START"
    fi

    dialog --msgbox "MKV conversion timer has been set up.\n\nIt will run daily at midnight.\nLocation: $MKV_CONVERT_ABS_PATH" 12 60
}

offer_mkv_conversion() {
    if dialog --title "Batch MKV to MP4 Conversion" --defaultno --yesno \
    "Do you want to set up a batch conversion script?\n\nThis will re-encode / remux at midnight any MKV file to MP4 in your Video directory to ensure maximum compatibility with all media players." 10 70; then
        setup_mkv_conversion_service
        CHOICE_MKV="[ ENABLED ]"
    else
        CHOICE_MKV="[ DISABLED ]"
    fi
    return 0
}

show_final_summary() {
    # Initialise variables to avoid empty display if Wi-Fi wasn't configured
    local ap_details=""
    
    # Only pull details if the user explicitly ENABLED the AP in this run
    if [ "$CHOICE_WIFI" = "[ ENABLED ]" ]; then
        # We look specifically for the Access Point profile. 
        # Your wifi script names the connection after the $SSID.
        # We can find it by looking for the 'shared' IP method you configured.
        local ap_name=$(nmcli -t -f NAME,IP4.METHOD connection show | grep ":shared" | cut -d: -f1 | head -n1)
        
        if [ -n "$ap_name" ]; then
            local actual_ssid=$(nmcli -s -g 802-11-wireless.ssid connection show "$ap_name")
            local actual_pass=$(nmcli -s -g 802-11-wireless-security.psk connection show "$ap_name")
            ap_details="\n    - Wi-Fi SSID:             $actual_ssid\n    - Wi-Fi Password:         $actual_pass"
        else
            ap_details="\n    - Status: AP profile not not activated until reboot"
        fi
    fi

    local msg="Setup Complete! Your Mini-Pi Server is configured to run:\n\n\
    - User Account:            $CURRENT_USER\n\
    - Samba Access:            [ CONFIGURED ]\n\
    - Remote Server Sync:      $CHOICE_SYNC\n\
    - Google Drive Sync:       $CHOICE_gdrive\n\
    - Wi-Fi/AP:                $CHOICE_WIFI$ap_details\n\
    - Media Scraper:           [ CONFIGURED ]\n\
    - MKV Conversion:          $CHOICE_MKV\n\n
The system will now reboot."

    dialog --title "Installation Summary" --msgbox "$msg" 18 60
}

finalize_setup() {
    # 1. Remote Server Sync Configuration
    SYNC_CHOICE=$(dialog --clear \
                --title " Remote Server Sync " \
                --menu "\nSelect your preferred media sync method:" 15 60 3 \
                1 "Mirror sync from remote server (uses same space as server)" \
                2 "Sync for the past X months (Rotating)" \
                3 "Don't set any sync from a server" \
                2>&1 >/dev/tty)

    case $SYNC_CHOICE in
        1)
            CHOICE_SYNC="[ MIRROR ]"
            sudo bash "$BASE_DIR/configure_server_sync.sh"
            ;;
        2)
            CHOICE_SYNC="[ ROTATING ]"
            sudo bash "$BASE_DIR/rotating-server-sync.sh"
            ;;
        3)
            CHOICE_SYNC="[ DISABLED ]"
            ;;
    esac

	if dialog --title "Cloud Drive Sync" --yesno "Would you like to set up Cloud (Google, One Drive or Mega) sync ?" 7 60; then
        if [ -f "$BASE_DIR/rclone-setup.sh" ]; then
            sudo bash "$BASE_DIR/rclone-setup.sh"
            CHOICE_gdrive="[ CONFIGURED ]"
        else
            dialog --msgbox "Error: $BASE_DIR/rclone-setup.sh not found!" 8 60
            CHOICE_gdrive="[ FILE MISSING ]"
        	fi
    	else
        CHOICE_gdrive="[ DISABLED ]"
	fi

    # 2. WiFi Reconfiguration
    if dialog --title "Reconfigure WiFi to an Access point" --defaultno --yesno "NOTE: Only select yes if you DO want the WiFi card as an access point. make sure your pi server is plugged up via Ethernet before you proceed.\n\nDo you want to reconfigure Wi-Fi/Access Point?" 10 70; then
        if [ -f "$BASE_DIR/reconfigure-wifi.sh" ]; then
            sudo bash "$BASE_DIR/reconfigure-wifi.sh"
            [ $? -eq 0 ] && CHOICE_WIFI="[ ENABLED ]" || CHOICE_WIFI="[ FAILED ]"
        else
            CHOICE_WIFI="[ FILE MISSING ]"
            dialog --msgbox "Error: $BASE_DIR/reconfigure-wifi.sh not found!" 8 60
        fi
    else
        CHOICE_WIFI="[ SKIPPED ]"
    fi

    show_final_summary
    return 0
}

#--- Run Order ---
display_header
check_files
install_packages
copy_configs
set_minidlna_friendly_name
configure_samba
set +e
offer_mkv_conversion
setup_media_scraper
finalize_setup
set -e

# Final reboot prompt
if dialog --title "Reboot Required" --yesno "The setup is complete. Would you like to reboot now?" 7 60; then
    reboot
fi
