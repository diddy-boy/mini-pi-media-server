<?php
header('Content-Type: application/json');

function getNetworkStatus() {
    clearstatcache();
    
    // 1. Check for Ethernet Carrier FIRST
    $eth_path = '/sys/class/net/eth0/carrier';
    $is_eth = (file_exists($eth_path) && trim(@file_get_contents($eth_path)) === '1');

    // 2. Only get Ethernet IP if the carrier is active
    $eth_ip = 'Disconnected';
    if ($is_eth) {
        $eth_ip = trim(shell_exec("ip -4 addr show eth0 | grep -oP '(?<=inet\s)\d+(\.\d+){3}'") ?? '');
    }
    
    return [
        'mode' => $is_eth ? 'LAN' : 'WIFI',
        'text' => $is_eth ? 'Connected via LAN' : 'Access Point only',
        'eth_ip' => $eth_ip ?: 'Disconnected',
        'ap_ip' => '192.168.50.1' 
    ];
}

echo json_encode(getNetworkStatus());
?>