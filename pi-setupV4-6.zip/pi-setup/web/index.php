<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 0);
ini_set('error_log', '/var/log/php_errors.log');

// Configuration
$base_dir = '/var/lib/minidlna';
$web_base = '/files';
// Folder where posters are stored
$poster_base = '/files/.metadata/posters'; 

// Get current directory from URL path
$request_uri = $_SERVER['REQUEST_URI'] ?? '/files/';
$path_parts = parse_url($request_uri, PHP_URL_PATH);
if (!$path_parts) {
    $path_parts = '/files/';
}
$relative_path = trim(str_replace($web_base, '', $path_parts), '/');
$current_dir = $base_dir . ($relative_path ? '/' . $relative_path : '');

// Security check
$real_base = realpath($base_dir);
$real_current = realpath($current_dir);

if (!$real_base) {
    http_response_code(500);
    die('Server configuration error: Base directory not found');
}

if (!$real_current || strpos($real_current, $real_base) !== 0) {
    $current_dir = $base_dir;
    $relative_path = '';
}

// File extensions
$image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
$video_extensions = ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm'];
$audio_extensions = ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'];
$hidden_extensions = ['php', 'env', 'srt', 'db', 'm3u', 'txt', 'nfo', 'DS_Store', 'thumbs'];

function get_file_extension($filename) {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

// PHP Helper to check for a poster file locally
function get_poster_url($filename, $poster_base) {
    $name_only = pathinfo($filename, PATHINFO_FILENAME);
    $local_check = $_SERVER['DOCUMENT_ROOT'] . $poster_base . '/' . $name_only . '.jpg';
    
    if (file_exists($local_check)) {
        return $poster_base . '/' . $name_only . '.jpg';
    }
    return '/movie.png'; 
}

function format_file_size($bytes) {
    if ($bytes === false) return 'Unknown';
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    elseif ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    elseif ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    else return $bytes . ' bytes';
}

function get_web_path($file_path, $base_dir, $web_base) {
    $relative = trim(str_replace($base_dir, '', $file_path), '/');
    return $web_base . ($relative ? '/' . $relative : '');
}

function get_directory_icon($dir_path, $image_extensions, $video_extensions, $audio_extensions, $hidden_extensions) {
    // 1. Define the SVG shapes
    $svgs = [
        'video'   => '<svg viewBox="0 0 24 24" width="48" height="48" fill="currentColor" style="display:block;margin:auto;"><path d="M18 7c0-1.103-.897-2-2-2H4c-1.103 0-2 .897-2 2v10c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-3.333L22 17V7l-4 3.333V7z"/></svg>',
        'audio'   => '<svg viewBox="0 0 24 24" width="48" height="48" fill="currentColor" style="display:block;margin:auto;"><path d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm1 10.19c.703.264 1.2 1.031 1.2 1.81 0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2c.101 0 .193.021.29.043V7h3v2-1.5v3.19z"/></svg>',
        'picture' => '<svg viewBox="0 0 24 24" width="48" height="48" fill="currentColor" style="display:block;margin:auto;"><path d="M19 3H5c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2V5c0-1.103-.897-2-2-2zM5 19V5h14l.002 14H5z"/><path d="m10 14-1-1-3 4h12l-5-7-3 4z"/><circle cx="8.5" cy="8.5" r="1.5"/></svg>',
        'folder'  => '<svg viewBox="0 0 24 24" width="48" height="48" fill="currentColor" style="display:block;margin:auto;"><path d="M20 5h-9.586L8.707 3.293A.997.997 0 0 0 8 3H4c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V7c0-1.103-.897-2-2-2z"/></svg>'
    ];

    // 2. Hardcoded Name Check (Pictures Priority)
    $folder_name = strtolower(basename($dir_path));
    if ($folder_name === 'pictures' || $folder_name === 'photos') return $svgs['picture'];
    if ($folder_name === 'video' || $folder_name === 'videos') return $svgs['video'];
    if ($folder_name === 'music') return $svgs['audio'];

    // 3. Subfolder Content Check
    $items = @scandir($dir_path);
    if ($items === false) return $svgs['folder'];
    
    $has_images = $has_videos = $has_audio = false;
    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item[0] === '.') continue;
        $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
        if (in_array($ext, $video_extensions)) $has_videos = true;
        elseif (in_array($ext, $audio_extensions)) $has_audio = true;
        elseif (in_array($ext, $image_extensions)) $has_images = true;
    }

    if ($has_videos) return $svgs['video'];
    if ($has_audio)  return $svgs['audio'];
    if ($has_images) return $svgs['picture'];
    
    return $svgs['folder'];
}

$directories = [];
$files = [];
if (is_dir($current_dir) && is_readable($current_dir)) {
    $items = @scandir($current_dir);
    if ($items !== false) {
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || $item[0] === '.') continue;
            $item_path = $current_dir . '/' . $item;
            $extension = get_file_extension($item);
            if (in_array($extension, $hidden_extensions)) continue;
            
            if (is_dir($item_path)) {
                $directories[] = [
                    'name' => $item,
                    'web_path' => get_web_path($item_path, $base_dir, $web_base),
                    'icon' => get_directory_icon($item_path, $image_extensions, $video_extensions, $audio_extensions, $hidden_extensions)
                ];
            } else {
                $size = @filesize($item_path);
                if ($size === false) continue;
                $files[] = [
                    'name' => $item,
                    'web_path' => get_web_path($item_path, $base_dir, $web_base),
                    'size' => format_file_size($size),
                    'extension' => $extension,
                    'poster' => in_array($extension, $video_extensions) ? get_poster_url($item, $poster_base) : null
                ];
            }
        }
    }
}

usort($directories, fn($a, $b) => strcasecmp($a['name'], $b['name']));
usort($files, fn($a, $b) => strcasecmp($a['name'], $b['name']));

$page_title = 'Pi Media - ' . ($relative_path ? htmlspecialchars($relative_path) : 'Main');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini-Pi Media Browser</title>
    <link rel="icon" type="image/png" href="/popcorn.png" />
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Cinzel', serif; }
    body { background: #000; color: #f4e9cd; overflow: auto; }
    /* Strict Layout control for the Preview Panel */
    .preview {
        flex: 1;
        padding: 30px;
        display: flex;
        flex-direction: column;
        align-items: stretch;
        justify-content: flex-start;
        overflow-y: auto;
        min-height: 0;
    }
    
    .preview-wrapper {
    display: flex;
    flex-direction: column;
    justify-content: center;
    width: 100%;
    }
    /* 1. Container for Title and Rating */
.preview-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    width: 100%;
    margin-bottom: 15px;
    min-width: 0;
}

/* 2. Style for the Title (Force Truncation) */
.preview-title {
    font-size: 1.4em;
    font-weight: bold;
    margin: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis; 
    min-width: 0; 
    flex: 1; 
}

/* 3. Style for the Rating Badge */
.preview-rating {
    background: #f5c518;
    color: #000;
    padding: 3px 8px;
    border-radius: 4px;
    font-weight: bold;
    font-size: 0.9em;
    flex-shrink: 0; 
    white-space: nowrap;
}
    .breadcrumb {
    display: flex;
    align-items: center;
    gap: 8px;
}
   #movie-synopsis {
    margin-top: 20px;
    padding: 18px;
    background: rgba(0, 0, 0, 0.5);
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.8);
    max-height: 25vh; 
    overflow-y: auto;
    opacity: 0;
    transition: opacity 0.8s ease-in-out;
    display: none;
    font-family: 'Cinzel', serif;
    font-weight: 400;
    font-size: 0.95rem; 
    line-height: 1.6; 
    letter-spacing: 0.5px; 
    text-transform: none;
    text-align: justify;
    hyphens: auto;
    color: #e0e0e0; 
}
    #movie-synopsis::-webkit-scrollbar {
        width: 6px;
    }
    #movie-synopsis::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.4);
    border-radius: 10px;
    }
    #movie-synopsis::-webkit-scrollbar-thumb {
    background: rgba(244, 233, 205, 0.3);
    border-radius: 10px;
    transition: background 0.3s ease;
    }
    .preview-rt-rating {
    background: #ff3333;
    color: #fff;
    padding: 3px 8px;
    border-radius: 4px;
    font-weight: bold;
    font-size: 0.85em;
    flex-shrink: 0;
    white-space: nowrap;
    display: none;
    box-shadow: 0 2px 5px rgba(0,0,0,0.3);
}
    #movie-synopsis::-webkit-scrollbar-thumb:hover {
    background: rgba(244, 233, 205, 0.6);
}
    .rating-container {
    display: flex;
    gap: 8px;
    align-items: center;
}
/* 1. The Glass Container for each item */
.file-item {
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
}

/* 2. The Signature Gold Icons */
.file-item svg {
    filter: drop-shadow(0 10px 15px rgba(0,0,0,0.5));
    transition: transform 0.4s ease;
}

/* 3. The Premium Hover Animation */
.file-item:hover {
    background: rgba(255, 255, 255, 0.08);
    border-color: rgba(255, 215, 0, 0.3); 
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.6);
}

.file-item:hover svg {
    transform: scale(1.1) rotate(2deg);
}

/* 4. THE MERGED FILE NAME (Style + Layout) */
.file-item .file-name {
    font-family: 'Cinzel', serif;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    color: #d4af37; /* The Muted Gold */
    margin-top: 15px;
    text-shadow: 0px 2px 4px rgba(0, 0, 0, 0.8), 
                 0px 0px 10px rgba(0, 0, 0, 0.5);
    
    /* Your essential layout logic */
    font-size: 0.85rem; 
    font-weight: bold; 
    word-wrap: break-word;
    overflow: hidden; 
    display: -webkit-box; 
    -webkit-line-clamp: 2; /* Keeps it to 2 lines */
    -webkit-box-orient: vertical;
    line-height: 1.3;
}

/* 5. Keep your mobile fix at the bottom */
@media (max-width: 768px) {
    .container { 
        flex-direction: column; 
        height: auto; 
    }
}

    /* Resume Playback Overlay */
.resume-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    z-index: 10;
    border-radius: 15px;
    backdrop-filter: blur(5px);
    transition: opacity 0.3s ease;
}

.resume-box {
    background: rgba(255, 255, 255, 0.1);
    padding: 30px;
    border-radius: 15px;
    border: 1px solid rgba(255, 255, 255, 0.3);
    text-align: center;
}

.resume-box h4 {
    margin-bottom: 20px;
    color: #f4e9cd;
    letter-spacing: 2px;
}

.resume-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
}

.resume-btn {
    padding: 10px 25px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-family: 'Cinzel', serif;
    font-weight: bold;
    transition: 0.3s;
}

.resume-yes { background: #d4af37; color: #000; }
.resume-no { background: rgba(255,255,255,0.2); color: #fff; }

.resume-yes:hover { background: #fff; transform: scale(1.05); }
.resume-no:hover { background: rgba(255,255,255,0.4); }
/* 1. Style the text the user actually types */
#fileSearch {
    font-family: 'Cinzel', serif !important;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: #ffffff !important;
}

/* 2. Force the placeholder text to be solid white (no transparency) and Cinzel */
#fileSearch::placeholder {
    color: #ffffff !important;
    opacity: 1 !important; /* This prevents the 'grey' look */
    font-family: 'Cinzel', serif !important;
    text-transform: uppercase;
}

/* Chrome, Safari, and newer Edge */
#fileSearch::-webkit-input-placeholder {
    color: #ffffff !important;
    opacity: 1 !important;
    font-family: 'Cinzel', serif !important;
    text-transform: uppercase;
}

/* Firefox */
#fileSearch::-moz-placeholder {
    color: #ffffff !important;
    opacity: 1 !important;
    font-family: 'Cinzel', serif !important;
    text-transform: uppercase;
}

/* Internet Explorer / Old Edge */
#fileSearch:-ms-input-placeholder {
    color: #ffffff !important;
    font-family: 'Cinzel', serif !important;
    text-transform: uppercase;
}
    .parallax { 
    min-height: 100vh; 
    position: relative; 
    display: flex; 
    justify-content: center; 
    align-items: center;
    overflow: hidden; 
    animation: fadeIn 0.8s ease-out; 
}
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .background { 
    position: fixed; 
    top: 0; 
    left: 0; 
    width: 100%; 
    height: 100%; 
    filter: blur(2px) brightness(0.7); 
    z-index: -1; 
    
    /* THE KEY FIXES: */
    background-size: cover; 
    background-position: center; 
    background-repeat: no-repeat;
}
    .background-video { position: absolute; top: 0; left: 0; width: 100vw; height: 100vh; object-fit: cover; filter: blur(2px) brightness(0.7); }
    .container { max-width: 1800px; width: 100%; display: flex; gap: 25px; padding: 20px; margin-top: 2vh; height: 95vh; }
/* --- YOUR ORIGINAL LOOK PRESERVED --- */
.file-list, .preview { 
    background: rgba(255, 255, 255, 0.08); 
    backdrop-filter: blur(20px); 
    border: 1px solid rgba(255, 255, 255, 0.15); 
    border-radius: 18px; 
    box-shadow: 0 8px 32px rgba(0,0,0,0.8); 
}

.file-list { 
    flex: 0 0 50%; 
    padding: 25px; 
    display: flex; 
    flex-direction: column; 
    overflow: hidden; 
    /* This line is the only change: it anchors the '?' icon to the corner */
    position: relative; 
}

/* --- NEW HELP ICON STYLES --- */
/* --- HELP SYSTEM (TOP RIGHT PREVIEW) --- */
.help-container {
    position: absolute;
    top: 10px; 
    right: 10px; 
    z-index: 1001; 
}

.help-icon {
    width: 26px;
    height: 26px;
    border: 1px solid rgba(244, 233, 205, 0.4);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #f4e9cd;
    cursor: help;
    font-size: 0.9rem;
    background: rgba(0, 0, 0, 0.6);
    transition: all 0.3s ease;
}

.help-container:hover .help-icon {
    background: #d4af37;
    color: #000;
    border-color: #d4af37;
    box-shadow: 0 0 15px rgba(212, 175, 55, 0.4);
}

.help-tooltip {
    position: absolute;
    top: 40px; 
    right: 0;
    width: 220px;
    background: rgba(10, 10, 10, 0.98);
    backdrop-filter: blur(15px);
    border: 1px solid rgba(255, 255, 255, 0.4);
    border-radius: 10px;
    padding: 15px;
    opacity: 0;
    visibility: hidden;
    transform: translateY(-10px);
    transition: all 0.3s ease;
    box-shadow: 0 10px 30px rgba(0,0,0,1);
    text-align: left;
    font-family: 'Cinzel', serif;
    letter-spacing: 0.5px;
}

.help-container:hover .help-tooltip {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

.help-header {
    font-family: 'Cinzel', serif;
    color: #d4af37;
    font-size: 0.85rem;
    font-weight: 700;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    padding-bottom: 8px;
    margin-bottom: 12px;
    letter-spacing: 2px;
    text-transform: uppercase;
}

.help-row {
    font-family: 'Cinzel', serif;
    display: flex;
    justify-content: space-between;
    font-size: 0.7rem;
    margin-bottom: 8px;
    color: #f4e9cd;
    letter-spacing: 1px;
}

.help-row span:last-child {
    color: rgba(244, 233, 205, 0.6);
}
.home-title, .breadcrumb a, .btn { 
    display: inline-block; 
    padding: 10px 22px; 
    font-size: 0.9rem; 
    font-weight: 600; 
    text-decoration: none; 
    color: rgba(255, 255, 255, 0.95); 
    background: rgba(255, 255, 255, 0.08); 
    backdrop-filter: blur(20px) saturate(180%); 
    -webkit-backdrop-filter: blur(20px) saturate(180%);
    
    border: 1px solid rgba(255, 255, 255, 0.18); 
    border-radius: 12px; 
    position: relative; 
    overflow: hidden; 
    box-shadow: 0 4px 15px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.1);
    transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), background 0.3s ease;
    cursor: pointer; 
}
/* 1. Style for the image specifically */
#preview-content img {
    max-width: 100%;
    border-radius: 15px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.9);
    border: 1px solid rgba(255, 255, 255, 0.1);
    transition: transform 0.3s ease;
}

/* 2. Apply the animation to the CONTAINER instead */
#preview-content {
    animation: fadeIn 0.4s ease-in-out;
}

/* 3. The Keyframes */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.2); 
    transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), 
                background-color 0.3s ease, 
                box-shadow 0.3s ease;
    cursor: pointer; 
}

/* The Shimmer Hover Effect */
.home-title::before, .breadcrumb a::before, .btn::before { 
    content: ""; 
    position: absolute; 
    top: 0; 
    left: -100%; 
    width: 100%; 
    height: 100%; 
    background: linear-gradient(120deg, transparent, rgba(255, 255, 255, 0.15), transparent); 
    transition: all 0.6s; 
}

.home-title:hover, .breadcrumb a:hover, .btn:hover { 
    background: rgba(255, 255, 255, 0.25); 
    transform: translateY(-2px); 
}

.home-title:hover::before, .breadcrumb a:hover::before, .btn:hover::before { 
    left: 100%; 
}

.btn:active, .home-title:active, .breadcrumb a:active { 
    transform: translateY(1px); 
}
    #directory-list, #file-list { display: grid; gap: 20px; grid-template-columns: repeat(3, 1fr); overflow-y: auto; flex-grow: 1; padding-bottom: 20px; }
    .file-item { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 10px; background: rgba(255,255,255,0.05); border-radius: 15px; transition: 0.3s; height: 240px; text-align: center; width: 100%;
    box-sizing: border-box; overflow: hidden;}
    .file-item:hover { background: rgba(255,255,255,0.2); transform: translateY(-5px); }
    .file-icon { width: 100%; height: 120px; object-fit: contain; border-radius: 8px; margin-bottom: 8px; background: #000; }
	#video-player {
    	width: 100%;
    	height: 50vh; 
    	object-fit: contain;
    	background: #000;
    	border-radius: 15px;
   	margin-bottom: 20px;
   	box-shadow: 0 10px 30px rgba(0, 0, 0, 0.8);
	}

	/* Mobile Devices (Phones) */
	@media (max-width: 768px) {
    	#video-player {
        height: 30vh; 
    		}
	}
    .file-poster {
        width: 100%;
        height: 160px;
        object-fit: contain; 
        background: rgba(0,0,0,0.2);
        border-radius: 6px;
        margin-bottom: 10px;
    }
    .file-name { ffont-size: 0.85rem; 
        font-weight: bold; 
        color: #f4e9cd;
        word-wrap: break-word;
        overflow: hidden; 
        display: -webkit-box; 
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        line-height: 1.2; }
    .file-info { font-size: 0.7rem; opacity: 0.6; margin-top: 5px; }
    @media (max-width: 768px) {
        .container { flex-direction: column; height: auto; }
        #directory-list, #file-list { grid-template-columns: repeat(2, 1fr); }
    }
</style>
</head>
<body>
    <div class="parallax">
        <div class="background"></div> 
        <div class="container">
            <div class="file-list">
                <div class="nav-header" style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px;">
                    <a href="/index.html" class="home-title">Home</a>
                    <div class="breadcrumb" style="display: flex; align-items: center; gap: 8px;">
                        <a href="#" class="main-directory-link">Main Directory</a>
                        <?php
                        if ($relative_path) {
                            $parts = explode('/', $relative_path);
                            $acc = '';
                            foreach ($parts as $p) {
                                $acc .= ($acc ? '/' : '') . $p;
                                echo ' <span style="opacity:0.5">/</span> <a href="'.$web_base.'/'.$acc.'/">'.htmlspecialchars($p).'</a>';
                            }
                        }
                        ?>
                    </div>
                </div>
                            <div style="margin-bottom: 15px; padding: 0 5px;">
    <input type="text" id="fileSearch" placeholder="SEARCH..." 
           style="width: 100%; background: rgba(255,255,255,0.05); border: 1px solid rgba(244, 233, 205, 0.4); 
           padding: 12px; border-radius: 10px; color: #ffffff; font-family: 'Cinzel', serif; outline: none; font-size: 0.8rem; text-transform: uppercase;">
</div>

<h1 id="list-title" style="margin-bottom:15px; font-size:1.2rem;">Browse</h1>  
                <div id="directory-list">
                    <?php foreach ($directories as $d): ?>
                        <div class="file-item directory" data-path="<?php echo $d['web_path']; ?>">
                            <div style="font-size:3.5rem;"><?php echo $d['icon']; ?></div>
                            <div class="file-name"><?php echo htmlspecialchars($d['name']); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div id="file-list" style="display: none;"></div>
            </div>
            <div class="preview">
    <div id="preview-content" class="preview-wrapper">
        <p style="text-align: center;">Choose a Directory or select a file to play</p>
    		</div>
	</div>
    </div>

                <div class="help-container">
                    <div class="help-icon">?</div>
                    <div class="help-tooltip">
                        <div class="help-header">Controls</div>
                        <div class="help-row"><span>ARROWS UP/DN</span> <span>VOLUME</span></div>
                        <div class="help-row"><span>ARROWS L/R</span> <span>SEEK / NAV</span></div>
                        <div class="help-row"><span>SPACE</span> <span>PLAY / PAUSE</span></div>
                        <div class="help-row"><span>ENTER / F</span> <span>FULLSCREEN</span></div>
                        <div class="help-row"><span>ESC</span> <span>EXIT VIEW</span></div>
                    </div>
                </div>
            </div> </div> </div>



<script>
    let backgrounds = [];
    let currentPath = '<?php echo $web_base . ($relative_path ? '/' . $relative_path : ''); ?>';
    let audioElement = null;
    let imagePlaylist = [];
    let currentImageIndex = -1;
    let selectedIndex = -1;
    let imageCycleInterval = null;

    // 1. Background Handling
    function setBackground(index = 0) {
    const bgDiv = document.querySelector('.background');
    if (backgrounds.length === 0) {
        bgDiv.style.background = 'linear-gradient(135deg, #000, #1a1a1a)';
        bgDiv.innerHTML = '';
        return;
    }

    const background = backgrounds[index % backgrounds.length];
    bgDiv.innerHTML = '';

    if (background.type === 'video') {
        // 2. Clear image background and create video element
        bgDiv.style.backgroundImage = 'none';
        
        const video = document.createElement('video');
        video.className = 'background-video';
        video.src = background.src;
        video.muted = true;
        video.loop = true;
        video.autoplay = true;
        video.playsInline = true;
        
        bgDiv.appendChild(video);
        video.play().catch(e => console.log('Autoplay blocked:', e));
    } else if (background.type === 'image') {
        // 3. Set image background as usual
        bgDiv.style.backgroundImage = `url('${background.src}')`;
    }
}

    // Fetch backgrounds from get_backgrounds.php
    function loadBackgrounds() {
        fetch('/get_backgrounds.php')
            .then(response => {
                if (!response.ok) throw new Error('Failed to fetch backgrounds: ' + response.statusText);
                return response.json();
            })
            .then(data => {
                if (!data.success) {
                    throw new Error('Background fetch unsuccessful');
                }
                backgrounds = data.backgrounds;
                const savedIndex = Math.max(0, Math.min(parseInt(localStorage.getItem('backgroundIndex')) || 0, backgrounds.length - 1));
                console.log('Backgrounds loaded:', backgrounds, 'Applying index:', savedIndex);
                setBackground(savedIndex);
            })
            .catch(error => {
                console.error('Error fetching backgrounds:', error);
                // Fallback to default gradient
                backgrounds = [{ type: 'gradient', src: 'gradient', name: 'Default Gradient' }];
                setBackground(0);
            });
    }

    // 2. Main File & Directory Loader
    function loadFiles(path) {
        currentPath = path;
        history.pushState({path: path}, '', path);
        
        fetch('/files/get_files.php?path=' + encodeURIComponent(path))
            .then(res => res.json())
            .then(data => {
                const dirList = document.getElementById('directory-list');
                dirList.innerHTML = '';
                selectedIndex = -1; 
                imagePlaylist = []; 
                
                const allItems = [];
                if (data.directories) data.directories.forEach(d => allItems.push({...d, isDir: true}));
                if (data.files) data.files.forEach(f => allItems.push({...f, isDir: false}));

                allItems.forEach((item, index) => {
                    const div = document.createElement('div');
                    div.className = 'file-item';
                    
                    let thumbHtml;
                    let fileType = 'other';

                    if (item.isDir) {
                fileType = 'directory';
                // Use the raw SVG code from the item.icon directly
                thumbHtml = `<div style="width: 100%; height: 120px; display: flex; align-items: center; justify-content: center;">${item.icon}</div>`;
                div.onclick = () => loadFiles(item.web_path);
                } else {
                        const ext = item.extension.toLowerCase();
                        const videoExts = <?php echo json_encode($video_extensions); ?>;
                        const audioExts = <?php echo json_encode($audio_extensions); ?>;
                        const isVideo = videoExts.includes(ext);
                        const isAudio = audioExts.includes(ext);
                        const isImage = <?php echo json_encode($image_extensions); ?>.includes(ext);

                        if (isImage) imagePlaylist.push({path: item.web_path, name: item.name});

                        if (isVideo) {
                            fileType = 'video';
                            const posterName = item.name.substring(0, item.name.lastIndexOf('.')) || item.name;
                            thumbHtml = `<img src="/files/.metadata/posters/${encodeURIComponent(posterName)}.jpg" onerror="this.onerror=null;this.src='/movie.png';" class="file-poster">`;
                        } else if (isImage) {
                            fileType = 'image';
                            thumbHtml = `<img src="${item.web_path}" class="file-poster" style="object-fit:cover;">`;
                        } else if (isAudio) {
                            fileType = 'audio';
                            thumbHtml = `<div style="font-size:3.5rem;">🎵</div>`;
                        } else {
                            thumbHtml = `<div style="font-size:3.5rem;">📄</div>`;
                        }
                        
                        div.onclick = (event) => {
                            selectedIndex = index;
                            showPreview(item.web_path, fileType, item.name, event);
                        };
                    }

                    div.innerHTML = `${thumbHtml}<div class="file-name">${item.name}</div>`;
                    dirList.appendChild(div);
                });
            }).catch(err => console.error("Error loading files:", err));
    }

    // 3. Preview Function
    function showPreview(file, type, filename, event) {
    const previewContent = document.getElementById('preview-content');
    
    // --- ANIMATION RESET LOGIC ---
    previewContent.style.animation = 'none';
    previewContent.offsetHeight;
    previewContent.style.animation = null; 
    // -----------------------------

    if (audioElement) { audioElement.pause(); audioElement = null; }
    
    if (type === 'image') {
        currentImageIndex = imagePlaylist.findIndex(img => img.path === file);
        previewContent.innerHTML = `
            <img src="${file}" alt="Preview" style="max-width:100%; border-radius:15px;">
            <div class="preview-info" style="margin-top:15px; text-align:center;">
                <h3>${filename}</h3>
                <p>Image ${currentImageIndex + 1} of ${imagePlaylist.length}. Use ←/→ for prev/next, Enter for full screen</p>
            </div>`;
    } else if (type === 'video') {
        const nameOnly = filename.substring(0,      filename.lastIndexOf('.')) || filename;
        const baseUrl = `/files/.metadata/posters/${encodeURIComponent(nameOnly)}`;

        previewContent.innerHTML = `
    <div style="position: relative; width: 100%;">
        <div id="resume-ui" class="resume-overlay" style="display: none;">
            <div class="resume-box">
                <h4>RESUME FROM <span id="resume-time-display">00:00</span>?</h4>
                <div class="resume-buttons">
                    <button id="btn-resume-yes" class="resume-btn resume-yes">YES</button>
                    <button id="btn-resume-no" class="resume-btn resume-no">START OVER</button>
                </div>
            </div>
        </div>
        <video id="video-player" controls autoplay>
            <source src="${file}" type="video/${file.split('.').pop()}">
        </video>
    </div>
    <div class="preview-info" style="margin-top:20px; text-align:center;">
        <div style="display: flex; justify-content: space-between; align-items: center; gap: 15px; margin-bottom: 10px; width: 100%; min-width: 0;">
            <h3 title="${filename}" style="margin: 0; color: #f4e9cd; font-size: 1.5rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; min-width: 0; text-align: left;">
                ${filename}
            </h3>
            <div class="rating-container">
                <span id="imdb-rating" class="preview-rating" style="display:none;"></span>
                <span id="rt-rating" class="preview-rt-rating" style="display:none;"></span>
            </div>
        </div>

                <p style="opacity: 0.6; font-size: 0.9rem; color: #f4e9cd; margin-bottom:15px; text-align: center;">
                    Video file. Seek with arrows. <strong>'F'</strong> for Fullscreen.
                </p>
                
                <a id="wiki-link" href="javascript:void(0)" target="_blank" style="text-decoration: none; color: inherit; pointer-events: none;">
                    <div id="movie-synopsis" style="margin-top:20px; padding:18px; background: rgba(0, 0, 0, 0.5); border-radius:12px; color: #f4e9cd; font-size:1.05rem; line-height:1.5; text-align:left; display: none; height: 140px; overflow-y: auto;"></div>
                </a>
                <p id="wiki-hint" style="opacity: 0.3; font-size: 0.7rem; margin-top: 10px; display:none;">(Click synopsis for Wikipedia)</p>
            </div>`;

        // --- 1. NEW RESUME FEATURE LOGIC ---
        const video = document.getElementById('video-player');
        const resumeUI = document.getElementById('resume-ui');
        const resumeTimeDisplay = document.getElementById('resume-time-display');
        const storageKey = 'resume_' + btoa(file); 
        const savedTime = localStorage.getItem(storageKey);

        if (savedTime && parseFloat(savedTime) > 15) {
            // Pause video and show overlay
            video.pause();
            const timeString = new Date(savedTime * 1000).toISOString().substr(11, 8);
            resumeTimeDisplay.innerText = timeString;
            resumeUI.style.display = 'flex';

            document.getElementById('btn-resume-yes').onclick = () => {
                video.currentTime = parseFloat(savedTime);
                resumeUI.style.display = 'none';
                video.play();
            };

            document.getElementById('btn-resume-no').onclick = () => {
                localStorage.removeItem(storageKey);
                resumeUI.style.display = 'none';
                video.play();
            };
        }

        video.ontimeupdate = () => {
            // Save time every few seconds, but only if we are past 15s and not at the very end
            if (video.currentTime > 15 && (video.duration - video.currentTime > 60)) {
                localStorage.setItem(storageKey, video.currentTime);
            }
        };

        video.onended = () => { localStorage.removeItem(storageKey); };

        // --- 2. IMDb RATING FETCH (With Blank-out Fix) ---
        const ratingBadge = document.getElementById('imdb-rating');
        fetch(`${baseUrl}.rating`)
            .then(res => res.text())
            .then(rating => {
                const cleanRating = rating.trim();
                if (cleanRating && cleanRating.length < 6 && !cleanRating.includes('<')) {
                    ratingBadge.innerText = "IMDb " + cleanRating;
                    ratingBadge.style.display = 'inline-block';
                } else {
                    ratingBadge.style.display = 'none';
                }
            }).catch(() => { ratingBadge.style.display = 'none'; });
            // --- 3. ROTTEN TOMATOES RATING FETCH ---
	const rtBadge = document.getElementById('rt-rating');
	fetch(`${baseUrl}.rt`)
    	.then(res => res.text())
    	.then(rtData => {
        const cleanRt = rtData.trim();
        // Check if data exists and isn't an HTML error page
        if (cleanRt && !cleanRt.includes('<')) {
            const criticsMatch = cleanRt.match(/Critics: (\d+)%/);
            const audienceMatch = cleanRt.match(/Audience: (\d+)%/);
            let displayHtml = "RT ";
            
            if (criticsMatch) {
                displayHtml += (parseInt(criticsMatch[1]) >= 60 ? '👍 ' : '👎 ') + criticsMatch[1] + '%';
            }
            if (audienceMatch) {
                displayHtml += ' / ' + (parseInt(audienceMatch[1]) >= 60 ? '👍 ' : '👎 ') + audienceMatch[1] + '%';
            }
            
            rtBadge.innerHTML = displayHtml;
            rtBadge.style.display = 'inline-block';
        }
    }).catch(() => { rtBadge.style.display = 'none'; });

        // --- 4. WIKIPEDIA URL FETCH ---
        const wikiLink = document.getElementById('wiki-link');
        const wikiHint = document.getElementById('wiki-hint');
        fetch(`${baseUrl}.url`)
            .then(res => res.text())
            .then(url => {
                const cleanUrl = url.trim();
                if (cleanUrl.startsWith('http')) {
                    wikiLink.href = cleanUrl;
                    wikiLink.style.pointerEvents = 'auto';
                    wikiLink.style.cursor = 'pointer';
                    wikiHint.style.display = 'block';
                }
            }).catch(() => { wikiLink.style.pointerEvents = 'none'; });

            // --- 5. MOVIE SYNOPSIS FETCH ---
const synopsisBox = document.getElementById('movie-synopsis');

// Add a timestamp to bypass browser caching
const cacheBuster = "?t=" + new Date().getTime();

fetch(`${baseUrl}.txt${cacheBuster}`) // <--- Added cacheBuster here
    .then(res => res.text())
    .then(text => {
        const cleanText = text.trim();
        const isHTML = cleanText.startsWith('<');
        
        if (!isHTML && cleanText.length > 10) {
            // It's a real synopsis - the replace() is a safety fallback for old files
            synopsisBox.innerText = cleanText.replace(/\[\d+\]/g, '');
            if (wikiHint) wikiHint.style.display = 'block';
            synopsisBox.style.display = 'block';
            setTimeout(() => {
                synopsisBox.style.opacity = '1';
            }, 10);
        } else {
            synopsisBox.style.display = 'none';
            if (wikiHint) wikiHint.style.display = 'none';
        }
    }).catch(() => { 
        synopsisBox.style.display = 'none'; 
        if (wikiHint) wikiHint.style.display = 'none';
    });
    } else if (type === 'audio') {
        previewContent.innerHTML = `
            <div style="width: 100%; text-align: center;">
                <div style="font-size:8rem; margin-bottom:30px; filter: drop-shadow(0 0 20px rgba(244, 233, 205, 0.4));">🎵</div>
                <div style="width: 100%; display: flex; justify-content: center; padding: 0 20px;">
                    <audio controls autoplay id="audio-player" style="width: 100%; max-width: 800px; height: 60px;">
                        <source src="${file}" type="audio/${file.split('.').pop()}">
                        Your browser does not support the audio tag.
                    </audio>
                </div>
                <div class="preview-info" style="margin-top:25px;">
                    <h3 style="font-size: 1.5rem; margin-bottom: 10px;">${filename}</h3>
                    <p style="opacity: 0.7; font-size: 0.9rem; line-height: 1.5;">
                        Audio file. Seek using cursor keys. Vol up/down.<br>
                        Press <strong>Space</strong> to pause/play.
                    </p>
                </div>
            </div>`;
        audioElement = document.getElementById('audio-player');
    }

    // Border highlight for selected item
    document.querySelectorAll('.file-item').forEach(item => item.style.border = 'none');
    if (event && event.currentTarget) { 
        event.currentTarget.style.border = '2px solid #f4e9cd'; 
    }
}

// 4. Integrated Keyboard Navigation & Media Controls
    document.addEventListener('keydown', (e) => {
        const t = e.target;
        if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;

        const items = document.querySelectorAll('.file-item');
        const media = document.querySelector('#preview-content video, #preview-content audio');
        const image = document.querySelector('#preview-content img');

        if (['ArrowRight', 'ArrowLeft', 'ArrowUp', 'ArrowDown'].includes(e.code)) {
            if (image && (e.code === 'ArrowRight' || e.code === 'ArrowLeft')) {
                e.preventDefault();
                if (e.code === 'ArrowRight' && currentImageIndex < imagePlaylist.length - 1) currentImageIndex++;
                else if (e.code === 'ArrowLeft' && currentImageIndex > 0) currentImageIndex--;
                showPreview(imagePlaylist[currentImageIndex].path, 'image', imagePlaylist[currentImageIndex].name);
            } 
            else if (media) {
                e.preventDefault();
                if (e.code === 'ArrowRight') media.currentTime = Math.min(media.currentTime + 5, media.duration || media.currentTime);
                if (e.code === 'ArrowLeft') media.currentTime = Math.max(media.currentTime - 5, 0);
                if (e.code === 'ArrowUp') media.volume = Math.min((media.volume || 0) + 0.1, 1);
                if (e.code === 'ArrowDown') media.volume = Math.max((media.volume || 0) - 0.1, 0);
            }
            else if (items.length > 0) {
                if (selectedIndex === -1) selectedIndex = 0;
                else if (e.code === 'ArrowRight') selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
                else if (e.code === 'ArrowLeft') selectedIndex = Math.max(selectedIndex - 1, 0);
                else if (e.code === 'ArrowUp') selectedIndex = Math.max(selectedIndex - 3, 0); 
                else if (e.code === 'ArrowDown') selectedIndex = Math.min(selectedIndex + 3, items.length - 1);

                items[selectedIndex].scrollIntoView({ behavior: 'smooth', block: 'center' });
                items[selectedIndex].click();
                e.preventDefault();
            }
        }

        if (e.code === 'Enter' || e.code === 'KeyF') {
            e.preventDefault();
            if (image) {
                if (image.requestFullscreen) image.requestFullscreen();
                else if (image.webkitRequestFullscreen) image.webkitRequestFullscreen();
            } else if (media && media.tagName === 'VIDEO') {
                if (!document.fullscreenElement) {
                    if (media.requestFullscreen) media.requestFullscreen();
                } else {
                    if (document.exitFullscreen) document.exitFullscreen();
                }
            } else if (selectedIndex !== -1) {
                items[selectedIndex].click();
            }
        }

        if (e.code === 'Space' && media) {
            e.preventDefault();
            media.paused ? media.play() : media.pause();
        }
    });

    // 5. Fullscreen Listeners & Initialization
    const handleExitFullscreen = () => {
        if (!document.fullscreenElement && !document.webkitFullscreenElement && imagePlaylist.length > 0 && currentImageIndex >= 0) {
            const imageData = imagePlaylist[currentImageIndex];
            showPreview(imageData.path, 'image', imageData.name);
        }
    };

    document.addEventListener('webkitfullscreenchange', handleExitFullscreen);
    
    document.addEventListener('dblclick', (e) => {
        if (e.target.tagName === 'IMG' && e.target.closest('#preview-content')) {
            if (e.target.requestFullscreen) e.target.requestFullscreen();
            else if (e.target.webkitRequestFullscreen) e.target.webkitRequestFullscreen();
        }
    });

    // Essential: Page Load initialization
    window.onload = () => { 
        loadBackgrounds(); 
        loadFiles(currentPath); 
    };

    document.querySelector('.main-directory-link').onclick = (e) => { 
        e.preventDefault(); 
        loadFiles('<?php echo $web_base; ?>'); 
    };
document.getElementById('fileSearch').addEventListener('input', function(e) {
    const term = e.target.value.toLowerCase();
    const items = document.querySelectorAll('.file-item');

    items.forEach(item => {
        const nameElement = item.querySelector('.file-name');
        if (nameElement) {
            const name = nameElement.textContent.toLowerCase();
            // Toggles visibility based on the search term
            item.style.display = name.includes(term) ? 'flex' : 'none';
        }
    });
});
</script>
</body>
</html>
