#!/bin/bash
#
# archive-movie-downloader.sh
#
# Search/browse legal public-domain feature films through a whiptail
# dialog UI, then get the chosen title into the Mini-Pi media library
# folder for MiniDLNA / the mkv pipeline to pick up.
#
# Three sources, searched together in "Search by title/keyword/actor" mode:
#   - Internet Archive (archive.org)          -> direct curl download
#   - Wikimedia Commons public-domain films   -> direct curl download
#   - Public Domain Torrents                  -> added to Transmission
#
# "Browse by decade" stays Internet Archive only, since Wikimedia Commons
# and Public Domain Torrents don't support that kind of sort/filter query.
# "Browse by genre" picks a genre first, then combines IA (ranked by real
# downloads, filtered on its free-text subject field) with PDT's own
# genre category page. Wikimedia is skipped in this mode - it has no genre
# metadata to filter on.
#
# Whichever source a result comes from is invisible to the user at
# search/browse time. Only once something is picked does it matter:
#   - IA / Wikimedia: downloads immediately, with a live whiptail gauge
#     showing percent complete, transfer speed, and total size.
#   - Public Domain Torrents: no file arrives immediately - it's hard-added
#     to the local Transmission daemon (targeted straight at OUTPUT_DIR) and
#     a message confirms it's been queued, since it may take minutes to
#     hours to complete depending on seeders.
#
# Requires: curl, jq, whiptail (whiptail ships by default on Raspberry Pi OS)
# Optional: transmission-remote (only needed to act on Public Domain
#           Torrents results - ships with transmission-daemon)
#
# Usage:
#   ./archive-movie-fetch.sh                 -> dialog menu:
#                                                  1) search by title/keyword/actor
#                                                  2) browse by decade (IA only)
#                                                  3) browse most-downloaded classics (IA only)
#   ./archive-movie-fetch.sh "film noir"      -> search term as arg (first pass only)
#
# Cancelling out of any sub-dialog (search box, decade box, results list,
# format warning) returns you to the main mode menu rather than exiting.
# Cancelling the main mode menu itself exits the script.
#
set -euo pipefail

# ---- Config ----------------------------------------------------------
OUTPUT_DIR="/var/lib/minidlna/Video"
MAX_RESULTS=40
MENU_HEIGHT=15          # visible rows in the results box before it scrolls
IA_SEARCH_URL="https://archive.org/advancedsearch.php"
IA_METADATA_URL="https://archive.org/metadata"
IA_DOWNLOAD_URL="https://archive.org/download"

WIKI_API_URL="https://commons.wikimedia.org/w/api.php"
WIKI_CATEGORY="Category:Videos of films in the public domain"
WIKI_CACHE_FILE="/tmp/.archive-movie-fetch-wiki-cache.json"
WIKI_CACHE_MAX_AGE=$((7 * 24 * 3600))   # weekly - this category barely changes

PDT_BASE_URL="https://www.publicdomaintorrents.info"
PDT_CACHE_FILE="/tmp/.archive-movie-fetch-pdt-cache.tsv"
PDT_CACHE_MAX_AGE=$((24 * 3600))        # daily - new titles do get added occasionally

TRANSMISSION_REMOTE_BIN="transmission-remote"
TR_ADD_LOG="/tmp/.archive-movie-fetch-tr-add.log"
# RPC target and credentials. Host is localhost:9091 since the daemon runs
# on this same Pi. Username/password match rpc-username / rpc-password in
# /var/lib/transmission-daemon/info/settings.json - update both here if
# they're ever changed on the daemon side. Still overridable via env vars
# (TRANSMISSION_RPC_USER / TRANSMISSION_RPC_PASS) without editing the script,
# e.g. if you want to keep the password out of this file on a shared system.
TRANSMISSION_RPC_HOST="localhost:9091"
TRANSMISSION_RPC_USER="${TRANSMISSION_RPC_USER:-pi}"
TRANSMISSION_RPC_PASS="${TRANSMISSION_RPC_PASS:-pi}"

# Used as the --title on every whiptail/dialog box so it's consistent, and
# so the two error-path references to it (in download_from_pdt) actually
# resolve instead of hitting an unbound-variable error under `set -u`.
SCRIPT_TITLE="Mini-Pi Movie Fetch"

TMP_JSON="$(mktemp)"

# Retry/resume behaviour shared by both the big background movie downloads
# and the small PDT metadata/torrent fetches. Kept as one pair of knobs so
# tuning "how patient should this script be with a flaky connection" is a
# one-place edit rather than hunting through every curl call.
MAX_DOWNLOAD_RETRIES=5      # big movie files - worth persisting through
RETRY_DELAY_SECONDS=5       # base pause between attempts (grows below)
MAX_QUICK_RETRIES=2         # small page/API fetches - fail fast, don't loop for ages

# RESULTS holds one entry per combined search/browse result, encoded as
# "SOURCE<US>ID<US>TITLE<US>YEAR<US>SIZE<US>SIZE_BYTES<US>TIER" using the
# ASCII Unit Separator (\x1f) as the field delimiter, since movie titles
# can contain almost anything else. SOURCE is one of: IA, WIKI, PDT. ID is
# source-specific (IA identifier, Wikimedia "File:..." title, or PDT
# numeric movieid). SIZE is a human-readable string (e.g. "734.2MB") or
# empty when unknown - PDT results always leave it empty since Public
# Domain Torrents doesn't expose file size anywhere on its
# catalogue/category listing pages, only (maybe) on each movie's own
# page, and it's not worth ~1000 extra page fetches to populate a field
# for something that's queued as a background torrent download rather
# than an immediate one anyway. SIZE_BYTES is the same value SIZE was
# derived from, kept as a plain integer (or empty) purely so results can
# be sorted numerically by real size. TIER is 0 for anything reasonably
# confident of being on-topic (a direct title match, or a WIKI/PDT hit,
# both of which are already title-substring matched) and 1 for IA's
# broader unscoped-text match, used for actor/genre-style search terms
# that won't appear in a film's title. Grouping by TIER first and only
# sorting by size within each group is what stops a large but barely-
# relevant tier-1 match (e.g. a scanner manual video) from outranking a
# small genuinely relevant tier-0 one - see sort_results_by_size below.
RESULTS=()
US=$'\x1f'

# Tracks IA identifiers already added to RESULTS in the current
# search/browse pass, so running the title-tier and broad-tier IA queries
# back-to-back (see mode 1 below) can't add the same item twice. Reset
# alongside RESULTS at the top of each loop iteration.
declare -A SEEN_IA_IDS=()

# Converts a raw byte count into a short human-readable string (e.g.
# "734.2MB"). Returns empty on anything that isn't a plain non-negative
# integer, so callers can just check -n "$result" rather than separately
# validating their input first.
human_size() {
    local bytes="$1"
    [[ "$bytes" =~ ^[0-9]+$ ]] || { echo ""; return; }
    awk -v b="$bytes" 'BEGIN {
        split("B KB MB GB TB", unit, " ")
        i = 1
        while (b >= 1024 && i < 5) { b /= 1024; i++ }
        printf "%.1f%s", b, unit[i]
    }'
}

# Re-sorts the global RESULTS array in place, largest file size first,
# using SIZE_BYTES (6th field). Entries with no known size (PDT always,
# IA/Wikimedia occasionally) sort's numeric comparison treats an empty
# field as 0, so they naturally fall to the bottom rather than erroring or
# needing a separate branch. Applied after every search/browse mode
# populates RESULTS, so whichever mix of sources contributed results, the
# biggest files always lead the list.
#
# RESULTS entries still carry a 7th TIER field (0 = title/precise match,
# 1 = IA's broader description/subject match - see mode 1 below), but
# it's no longer used for ordering here. It turned out relevance and file
# size didn't need reconciling in practice: once the broad-tier query was
# tightened to named fields, what it was returning were genuine, on-topic
# matches (e.g. "Ice Station Zebra" turning up in a movie-themes radio
# mixtape and a Jack White setlist that includes a song of that name) -
# not junk that needed hiding behind tier-0 results, just other results
# that a plain size sort now handles fine on its own.
sort_results_by_size() {
    [ "${#RESULTS[@]}" -eq 0 ] && return
    local sorted=()
    while IFS= read -r line; do
        sorted+=("$line")
    done < <(printf '%s\n' "${RESULTS[@]}" | sort -t "$US" -k6,6nr)
    RESULTS=("${sorted[@]}")
}

cleanup() { rm -f "$TMP_JSON"; }
trap cleanup EXIT
clear

# ---- Dependency check --------------------------------------------------
for bin in curl jq whiptail; do
    if ! command -v "$bin" >/dev/null 2>&1; then
        echo "Error: '$bin' is required but not installed. Try: sudo apt install $bin" >&2
        exit 1
    fi
done
if ! command -v "$TRANSMISSION_REMOTE_BIN" >/dev/null 2>&1; then
    echo "Note: '$TRANSMISSION_REMOTE_BIN' not found - Public Domain Torrents results" >&2
    echo "      will show up in search but can't be added until transmission-daemon" >&2
    echo "      (which provides it) is installed." >&2
fi
if ! command -v ffprobe >/dev/null 2>&1; then
    echo "Note: 'ffprobe' not found - downloaded files won't be checked for browser-safe" >&2
    echo "      codecs, so anything that needs re-encoding won't get auto-routed to" >&2
    echo "      mkv-watcher.sh. Install ffmpeg to enable this check." >&2
fi

# dialog(1) is optional. whiptail (required above) drives every dialog in
# this script EXCEPT the download progress display: whiptail's --gauge
# only ever reads a bare percentage from stdin and silently ignores any
# text sent alongside it (unlike dialog's --gauge, which is a genuine
# extension both tools' docs describe but only dialog actually honours),
# so it can't show live speed/size. We work around that for whiptail-only
# systems by redrawing a whiptail --infobox on a timer instead, which
# works but means a brief flash to the underlying terminal on every
# redraw, since each redraw is a fresh process. dialog's --gauge is a
# single long-lived process fed over a pipe, so it updates in place with
# no flash - use it for the progress display when it's available.
DIALOG_BIN=""
if command -v dialog >/dev/null 2>&1; then
    DIALOG_BIN="dialog"
else
    echo "Note: 'dialog' not found - the download progress display will use a whiptail" >&2
    echo "      fallback that briefly flashes to the terminal on each update. Install" >&2
    echo "      it (sudo apt install dialog) for a smoother, flicker-free progress bar." >&2
fi

# ---- Output dir check ----------------------------------------------------
if [ ! -d "$OUTPUT_DIR" ]; then
    echo "Error: output directory '$OUTPUT_DIR' does not exist." >&2
    echo "Create it or edit OUTPUT_DIR at the top of this script." >&2
    exit 1
fi
if [ ! -w "$OUTPUT_DIR" ]; then
    echo "Error: no write permission on '$OUTPUT_DIR'. Try running with sudo, or check ownership." >&2
    exit 1
fi

# ---- Dialog helpers -----------------------------------------------------
# whiptail writes its output to stderr; the 3>&1 1>&2 2>&3 dance swaps
# stdout/stderr so we can capture the user's answer in a variable.
wt_menu() {
    whiptail --title "$1" --menu "$2" "$3" "$4" "$5" "${@:6}" 3>&1 1>&2 2>&3
}
wt_input() {
    whiptail --title "$1" --inputbox "$2" "$3" "$4" 3>&1 1>&2 2>&3
}
wt_yesno() {
    whiptail --title "$1" --yesno "$2" "$3" "$4"
}

# ============================================================================
# Post-download codec check
# ============================================================================
# mkv-watcher.sh (the Mini-Pi pipeline) only triggers on .mkv/.mp4/.srt/.vob
# extensions, and its convert step only stream-copies (skips) files it
# already considers browser-safe H.264. Neither check cares about the real
# container format - ffprobe/ffmpeg identify codecs by content signature,
# not file extension - so renaming a non-mkv file to .mkv is enough to route
# it through the existing re-encode pipeline even though it isn't really
# Matroska. This mirrors the profile check added to mkv-common.sh's
# build_video_args(), so a file rerouted here will actually get re-encoded
# rather than silently remuxed unchanged once mkv-watcher picks it up.
#
# Returns 0 if the file was left alone (looks browser-safe, or couldn't be
# probed). Returns 1 if it was renamed to .mkv and handed off to the pipeline.
maybe_route_for_reencode() {
    local dest_path="$1"

    if ! command -v ffprobe >/dev/null 2>&1; then
        return 0
    fi

    local codec profile
    codec=$(ffprobe -v quiet -select_streams v:0 -show_entries stream=codec_name -of csv=p=0 "$dest_path" 2>/dev/null)
    profile=$(ffprobe -v quiet -select_streams v:0 -show_entries stream=profile -of csv=p=0 "$dest_path" 2>/dev/null)

    local needs_reencode=0
    case "$codec" in
        h264)
            # codec=h264 alone isn't enough - High 10 / 4:2:2 / 4:4:4 profiles
            # are still technically H.264 but not browser-decodable.
            case "$profile" in
                *"High 10"*|*"4:2:2"*|*"4:4:4"*) needs_reencode=1 ;;
            esac
            ;;
        hevc|"") ;;   # HEVC: pipeline already handles it (incl. high-bit-depth
                      # SW downconvert). Empty: couldn't probe - leave alone
                      # rather than guess.
        *) needs_reencode=1 ;;  # mpeg4 (ASP/DivX), mpeg2, theora, vp8/vp9, etc.
    esac

    [ "$needs_reencode" -eq 0 ] && return 0

    local reroute_path="${dest_path%.*}.mkv"
    if [ -e "$reroute_path" ]; then
        echo "Note: $(basename "$reroute_path") already exists - leaving $(basename "$dest_path") as downloaded. Codec: ${codec:-unknown}${profile:+, profile=$profile}. Check manually."
        return 0
    fi

    mv -- "$dest_path" "$reroute_path"
    echo "Video stream (codec=${codec:-unknown}${profile:+, profile=$profile}) isn't browser-safe -"
    echo "renamed to $(basename "$reroute_path") and handed to mkv-watcher.sh for re-encoding."
    return 1
}

# ============================================================================
# Download with a live progress display (percent / speed / size)
# ============================================================================
# curl's default progress meter (active unless -s/--silent is given) writes
# updating stats to stderr using \r rather than \n, and does this
# regardless of whether stderr is a tty - so it works fine redirected to a
# plain log file. We poll that file and take the latest \r-delimited chunk.
#
# curl's meter columns, once split on whitespace:
#   1 %Total  2 Total-size  3 %Received  4 Received  5 %Xferd  6 Xferd
#   7 Avg-Dload-speed  8 Avg-Upload-speed  9 Time-total  10 Time-spent
#   11 Time-left  12 Current-speed
#
# If the server doesn't send Content-Length (e.g. chunked), curl can't
# compute a percentage - column 1 stays "0" the whole transfer. We still
# show live size/speed in that case, just without a moving bar, rather
# than pretending we know progress we don't.
#
# Stall guard: --connect-timeout only covers the initial TCP connect, so a
# server that accepts the connection and then goes silent would otherwise
# sit there until --max-time (hours) ran out, looking exactly like a hang.
# --speed-time/--speed-limit aborts if the transfer stays below ~2KB/s for
# 30 seconds straight, which is what actually catches that case.

# Parses the latest curl progress-meter line out of progress log $1 and
# (re)builds the ${bar_width}-wide ASCII bar plus the speed/size line,
# leaving the results in the caller's _dlp_pct / _dlp_bar / _dlp_size_line
# variables. Shared by both render paths below so the parsing only lives
# in one place. Relies on bash's dynamic scoping: since these variables
# are declared `local` in curl_download_with_progress and this function
# doesn't redeclare them, assignments here reach back into the caller.
_dlp_update() {
    local progress_log="$1" bar_width="$2"
    local line pct total speed eta
    # || true guards this: grep legitimately finds nothing on the very
    # first poll or two (curl hasn't written a progress line to the log
    # yet), which makes the whole pipeline exit non-zero under
    # `pipefail`. Without the guard, that non-zero status on a plain
    # `line=$(...)` assignment trips `set -e` and kills the entire
    # script - confirmed by testing this exact shape against an empty
    # log file. An empty $line here is fine; the checks below already
    # treat "no new data this poll" as "keep the last good reading".
    line=$(tr '\r' '\n' < "$progress_log" 2>/dev/null | grep -E '[0-9]+ +[0-9.]+[kKMG]?' | tail -n 1) || true
    read -r pct total _ _ _ _ speed _ _ _ eta _ <<< "$line"

    # Only trust a fully-formed snapshot - a line caught mid-write by the
    # race between curl's \r and our tail can be truncated, so falling
    # back to the last good reading beats flickering back to 0%.
    [[ "$pct" =~ ^[0-9]+$ ]] && _dlp_pct="$pct"
    [[ -n "$total" ]] && _dlp_total="$total"
    [[ "$speed" =~ ^[0-9.]+[kKMG]?$ ]] && _dlp_speed="$speed"
    [[ -n "$eta" ]] && _dlp_eta="$eta"

    local filled=$(( _dlp_pct * bar_width / 100 ))
    [ "$filled" -gt "$bar_width" ] && filled="$bar_width"
    _dlp_bar="$(printf '%*s' "$filled" '' | tr ' ' '#')$(printf '%*s' "$((bar_width - filled))" '' | tr ' ' '-')"

    if [ -n "$_dlp_total" ] && [ "$_dlp_total" != "0" ]; then
        _dlp_size_line="Size: ${_dlp_total}B   Speed: ${_dlp_speed:-0}B/s"
    else
        _dlp_size_line="Speed: ${_dlp_speed:-0}B/s   (total size not reported by server)"
    fi
    [ -n "$_dlp_eta" ] && [ "$_dlp_eta" != "--:--:--" ] && _dlp_size_line="${_dlp_size_line}   ETA: ${_dlp_eta}"
    # This function is called as a bare statement in the polling loop
    # below (not inside an if/&&/||), so its own exit status matters:
    # the ETA check just above is a chained && used only for its side
    # effect, and evaluates false (returning 1) on almost every poll,
    # since curl rarely reports an ETA in the first few seconds of a
    # transfer. Left unguarded, that alone was enough to trip `set -e`
    # and kill the whole script on nearly every real download - the
    # single most reliably-triggered bug of the bunch, confirmed by
    # testing this function against a blank progress log.
    return 0
}

# Runs curl in the background so this shell can poll its log file; returns
# curl's real exit status (0 on success) via a small status file, since
# backgrounding means $? from a plain job-control wait isn't curl's own.
#
# Resumes automatically on retry: -C - tells curl to pick up from wherever
# $dest_path already got to. If the server doesn't support range requests
# curl falls back to a clean full re-download by itself - not an error case,
# just less efficient. A dropped connection therefore costs at most the
# retry delay, not the whole download.
curl_download_with_progress() {
    local url="$1" dest_path="$2" label="$3"
    local progress_log exit_file
    progress_log="$(mktemp)"
    exit_file="$(mktemp)"

    local attempt=1 status=1 curl_pid retry_note=""

    while [ "$attempt" -le "$MAX_DOWNLOAD_RETRIES" ]; do
        : >"$progress_log"
        (
            # && ec=0 || ec=$? (rather than a plain `curl ...` statement
            # followed by `echo "$?" > ...` on the next line) is required
            # here: this subshell inherits `set -e` from the parent, so a
            # bare failing curl statement would kill the subshell on the
            # spot and never reach the echo - confirmed by testing this
            # exact shape against a guaranteed-to-fail URL. That left
            # $exit_file empty, which then broke the retry loop below in
            # a second way (see the `wait` comment further down).
            local ec
            curl -L --fail \
                 -C - \
                 --connect-timeout 15 --max-time 14400 \
                 --speed-time 30 --speed-limit 2048 \
                 --stderr "$progress_log" \
                 -o "$dest_path" "$url" && ec=0 || ec=$?
            echo "$ec" > "$exit_file"
        ) &
        curl_pid=$!

        local bar_width=40
        local _dlp_pct=0 _dlp_total="" _dlp_speed="" _dlp_eta="" _dlp_bar="" _dlp_size_line=""
        local attempt_label="$label"
        [ -n "$retry_note" ] && attempt_label="$label

$retry_note"

        if [ -n "$DIALOG_BIN" ]; then
            # dialog(1)'s --gauge reads the "XXX / percent / text / XXX" block
            # protocol as ONE long-lived process fed over a pipe, and redraws
            # only the parts of the screen that changed - no flicker, because
            # there's no repeated process spawn/init/teardown behind it.
            (
                echo "XXX"; echo 0; echo "$attempt_label"; echo ""; echo "Connecting..."; echo "XXX"
                while kill -0 "$curl_pid" 2>/dev/null; do
                    _dlp_update "$progress_log" "$bar_width"
                    echo "XXX"
                    echo "$_dlp_pct"
                    echo "$attempt_label"
                    echo ""
                    echo "[${_dlp_bar}] ${_dlp_pct}%"
                    echo ""
                    echo "$_dlp_size_line"
                    echo "XXX"
                    sleep 0.5
                done
            ) | "$DIALOG_BIN" --title "$SCRIPT_TITLE" --gauge "$attempt_label" 12 74 0 || true
        else
            # Fallback for whiptail-only systems: whiptail's --gauge (unlike
            # dialog's) silently ignores that same text-update protocol and
            # only ever reads the bare percentage, so it can't show speed/size
            # at all - confirmed directly against the whiptail build shipped
            # in Debian/Raspberry Pi OS. We redraw a whiptail --infobox on a
            # timer instead, which can show arbitrary text but, because each
            # redraw is a brand-new process, briefly flashes to whatever's
            # behind it (newt restores the underlying screen on exit before
            # the next call redraws over it). Install dialog to avoid this.
            whiptail --infobox "$attempt_label

Connecting..." 11 74
            while kill -0 "$curl_pid" 2>/dev/null; do
                _dlp_update "$progress_log" "$bar_width"
                whiptail --infobox "$attempt_label

[${_dlp_bar}] ${_dlp_pct}%

${_dlp_size_line}" 11 74
                sleep 0.5
            done
        fi

        # wait's own exit status isn't what we care about (the real curl
        # exit code is captured in $exit_file above) - but a plain
        # `wait "$curl_pid"` statement still trips `set -e` if the
        # backgrounded job exited non-zero, which killed the whole
        # script before the retry logic below ever ran. || true stops
        # that; confirmed with a repro against a failing download.
        wait "$curl_pid" 2>/dev/null || true
        status="$(cat "$exit_file" 2>/dev/null)"
        [[ "$status" =~ ^[0-9]+$ ]] || status=1

        if [ "$status" -eq 0 ]; then
            break
        fi

        # curl exit 22 = HTTP error under --fail (404, 403, etc). The file
        # genuinely isn't there or access is denied - retrying identical
        # requests won't fix that, so stop immediately rather than making
        # the user wait through pointless attempts.
        if [ "$status" -eq 22 ]; then
            break
        fi

        if [ "$attempt" -lt "$MAX_DOWNLOAD_RETRIES" ]; then
            local wait_secs=$((RETRY_DELAY_SECONDS * attempt))
            retry_note="Connection dropped (curl exit $status) - resuming attempt $((attempt + 1))/$MAX_DOWNLOAD_RETRIES in ${wait_secs}s..."
            whiptail --infobox "$label

$retry_note" 11 74
            sleep "$wait_secs"
        fi
        attempt=$((attempt + 1))
    done

    rm -f "$progress_log" "$exit_file"
    return "$status"
}

# ============================================================================
# Internet Archive
# ============================================================================

# Optional 2nd arg is a sort clause, e.g. "downloads desc"
ia_search() {
    local query="$1"
    local sort="${2:-}"
    local curl_status
    if [ -n "$sort" ]; then
        curl -sG "$IA_SEARCH_URL" \
            --data-urlencode "q=${query}" \
            --data-urlencode "fl[]=identifier" \
            --data-urlencode "fl[]=title" \
            --data-urlencode "fl[]=year" \
            --data-urlencode "fl[]=item_size" \
            --data-urlencode "sort[]=${sort}" \
            --data-urlencode "rows=${MAX_RESULTS}" \
            --data-urlencode "output=json" \
            -o "$TMP_JSON" && curl_status=0 || curl_status=$?
    else
        curl -sG "$IA_SEARCH_URL" \
            --data-urlencode "q=${query}" \
            --data-urlencode "fl[]=identifier" \
            --data-urlencode "fl[]=title" \
            --data-urlencode "fl[]=year" \
            --data-urlencode "fl[]=item_size" \
            --data-urlencode "rows=${MAX_RESULTS}" \
            --data-urlencode "output=json" \
            -o "$TMP_JSON" && curl_status=0 || curl_status=$?
    fi

    # A plain failing curl statement (or a jq parse failure on the next
    # line) would otherwise trip `set -e` and kill the whole script over
    # a single dropped search request - fail soft with 0 results instead,
    # same as every other network call in this script now does.
    if [ "$curl_status" -ne 0 ]; then
        echo "Note: couldn't reach archive.org for this search (curl exit $curl_status)." >&2
        echo 0
        return
    fi
    jq '.response.docs | length' "$TMP_JSON" 2>/dev/null || echo 0
}

# Appends every doc currently sitting in $TMP_JSON (from the last ia_search
# call) onto the global RESULTS array, tagged as source IA. Skips any
# identifier already recorded in SEEN_IA_IDS, so calling this twice in a
# row for two different queries (e.g. the title-tier then broad-tier IA
# searches in mode 1) can't produce duplicate entries for the same item.
#
# Takes an optional relevance tier (default 0) - see the TIER field notes
# on RESULTS above. Callers pass 1 for IA's broad unscoped-text query.
#
# item_size is the TOTAL size of everything attached to the item (original
# upload plus every IA-generated derivative, thumbnails, etc), not just the
# one video file download_from_ia will actually pick - so treat it as a
# rough "how big is this listing" indicator rather than an exact download
# size. Still far more useful than nothing, and it costs zero extra
# requests since it rides along in the same search response.
add_ia_results_from_tmp_json() {
    local tier="${1:-0}"
    local doc t y id sz sz_h
    while IFS= read -r doc; do
        id=$(echo "$doc" | jq -r '.identifier')
        [ -n "${SEEN_IA_IDS[$id]:-}" ] && continue
        t=$(echo "$doc" | jq -r '.title // "Unknown title"')
        y=$(echo "$doc" | jq -r '.year // empty')
        sz=$(echo "$doc" | jq -r '.item_size // empty')
        sz_h=$(human_size "$sz")
        SEEN_IA_IDS[$id]=1
        RESULTS+=("IA${US}${id}${US}${t}${US}${y}${US}${sz_h}${US}${sz}${US}${tier}")
    done < <(jq -c '.response.docs[]' "$TMP_JSON")
}

download_from_ia() {
    local identifier="$1" display_title="$2"

    echo "Fetching file list for: $display_title ($identifier)"

    local meta_json files_json best_file fallback=0

    local meta_attempt=1 meta_status=1
    while [ "$meta_attempt" -le "$MAX_QUICK_RETRIES" ]; do
        meta_json="$(curl -s --connect-timeout 10 --max-time 30 "${IA_METADATA_URL}/${identifier}")" && meta_status=0 || meta_status=$?
        [ "$meta_status" -eq 0 ] && [ -n "$meta_json" ] && break
        [ "$meta_attempt" -lt "$MAX_QUICK_RETRIES" ] && sleep 2
        meta_attempt=$((meta_attempt + 1))
    done

    if [ "$meta_status" -ne 0 ] || [ -z "$meta_json" ]; then
        whiptail --msgbox "Could not reach archive.org to fetch details for '$display_title' after $MAX_QUICK_RETRIES attempts.\n\nCheck the Pi's internet connection and try again." 10 70
        return
    fi

    # Format preference matters here: mkv-watcher only triggers on .mkv/.vob,
    # and the web UI needs browser-playable containers. mp4 and mkv are safe
    # for both. avi/ogv will sit untouched by the pipeline and may not play
    # in-browser (ogv especially - Theora support is patchy to absent in most
    # browsers now), so only use them as a last resort.
    local jq_filter_common='
        map(select(.name | test("sample|thumb|preview"; "i") | not))
        | sort_by((.size // "0") | tonumber)
        | last
        | .name // empty
    '

    files_json=$(echo "$meta_json" | jq -c '.files')

    # A valid metadata response has a "files" array. Items that are
    # dark/restricted/withdrawn on archive.org (or any malformed response)
    # can come back with .files as null - jq's map/select would then crash
    # trying to iterate over null, and with set -e active that kills the
    # entire script rather than just this one download attempt. Guard it
    # explicitly and fail soft with a clear message instead.
    if ! echo "$files_json" | jq -e 'type == "array"' >/dev/null 2>&1; then
        whiptail --msgbox "'$display_title' has no downloadable files listed on archive.org.\n\nIt may be restricted, withdrawn, or a metadata-only entry. Try a different result." 11 70
        return
    fi

    best_file=$(echo "$files_json" | jq -r --arg pat '\.(mp4|mkv)$' "map(select(.name | test(\$pat; \"i\"))) | $jq_filter_common")

    if [ -z "$best_file" ]; then
        fallback=1
        best_file=$(echo "$files_json" | jq -r --arg pat '\.(avi|ogv)$' "map(select(.name | test(\$pat; \"i\"))) | $jq_filter_common")
    fi

    if [ -z "$best_file" ]; then
        whiptail --msgbox "No suitable video file found for '$display_title'. It may be audio-only, images, or unavailable." 10 70
        return
    fi

    if [ "$fallback" -eq 1 ]; then
        local ext="${best_file##*.}"
        local warn_msg="No mp4/mkv available for this item - only found a .${ext} file.\n\n"
        warn_msg+="- mkv-watcher won't pick this up for conversion or subtitle matching.\n"
        warn_msg+="- .ogv in particular may not play in most browsers (Theora support is patchy/dropped).\n"
        warn_msg+="- .avi playback in-browser depends on the codec inside and is not guaranteed.\n\n"
        warn_msg+="Continue anyway?"
        wt_yesno "Format Warning" "$warn_msg" 16 70 || return
    fi

    local safe_name dest_path download_url best_file_encoded
    safe_name=$(echo "${display_title}.${best_file##*.}" | tr -cd '[:alnum:] ._-')
    dest_path="${OUTPUT_DIR}/${safe_name}"
    # best_file is a path segment, not a query param, so curl --data-urlencode
    # doesn't apply here - percent-encode it manually via jq's @uri filter.
    # Archive.org filenames often contain spaces, "=", "&", etc. and curl
    # rejects those unencoded as a malformed URL.
    best_file_encoded=$(jq -rn --arg s "$best_file" '$s | @uri')
    download_url="${IA_DOWNLOAD_URL}/${identifier}/${best_file_encoded}"

    if ! curl_download_with_progress "$download_url" "$dest_path" "Downloading: $best_file"; then
        rm -f "$dest_path"
        whiptail --msgbox "Download failed for '$display_title'.\n\nCheck your network connection (or that the file still exists on archive.org) and try again." 11 70
        return
    fi

    if maybe_route_for_reencode "$dest_path"; then
        whiptail --msgbox "Done - browser-compatible codec confirmed.\n\n'$display_title' saved to:\n$dest_path\n\nNo further processing needed - MiniDLNA will pick it up on its next rescan." 15 70
    else
        whiptail --msgbox "'$display_title' downloaded, but its video stream isn't browser-safe as-is.\n\nIt's been renamed to .mkv so mkv-watcher.sh will pick it up and re-encode it automatically - check 'journalctl -t mkv-pipeline -f' on the Pi for progress." 16 74
    fi
}
# ============================================================================

wiki_refresh_cache() {
    if [ -f "$WIKI_CACHE_FILE" ]; then
        local age
        age=$(( $(date +%s) - $(stat -c %Y "$WIKI_CACHE_FILE" 2>/dev/null || echo 0) ))
        [ "$age" -lt "$WIKI_CACHE_MAX_AGE" ] && return
    fi

    # Fetch into a scratch file first and validate it's actually the JSON
    # we expect before touching the real cache. The previous version wrote
    # straight to WIKI_CACHE_FILE regardless of curl's exit status or
    # response content - so a single transient network blip (or the API
    # returning an HTML error page) would silently clobber a perfectly
    # good week-old cache with garbage, and that garbage then counted as
    # "fresh" for another 7 days, making Wikimedia results vanish for a
    # week with no indication why. Now a failed refresh just leaves
    # whatever cache (stale or absent) was already there, and retries on
    # the very next run instead of waiting out the full cache lifetime.
    # Uses generator=categorymembers rather than the plain list= form so we
    # can fold prop=imageinfo (iiprop=size) onto the same request and get
    # each file's size cached alongside its title - one call either way,
    # just a richer one, rather than a second per-title lookup later.
    local tmp_wiki
    tmp_wiki="$(mktemp)"
    if curl -s --fail --connect-timeout 15 --max-time 30 -G "$WIKI_API_URL" \
        --data-urlencode "action=query" \
        --data-urlencode "generator=categorymembers" \
        --data-urlencode "gcmtitle=${WIKI_CATEGORY}" \
        --data-urlencode "gcmnamespace=6" \
        --data-urlencode "gcmlimit=500" \
        --data-urlencode "prop=imageinfo" \
        --data-urlencode "iiprop=size" \
        --data-urlencode "format=json" \
        -o "$tmp_wiki" \
       && jq -e '.query.pages' "$tmp_wiki" >/dev/null 2>&1; then
        mv -- "$tmp_wiki" "$WIKI_CACHE_FILE"
    else
        rm -f "$tmp_wiki"
        echo "Note: couldn't refresh the Wikimedia Commons title list (network error or an unexpected API response) - Wikimedia results may be stale or empty this run." >&2
    fi
}

# Prints matching Commons file entries as compact JSON, one per line.
# The generator query caches pages as an object keyed by pageid rather
# than the flat array list= used to return, so unwrap via to_entries first.
wiki_search() {
    local term="$1"
    wiki_refresh_cache
    jq -c --arg t "$term" '
        (.query.pages // {}) | to_entries[] | .value
        | select(.title | ascii_downcase | contains($t | ascii_downcase))
    ' "$WIKI_CACHE_FILE" 2>/dev/null || true
}

# Appends matching Commons results onto the global RESULTS array, tagged WIKI.
# Note: Commons filenames in this category already embed the year, e.g.
# "Hell's Heroes (1929).webm", so YEAR is left blank here rather than
# duplicating it in the menu label.
add_wiki_results() {
    local term="$1" doc wiki_title disp sz sz_h
    while IFS= read -r doc; do
        [ -z "$doc" ] && continue
        wiki_title=$(echo "$doc" | jq -r '.title')
        disp=$(echo "$wiki_title" | sed -E 's/^File://; s/\.[A-Za-z0-9]+$//')
        sz=$(echo "$doc" | jq -r '.imageinfo[0].size // empty')
        sz_h=$(human_size "$sz")
        RESULTS+=("WIKI${US}${wiki_title}${US}${disp}${US}${US}${sz_h}${US}${sz}${US}0")
    done < <(wiki_search "$term")
}

wiki_get_file_url() {
    local file_title="$1"
    curl -sG "$WIKI_API_URL" \
        --data-urlencode "action=query" \
        --data-urlencode "titles=${file_title}" \
        --data-urlencode "prop=imageinfo" \
        --data-urlencode "iiprop=url" \
        --data-urlencode "format=json" \
    | jq -r '(.query.pages // {}) | to_entries[0].value.imageinfo[0].url // empty'
}

download_from_wiki() {
    local file_title="$1" display_title="$2"

    echo "Fetching file info for: $display_title"

    local url ext
    url=$(wiki_get_file_url "$file_title")
    if [ -z "$url" ]; then
        whiptail --msgbox "Could not resolve a download URL for '$display_title' on Wikimedia Commons." 10 70
        return
    fi
    ext="${url##*.}"

    if [[ ! "$ext" =~ ^(mp4|mkv)$ ]]; then
        local warn_msg="Wikimedia Commons serves this as a .${ext} file.\n\n"
        warn_msg+="- mkv-watcher won't pick this up for conversion or subtitle matching.\n"
        warn_msg+="- .webm/.ogv playback in-browser depends on your browser's codec support\n"
        warn_msg+="  (most current browsers do support webm).\n\n"
        warn_msg+="Continue anyway?"
        wt_yesno "Format Warning" "$warn_msg" 14 70 || return
    fi

    local safe_name dest_path
    safe_name=$(echo "${display_title}.${ext}" | tr -cd '[:alnum:] ._-')
    dest_path="${OUTPUT_DIR}/${safe_name}"

    if ! curl_download_with_progress "$url" "$dest_path" "Downloading: $display_title"; then
        rm -f "$dest_path"
        whiptail --msgbox "Download failed for '$display_title'.\n\nCheck your network connection (or that the file still exists on Commons) and try again." 11 70
        return
    fi

    if maybe_route_for_reencode "$dest_path"; then
        whiptail --msgbox "Done - browser-compatible codec confirmed.\n\n'$display_title' saved to:\n$dest_path\n\nNo further processing needed - MiniDLNA will pick it up on its next rescan." 15 80
    else
        whiptail --msgbox "'$display_title' downloaded, but its video stream isn't browser-safe as-is.\n\nIt's been renamed to .mkv so mkv-watcher.sh will pick it up and re-encode it automatically - check 'journalctl -t mkv-pipeline -f' on the Pi for progress." 16 74
    fi
}

# ============================================================================
# Public Domain Torrents
# ============================================================================
# No keyword-search endpoint on this site - it's a static, category-based
# listing (the ALL category alone runs to ~1000 titles). So the whole ALL
# listing is cached locally and matched against with a plain substring
# grep, refreshed once a day.

pdt_refresh_cache() {
    if [ -f "$PDT_CACHE_FILE" ]; then
        local age
        age=$(( $(date +%s) - $(stat -c %Y "$PDT_CACHE_FILE" 2>/dev/null || echo 0) ))
        [ "$age" -lt "$PDT_CACHE_MAX_AGE" ] && return
    fi

    # Same reasoning as wiki_refresh_cache: validate before overwriting.
    # The old version wrote straight to PDT_CACHE_FILE with no check on
    # curl's exit status and no check that the scrape actually matched
    # anything - so a network hiccup, or the site's markup changing shape,
    # produced an empty cache file that then counted as "fresh" for a full
    # day, silently zeroing out Public Domain Torrents results.
    local tmp_html tmp_pdt
    tmp_html="$(mktemp)"
    tmp_pdt="$(mktemp)"
    if curl -s --fail --connect-timeout 15 --max-time 30 \
        "${PDT_BASE_URL}/nshowcat.html?category=ALL" -o "$tmp_html"; then
        # The site's href attribute is unquoted (<a href=nshowmovie.html?movieid=939>...)
        # rather than the more common <a href="...">, so the pattern here can't
        # require quotes around it.
        grep -oP '<a href=nshowmovie\.html\?movieid=[0-9]+>[^<]+</a>' "$tmp_html" \
            | sed -E 's#<a href=nshowmovie\.html\?movieid=([0-9]+)>([^<]+)</a>#\1\t\2#' \
            > "$tmp_pdt"
    fi

    if [ -s "$tmp_pdt" ]; then
        mv -- "$tmp_pdt" "$PDT_CACHE_FILE"
    else
        echo "Note: couldn't refresh the Public Domain Torrents title list (network error, or the site's page layout changed) - Public Domain Torrents results may be stale or empty this run." >&2
    fi
    rm -f "$tmp_html" "$tmp_pdt" 2>/dev/null || true
}

# Prints matching "movieid<TAB>title" lines.
pdt_search() {
    local term="$1"
    pdt_refresh_cache
    grep -i -F -- "$term" "$PDT_CACHE_FILE" 2>/dev/null || true
}

# Appends matching PDT results onto the global RESULTS array, tagged PDT.
add_pdt_results() {
    local term="$1" movieid title
    while IFS=$'\t' read -r movieid title; do
        [ -z "$movieid" ] && continue
        RESULTS+=("PDT${US}${movieid}${US}${title}${US}${US}${US}${US}0")
    done < <(pdt_search "$term")
}

# ---- Genre browsing --------------------------------------------------
# The site itself splits its catalogue into genre categories server-side
# (nshowcat.html?category=<slug>), confirmed against the real page rather
# than guessed - see the slugs below. There's no "thriller" category on
# PDT; mystery/drama are the closest available. Unlike pdt_search (which
# works off the daily ALL-category cache, since keyword search needs to
# check every title repeatedly), this fetches the one requested category
# page live and doesn't cache it - genre browsing is an occasional action,
# not a per-keystroke lookup, so the cache's upkeep cost isn't worth it here.
pdt_search_by_category() {
    local slug="$1"
    local tmp_html
    tmp_html="$(mktemp)"
    if curl -s --fail --connect-timeout 15 --max-time 30 \
        "${PDT_BASE_URL}/nshowcat.html?category=${slug}" -o "$tmp_html"; then
        # Same unquoted-href markup as nshowcat.html?category=ALL.
        grep -oP '<a href=nshowmovie\.html\?movieid=[0-9]+>[^<]+</a>' "$tmp_html" \
            | sed -E 's#<a href=nshowmovie\.html\?movieid=([0-9]+)>([^<]+)</a>#\1\t\2#'
    fi
    rm -f "$tmp_html"
}

add_pdt_results_by_category() {
    local slug="$1" movieid title
    while IFS=$'\t' read -r movieid title; do
        [ -z "$movieid" ] && continue
        RESULTS+=("PDT${US}${movieid}${US}${title}${US}${US}${US}${US}0")
    done < <(pdt_search_by_category "$slug")
}

pdt_get_torrent_url() {
    local movieid="$1"
    local page_tmp
    page_tmp="$(mktemp)"

    # Small, fast fetch - if PDT isn't back within a few seconds something's
    # actually wrong (site down, connection dropped), not just slow. A
    # couple of quick retries covers a transient blip without the script
    # appearing to hang.
    local attempt=1 status=1
    while [ "$attempt" -le "$MAX_QUICK_RETRIES" ]; do
        curl -s --connect-timeout 10 --max-time 30 \
             -o "$page_tmp" \
             "${PDT_BASE_URL}/nshowmovie.html?movieid=${movieid}" && status=0 || status=$?
        [ "$status" -eq 0 ] && break
        [ "$attempt" -lt "$MAX_QUICK_RETRIES" ] && sleep 2
        attempt=$((attempt + 1))
    done

    if [ "$status" -ne 0 ]; then
        rm -f "$page_tmp"
        return 1
    fi

    # href="..." would be the norm, but nshowcat.html turned out to use
    # unquoted hrefs on this site, so don't assume this page quotes them
    # either - match with or without the quote.
    local url
    url=$(grep -oP 'href="?\Khttps?://[^">]*btdownload\.php\?type=torrent&file=[^">]*' "$page_tmp" | head -n1)
    rm -f "$page_tmp"
    echo "$url"
    return 0
}

download_from_pdt() {
    local movieid="$1" display_title="$2"

    if ! command -v "$TRANSMISSION_REMOTE_BIN" >/dev/null 2>&1; then
        whiptail --msgbox "transmission-remote not found - can't add this torrent.\n\nThis ships with transmission-daemon, which should already be part of the Mini-Pi setup - check it's installed and running." 12 70
        return
    fi

    echo "Fetching torrent link for: $display_title (movieid=$movieid)"
    local torrent_url pdt_status
    torrent_url=$(pdt_get_torrent_url "$movieid") && pdt_status=0 || pdt_status=$?
    if [ "$pdt_status" -ne 0 ]; then
        whiptail --msgbox "Could not reach Public Domain Torrents to look up '$display_title' after $MAX_QUICK_RETRIES attempts.\n\nCheck the Pi's internet connection and try again." 10 70
        return
    fi
    if [ -z "$torrent_url" ]; then
        whiptail --msgbox "Could not find a torrent link for '$display_title'. The site's page format may have changed." 10 70
        return
    fi

    local warn_msg="Public Domain Torrents delivers this as a DivX .avi file via BitTorrent.\n\n"
    warn_msg+="- mkv-watcher won't pick this up for conversion or subtitle matching.\n"
    warn_msg+="- Delivery is NOT immediate - it downloads in the background via Transmission\n"
    warn_msg+="  once peers are found (could be minutes to hours, not guaranteed).\n\n"
    warn_msg+="Add to Transmission now?"
    wt_yesno "Torrent Download" "$warn_msg" 14 70 || return

    # transmission-daemon 4.1.0-beta.2 (as shipped on Debian Trixie) has a
    # known upstream bug where handing it a remote URL to fetch itself
    # fails with "Couldn't fetch torrent: No Response (0)" against some
    # servers - see https://github.com/transmission/transmission/issues/5603
    # Workaround: fetch the .torrent file ourselves with curl (which works
    # fine) and hand transmission-remote the local file path instead. The
    # RPC client reads local files directly, so the daemon's own fetcher
    # never gets involved.
    local tmp_torrent
    tmp_torrent="$(mktemp --suffix=.torrent)"

    local dl_attempt=1 dl_status=1
    while [ "$dl_attempt" -le "$MAX_QUICK_RETRIES" ]; do
        curl -sL --fail --connect-timeout 10 --max-time 60 \
             -o "$tmp_torrent" "$torrent_url" && dl_status=0 || dl_status=$?
        [ "$dl_status" -eq 0 ] && break
        # curl exit 22 = HTTP error under --fail (404/403/etc) - the file
        # genuinely isn't there, retrying an identical request won't help.
        [ "$dl_status" -eq 22 ] && break
        [ "$dl_attempt" -lt "$MAX_QUICK_RETRIES" ] && sleep 2
        dl_attempt=$((dl_attempt + 1))
    done

    if [ "$dl_status" -ne 0 ]; then
        rm -f "$tmp_torrent"
        whiptail --title "$SCRIPT_TITLE" --msgbox "Failed to download the .torrent file itself from:\n$torrent_url\n\nTried $dl_attempt time(s). This is a separate problem from adding it to Transmission - the source URL may be down or changed." 12 78
        return 1
    fi

    # Sanity check: a real .torrent file is bencoded and starts with 'd'
    # (a bencoded dictionary). If PDT served an HTML error page instead
    # (e.g. file not found), catch that here rather than confusing
    # transmission-remote with garbage.
    if [ "$(head -c 1 "$tmp_torrent")" != "d" ]; then
        rm -f "$tmp_torrent"
        whiptail --title "$SCRIPT_TITLE" --msgbox "Downloaded file from:\n$torrent_url\n\ndoes not look like a valid .torrent file (got HTML or an error page instead). The source may no longer have this file." 12 78
        return 1
    fi

    # -w targets this specific add straight at OUTPUT_DIR, regardless of
    # whatever Transmission's own default download-dir is set to.
    # Auth is only appended if credentials are actually set, so this still
    # works unchanged against a daemon with rpc-authentication-required=false.
    local tr_args=("$TRANSMISSION_RPC_HOST")
    if [ -n "$TRANSMISSION_RPC_USER" ]; then
        tr_args+=(-n "${TRANSMISSION_RPC_USER}:${TRANSMISSION_RPC_PASS}")
    fi
    tr_args+=(-a "$tmp_torrent" -w "$OUTPUT_DIR")

    echo "DEBUG: extracted torrent_url = $torrent_url" >"$TR_ADD_LOG"
    echo "DEBUG: downloaded to = $tmp_torrent" >>"$TR_ADD_LOG"
    if transmission-remote "${tr_args[@]}" >>"$TR_ADD_LOG" 2>&1; then
        rm -f "$tmp_torrent"
        whiptail --msgbox "Added to Transmission.\n\n'$display_title' has been queued as a torrent download into:\n$OUTPUT_DIR\n\nThat's the MiniDLNA library folder, so once the download finishes it'll show up in your library automatically on the next scan - no extra step needed.\n\nCheck download progress at:\n  http://mini-pi.local/transmission/web/\n\nor with:\n  transmission-remote -l" 18 70
    else
        rm -f "$tmp_torrent"
        whiptail --msgbox "Failed to add the torrent to Transmission. Is transmission-daemon running?\n\n$(cat "$TR_ADD_LOG" 2>/dev/null)" 12 70
    fi
}

# ============================================================================
# Startup catalogue size check
# ============================================================================
# Quick per-source totals shown once at launch, so it's obvious roughly how
# much each source has before you start searching. Best-effort: any source
# that fails to answer just shows "unknown" rather than aborting startup -
# set -e is deliberately worked around here with explicit `|| true` guards.

ia_count_total() {
    local count
    count=$(curl -sG "$IA_SEARCH_URL" \
        --data-urlencode "q=collection:feature_films AND mediatype:movies" \
        --data-urlencode "rows=0" \
        --data-urlencode "output=json" \
        2>/dev/null | jq -r '.response.numFound // empty' 2>/dev/null) || true
    [ -n "$count" ] && echo "$count" || echo "unknown"
}

wiki_count_total() {
    # categoryinfo gives the category's file count directly - no need to
    # page through categorymembers just to count them.
    local count
    count=$(curl -sG "$WIKI_API_URL" \
        --data-urlencode "action=query" \
        --data-urlencode "titles=${WIKI_CATEGORY}" \
        --data-urlencode "prop=categoryinfo" \
        --data-urlencode "format=json" \
        2>/dev/null | jq -r '(.query.pages // {}) | to_entries[0].value.categoryinfo.files // empty' 2>/dev/null) || true
    [ -n "$count" ] && echo "$count" || echo "unknown"
}

pdt_count_total() {
    # No count endpoint on this site - reuse the existing daily-refreshed
    # cache (it's already the full ALL-category listing) and count lines.
    pdt_refresh_cache
    if [ -s "$PDT_CACHE_FILE" ]; then
        wc -l < "$PDT_CACHE_FILE" | tr -d ' '
    else
        echo "unknown"
    fi
}

show_startup_counts() {
    whiptail --infobox "Checking catalogue sizes across all three sources..." 8 60
    local ia_n wiki_n pdt_n
    ia_n=$(ia_count_total)
    wiki_n=$(wiki_count_total)
    pdt_n=$(pdt_count_total)
    whiptail --title "$SCRIPT_TITLE" --msgbox "Approximate catalogue sizes:\n\n  Internet Archive (feature_films):  ${ia_n}\n  Wikimedia Commons:                  ${wiki_n}\n  Public Domain Torrents:             ${pdt_n}\n\nThese are rough totals for the curated/browsable sets. Keyword search on IA can also surface titles outside the feature_films collection, so its real reach is a bit larger than the number above." 14 68
}

# ============================================================================
# Main
# ============================================================================

whiptail --title "$SCRIPT_TITLE" --msgbox "This tool searches and fetches films from three legal public-domain sources: the Internet Archive, Wikimedia Commons, and Public Domain Torrents.\n\nAll titles shown here are either in the public domain or released under an open licence by their rights holder - fully legal to download and keep, no legal issues.\n\nMost results download straight away. A few (Public Domain Torrents) get queued into Transmission instead - you'll be told which happened once you pick a title.\n\nCatalogue size and quality varies, mostly older/classic titles." 18 74

show_startup_counts

# A CLI arg is treated as a keyword search on the first pass through the
# loop only; after that (or if no arg was given) the mode menu takes over.
SEARCH_TERM_ARG="${1:-}"
FIRST_PASS=1

while true; do
    RESULTS=()
    SEEN_IA_IDS=()
    SEARCH_TERM=""

    if [ "$FIRST_PASS" -eq 1 ] && [ -n "$SEARCH_TERM_ARG" ]; then
        MODE=1
        SEARCH_TERM="$SEARCH_TERM_ARG"
    else
        MODE=$(wt_menu "$SCRIPT_TITLE" "How do you want to find a film?" 18 70 5 \
            "1" "Search by title / keyword / actor" \
            "2" "Search by exact year (Internet Archive)" \
            "3" "Browse by decade (Internet Archive)" \
            "4" "Browse by genre (IA ranked + Torrent category)" \
            "5" "Exit") || break   # cancel/Esc on main menu = exit script
    fi
    FIRST_PASS=0

    LIST_TEXT=""

    case "$MODE" in
        1)
            if [ -z "$SEARCH_TERM" ]; then
                SEARCH_TERM=$(wt_input "Search" "Title, genre, actor, etc:" 8 60) || continue
            fi
            if [ -z "$SEARCH_TERM" ]; then
                whiptail --msgbox "No search term given." 8 50
                continue
            fi

            # Search mediatype:movies broadly rather than restricting to the
            # curated feature_films collection - that collection is a subset,
            # and gating the broader query behind "only if curated returned
            # zero" meant a legitimate user-uploaded title (outside the
            # curated collection) could get permanently hidden any time the
            # search term also matched something already in feature_films.
            # IA's relevance ranking still tends to surface close title
            # matches first, so this doesn't meaningfully bury good results.
            # Quoted as a phrase rather than left as bare words: IA's search
            # defaults to AND, but that only requires "vivien" and "leigh" to
            # both appear *somewhere* in an item's combined metadata text -
            # not adjacent, not even in the same field. That let through
            # false positives (e.g. "vivien" in one field, "leigh" as an
            # unrelated word or place name in another). Quoting forces the
            # words to appear together and in order, which is a much closer
            # match to "this item is actually about Vivien Leigh".
            #
            # The unscoped phrase alone still isn't enough, though: it
            # matches the term anywhere in an item's combined metadata text,
            # not just the title. A search for "Scanners" (Cronenberg, 1981)
            # was turning up a wall of unrelated items about barcode
            # scanners, document scanners, police scanners, etc., because
            # the word "scanners" appeared somewhere in their description or
            # subject tags. Since this box is deliberately also used for
            # genre/actor searches (not just titles), we can't just restrict
            # to title: - that would break "Vivien Leigh" style lookups.
            # Instead, OR in an explicit title: clause alongside the
            # unscoped one: IA's relevance scoring adds up matched clauses,
            # mediatype:movies is also a much wider bucket than "films" -
            # it's IA's generic video type, which includes their TV News
            # Archive: round-the-clock captures of BBC News, CNN, TRT World
            # etc, filed under collection:tvarchive. A search for "Scanners"
            # was surfacing a segment about police radio scanners from a
            # news broadcast, not the Cronenberg film. Excluding that one
            # collection removes news captures specifically without
            # touching genuine feature films, documentaries, TV movies, etc.
            #
            # Two-tier query, title tier (0) and broad tier (1): an item
            # matching only the broad unscoped clause - anywhere in its
            # description, subject tags, etc, not just the title - is
            # exactly the kind of match that pulled in barcode-scanner and
            # police-scanner-radio junk for a plain "scanners" search. But
            # the broad tier can't just be dropped either, since actor and
            # genre-style terms like "Vivien Leigh" normally won't appear
            # in a film's title at all - that's what the broad tier exists
            # to catch. Both tiers always run, and add_ia_results_from_tmp_json
            # tags each result with its tier so sort_results_by_size can
            # rank all tier-0 (title) matches ahead of tier-1 (broad-only)
            # ones as a group, sorting by size only within each group -
            # that's what stops a large but barely-relevant tier-1 match
            # from outranking a small genuinely relevant tier-0 one, while
            # still surfacing broad-tier results underneath rather than
            # hiding them. SEEN_IA_IDS then dedupes anything that matched
            # both tiers so it doesn't appear twice.
            #
            # The broad tier used to be a bare, unfielded quoted phrase
            # (AND "${SEARCH_TERM}"). Switching it to named fields
            # (description/subject/creator, phrase-matched individually)
            # made barely any difference in practice - the exact same
            # unrelated concert recordings and TV commercial bumpers kept
            # surviving both versions of the query. That's the tell: they
            # weren't slipping in through a loose unfielded match, they
            # were genuinely matching one of those fields every time. The
            # likely culprit is creator - for informal, personally-
            # uploaded content (bootleg concert tapes, home-recorded TV
            # bumpers), IA often auto-populates "creator" with the
            # uploading account's own username rather than leaving it
            # blank. "Ice Station Zebra" is a quotable enough film title
            # that it's plausible someone's account is literally named or
            # tagged after it, which would surface every single item
            # they've ever uploaded on a creator: search, regardless of
            # actual content. Dropping creator here and keeping only
            # description/subject - fields that describe the item's
            # actual content rather than who uploaded it - should keep
            # catching genuine cast/subject mentions (including actor-
            # name searches like "Vivien Leigh") without pulling in an
            # unrelated uploader's entire catalogue by handle.
            QUERY_IA_TITLE="mediatype:movies AND NOT collection:tvarchive AND title:(\"${SEARCH_TERM}\")"
            IA_COUNT=$(ia_search "$QUERY_IA_TITLE")
            [ "$IA_COUNT" -gt 0 ] && add_ia_results_from_tmp_json 0

            QUERY_IA_BROAD="mediatype:movies AND NOT collection:tvarchive AND (description:(\"${SEARCH_TERM}\") OR subject:(\"${SEARCH_TERM}\"))"
            IA_COUNT=$(ia_search "$QUERY_IA_BROAD")
            [ "$IA_COUNT" -gt 0 ] && add_ia_results_from_tmp_json 1

            add_wiki_results "$SEARCH_TERM"
            add_pdt_results "$SEARCH_TERM"

            LIST_TEXT="Select a film to fetch (${#RESULTS[@]} found):"
            ;;
        2)
            YEAR_INPUT=$(wt_input "Search by Exact Year" "4-digit year (e.g. 1959):" 8 60) || continue
            if ! [[ "$YEAR_INPUT" =~ ^[0-9]{4}$ ]]; then
                whiptail --msgbox "Enter a 4-digit year, e.g. 1959." 8 60
                continue
            fi
            QUERY_YEAR="collection:feature_films AND mediatype:movies AND year:[${YEAR_INPUT} TO ${YEAR_INPUT}]"
            IA_COUNT=$(ia_search "$QUERY_YEAR" "downloads desc")
            [ "$IA_COUNT" -gt 0 ] && add_ia_results_from_tmp_json
            LIST_TEXT="Select a film to download (${#RESULTS[@]} found from ${YEAR_INPUT}):"
            ;;
        3)
            DECADE=$(wt_input "Browse by Decade" "Decade start year (e.g. 1950 covers 1950-1959):" 8 60) || continue
            if ! [[ "$DECADE" =~ ^[0-9]{4}$ ]]; then
                whiptail --msgbox "Enter a 4-digit decade start year, e.g. 1950." 8 60
                continue
            fi
            DECADE_END=$((DECADE + 9))
            QUERY_DECADE="collection:feature_films AND mediatype:movies AND year:[${DECADE} TO ${DECADE_END}]"
            IA_COUNT=$(ia_search "$QUERY_DECADE" "downloads desc")
            [ "$IA_COUNT" -gt 0 ] && add_ia_results_from_tmp_json
            LIST_TEXT="Select a film to download (${#RESULTS[@]} found, ${DECADE}-${DECADE_END}):"
            ;;
        4)
            # PDT's own genre slugs, confirmed against the live site rather
            # than guessed (nshowcat.html's nav links). There's no "thriller"
            # category there - mystery/drama are the closest fits available.
            # "Exploitation" deliberately left off this list: as a genre it's
            # a broad 1960s-80s catch-all (blaxploitation, ozploitation, car
            # chase films, etc), and mostly legitimate cult cinema, but the
            # historical "sexploitation" sub-genre means it can also surface
            # softcore titles. This script ships as a menu option on a
            # shared media server other people click through, not just a
            # personal tool - not worth a curated one-click path to that.
            GENRE_SLUG=$(wt_menu "Browse by Genre" "Pick a genre:" 24 60 14 \
                "action"      "Action" \
                "animation"   "Animation" \
                "comedy"      "Comedy" \
                "drama"       "Drama" \
                "family"      "Family" \
                "horror"      "Horror" \
                "martialarts" "Martial Arts" \
                "musicals"    "Musicals" \
                "mystery"     "Mystery" \
                "scifi"       "Sci-Fi" \
                "serial"      "Serials" \
                "war"         "War" \
                "westerns"    "Westerns") || continue

            # IA's `subject` field is free-text tagging by whoever uploaded
            # each item, not a controlled genre taxonomy - these are the
            # closest phrase matches, but coverage per genre will vary a lot
            # more than PDT's actual category pages do.
            case "$GENRE_SLUG" in
                martialarts) IA_SUBJECT="martial arts" ;;
                musicals)    IA_SUBJECT="musical" ;;
                scifi)       IA_SUBJECT="science fiction" ;;
                westerns)    IA_SUBJECT="western" ;;
                *)           IA_SUBJECT="$GENRE_SLUG" ;;
            esac

            QUERY_GENRE="collection:feature_films AND mediatype:movies AND subject:\"${IA_SUBJECT}\""
            IA_COUNT=$(ia_search "$QUERY_GENRE" "downloads desc")
            [ "$IA_COUNT" -gt 0 ] && add_ia_results_from_tmp_json

            add_pdt_results_by_category "$GENRE_SLUG"

            LIST_TEXT="Select a film (${#RESULTS[@]} found in this genre - IA ranked by downloads, Torrent unranked; Wikimedia has no genre data so isn't included here):"
            ;;
        5)
            break
            ;;
        *)
            whiptail --msgbox "Invalid choice." 8 50
            continue
            ;;
    esac

    if [ "${#RESULTS[@]}" -eq 0 ]; then
        whiptail --msgbox "No results found. Try a different search, decade, or browse mode." 8 60
        continue
    fi

    # Largest file size first, regardless of which source(s) contributed -
    # this is the one place both display loops below draw from, so
    # sorting here covers the results menu build and (via RESULTS itself)
    # the index lookup on selection further down.
    sort_results_by_size

    # ---- Build and show the results menu -------------------------------------
    MENU_ITEMS=()
    for i in "${!RESULTS[@]}"; do
        IFS="$US" read -r _SRC _ID TITLE YEAR SIZE _SZB _TIER <<< "${RESULTS[$i]}"
        LABEL="$TITLE"
        if [ -n "$YEAR" ] && [ "$YEAR" != "N/A" ]; then
            LABEL="${TITLE} (${YEAR})"
        fi
        [ -n "$SIZE" ] && LABEL="${LABEL} - ${SIZE}"
        case "$_SRC" in
            IA)   LABEL="${LABEL} [IA]" ;;
            WIKI) LABEL="${LABEL} [Wiki]" ;;
            PDT)  LABEL="${LABEL} [Torrent]" ;;
        esac
        MENU_ITEMS+=("$((i + 1))" "$LABEL")
    done

    BOX_HEIGHT=$((MENU_HEIGHT + 7))
    LIST_TITLE="Results"

    # Inner loop: stay on this same result set after each fetch so the
    # user can grab several titles from one search/browse without
    # re-querying. Cancelling the results menu drops back out to the main
    # mode menu (outer loop).
    while true; do
        CHOICE=$(wt_menu "$LIST_TITLE" "$LIST_TEXT" "$BOX_HEIGHT" 78 "$MENU_HEIGHT" "${MENU_ITEMS[@]}") || break

        IFS="$US" read -r SRC ID TITLE YEAR SIZE _SZB _TIER <<< "${RESULTS[$((CHOICE - 1))]}"

        DISPLAY_TITLE="$TITLE"
        if [ -n "$YEAR" ] && [ "$YEAR" != "N/A" ]; then
            DISPLAY_TITLE="${TITLE} (${YEAR})"
        fi

        case "$SRC" in
            IA)   download_from_ia "$ID" "$DISPLAY_TITLE" ;;
            WIKI) download_from_wiki "$ID" "$DISPLAY_TITLE" ;;
            PDT)  download_from_pdt "$ID" "$DISPLAY_TITLE" ;;
            *)    whiptail --msgbox "Internal error: unknown source '$SRC'." 8 60 ;;
        esac

        # Loop back to the SAME results list so the user can grab another
        # title from this search/browse without re-querying.
    done
done
clear
echo "Goodbye."
