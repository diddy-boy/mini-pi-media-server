<?php
// remote_command.php
// POST: a controller (e.g. phone) sends { target, file, action, fromName }
//       to queue a one-shot command for the target device.
// GET  ?device_id=<id>: the target device polls this every few seconds;
//       if a command is waiting it is returned once, then deleted.

header('Content-Type: application/json');

$cmdDir = sys_get_temp_dir() . '/mini-pi-remote/commands';
if (!is_dir($cmdDir)) {
    @mkdir($cmdDir, 0777, true);
}

function safeDeviceFile($dir, $id) {
    $id = preg_replace('/[^a-zA-Z0-9\-]/', '', (string)$id);
    if ($id === '') return null;
    return $dir . '/' . $id . '.json';
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $target = isset($input['target']) ? trim($input['target']) : '';
    $file = isset($input['file']) ? trim($input['file']) : '';
    $action = isset($input['action']) ? trim($input['action']) : 'play';
    $fromName = isset($input['fromName']) ? mb_substr(trim($input['fromName']), 0, 64) : '';

    $targetFile = safeDeviceFile($cmdDir, $target);
    if (!$targetFile || $file === '') {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Missing target or file']);
        exit;
    }

    // Refuse to queue a cast for a device that isn't currently online —
    // otherwise a stale/offline target (e.g. one that's mid-cast already,
    // or that closed its browser) would just silently pick the command up
    // whenever it next happens to load index.html again.
    $devicesFile = sys_get_temp_dir() . '/mini-pi-remote/devices.json';
    $devices = [];
    if (file_exists($devicesFile)) {
        $devices = json_decode(file_get_contents($devicesFile), true) ?: [];
    }
    $now = time();
    $isOnline = isset($devices[$target]) && ($now - $devices[$target]['last_seen']) <= 90;
    if (!$isOnline) {
        http_response_code(409);
        echo json_encode(['success' => false, 'error' => 'That device is no longer available. Refresh and pick another.']);
        exit;
    }
    $targetName = isset($devices[$target]['name']) ? $devices[$target]['name'] : 'That device';

    // Refuse a second cast that would silently clobber one already sitting
    // there undelivered — two controllers casting to the same device
    // within the same few-second window (before the target has even
    // polled the first one yet, so the online check above doesn't catch
    // it) would otherwise both get a "success" toast while only the
    // second cast actually plays.
    if (file_exists($targetFile)) {
        $pending = json_decode(file_get_contents($targetFile), true);
        $pendingAge = $pending ? ($now - ($pending['issued'] ?? 0)) : 999;
        if ($pending && $pendingAge <= 15) {
            $pendingFilename = basename($pending['file']);
            http_response_code(409);
            echo json_encode([
                'success' => false,
                'error' => "Failed to cast \u2014 {$targetName} is now set to play \"{$pendingFilename}\" from another cast. Wait for it to start, then try again."
            ]);
            exit;
        }
    }

    // Make sure the requested file is actually inside the video folder
    // (blocks ../ path traversal attempts).
    $baseDir = realpath('/var/lib/minidlna/Video');
    $candidate = $baseDir ? realpath($baseDir . '/' . $file) : false;
    if ($baseDir === false || $candidate === false || strpos($candidate, $baseDir) !== 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid or unknown file']);
        exit;
    }

    $command = [
        'action' => $action,
        'file' => $file,
        'fromName' => $fromName,
        'issued' => time()
    ];
    file_put_contents($targetFile, json_encode($command), LOCK_EX);
    echo json_encode(['success' => true]);
    exit;
}

if ($method === 'GET') {
    $deviceId = isset($_GET['device_id']) ? trim($_GET['device_id']) : '';
    $file = safeDeviceFile($cmdDir, $deviceId);

    if (!$file || !file_exists($file)) {
        echo json_encode(['success' => true, 'command' => null]);
        exit;
    }

    $raw = file_get_contents($file);
    $command = json_decode($raw, true);

    // One-shot delivery: consume it immediately so it isn't replayed.
    @unlink($file);

    if (!$command || (time() - ($command['issued'] ?? 0)) > 60) {
        echo json_encode(['success' => true, 'command' => null]);
        exit;
    }

    echo json_encode(['success' => true, 'command' => $command]);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'error' => 'Method not allowed']);
