<?php
// remote_files.php
// Lists video files under the DLNA video folder so remote.html can offer
// them for casting. Adjust $baseDir if your videos live elsewhere.

header('Content-Type: application/json');

$baseDir = '/var/lib/minidlna/Video';
// Kept identical to $video_extensions in index.php so anything listed here
// is guaranteed to be recognised as a video by the player.
$extensions = ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm'];

$files = [];

if (is_dir($baseDir)) {
    $realBase = realpath($baseDir);
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($baseDir, FilesystemIterator::SKIP_DOTS)
    );
    foreach ($iterator as $fileInfo) {
        if (!$fileInfo->isFile()) continue;
        $filename = $fileInfo->getFilename();
        // Skip hidden files, incl. macOS "._foo.mp4" AppleDouble junk
        // that shows up alongside real files after copying from a Mac.
        if ($filename[0] === '.') continue;
        $ext = strtolower($fileInfo->getExtension());
        if (!in_array($ext, $extensions, true)) continue;

        $relative = ltrim(str_replace($realBase, '', $fileInfo->getPathname()), '/');
        $files[] = [
            'path' => $relative,
            'name' => $fileInfo->getFilename(),
            'size' => $fileInfo->getSize(),
            'size_human' => formatBytes($fileInfo->getSize())
        ];
    }
}

usort($files, function ($a, $b) { return strcasecmp($a['name'], $b['name']); });

echo json_encode(['success' => true, 'files' => $files]);

function formatBytes($bytes) {
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 1) . ' GB';
    if ($bytes >= 1048576) return round($bytes / 1048576, 1) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024, 1) . ' KB';
    return $bytes . ' B';
}
