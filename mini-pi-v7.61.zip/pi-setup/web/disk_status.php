<?php
header('Content-Type: application/json');

// 1. Get disk space information
$free_space = disk_free_space("/");
$total_space = disk_total_space("/");
$free_percentage = ($total_space > 0) ? ($free_space / $total_space) * 100 : 0;

// 2. Get CPU Temperature
$temp = shell_exec("cat /sys/class/thermal/thermal_zone0/temp");
$temp_c = round($temp / 1000, 1);

// 3. Get CPU Usage (%)
$cpu_now = shell_exec("vmstat 1 2 | tail -1 | awk '{print 100 - $15}'");
$cpu_usage = (float)trim($cpu_now);

// 4. Fixed Helper function to safely count files by extension
function count_media_files($path, $extensions = []) {
    if (!is_dir($path)) return 0;
    
    // Fallback if no extensions provided (counts all files safely)
    if (empty($extensions)) {
        $output = shell_exec("find " . escapeshellarg($path) . " -type f | wc -l");
        return intval(trim($output));
    }

    $total_count = 0;
    
    // Count each extension individually and add them together
    foreach ($extensions as $ext) {
        // Case-insensitive match (-iname), looking strictly for files (-type f)
        $cmd = "find " . escapeshellarg($path) . " -type f -iname " . escapeshellarg("*." . $ext) . " | wc -l";
        $output = shell_exec($cmd);
        $total_count += intval(trim($output));
    }

    return $total_count;
}

// 5. Service Health Check Helper
function check_service($name) {
    $status = shell_exec("systemctl is-active " . escapeshellarg($name));
    return (trim($status) === 'active');
}

// 6. Prepare the FINAL combined JSON response
$response = [
    'low_disk' => $free_percentage < 5,
    'free_percentage' => floor($free_percentage),
    'cpu_temp' => $temp_c,
    'cpu_usage' => $cpu_usage,
    'media_counts' => [ 
        // Only counting actual media files, ignoring your .srt and .vtt files
        'video'    => count_media_files("/var/lib/minidlna/Video", ['mp4', 'mkv', 'avi', 'mov', 'm4v']),
        'music'    => count_media_files("/var/lib/minidlna/Music", ['mp3', 'flac', 'wav', 'm4a', 'ogg']),
        'pictures' => count_media_files("/var/lib/minidlna/Pictures", ['jpg', 'jpeg', 'png', 'gif', 'webp'])
    ],
    'services' => [
        'smb' => check_service('smbd'),
        'dlna' => check_service('minidlna'),
        'transmission' => check_service('transmission-daemon')
    ]
];

echo json_encode($response);
?>