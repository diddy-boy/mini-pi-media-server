<?php
header('Content-Type: application/json');

function getNetworkStatus() {
    clearstatcache();
    
    // 1. Check for Ethernet Carrier
    $eth_path = '/sys/class/net/eth0/carrier';
    $is_eth = (file_exists($eth_path) && trim(@file_get_contents($eth_path)) === '1');

    // 2. Get Ethernet IP
    $eth_ip = 'Disconnected';
    if ($is_eth) {
        $eth_ip = trim(shell_exec("ip -4 addr show eth0 | grep -oP '(?<=inet\s)\d+(\.\d+){3}'") ?? '');
    }

    // 3. Get WiFi SSID and Password via nmcli (NetworkManager)
    $ssid = "Mini-Pi-Server"; 
    $password = "";

    // Get the name of the active connection on wlan0
    $active_con = trim(shell_exec("nmcli -t -f DEVICE,NAME connection show --active | grep wlan0 | cut -d: -f2") ?? '');

    if ($active_con) {
        // Fetch SSID
        $get_ssid = shell_exec("nmcli -s -g 802-11-wireless.ssid connection show '$active_con'");
        if ($get_ssid) $ssid = trim($get_ssid);

        // Fetch Password (PSK)
        $get_pass = shell_exec("sudo nmcli -s -g 802-11-wireless-security.psk connection show '$active_con'");
        if ($get_pass) $password = trim($get_pass);
    }
    
    return [
        'mode' => $is_eth ? 'LAN' : 'WIFI',
        'text' => $is_eth ? 'Connected via LAN' : 'Access Point only',
        'eth_ip' => $eth_ip ?: 'Disconnected',
        'ap_ip' => '192.168.50.1',
        'ssid' => $ssid,
        'password' => $password
    ];
}

echo json_encode(getNetworkStatus());
?>