<?php
$version_file = '/var/www/html/version.txt';
$local_version = file_exists($version_file) ? trim(file_get_contents($version_file)) : "0.0";
$repo_url = "https://raw.githubusercontent.com/diddy-boy/mini-pi-media-server/main/version.json";

// 1. Set a tight timeout (3 seconds is plenty for a ping)
$ctx = stream_context_create(['http'=> ['timeout' => 3]]);

// 2. The '@' suppresses errors if DNS fails (no internet)
$response = @file_get_contents($repo_url, false, $ctx);

if ($response) {
    $remote_data = json_decode($response, true);
    if ($remote_data && version_compare($remote_data['version'], $local_version, '>')) {
        echo json_encode([
            "update_available" => true,
            "new_version" => $remote_data['version']
        ]);
        exit;
    }
}

// 3. If internet is dead or no update, just return false silently
echo json_encode(["update_available" => false]);