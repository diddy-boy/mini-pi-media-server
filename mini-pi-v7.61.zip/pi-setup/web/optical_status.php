<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache');

// pgrep -x matches the process name exactly (not the full command line).
// This avoids false positives from pgrep matching its own arguments or
// unrelated processes that happen to contain the search string.
function is_running_exact(string $name): bool {
    exec('pgrep -x ' . escapeshellarg($name) . ' > /dev/null 2>&1', $out, $exit);
    return $exit === 0;
}

// disc-handler.sh needs -f (full cmdline match) since the process name seen
// by pgrep will be "bash", not "disc-handler.sh". We narrow it with the
// lock directory as a corroborating check to avoid false positives.
$lock_exists          = is_dir('/tmp/disc-handler.lock.d');
$disc_handler_running = $lock_exists;   // lock is only present while the script runs
$abcde_running        = is_running_exact('abcde');
$vobcopy_running      = is_running_exact('vobcopy');

$ripping = $disc_handler_running || $abcde_running || $vobcopy_running;

if ($abcde_running) {
    $status = 'Ripping Audio CD';
} elseif ($vobcopy_running) {
    $status = 'Ripping DVD';
} elseif ($disc_handler_running) {
    $status = 'Detecting Disc';
} else {
    $status = '';
}

echo json_encode([
    'ripping' => $ripping,
    'status'  => $status,
]);
