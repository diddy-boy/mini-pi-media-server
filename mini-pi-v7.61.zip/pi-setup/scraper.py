import os
import requests
import PTN
import time
import random
import re
import argparse
import socket
from pathlib import Path
from PIL import Image
from bs4 import BeautifulSoup
import io
from ddgs import DDGS

# --- CONFIG ---
MOVIE_DIR = "/var/lib/minidlna/Video"
POSTER_DIR = "/var/lib/minidlna/.metadata/posters"
VIDEO_EXTS = ['.mp4', '.avi', '.mov', '.wmv', '.mkv']
THUMBNAIL_SIZE = (300, 450)

# --- SUBTITLES (optional) ---
# To enable subtitle downloads, register a free account at https://www.opensubtitles.com
# Then create a free API key at https://www.opensubtitles.com/en/consumers
# Free accounts get 20 downloads/day — plenty for a home media server.
# Leave all three blank to disable subtitle downloading entirely.
OPENSUBTITLES_API_KEY = ""
OPENSUBTITLES_USERNAME = ""
OPENSUBTITLES_PASSWORD = ""


def is_connected():
    """Returns True if WAN is reachable, False if in Ad-hoc/Offline mode."""
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except OSError:
        return False


def clean_text(text):
    if not text:
        return None
    text = re.sub(r'\[\d+\]|\[\w+\]', '', text)
    return text.strip()


def _parse_scores_from_reception(soup):
    """
    Scan the Wikipedia Reception section for RT scores.
    Returns rt_string (or None).
    """
    rt = None

    main_content = soup.find('div', class_='mw-parser-output')
    if not main_content:
        return rt

    in_reception = False
    reception_text_blocks = []

    for el in main_content.find_all(['h2', 'h3', 'p']):
        heading = el.get_text().strip().lower()
        if el.name in ['h2', 'h3']:
            if 'reception' in heading or 'critical response' in heading:
                in_reception = True
                continue
            elif in_reception:
                break
            continue
        if in_reception and el.name == 'p':
            reception_text_blocks.append(el.get_text())

    full_text = ' '.join(reception_text_blocks)

    if not full_text:
        return rt

    rt_patterns = [
        r'(\d{1,3})%\s+(?:approval rating|of \d+ critics|of critics|fresh)',
        r'(?:approval rating of|rated)\s+(\d{1,3})%',
        r'(\d{1,3})%\s+on Rotten Tomatoes',
        r'Rotten Tomatoes[^.]*?(\d{1,3})%',
    ]
    for pat in rt_patterns:
        m = re.search(pat, full_text, re.IGNORECASE)
        if m:
            score = int(m.group(1))
            if 0 <= score <= 100:
                aud = re.search(
                    r'audience score of (\d{1,3})%|(\d{1,3})%\s+of audiences',
                    full_text, re.IGNORECASE
                )
                aud_score = aud.group(1) or aud.group(2) if aud else None
                if aud_score:
                    rt = f"Critics: {score}% | Audience: {aud_score}%"
                else:
                    rt = f"Critics: {score}%"
                break

    return rt


def _extract_canonical_title(soup, original_title):
    """
    Extract the canonical film title from the Wikipedia page <title> tag.
    e.g. "2010: The Year We Make Contact - Wikipedia" -> "2010: The Year We Make Contact"

    Validates the result is plausibly about the right film — if no significant
    word from the original title appears in the canonical title, we've landed on
    the wrong Wikipedia page (e.g. "1984 in film" for "2010") and return None.
    """
    page_title = soup.find('title')
    if not page_title:
        return None
    canonical = page_title.get_text()
    canonical = re.sub(r'\s*-\s*Wikipedia$', '', canonical).strip()
    canonical = re.sub(r'\s*\(\d{4} film\)$', '', canonical, flags=re.IGNORECASE).strip()
    canonical = re.sub(r'\s*\(film\)$', '', canonical, flags=re.IGNORECASE).strip()

    if not canonical:
        return None

    # Sanity check: at least one significant word from the original parsed title
    # must appear in the canonical title, otherwise we've landed on the wrong page
    stopwords = {'the', 'and', 'for', 'with', 'from', 'into', 'that', 'this', 'was'}
    original_words = set(
        w.lower() for w in re.split(r'\W+', original_title)
        if len(w) > 2 and w.lower() not in stopwords
    )
    canonical_lower = canonical.lower()
    if original_words and not any(w in canonical_lower for w in original_words):
        return None

    return canonical


def get_wikipedia_data(title, year):
    """
    Fetch Wikipedia page for a film. Returns a tuple:
      (plot_text, rt_score, wiki_url, canonical_title)
    Any element may be None if not found.
    """
    try:
        search_query = f"{title} {year if year else ''} film wikipedia"
        wiki_url = None

        with DDGS() as ddgs:
            results = ddgs.text(search_query, max_results=3)
            for r in results:
                if 'en.wikipedia.org/wiki/' in r['href'] and '/wiki/File:' not in r['href']:
                    wiki_url = r['href']
                    break

        if not wiki_url:
            return None, None, None, None

        headers = {
            'User-Agent': (
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/120.0.0.0 Safari/537.36'
            )
        }
        response = requests.get(wiki_url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Extract canonical title before decomposing anything
        canonical_title = _extract_canonical_title(soup, title)

        # Extract RT scores before decomposing anything
        rt_score = _parse_scores_from_reception(soup)

        # Strip nav/infobox clutter then extract plot text
        for extra in soup.find_all(
            ['table', 'div', 'style', 'script', 'sup', 'span'],
            class_=['infobox', 'toc', 'navbox', 'metadata', 'reference', 'mw-editsection']
        ):
            extra.decompose()

        main_content = soup.find('div', class_='mw-parser-output')
        if not main_content:
            return None, rt_score, wiki_url, canonical_title

        lead_paragraphs = []
        plot_paragraphs = []
        word_limit = 600
        plot_targets = ['plot', 'synopsis', 'premise', 'summary', 'story']

        found_specific_plot = False
        capture_enabled = True

        for element in main_content.find_all(['p', 'h2', 'h3']):
            if element.name in ['h2', 'h3']:
                header_text = element.get_text().strip().lower()
                if any(t in header_text for t in plot_targets):
                    found_specific_plot = True
                    capture_enabled = True
                    continue
                elif found_specific_plot:
                    capture_enabled = False
                    break
                else:
                    capture_enabled = False
                    continue

            if element.name == 'p' and capture_enabled:
                txt = clean_text(element.get_text())
                if txt and len(txt.split()) > 5:
                    if not found_specific_plot:
                        lead_paragraphs.append(txt)
                    else:
                        plot_paragraphs.append(txt)

            current_total = sum(len(x.split()) for x in (lead_paragraphs + plot_paragraphs))
            if current_total >= word_limit:
                break

        lead_text = "\n\n".join(lead_paragraphs).strip()
        plot_body = "\n\n".join(plot_paragraphs).strip()

        if plot_body:
            plot_out = f"{lead_text}\n\nPLOT\n\n{plot_body}"
        else:
            plot_out = lead_text

        return (plot_out if plot_out else None), rt_score, wiki_url, canonical_title

    except Exception as e:
        print(f"    ⚠️  Wikipedia error: {e}")
        return None, None, None, None


def download_and_resize_image(url, save_path):
    try:
        response = requests.get(url, timeout=15)
        img = Image.open(io.BytesIO(response.content))
        if img.mode in ("RGBA", "P"):
            img = img.convert("RGB")
        img.thumbnail(THUMBNAIL_SIZE)
        img.save(save_path, "JPEG", optimize=True, quality=85)
        return True
    except Exception as e:
        print(f"    ⚠️  Image download error: {e}")
        return False


# Cached JWT token for the current script run — login once, reuse for all downloads
_os_token_cache = None
_os_creds_warning_shown = False  # Ensures "credentials not set" logs only once


def _opensubtitles_login():
    """Login to OpenSubtitles REST API and return a JWT token. Cached for the session."""
    global _os_token_cache
    if _os_token_cache:
        return _os_token_cache
    try:
        resp = requests.post(
            "https://api.opensubtitles.com/api/v1/login",
            headers={
                "Content-Type": "application/json",
                "User-Agent": "MiniPiMediaServer v1.0",
                "Api-Key": OPENSUBTITLES_API_KEY,
            },
            json={"username": OPENSUBTITLES_USERNAME, "password": OPENSUBTITLES_PASSWORD},
            timeout=10,
        )
        data = resp.json()
        token = data.get("token")
        if token:
            _os_token_cache = token
            return token
        print(f"    ⚠️  Subtitles: Login failed (HTTP {resp.status_code}) — {data.get('message', 'unknown error')}")
        return None
    except Exception as e:
        print(f"    ⚠️  Subtitles: Login error — {e}")
        return None


def get_subtitles(title, year, video_path, canonical_title=None):
    """
    Downloads English subtitles via the OpenSubtitles REST API.
    - Search is free and requires no account.
    - Download requires a free account — set credentials in CONFIG above.
    - Prefers canonical_title for ambiguous titles like "2010".
    - Picks the subtitle with the highest download count (most proven match).
    - Logs in once per script run and reuses the JWT token.
    """
    global _os_creds_warning_shown
    if not all([OPENSUBTITLES_API_KEY, OPENSUBTITLES_USERNAME, OPENSUBTITLES_PASSWORD]):
        if not _os_creds_warning_shown:
            print("    ⚠️  Subtitles: No OpenSubtitles credentials set — subtitle downloads disabled.")
            print("        To enable, register free at https://www.opensubtitles.com and add credentials to CONFIG.")
            _os_creds_warning_shown = True
        return False

    search_title = canonical_title if canonical_title else title
    print(f"    🔍 Subtitles: Searching for '{search_title}'...")

    headers = {
        "User-Agent": "MiniPiMediaServer v1.0",
        "Api-Key": OPENSUBTITLES_API_KEY,
    }

    try:
        # --- 1. Search (no auth needed) ---
        params = {"query": search_title, "languages": "en", "type": "movie"}
        if year:
            params["year"] = int(year)

        resp = requests.get(
            "https://api.opensubtitles.com/api/v1/subtitles",
            headers=headers,
            params=params,
            timeout=10,
        )
        data = resp.json()
        results = data.get("data", [])

        if not results:
            if resp.status_code != 200 or "data" not in data:
                print(f"    ❌ Subtitles: API error (HTTP {resp.status_code}) — {data}")
            else:
                print(f"    ❌ Subtitles: No matching subtitles found online")
            return False

        # Pick highest download count, preferring non-hearing-impaired
        def sort_key(r):
            a = r.get("attributes", {})
            return (not a.get("hearing_impaired", True), a.get("new_download_count", 0))

        results.sort(key=sort_key, reverse=True)
        best = results[0]
        file_id = best["attributes"]["files"][0]["file_id"]
        release = best["attributes"].get("release", "unknown")

        # --- 2. Login (cached) ---
        token = _opensubtitles_login()
        if not token:
            return False

        # --- 3. Request download link ---
        auth_headers = {**headers, "Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        resp = requests.post(
            "https://api.opensubtitles.com/api/v1/download",
            headers=auth_headers,
            json={"file_id": file_id},
            timeout=10,
        )
        dl_data = resp.json()
        link = dl_data.get("link")
        remaining = dl_data.get("remaining", "?")

        if not link:
            print(f"    ❌ Subtitles: Download link not returned — {dl_data.get('message', 'unknown error')}")
            return False

        # --- 4. Download the .srt file ---
        srt_resp = requests.get(link, timeout=15)
        if srt_resp.status_code != 200:
            print(f"    ❌ Subtitles: File download failed (HTTP {srt_resp.status_code})")
            return False

        target_path = os.path.splitext(video_path)[0] + '.srt'
        with open(target_path, 'wb') as f:
            f.write(srt_resp.content)

        print(f"    ✅ Subtitles: Downloaded '{os.path.basename(target_path)}' [{release}] ({remaining} quota remaining today)")
        return True

    except Exception as e:
        print(f"    ⚠️  Subtitles Error: {e}")
        return False


def process_file(video_path, force=False):
    """Process a single video file. Returns 1 if poster was downloaded/updated, else 0."""
    file = os.path.basename(video_path)

    if not any(file.lower().endswith(ext) for ext in VIDEO_EXTS):
        return 0

    info = PTN.parse(file)
    title = info.get('title')
    year = info.get('year')

    if not title:
        print(f"⚠️  Parsing Error: Could not extract title from '{file}', skipping.")
        return 0

    base_name = os.path.splitext(file)[0]

    paths = {
        'img':   os.path.join(POSTER_DIR, f"{base_name}.jpg"),
        'txt':   os.path.join(POSTER_DIR, f"{base_name}.txt"),
        'url':   os.path.join(POSTER_DIR, f"{base_name}.url"),
        'rt':    os.path.join(POSTER_DIR, f"{base_name}.rt"),
        'canon': os.path.join(POSTER_DIR, f"{base_name}.canon"),
    }

    print(f"🎬 Processing: {title} ({year if year else 'Year Unknown'})")

    need_plot      = not os.path.exists(paths['txt'])   or force
    need_rt        = not os.path.exists(paths['rt'])    or force
    need_poster    = not os.path.exists(paths['img'])   or force
    need_canon     = not os.path.exists(paths['canon']) or force

    # --- 1. Wikipedia: plot + RT score + canonical title in one request ---
    canonical_title = None

    if need_plot or need_rt or need_canon:
        plot, rt_score, wiki_url, canonical_title = get_wikipedia_data(title, year)

        if need_canon:
            if canonical_title:
                with open(paths['canon'], 'w') as f:
                    f.write(canonical_title)
                # Only log if the canonical title is meaningfully different to the parsed title
                if canonical_title.lower() != title.lower():
                    print(f"    ✅ Canonical title: '{canonical_title}'")
            else:
                print(f"    ❌ Canonical title not found, using parsed title")

        if need_plot:
            if plot:
                with open(paths['txt'], 'w') as f:
                    f.write(plot)
                if wiki_url:
                    with open(paths['url'], 'w') as f:
                        f.write(wiki_url)
                print(f"    ✅ Synopsis saved")
            else:
                print(f"    ❌ Synopsis not found")

        if need_rt:
            if rt_score:
                with open(paths['rt'], 'w') as f:
                    f.write(rt_score)
                print(f"    ✅ Rotten Tomatoes: {rt_score}")
            else:
                print(f"    ❌ Rotten Tomatoes score not found")

        time.sleep(random.uniform(1, 2))

    else:
        # Wikipedia not needed this run — load canonical title from disk for subtitle use
        if os.path.exists(paths['canon']):
            with open(paths['canon']) as f:
                canonical_title = f.read().strip() or None

    # --- 2. Poster ---
    count = 0
    if need_poster:
        p_url = None
        try:
            with DDGS() as ddgs:
                res = ddgs.images(
                    f"{title} {year if year else ''} movie poster",
                    max_results=1
                )
                if res:
                    p_url = res[0]['image']
        except Exception as e:
            print(f"    ⚠️  Poster Art: Search failed — {e}")

        if p_url and download_and_resize_image(p_url, paths['img']):
            print(f"    ✅ Poster Art downloaded")
            count = 1
        elif not os.path.exists(paths['img']):
            print(f"    ❌ Poster Art not available")

        time.sleep(random.uniform(1, 2))

    # --- 3. Subtitles ---
    srt_path = os.path.splitext(video_path)[0] + '.srt'
    vtt_path = os.path.splitext(video_path)[0] + '.vtt'
    if (not os.path.exists(srt_path) and not os.path.exists(vtt_path)) or force:
        get_subtitles(title, year, video_path, canonical_title=canonical_title)

    return count


def run_scraper(force=False, single_file=None):
    print("--- Script Started ---")
    if not is_connected():
        print("🛑 No internet access detected. Exiting.")
        return

    Path(POSTER_DIR).mkdir(parents=True, exist_ok=True)
    count = 0

    if single_file:
        if not os.path.isfile(single_file):
            print(f"🛑 File not found: {single_file}")
            return
        count = process_file(single_file, force=force)
        print(f"--- Finished. Updated {count} item(s). ---")
        return

    video_found = False
    for root, dirs, files in os.walk(MOVIE_DIR):
        dirs[:] = [d for d in dirs if d not in ['.metadata', 'Test-Vids', 'Web']]
        for file in files:
            if any(file.lower().endswith(ext) for ext in VIDEO_EXTS):
                video_found = True
                count += process_file(os.path.join(root, file), force=force)
                time.sleep(random.uniform(3, 6))

    if not video_found:
        print(f"ℹ️  No compatible videos found scanning path: '{MOVIE_DIR}'")

    print(f"--- Finished. Updated {count} item(s). ---")


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(line_buffering=True)

    parser = argparse.ArgumentParser(description="Fetch movie metadata for MiniDLNA.")
    parser.add_argument('--force', action='store_true', help="Re-fetch all metadata.")
    parser.add_argument('--file', metavar='PATH', help="Process a single video file.")
    args = parser.parse_args()
    run_scraper(force=args.force, single_file=args.file)