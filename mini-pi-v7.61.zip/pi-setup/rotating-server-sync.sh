#!/usr/bin/env bash
#
# Server Media Sync with dialog - set amount of months by user in this script.
#
# NOTE: use this or configure_server_script.sh NOT both. They work in different ways.
# Syncs media files modified within a user-specified number of months from a Samba server share
# to a /var/lib/minidlna (flat structure) folder.
# If an MP4 file of the same name already exists do NOT rsync the MKV file down from server.
# Deletes local files older than the date range set by the user.
# Uses dialog for user interaction and shows rsync output during sync.
# User can schedule this script to run nightly via a systemd service/timer
# (sync only - MKV to MP4 conversion is handled by a separate script/schedule).
# User can also remove that nightly sync timer from systemd as well.
# INTELLIGENT: Skips MKV files if MP4 equivalents already exist locally when running rsync
# CRON SAFE: When run with --cron, dialog is replaced with plain echo logging, and the server
#            is pinged first - if unreachable the sync skips cleanly with no errors.
#

SCRIPT_DIR="$(dirname "$(realpath "$0")")"
CONFIG_FILE="$SCRIPT_DIR/.samba_film_sync.conf"
CRON_LOG="/var/log/media-sync.log"

# Default config values
SAMBA_SHARE="//192.168.8.10/Films"
SAMBA_USER="username"
SAMBA_PASS=""
DEST_DIR="/var/lib/minidlna/Video"
MONTHS=3
MOUNT_POINT="/mnt/samba_share"

# Is this a cron/unattended run?
CRON_MODE=false
[[ "$1" == "--cron" ]] && CRON_MODE=true

# ─────────────────────────────────────────────
# Root/sudo check - this script mounts shares, writes to /var/lib/minidlna,
# and manages systemd units, so it needs root privileges throughout.
# Running it as a plain user (even with passwordless sudo for some commands)
# is what causes the "works after reboot / fails silently the first time"
# class of bugs, since some steps run privileged and some don't.
# ─────────────────────────────────────────────
if [ "$(id -u)" -ne 0 ]; then
    WARN_MSG="This script needs to be run as root (e.g. 'sudo $0') to mount the Samba share, write to $DEST_DIR, and manage the systemd timer reliably.\n\nRunning it as a normal user can cause mounts and syncs to fail silently or behave inconsistently."
    if [ "$CRON_MODE" = true ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] Not running as root - aborting cron sync." >> "$CRON_LOG"
    elif command -v dialog >/dev/null 2>&1; then
        dialog --title "Not Running as Root" --msgbox "$WARN_MSG" 12 70
    else
        echo -e "WARNING: $WARN_MSG"
    fi
    exit 1
fi

# ─────────────────────────────────────────────
# HELPER: output to dialog or log depending on mode
# ─────────────────────────────────────────────

# Usage: notify "title" "message"
notify() {
    local title="$1"
    local msg="$2"
    if [ "$CRON_MODE" = true ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$title] $msg" >> "$CRON_LOG"
    else
        dialog --title "$title" --msgbox "$msg" 10 60
    fi
}

# Usage: log_info "message"
log_info() {
    if [ "$CRON_MODE" = true ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$CRON_LOG"
    else
        echo "$1"
    fi
}

# ─────────────────────────────────────────────
# FUNCTIONS
# ─────────────────────────────────────────────

load_config() {
    if [ -f "$CONFIG_FILE" ]; then
        source "$CONFIG_FILE"
    fi
}

save_config() {
    cat > "$CONFIG_FILE" << EOF
SAMBA_SHARE="$SAMBA_SHARE"
SAMBA_USER="$SAMBA_USER"
SAMBA_PASS="$SAMBA_PASS"
DEST_DIR="$DEST_DIR"
MONTHS=$MONTHS
EOF
    chmod 600 "$CONFIG_FILE"
}

setup_sync_service() {
    SERVICE_FILE="/etc/systemd/system/media-sync.service"
    TIMER_FILE="/etc/systemd/system/media-sync.timer"

    SYNC_SCRIPT_PATH="$(realpath "$0")"

    sudo bash -c "cat > $SERVICE_FILE" << EOF
[Unit]
Description=Sync Media from Server
Wants=network-online.target
After=network-online.target

[Service]
Type=oneshot
ExecStart=/bin/bash $SYNC_SCRIPT_PATH --cron
User=root
Group=root
WorkingDirectory=/var/lib/minidlna/Video
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF

    sudo bash -c "cat > $TIMER_FILE" << 'EOF'
[Unit]
Description=Run Media Sync daily at 11pm

[Timer]
OnCalendar=*-*-* 23:00:00
Persistent=true

[Install]
WantedBy=timers.target
EOF

    sudo systemctl daemon-reload
    sudo systemctl enable media-sync.timer
    sudo systemctl start media-sync.timer

    dialog --msgbox "Automation Set!\n\nEvery night at 11pm, this script will pull files from the server (--cron mode).\n\nIf the Pi is away from home the sync will skip cleanly.\nCheck logs at: $CRON_LOG" 14 60
}

remove_sync_service() {
    SERVICE_FILE="/etc/systemd/system/media-sync.service"
    TIMER_FILE="/etc/systemd/system/media-sync.timer"

    if [ ! -f "$SERVICE_FILE" ] && [ ! -f "$TIMER_FILE" ]; then
        dialog --msgbox "No sync timer or service found." 10 60
        return 1
    fi

    dialog --yesno "Are you sure you want to remove the nightly sync timer and service?" 10 60
    if [ $? -ne 0 ]; then
        dialog --msgbox "Aborted. The sync timer and service were not removed." 10 60
        return 1
    fi

    sudo systemctl stop media-sync.timer >/dev/null 2>&1 || true
    sudo systemctl disable media-sync.timer >/dev/null 2>&1 || true
    sudo rm -f "$SERVICE_FILE" "$TIMER_FILE"
    sudo systemctl daemon-reload

    if ! systemctl list-timers --all | grep -q media-sync.timer; then
        status="REMOVED"
    else
        status="FAILED TO REMOVE"
    fi

    dialog --msgbox "Sync timer and service have been removed.\nStatus: $status" 10 60
}

configure_setup() {
    while true; do
        CHOICE=$(dialog --clear --backtitle "Rotational Server Media Sync - Configure Setup" \
            --menu "Current Configuration:\n
Samba Share: $SAMBA_SHARE
Username: $SAMBA_USER
Password: [hidden]
Destination: $DEST_DIR
Months to Keep: $MONTHS

Select option to edit:" 16 90 8 \
            1 "Server Share Path" \
            2 "Server Username" \
            3 "Server Password" \
            4 "Local Destination Directory" \
            5 "How many months back do you want to sync Media from" \
            0 "Save and continue" \
            3>&1 1>&2 2>&3)

        case $CHOICE in
            1)
                input=$(dialog --inputbox "Enter Server Share Path (e.g., //192.168.8.10/Films):" 10 60 "$SAMBA_SHARE" 3>&1 1>&2 2>&3)
                if [ -n "$input" ]; then SAMBA_SHARE="$input"; fi
                ;;
            2)
                input=$(dialog --inputbox "Enter a Username to access this server:" 10 50 "$SAMBA_USER" 3>&1 1>&2 2>&3)
                if [ -n "$input" ]; then SAMBA_USER="$input"; fi
                ;;
            3)
                input=$(dialog --insecure --passwordbox "What Password is used to access this server:" 10 50 3>&1 1>&2 2>&3)
                if [ -n "$input" ]; then SAMBA_PASS="$input"; fi
                ;;
            4)
                dest_choice=$(dialog --menu "Select destination directory:" 10 50 3 \
                    1 "/var/lib/minidlna/Video" \
                    2 "/var/lib/minidlna/Music" \
                    3 "/var/lib/minidlna/Pictures" \
                    3>&1 1>&2 2>&3)
                case $dest_choice in
                    1) DEST_DIR="/var/lib/minidlna/Video" ;;
                    2) DEST_DIR="/var/lib/minidlna/Music" ;;
                    3) DEST_DIR="/var/lib/minidlna/Pictures" ;;
                esac
                ;;
            5)
                input=$(dialog --inputbox "How many months back do you want to synchronise media files from:" 8 50 "$MONTHS" 3>&1 1>&2 2>&3)
                if [[ "$input" =~ ^[1-9][0-9]*$ ]]; then
                    MONTHS="$input"
                else
                    dialog --msgbox "Invalid input. Please enter a number of months to sync within." 10 60
                fi
                ;;
            0)
                save_config
                # Stage the mount point and destination directory now, with
                # sane permissions, rather than waiting for the first sync to
                # create them - this was the root cause of the first-run-after-
                # setup failure. Guard each step so a silent failure here
                # doesn't just surface later as a confusing "Setup Incomplete"
                # error during a sync.
                SETUP_ERR=""
                if ! sudo mkdir -p "$MOUNT_POINT" 2>/tmp/setup_err; then
                    SETUP_ERR="Failed to create mount point $MOUNT_POINT:\n$(cat /tmp/setup_err)"
                elif ! sudo chmod 775 "$MOUNT_POINT" 2>/tmp/setup_err; then
                    SETUP_ERR="Failed to set permissions on $MOUNT_POINT:\n$(cat /tmp/setup_err)"
                elif ! sudo mkdir -p "$DEST_DIR" 2>/tmp/setup_err; then
                    SETUP_ERR="Failed to create destination directory $DEST_DIR:\n$(cat /tmp/setup_err)"
                elif ! sudo chmod 775 "$DEST_DIR" 2>/tmp/setup_err; then
                    SETUP_ERR="Failed to set permissions on $DEST_DIR:\n$(cat /tmp/setup_err)"
                fi
                rm -f /tmp/setup_err

                if [ -n "$SETUP_ERR" ]; then
                    dialog --title "Setup Failed" --msgbox "$SETUP_ERR\n\nSettings have been saved, but folders could not be prepared. Fix the issue above and re-open setup to retry, before running a sync." 14 70
                    break
                fi

                summary="Synchronise files from server: $SAMBA_SHARE\nWith a Username of: $SAMBA_USER\nTo the Destination Directory of: $DEST_DIR\nOnly synchronise media in the past: $MONTHS Months"
                dialog --title "Summary of Settings" --msgbox "$summary" 15 60
                dialog --yesno "Run synchronisation now?" 10 60
                if [ $? -eq 0 ]; then
                    run_sync
                fi
                break
                ;;
            *)
                ;;
        esac
    done
}

run_sync() {
    # ── Cron mode: ping server first, skip cleanly if unreachable ──
    if [ "$CRON_MODE" = true ]; then
        # Strip leading // and grab just the IP/hostname
        SERVER_HOST=$(echo "$SAMBA_SHARE" | sed 's|^//||' | cut -d'/' -f1)
        log_info "Checking if server $SERVER_HOST is reachable..."
        if ! ping -c 2 -W 3 "$SERVER_HOST" >/dev/null 2>&1; then
            log_info "Server $SERVER_HOST unreachable (Pi likely away from home). Skipping sync."
            exit 0
        fi
        log_info "Server reachable. Starting sync..."
    fi

    DAYS=$(echo "$MONTHS * 30.42" | bc | cut -d. -f1)
    if ! [[ "$DAYS" =~ ^[0-9]+$ ]] || [ "$DAYS" -lt 1 ]; then
        DAYS=91
    fi

    # Setup is responsible for creating these with the right permissions -
    # run_sync should only mount and sync, not silently paper over a missing
    # or skipped setup step.
    if [ ! -d "$MOUNT_POINT" ] || [ ! -d "$DEST_DIR" ]; then
        notify "Setup Incomplete" "$MOUNT_POINT or $DEST_DIR does not exist.\n\nPlease run 'Create/Edit Setup' and save your settings before running a sync."
        return 1
    fi

    if [ ! -w "$DEST_DIR" ]; then
        notify "Permission Error" "No write permission to $DEST_DIR. Run with sudo or fix permissions."
        return 1
    fi

    if mountpoint -q "$MOUNT_POINT"; then
        mounted=1
    else
        # Belt-and-braces: on a fresh install the cifs kernel module can still
        # be unloaded the first time this runs (only fully sorted out after a
        # reboot), which makes the very first mount attempt fail. Force it in
        # here, and clear out any stale/half mount left behind by a previous
        # failed attempt, before trying to mount.
        sudo modprobe cifs 2>/dev/null
        sudo umount -l "$MOUNT_POINT" 2>/dev/null

        CRED_FILE=$(mktemp)
        echo -e "username=$SAMBA_USER\npassword=$SAMBA_PASS" > "$CRED_FILE"
        chmod 600 "$CRED_FILE"
        # uid/gid/file_mode/dir_mode force consistent, predictable permissions
        # on the mounted content regardless of what the Samba server's own
        # ACLs say - otherwise readability depends on the invoking user and
        # the server config, which is what made this flaky before.
        MOUNT_ERR=$(sudo mount -t cifs "$SAMBA_SHARE" "$MOUNT_POINT" -o credentials="$CRED_FILE",vers=3.0,nounix,iocharset=utf8,uid=$(id -u),gid=$(id -g),file_mode=0775,dir_mode=0775 2>&1)
        status=$?
        rm -f "$CRED_FILE"
        if [ $status -ne 0 ]; then
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] Mount failed: $MOUNT_ERR" >> "$CRON_LOG"
            notify "Mount Failed" "Failed to mount $SAMBA_SHARE.\n\nError:\n$MOUNT_ERR"
            return 1
        fi
        mounted=0
    fi

    if [ ! -r "$MOUNT_POINT" ] || [ -z "$(ls -A "$MOUNT_POINT")" ]; then
        notify "Mount Error" "Mount point $MOUNT_POINT is unreadable or empty. Aborting."
        [ $mounted -eq 0 ] && sudo umount "$MOUNT_POINT"
        return 1
    fi

    log_info "Deleting files older than $MONTHS months ($DAYS days) from $DEST_DIR..."
    if [ "$CRON_MODE" = false ]; then
        dialog --title "Cleanup" --infobox "Deleting files older than $MONTHS months ($DAYS days) in $DEST_DIR..." 10 60
    fi
    find "$DEST_DIR" -maxdepth 1 -type f -mtime +"$DAYS" -exec rm -f {} \;

    mapfile -d '' files < <(find "$MOUNT_POINT" -type f -mtime -"$DAYS" -print0)

    total_files=${#files[@]}
    if [ "$total_files" -eq 0 ]; then
        notify "No Files" "No files found on server modified within $MONTHS months."
        [ $mounted -eq 0 ] && sudo umount "$MOUNT_POINT"
        return 0
    fi

    [ "$CRON_MODE" = false ] && clear
    log_info "Starting intelligent sync - checking for MKV/MP4 duplicates..."

    synced_files=0
    skipped_mkvs=0

    for src_file in "${files[@]}"; do
        filename=$(basename "$src_file")
        base_name="${filename%.*}"
        extension="${filename##*.}"
        extension_lower=$(echo "$extension" | tr '[:upper:]' '[:lower:]')

        if [[ "$extension_lower" == "mkv" ]]; then
            mp4_equivalent="$DEST_DIR/${base_name}.mp4"
            if [[ -f "$mp4_equivalent" ]]; then
                log_info "Skipping $filename - MP4 version already exists locally"
                ((skipped_mkvs++))
                continue
            else
                log_info "Syncing MKV: $filename (no MP4 equivalent found)"
            fi
        else
            log_info "Syncing: $filename"
        fi

        if rsync -av --progress --inplace --ignore-existing -z --exclude='.*' --exclude='*.avi' "$src_file" "$DEST_DIR/$filename" >> "$CRON_LOG" 2>&1; then
            ((synced_files++))
        else
            log_info "Failed to sync: $filename"
        fi
    done

    [ $mounted -eq 0 ] && sudo umount "$MOUNT_POINT"
    sudo chmod -R 775 /var/lib/minidlna
    sudo chown -R minidlna:minidlna /var/lib/minidlna

    log_info "Sync complete. Synced: $synced_files | MKVs skipped: $skipped_mkvs | Total: $total_files"

    if [ "$CRON_MODE" = false ]; then
        dialog --title "Sync Complete" --msgbox "Synchronisation completed successfully!\n\nFiles synced: $synced_files\nMKVs skipped (MP4 file exists): $skipped_mkvs\nTotal files processed: $total_files" 12 60
    fi
}

# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

if [ "$CRON_MODE" = true ]; then
    load_config
    run_sync
    exit 0
fi

clear

if ! command -v rsync >/dev/null; then
    dialog --msgbox "'rsync' is not installed. Please install it before running." 7 50
    exit 1
fi

if ! command -v mount.cifs >/dev/null; then
    dialog --msgbox "'cifs-utils' is not installed. Please install it before running." 7 60
    exit 1
fi

if ! command -v dialog >/dev/null; then
    echo "'dialog' is not installed. Please install it before running."
    exit 1
fi

load_config

while true; do
    choice=$(dialog --clear --backtitle "Rotational Server Media Sync" --menu "Select an option:" 15 60 5 \
        1 "Create/Edit Setup" \
        2 "Run Synchronisation Now" \
        3 "Setup Nightly Sync Timer" \
        4 "Remove Nightly Sync Timer" \
        5 "Exit" \
        3>&1 1>&2 2>&3)
    case $choice in
        1) configure_setup ;;
        2) run_sync ;;
        3) setup_sync_service ;;
        4) remove_sync_service ;;
        5) clear; exit 0 ;;
        *) dialog --msgbox "Invalid option. Please choose 1-5." 10 60 ;;
    esac
done