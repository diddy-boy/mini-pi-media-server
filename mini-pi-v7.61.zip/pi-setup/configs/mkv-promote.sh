#!/bin/bash
# =============================================================================
# mkv-promote.sh — Phase 1
# Moves MKV / MP4 / SRT files from Transmission subfolders up to SOURCE_DIR.
# Writes promoted MP4 paths to PROMOTED_LIST file for mkv-scrape.sh.
# Location: /usr/local/bin/mkv-promote.sh
#
# Usage: mkv-promote.sh TARGET_FILE PROMOTED_LIST
#   TARGET_FILE    — specific file passed from watcher (may be empty "")
#   PROMOTED_LIST  — temp file path to record promoted MP4s for Phase 4
# =============================================================================

source /usr/local/bin/mkv-common.sh || { echo "[PROMOTE] ERROR: cannot source mkv-common.sh"; exit 1; }

TARGET_FILE="${1:-}"
PROMOTED_LIST="${2:-}"

PROMOTED_COUNT=0

# If the target is already sitting directly in SOURCE_DIR root, nothing to promote
if [ -n "$TARGET_FILE" ]; then
    TARGET_DIR=$(dirname "$(realpath "$TARGET_FILE" 2>/dev/null || echo "$TARGET_FILE")")
    if [ "$(realpath "$TARGET_DIR" 2>/dev/null)" = "$(realpath "$SOURCE_DIR")" ]; then
        log PROMOTE "Target already in $SOURCE_DIR — skipping promote phase"
        exit 0
    fi
fi

log PROMOTE "Scanning for Transmission downloads to promote..."

for subdir in "$SOURCE_DIR"/*/; do
    [ -d "$subdir" ] || continue

    if is_protected_dir "$subdir"; then
        log PROMOTE "Skipping protected folder: $(basename "$subdir")"
        continue
    fi

    # Collect video files (MKV and MP4) one level deep only
    mapfile -t video_files < <(find "$subdir" -maxdepth 1 -type f \( -iname "*.mkv" -o -iname "*.mp4" -o -iname "*.vob" \))

    # ------------------------------------------------------------------
    # Multiple videos — leave for manual review
    # ------------------------------------------------------------------
    if [ "${#video_files[@]}" -gt 1 ]; then
        log PROMOTE "SKIP: Multiple video files in $(basename "$subdir") — manual review needed"
        continue
    fi

    # ------------------------------------------------------------------
    # No video files — check for a lone SRT whose MP4 already exists
    # ------------------------------------------------------------------
    if [ "${#video_files[@]}" -eq 0 ]; then
        mapfile -t lone_srts < <(find "$subdir" -maxdepth 1 -type f -iname "*.srt")

        if [ "${#lone_srts[@]}" -eq 1 ]; then
            lone_srt="${lone_srts[0]}"
            lone_base="$(basename "${lone_srt%.*}")"

            if [ -f "$SOURCE_DIR/$lone_base.mp4" ] || [ -f "$SOURCE_DIR/$lone_base.mkv" ]; then
                lone_dest="$SOURCE_DIR/$(basename "$lone_srt")"
                if [ -f "$lone_dest" ]; then
                    log PROMOTE "SKIP: $(basename "$lone_srt") already exists in $SOURCE_DIR"
                else
                    mv -- "$lone_srt" "$lone_dest"
                    if [ $? -eq 0 ]; then
                        log PROMOTE "Promoted standalone subtitle: $(basename "$lone_srt")"
                        PROMOTED_COUNT=$((PROMOTED_COUNT + 1))
                        remaining=$(find "$subdir" -maxdepth 1 -type f | wc -l)
                        if [ "$remaining" -eq 0 ]; then
                            rm -rf -- "$subdir"
                            log PROMOTE "Removed empty subfolder: $(basename "$subdir")"
                        fi
                    else
                        log PROMOTE "ERROR: Failed to promote $(basename "$lone_srt") — left in subfolder"
                    fi
                fi
            else
                log PROMOTE "SKIP: No matching MP4/MKV in $SOURCE_DIR for $(basename "$lone_srt") — manual review needed"
            fi

        elif [ "${#lone_srts[@]}" -gt 1 ]; then
            log PROMOTE "SKIP: No video files and multiple SRTs in $(basename "$subdir") — manual review needed"
        else
            log PROMOTE "SKIP: No video files in $(basename "$subdir") — manual review needed"
        fi
        continue
    fi

    # ------------------------------------------------------------------
    # Exactly one video file — attempt promote
    # ------------------------------------------------------------------
    video_file="${video_files[0]}"
    filename=$(basename "$video_file")
    dest="$SOURCE_DIR/$filename"

    # Already promoted verbatim
    if [ -f "$dest" ]; then
        log PROMOTE "SKIP: $filename already exists in $SOURCE_DIR"
        continue
    fi

    # Already converted (MKV/VOB whose MP4 already exists)
    if [[ "${filename,,}" == *.mkv ]] || [[ "${filename,,}" == *.vob ]]; then
        dest_mp4="$SOURCE_DIR/${filename%.*}.mp4"
        if [ -f "$dest_mp4" ]; then
            log PROMOTE "SKIP: $filename already converted as $(basename "$dest_mp4")"
            continue
        fi
    fi

    # Duplicate promote sentinel already present (another folder raced us)
    promoting_file="$SOURCE_DIR/PROMOTING_$filename"
    if [ -f "$promoting_file" ]; then
        log PROMOTE "SKIP: PROMOTING sentinel exists for $filename — duplicate folder? Manual review needed"
        continue
    fi

    log PROMOTE "Promoting: $filename from $(basename "$subdir")"

    # Atomic-ish move via sentinel name to survive power loss mid-copy
    mv -- "$video_file" "$promoting_file"
    if [ $? -ne 0 ]; then
        log PROMOTE "ERROR: Failed to move $filename to staging name — subfolder left intact"
        continue
    fi

    mv -- "$promoting_file" "$dest"
    if [ $? -ne 0 ]; then
        log PROMOTE "ERROR: Failed to complete promote of $filename — PROMOTING_ sentinel left for manual review"
        continue
    fi

    log PROMOTE "Promoted: $filename → $SOURCE_DIR"
    PROMOTED_COUNT=$((PROMOTED_COUNT + 1))

    # Track promoted MP4s so Phase 4 can scrape them (MKVs get scraped after conversion)
    if [[ "$filename" == *.mp4 ]] && [ -n "$PROMOTED_LIST" ]; then
        echo "$dest" >> "$PROMOTED_LIST"
        log PROMOTE "Queued for metadata scrape: $filename"
    fi

    # Promote matching SRT if exactly one exists alongside the video
    base_noext="${filename%.*}"
    mapfile -t sub_files < <(find "$subdir" -maxdepth 1 -type f -iname "*.srt")

    if [ "${#sub_files[@]}" -eq 1 ]; then
        sub_file="${sub_files[0]}"
        sub_ext="${sub_file##*.}"
        sub_dest="$SOURCE_DIR/$base_noext.$sub_ext"

        if [ -f "$sub_dest" ]; then
            log PROMOTE "SKIP: Subtitle $(basename "$sub_dest") already exists in $SOURCE_DIR"
        else
            mv -- "$sub_file" "$sub_dest"
            if [ $? -eq 0 ]; then
                log PROMOTE "Promoted subtitle: $base_noext.$sub_ext"
            else
                log PROMOTE "ERROR: Failed to promote subtitle $(basename "$sub_file") — left in subfolder"
            fi
        fi
    elif [ "${#sub_files[@]}" -gt 1 ]; then
        log PROMOTE "SKIP: Multiple subtitle files in $(basename "$subdir") — manual review needed"
    else
        log PROMOTE "No subtitle found in $(basename "$subdir")"
    fi

    # Clean up now-empty subfolder
    log PROMOTE "Cleaning up subfolder: $(basename "$subdir")"
    rm -rf -- "$subdir"
    log PROMOTE "Removed subfolder: $(basename "$subdir")"

done

if [ "$PROMOTED_COUNT" -eq 0 ]; then
    log PROMOTE "No new files to promote"
else
    log PROMOTE "Promoted $PROMOTED_COUNT file(s) to $SOURCE_DIR"
fi
