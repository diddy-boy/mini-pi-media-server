#!/bin/bash
# =============================================================================
# mkv-2-mp4.sh — orchestrator
# Acquires an atomic lock then sequences the four pipeline phases:
#   Phase 1: mkv-promote.sh   — move files out of Transmission subfolders
#   Phase 2: mkv-convert.sh   — MKV → MP4 with HW/SW fallback
#   Phase 3: mkv-subtitles.sh — standalone SRT → VTT
#   Phase 4: mkv-scrape.sh    — metadata scrape for promoted MP4s
# Location: /usr/local/bin/mkv-2-mp4.sh
#
# Usage: mkv-2-mp4.sh [TARGET_FILE]
#   TARGET_FILE — optional specific file passed from mkv-watcher.sh
# =============================================================================

source /usr/local/bin/mkv-common.sh || { echo "[PIPELINE] ERROR: cannot source mkv-common.sh"; exit 1; }

TARGET_FILE="${1:-}"

# =============================================================================
# Atomic lock acquisition — mkdir is atomic; touch+test is not
# =============================================================================
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    log PIPELINE "Already running (lock: $LOCK_DIR) — exiting"
    exit 1
fi

# Temp file for promoted MP4 list; $$ is this process's PID so parallel runs
# (if lock somehow fails) cannot cross-contaminate. Cleaned up on exit.
PROMOTED_LIST=$(mktemp /tmp/mkv-promoted-$$.XXXXXX)
PHASE_LOG=$(mktemp /tmp/mkv-phaselog-$$.XXXXXX)

cleanup() {
    rm -rf -- "$LOCK_DIR"
    rm -f  -- "$PROMOTED_LIST" "$PHASE_LOG"
}
trap cleanup EXIT

PIPELINE_START=$(date +%s)
log PIPELINE "Starting pipeline | target=${TARGET_FILE:-<scan>}"

# Per-phase log capture so we can derive a summary at the end without
# touching the internals of promote/convert/subtitles/scrape. Each phase's
# output is still streamed to stdout live (via tee) so the watcher's
# `logger` pickup is unaffected — this only adds a parallel copy on disk.

# =============================================================================
# Phase 1 — Promote
# =============================================================================
log PIPELINE "--- Phase 1: Promote ---"
bash /usr/local/bin/mkv-promote.sh "$TARGET_FILE" "$PROMOTED_LIST" | tee "$PHASE_LOG"
PROMOTED_COUNT=$(grep -c '^\[PROMOTE\] Promoted: ' "$PHASE_LOG")
PROMOTED_SUBS=$(grep -c '^\[PROMOTE\] Promoted subtitle: \|^\[PROMOTE\] Promoted standalone subtitle: ' "$PHASE_LOG")
PROMOTE_ERRORS=$(grep -c '^\[PROMOTE\] ERROR: ' "$PHASE_LOG")

# =============================================================================
# Phase 2 — Convert
# =============================================================================
log PIPELINE "--- Phase 2: Convert ---"
bash /usr/local/bin/mkv-convert.sh "$TARGET_FILE" | tee "$PHASE_LOG"
CONVERTED_COUNT=$(grep -c '^\[CONVERT\] Done: ' "$PHASE_LOG")
CONVERT_SCRAPED=$(grep -c '^\[CONVERT\] Metadata scrape complete: ' "$PHASE_LOG")
CONVERT_ERRORS=$(grep -c '^\[CONVERT\] ERROR: ' "$PHASE_LOG")

# =============================================================================
# Phase 3 — Subtitles
# =============================================================================
log PIPELINE "--- Phase 3: Subtitles ---"
bash /usr/local/bin/mkv-subtitles.sh "$TARGET_FILE" | tee "$PHASE_LOG"
SUBTITLE_COUNT=$(grep -c '^\[SUBTITLES\] Done: ' "$PHASE_LOG")
SUBTITLE_ERRORS=$(grep -c '^\[SUBTITLES\] ERROR: ' "$PHASE_LOG")

# =============================================================================
# Phase 4 — Scrape promoted MP4s
# =============================================================================
log PIPELINE "--- Phase 4: Scrape ---"
bash /usr/local/bin/mkv-scrape.sh "$PROMOTED_LIST" | tee "$PHASE_LOG"
SCRAPED_COUNT=$(grep -c '^\[SCRAPE\] Metadata scrape complete: ' "$PHASE_LOG")
SCRAPE_ERRORS=$(grep -c '^\[SCRAPE\] WARNING: \|^\[SCRAPE\] ERROR: ' "$PHASE_LOG")

TOTAL_SCRAPED=$((CONVERT_SCRAPED + SCRAPED_COUNT))

# =============================================================================
# Fix permissions and restart MiniDLNA so new files are indexed
# Runs after Phase 4 (not before) so scrape-created metadata/poster files
# also get normalized to minidlna:minidlna 775, not just the earlier phases.
# =============================================================================
log PIPELINE "Fixing permissions on $SOURCE_DIR"
chmod -R 775 "$SOURCE_DIR"
chown -R minidlna:minidlna "$SOURCE_DIR"
log PIPELINE "Restarting MiniDLNA"
systemctl restart minidlna

# =============================================================================
# Final summary
# =============================================================================
PIPELINE_END=$(date +%s)
ELAPSED=$((PIPELINE_END - PIPELINE_START))
ELAPSED_FMT=$(printf '%dm%02ds' $((ELAPSED / 60)) $((ELAPSED % 60)))
TOTAL_ERRORS=$((PROMOTE_ERRORS + CONVERT_ERRORS + SUBTITLE_ERRORS + SCRAPE_ERRORS))

if [ "$TOTAL_ERRORS" -gt 0 ]; then
    log PIPELINE "Pipeline complete WITH ERRORS | promoted=${PROMOTED_COUNT}(+${PROMOTED_SUBS} subs) converted=${CONVERTED_COUNT} subtitled=${SUBTITLE_COUNT} scraped=${TOTAL_SCRAPED} | errors=${TOTAL_ERRORS} | elapsed=${ELAPSED_FMT}"
else
    log PIPELINE "Pipeline complete | promoted=${PROMOTED_COUNT}(+${PROMOTED_SUBS} subs) converted=${CONVERTED_COUNT} subtitled=${SUBTITLE_COUNT} scraped=${TOTAL_SCRAPED} | elapsed=${ELAPSED_FMT}"
fi
