#!/bin/bash
# =============================================================================
# mkv-subtitles.sh — Phase 3
# Converts standalone SRT files in SOURCE_DIR to VTT, but only when a
# matching MP4 already exists. MKVs that were just converted will have had
# their subtitles handled inline by mkv-convert.sh already.
# Location: /usr/local/bin/mkv-subtitles.sh
#
# Usage: mkv-subtitles.sh TARGET_FILE
#   TARGET_FILE — if it is an .srt file, process it first then do a full scan.
#                 Pass empty "" for a full scan only.
# =============================================================================

source /usr/local/bin/mkv-common.sh || { echo "[SUBTITLES] ERROR: cannot source mkv-common.sh"; exit 1; }

TARGET_FILE="${1:-}"

log SUBTITLES "Checking for standalone SRT files to convert..."

# Build work list: target first (if SRT), then everything else in SOURCE_DIR
if [ -n "$TARGET_FILE" ] && [[ "${TARGET_FILE,,}" == *.srt ]]; then
    mapfile -d '' srt_files < <(
        printf '%s\0' "$TARGET_FILE"
        find "$SOURCE_DIR" -maxdepth 1 -iname "*.srt" ! -path "$TARGET_FILE" -print0
    )
else
    mapfile -d '' srt_files < <(find "$SOURCE_DIR" -maxdepth 1 -iname "*.srt" -print0)
fi

converted_any=false

for sub_src in "${srt_files[@]}"; do
    [ -e "$sub_src" ] || continue

    filename=$(basename "$sub_src")
    base_name="${filename%.*}"

    # Only convert if the matching MP4 is already in SOURCE_DIR
    if [ ! -f "$SOURCE_DIR/$base_name.mp4" ]; then
        log SUBTITLES "SKIP: No matching MP4 for $filename"
        continue
    fi

    vtt_dest="$SOURCE_DIR/$base_name.vtt"

    if [ -f "$vtt_dest" ]; then
        continue
    fi

    log SUBTITLES "Converting: $filename → $base_name.vtt"
    ffmpeg -hide_banner -y -i "$sub_src" "$vtt_dest" 2>/dev/null

    if [ $? -eq 0 ] && [ -s "$vtt_dest" ]; then
        log SUBTITLES "Done: $base_name.vtt"
        converted_any=true
    else
        log SUBTITLES "ERROR: Failed to convert $filename to VTT"
        rm -f -- "$vtt_dest"
    fi
done

[ "$converted_any" = false ] && log SUBTITLES "All standalone subtitles are up to date"