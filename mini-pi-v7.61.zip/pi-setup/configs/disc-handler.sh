#!/bin/bash
set -u

DEVICE="/dev/sr0"
MUSIC_DIR="/var/lib/minidlna/Music"
VIDEO_DIR="/var/lib/minidlna/Video"
LOCK_DIR="/tmp/disc-handler.lock.d"
SCRATCH_DIR="/var/lib/minidlna/.tmp_rip"

# Initialise WORK_DIR and MOUNT_DIR as empty so the cleanup trap never errors on unset variables
WORK_DIR=""
MOUNT_DIR=""

log() { logger -t disc-handler "$*"; echo "[DISC-HANDLER] $*" >&2; }

# ---------------------------------------------------------------------------
# MOVIE TITLE LOOKUP (best-effort, no API key)
#
# Strategy: get the main feature's runtime via lsdvd, clean up the disc
# label into a search string, query Wikipedia's opensearch API for
# candidate pages, then pick whichever candidate's infobox runtime is
# closest to the ripped runtime. If nothing matches within tolerance, or
# either jq or lsdvd is missing, this is skipped entirely and the existing
# disc-label-derived $TITLE is used unchanged — this never blocks or fails
# the rip itself.
# ---------------------------------------------------------------------------
TITLE_LOOKUP_RUNTIME_TOLERANCE_MIN=8

get_main_feature_runtime_minutes() {
    local vts_num="$1"
    local video_ts_dir="$2"

    command -v lsdvd >/dev/null 2>&1 || { log "Title lookup: lsdvd not installed — skipping"; return 1; }

    # lsdvd expects the directory containing VIDEO_TS, not VIDEO_TS itself.
    local lsdvd_target
    lsdvd_target=$(dirname "$video_ts_dir")

    local title_num_decimal
    title_num_decimal=$((10#$vts_num))

    # lsdvd -q prints one summary line per title, e.g.:
    #   Title: 01, Length: 02:11:36.633 Chapters: 33, Cells: 49, ...
    local length_str
    length_str=$(lsdvd -q "$lsdvd_target" 2>/dev/null \
        | grep -A0 "^Title: $(printf '%02d' "$title_num_decimal")," \
        | grep -oP 'Length:\s*\K[0-9]{2}:[0-9]{2}:[0-9]{2}')

    if [ -z "$length_str" ]; then
        log "Title lookup: could not determine runtime via lsdvd for title $vts_num — skipping"
        return 1
    fi

    local h m s
    IFS=':' read -r h m s <<< "$length_str"
    h=$((10#$h)); m=$((10#$m)); s=$((10#$s))
    echo $(( h * 60 + m + (s >= 30 ? 1 : 0) ))
}

clean_label_for_search() {
    local raw="$1"
    echo "$raw" \
        | sed -E 's/_/ /g' \
        | sed -E 's/\b(WS|FS|DISC[0-9]*|DVD|R[0-9]|PAL|NTSC|SE|SPECIAL EDITION)\b//gi' \
        | sed -E 's/[[:space:]]+/ /g' \
        | sed -E 's/^[[:space:]]*//;s/[[:space:]]*$//'
}

wikipedia_search_candidates() {
    local query="$1"
    local encoded
    encoded=$(jq -rn --arg q "$query" '$q|@uri')
    curl -s --max-time 10 \
        "https://en.wikipedia.org/w/api.php?action=opensearch&search=${encoded}&limit=5&namespace=0&format=json" \
        | jq -r '.[1][]?' 2>/dev/null
}

wikipedia_runtime_minutes() {
    local page_title="$1"
    local encoded
    encoded=$(jq -rn --arg q "$page_title" '$q|@uri')

    local extract
    extract=$(curl -s --max-time 10 \
        "https://en.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&titles=${encoded}&format=json" \
        | jq -r '.query.pages[]?.extract // empty' 2>/dev/null)
    [ -z "$extract" ] && return 1

    local mins
    mins=$(echo "$extract" | grep -oP '(?i)running time[^0-9]{0,20}\K[0-9]{2,3}(?=\s*min)' | head -1)
    [ -z "$mins" ] && mins=$(echo "$extract" | grep -oP '\b[0-9]{2,3}(?=\s*minutes\b)' | head -1)
    [ -z "$mins" ] && return 1
    echo "$mins"
}

lookup_movie_title() {
    local disc_title_fallback="$1"
    local vts_num="$2"
    local video_ts_dir="$3"

    command -v jq >/dev/null 2>&1 || { log "Title lookup: jq not installed — skipping"; return 1; }

    local ripped_runtime
    ripped_runtime=$(get_main_feature_runtime_minutes "$vts_num" "$video_ts_dir") || return 1
    log "Title lookup: ripped feature runtime ${ripped_runtime} min"

    local search_query
    search_query=$(clean_label_for_search "$disc_title_fallback")
    [ -z "$search_query" ] && return 1
    log "Title lookup: searching Wikipedia for '$search_query'"

    local candidates
    mapfile -t candidates < <(wikipedia_search_candidates "$search_query")
    if [ "${#candidates[@]}" -eq 0 ]; then
        log "Title lookup: no Wikipedia candidates found"
        return 1
    fi

    local best_title="" best_diff=999 candidate
    for candidate in "${candidates[@]}"; do
        local cand_runtime
        cand_runtime=$(wikipedia_runtime_minutes "$candidate") || continue
        local diff=$(( cand_runtime > ripped_runtime ? cand_runtime - ripped_runtime : ripped_runtime - cand_runtime ))
        log "Title lookup: candidate '$candidate' runtime ${cand_runtime} min (diff ${diff})"
        if [ "$diff" -lt "$best_diff" ]; then
            best_diff="$diff"
            best_title="$candidate"
        fi
    done

    if [ -n "$best_title" ] && [ "$best_diff" -le "$TITLE_LOOKUP_RUNTIME_TOLERANCE_MIN" ]; then
        log "Title lookup: matched '$best_title' (runtime diff ${best_diff} min)"
        echo "$best_title" | tr -cd '[:alnum:] _-' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'
        return 0
    fi

    log "Title lookup: no candidate within ${TITLE_LOOKUP_RUNTIME_TOLERANCE_MIN} min tolerance — keeping disc label"
    return 1
}

# ---------------------------------------------------------------------------
# PHASE 1 — LOCK ACQUISITION
# Must happen before any scratch-dir cleanup below: a second, blocked
# instance must never get far enough to touch scratch space that belongs
# to the instance already holding the lock.
# ---------------------------------------------------------------------------
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    OLD_PID=""
    [ -f "$LOCK_DIR/pid" ] && OLD_PID=$(cat "$LOCK_DIR/pid" 2>/dev/null)
    if [ -n "$OLD_PID" ] && ! kill -0 "$OLD_PID" 2>/dev/null; then
        log "Stale lock from dead process $OLD_PID — removing and retrying"
        rm -rf -- "$LOCK_DIR"
        if ! mkdir "$LOCK_DIR" 2>/dev/null; then
            log "Already running — exiting"
            exit 1
        fi
    else
        log "Already running (pid ${OLD_PID:-unknown}) — exiting"
        exit 1
    fi
fi
echo $$ > "$LOCK_DIR/pid"

# ---------------------------------------------------------------------------
# PHASE 2 — PRE-RIP SCRATCH CLEANUP (now safe: we hold the lock)
# ---------------------------------------------------------------------------
pre_cleanup() {
    if [ -d "$SCRATCH_DIR" ]; then
        find "$SCRATCH_DIR" -mindepth 1 -maxdepth 1 -type d -name "vobcopy-*" -exec rm -rf -- {} + 2>/dev/null
        log "Pre-cleanup: cleared any stale scratch directories"
    fi
}

pre_cleanup
mkdir -p "$SCRATCH_DIR"

# ---------------------------------------------------------------------------
# PHASE 3 — MAIN CLEANUP TRAP
# Handles lock removal, scratch dir cleanup, mount cleanup, and eject.
# Eject is intentionally kept here as a safety net for error/early-exit paths.
# For the normal DVD path, eject_disc() is called explicitly after vobcopy
# so the drive is freed before the long ffmpeg concatenation runs.
# ---------------------------------------------------------------------------
cleanup() {
    rm -rf -- "$LOCK_DIR"
    if [ -n "$WORK_DIR" ] && [ -d "$WORK_DIR" ]; then
        rm -rf -- "$WORK_DIR"
    fi
    # Unmount DVD if still mounted
    if [ -n "$MOUNT_DIR" ] && mountpoint -q "$MOUNT_DIR" 2>/dev/null; then
        umount "$MOUNT_DIR"
        rmdir "$MOUNT_DIR" 2>/dev/null
    fi
    # Eject if not already ejected
    eject "$DEVICE" 2>/dev/null
}
trap cleanup EXIT

# Eject the disc and unmount as soon as we no longer need the drive.
# Called explicitly after vobcopy finishes so the drive is freed before
# the ffmpeg concatenation (which can take several minutes).
eject_disc() {
    if [ -n "$MOUNT_DIR" ] && mountpoint -q "$MOUNT_DIR" 2>/dev/null; then
        umount "$MOUNT_DIR"
        rmdir "$MOUNT_DIR" 2>/dev/null
        MOUNT_DIR=""
    fi
    eject "$DEVICE" 2>/dev/null
    log "Disc ejected"
}

# ---------------------------------------------------------------------------
# Give udev a moment to finish settling before we probe the drive
# ---------------------------------------------------------------------------
sleep 5

if [ ! -b "$DEVICE" ]; then
    log "ERROR: $DEVICE not present"
    exit 1
fi

# ---------------------------------------------------------------------------
# DISC DETECTION
# ---------------------------------------------------------------------------
FS_TYPE=$(blkid -o value -s TYPE "$DEVICE" 2>/dev/null)

if [ -z "$FS_TYPE" ]; then
    DISC_TYPE="audio"
elif [[ "$FS_TYPE" == "udf" || "$FS_TYPE" == "iso9660" ]]; then
    DISC_TYPE="dvd"
else
    log "ERROR: Unrecognised filesystem type '$FS_TYPE' — ejecting"
    exit 1
fi

log "Detected disc type: $DISC_TYPE"

# ---------------------------------------------------------------------------
# RIP
# ---------------------------------------------------------------------------
case "$DISC_TYPE" in

    audio)
        log "Starting audio CD rip with abcde"

        # Snapshot top-level folders in MUSIC_DIR before the rip, so we can
        # reliably find whichever folder abcde just created — rather than
        # guessing its exact sanitised name, which varies by abcde version.
        mapfile -t PRE_RIP_DIRS < <(find "$MUSIC_DIR" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort)

        # Capture abcde's FULL output to a per-rip debug log (not just the
        # filtered syslog line) so a failed/partial CDDB lookup is fully
        # diagnosable after the fact. The filtered grep below remains for
        # live syslog visibility, but is no longer the only record kept —
        # "CDDB unavailable." (abcde's actual unmatched-disc message) does
        # not match any pattern in the filter, so without this full capture
        # a failed lookup was invisible in the logs entirely.
        ABCDE_DEBUG_LOG="$SCRATCH_DIR/abcde-$(date +%Y%m%d_%H%M%S).log"
        abcde -d "$DEVICE" -N > "$ABCDE_DEBUG_LOG" 2>&1
        ABCDE_STATUS=$?

        tr -d '\r' < "$ABCDE_DEBUG_LOG" \
            | grep -E 'No lookup|Selected:|Grabbing entire|CDDB unavailable|Unknown Artist|[Ee]rror|^abcde:' \
            | logger -t disc-handler-abcde

        if [ "$ABCDE_STATUS" -eq 0 ]; then
            chown -R pi:minidlna "$MUSIC_DIR"
            chmod -R 775 "$MUSIC_DIR"
            log "Audio CD rip complete"

            # Find the folder(s) that didn't exist before this rip.
            mapfile -t POST_RIP_DIRS < <(find "$MUSIC_DIR" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort)
            mapfile -t NEW_DIRS < <(comm -13 \
                <(printf '%s\n' "${PRE_RIP_DIRS[@]}") \
                <(printf '%s\n' "${POST_RIP_DIRS[@]}"))

            # Among the newly-created folder(s), flag any whose name looks
            # like abcde's generic "unidentified disc" fallback (contains
            # "Unknown" — covers "Unknown_Artist-Unknown_Album",
            # "Unknown_Album", "Unknown Artist", etc across abcde versions).
            NEW_DIR=""
            for d in "${NEW_DIRS[@]:-}"; do
                [ -z "$d" ] && continue
                case "$(basename "$d")" in
                    *Unknown*) NEW_DIR="$d" ;;
                esac
            done

            if [ -n "$NEW_DIR" ]; then
                # Rename to a timestamp-unique folder immediately so a
                # second unidentified disc can never collide with this one.
                UNIQUE_DIR="$MUSIC_DIR/Unknown_Album_$(date +%Y%m%d_%H%M%S)"
                if mv "$NEW_DIR" "$UNIQUE_DIR" 2>/tmp/mv-error.log; then
                    log "Warning: CD could not be identified via CDDB — moved to $(basename "$UNIQUE_DIR") to avoid overwriting future unidentified rips. See $ABCDE_DEBUG_LOG for details."
                else
                    log "ERROR: CD unidentified AND could not rename $NEW_DIR — next unidentified rip MAY OVERWRITE this one. mv said: $(cat /tmp/mv-error.log 2>/dev/null)"
                fi
            fi
        else
            log "ERROR: abcde rip failed (exit $ABCDE_STATUS) — see $ABCDE_DEBUG_LOG"
        fi
        ;;

    dvd)
        # Mount the disc read-only so vobcopy can access it
        MOUNT_DIR=$(mktemp -d /tmp/dvd-mount-XXXXXX)
        log "Mounting DVD at $MOUNT_DIR"
        if ! mount -o ro "$DEVICE" "$MOUNT_DIR" 2>/dev/null; then
            log "ERROR: Could not mount DVD — check libdvdcss2 is installed"
            rmdir "$MOUNT_DIR" 2>/dev/null
            MOUNT_DIR=""
            exit 1
        fi

        # Build a safe title from the disc label, falling back to a timestamp
        TITLE=$(blkid -o value -s LABEL "$DEVICE" 2>/dev/null)
        TITLE=$(echo "$TITLE" | tr -cd '[:alnum:] _-' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        [ -z "$TITLE" ] && TITLE="DVD_$(date +%Y%m%d_%H%M%S)"

        # Create a unique scratch directory for this rip
        WORK_DIR=$(mktemp -d "$SCRATCH_DIR/vobcopy-XXXXXX")
        log "Starting DVD rip with vobcopy: title='$TITLE'"

        vobcopy -m -l -F 64 -i "$MOUNT_DIR" -o "$WORK_DIR" 2>&1 | tr -d '\r' | grep -E '^\[Info\]|^\[Error\]|^\[Warning\]' | logger -t disc-handler-vobcopy
        VOBCOPY_STATUS="${PIPESTATUS[0]}"

        # Eject the disc now — no longer needed, ffmpeg works from scratch dir
        eject_disc

        if [ "$VOBCOPY_STATUS" -eq 0 ]; then

            # Locate the VIDEO_TS directory vobcopy created
            VIDEO_TS_DIR=$(find "$WORK_DIR" -type d -name "VIDEO_TS" 2>/dev/null | head -1)
            if [ -z "$VIDEO_TS_DIR" ]; then
                log "ERROR: vobcopy succeeded but no VIDEO_TS directory found in $WORK_DIR"
                exit 1
            fi

            # Find the main feature VTS — the one with the most VOB parts
            # (VTS_XX_0.VOB is the menu; main feature starts at VTS_XX_1.VOB)
            MAIN_VTS=$(ls "$VIDEO_TS_DIR"/VTS_*_1.VOB 2>/dev/null | \
                sed 's/_1\.VOB$//' | \
                awk -F'VTS_' '{
                    cmd="ls " $0 "_*.VOB 2>/dev/null | wc -l"
                    cmd | getline count
                    close(cmd)
                    print count, $0
                }' | sort -rn | head -1 | awk '{print $2}')

            if [ -z "$MAIN_VTS" ]; then
                log "ERROR: Could not identify main feature VTS in $VIDEO_TS_DIR"
                exit 1
            fi

            VTS_NUM=$(basename "$MAIN_VTS" | grep -oP '(?<=VTS_)\d+')
            log "Main feature identified as VTS_${VTS_NUM}"

            # Best-effort movie title lookup via runtime + disc label. If this
            # fails or isn't confident, $TITLE is left exactly as it was
            # (disc-label-derived) — see lookup_movie_title() near the top.
            LOOKUP_TITLE=$(lookup_movie_title "$TITLE" "$VTS_NUM" "$VIDEO_TS_DIR")
            if [ -n "$LOOKUP_TITLE" ]; then
                log "Using looked-up title '$LOOKUP_TITLE' instead of disc label '$TITLE'"
                TITLE="$LOOKUP_TITLE"
            fi

            # Remove any stale destination file for the final title before writing
            if [ -f "$VIDEO_DIR/$TITLE.vob" ]; then
                log "Warning: $TITLE.vob already exists — removing before rip"
                rm -f "$VIDEO_DIR/$TITLE.vob"
            fi

            # Collect VOB parts (parts 1 onwards, in order, skip _0 menu)
            mapfile -t VOB_PARTS < <(ls "$VIDEO_TS_DIR/VTS_${VTS_NUM}_"[1-9]*.VOB 2>/dev/null | sort)
            log "Joining ${#VOB_PARTS[@]} VOB parts into $VIDEO_DIR/$TITLE.vob"

            # cat is the correct tool here — VOB parts are designed to be
            # concatenated at the byte level per the DVD spec. ffmpeg's concat
            # demuxer chokes on the nav packs at the start of each part.
            cat "${VOB_PARTS[@]}" > "$VIDEO_DIR/$TITLE.vob"

            if [ -s "$VIDEO_DIR/$TITLE.vob" ]; then
                chown pi:minidlna "$VIDEO_DIR/$TITLE.vob"
                chmod 664 "$VIDEO_DIR/$TITLE.vob"
                FINAL_SIZE=$(du -h "$VIDEO_DIR/$TITLE.vob" | cut -f1)
                log "VOB join complete: $VIDEO_DIR/$TITLE.vob ($FINAL_SIZE)"
            else
                log "ERROR: VOB join failed for $TITLE"
                rm -f -- "$VIDEO_DIR/$TITLE.vob"
            fi

        else
            log "ERROR: vobcopy rip failed"
        fi
        # WORK_DIR removed by cleanup trap on EXIT
        ;;

esac

exit 0