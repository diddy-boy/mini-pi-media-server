#!/bin/bash
# =============================================================================
# mkv-watcher.sh — inotify-based watcher
# Triggers the MKV pipeline when files land in SOURCE_DIR or its subfolders.
# Location: /usr/local/bin/mkv-watcher.sh
# =============================================================================

source /usr/local/bin/mkv-common.sh || { echo "[WATCHER] ERROR: cannot source mkv-common.sh"; exit 1; }

CONVERT_SCRIPT="/usr/local/bin/mkv-2-mp4.sh"
STABILITY_WAIT=30
STABILITY_PASSES=3
OPEN_FILE_TIMEOUT=300
SWEEP_INTERVAL=300

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | logger -t mkv-pipeline; }

# Pass the specific file to the orchestrator.
# All output is piped through logger which writes to the systemd journal
# line by line under the identifier mkv-pipeline. This applies to all call
# sites — boot sweep (backgrounded), periodic sweep (backgrounded), and the
# inotify loop (foreground) — so all pipeline output appears consistently in:
#   journalctl -t mkv-pipeline -f
# The -s flag is deliberately omitted to prevent duplicate output: without -s
# logger does not echo to stderr, so the service stdout does not get a second
# copy of every line tagged as bash.
run_converter() {
    local target_file="$1"
    bash "$CONVERT_SCRIPT" "$target_file" 2>&1 | grep -vE \
        "No new|Skipping protected|No video files found|Checking for standalone|Restarting MiniDLNA|No MKV/VOB files|All standalone|No promoted" | \
        logger -t mkv-pipeline
}

is_file_open() {
    lsof "$1" > /dev/null 2>&1
}

is_file_valid() {
    local file="$1"
    if [[ "$file" == *.srt ]]; then
        [ -s "$file" ] && return 0 || return 1
    fi
    ffprobe -v error -select_streams v:0 \
        -show_entries stream=codec_name -of csv=p=0 "$file" > /dev/null 2>&1
}

wait_for_file_ready() {
    local file="$1"
    local elapsed=0
    local stable_count=0
    local last_size=-1

    while true; do
        [ -f "$file" ] || return 1

        if is_file_open "$file"; then
            stable_count=0
            last_size=-1
            sleep "$STABILITY_WAIT"
            elapsed=$((elapsed + STABILITY_WAIT))
            [ "$elapsed" -ge "$OPEN_FILE_TIMEOUT" ] && return 1
            continue
        fi

        local current_size
        current_size=$(stat -c%s "$file" 2>/dev/null) || return 1

        if [ "$current_size" -eq "$last_size" ]; then
            stable_count=$((stable_count + 1))
        else
            stable_count=0
        fi
        last_size="$current_size"

        if [ "$stable_count" -ge "$STABILITY_PASSES" ]; then
            is_file_valid "$file" && return 0 || return 1
        fi

        sleep "$STABILITY_WAIT"
        elapsed=$((elapsed + STABILITY_WAIT))
    done
}

log "*** MKV watcher started — monitoring: $SOURCE_DIR ***"

# Boot-time sweep: if MKV/SRT files already exist, kick off a full scan.
# Backgrounded so the inotify loop starts immediately; logger in run_converter
# ensures output still reaches the journal line by line.
shopt -s nocaseglob
if compgen -G "$SOURCE_DIR/*.mkv" > /dev/null 2>&1 || \
   compgen -G "$SOURCE_DIR/*.srt" > /dev/null 2>&1 || \
   compgen -G "$SOURCE_DIR/*.vob" > /dev/null 2>&1; then
    shopt -u nocaseglob
    log "Found existing MKV/SRT/VOB files — starting boot-time sweep"
    run_converter "" &
else
    shopt -u nocaseglob
fi

# =============================================================================
# Periodic sweep — catches anything the inotify loop may have queued/skipped
# =============================================================================
(
    while true; do
        sleep "$SWEEP_INTERVAL"

        # Skip if pipeline is already running
        [ -d "$LOCK_DIR" ] && continue

        for subdir in "$SOURCE_DIR"/*/; do
            [ -d "$subdir" ] || continue

            # Skip protected folders (defined in mkv-common.sh PROTECTED_DIRS)
            is_protected_dir "$subdir" && continue

            while IFS= read -r -d '' f; do
                [[ "$(basename "$f")" == ._* ]] && continue
                if ! is_file_open "$f"; then
                    log "Sweep: triggering pipeline for $(basename "$f")"
                    run_converter "$f" &
                    break 2
                fi
            done < <(find "$subdir" -maxdepth 1 -type f \
                \( -iname "*.mkv" -o -iname "*.mp4" -o -iname "*.srt" -o -iname "*.vob" \) -print0)
        done
    done
) &

# =============================================================================
# inotify event loop
# =============================================================================
inotifywait -q -m -r \
    -e close_write -e moved_to \
    --include '\.([mM][kK][vV]|[mM][pP]4|[sS][rR][tT]|[vV][oO][bB])$' \
    --format '%w%f' \
    "$SOURCE_DIR" |
while IFS= read -r filepath; do
    filename=$(basename "$filepath")

    # Ignore macOS metadata files, pipeline sentinels, and incomplete downloads
    [[ "$filename" == ._* ]]          && continue
    [[ "$filename" == CONVERTING_* ]] && continue
    [[ "$filename" == PROMOTING_* ]]  && continue
    [[ "$filename" == *.part ]]       && continue

    # Skip if pipeline is already running — sweep will catch it
    if [ -d "$LOCK_DIR" ]; then
        log "Pipeline busy — queued (sweep will catch): $filename"
        continue
    fi

    if wait_for_file_ready "$filepath"; then
        if [[ "$filename" == *.srt ]]; then
            log "Processing subtitle arrival: $filename"
        else
            log "Processing arrival: $filename"
        fi
        run_converter "$filepath"
    else
        log "WARNING: $filename did not become stable/valid — skipping"
    fi
done
