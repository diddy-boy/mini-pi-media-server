#!/bin/bash
# =============================================================================
# mkv-scrape.sh — Phase 4
# Runs the metadata scraper against promoted MP4s that skipped conversion.
# (MKVs that were converted have already been scraped inline by mkv-convert.sh)
# Location: /usr/local/bin/mkv-scrape.sh
#
# Usage: mkv-scrape.sh PROMOTED_LIST
#   PROMOTED_LIST — path to the temp file written by mkv-promote.sh containing
#                   one absolute MP4 path per line. Pass empty "" to skip.
# =============================================================================

source /usr/local/bin/mkv-common.sh || { echo "[SCRAPE] ERROR: cannot source mkv-common.sh"; exit 1; }

PROMOTED_LIST="${1:-}"

if [ -z "$PROMOTED_LIST" ] || [ ! -s "$PROMOTED_LIST" ]; then
    log SCRAPE "No promoted MP4s to scrape"
    exit 0
fi

while IFS= read -r mp4_path; do
    [ -z "$mp4_path" ] && continue
    if [ -f "$mp4_path" ]; then
        log SCRAPE "Fetching metadata: $(basename "$mp4_path")"
        # shellcheck disable=SC2086
        $SCRAPER --file "$mp4_path" \
            && log SCRAPE "Metadata scrape complete: $(basename "$mp4_path")" \
            || log SCRAPE "WARNING: Metadata scrape failed: $(basename "$mp4_path")"
    else
        log SCRAPE "WARNING: Promoted MP4 no longer exists: $mp4_path"
    fi
done < "$PROMOTED_LIST"
