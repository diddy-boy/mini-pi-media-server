#!/bin/bash
# =============================================================================
# mkv-convert.sh — Phase 2
# Converts MKV/VOB files in SOURCE_DIR to MP4 using HW encoder with SW fallback.
# Explicitly maps video + first English-tagged audio track (falling back to
# the first audio track if untagged) and drops subtitle/attachment streams,
# for both MKV and VOB sources. VOB skips the file (with a log warning) if
# no audio track is found at all; MKV proceeds video-only in that case.
# Calls scraper inline after each successful conversion.
# Converts matching SRT → VTT inline after each successful conversion.
# Location: /usr/local/bin/mkv-convert.sh
#
# Usage: mkv-convert.sh TARGET_FILE
#   TARGET_FILE — specific MKV/VOB to process first (may be empty "")
#                 A full scan of SOURCE_DIR always follows; already-converted
#                 files are skipped so no work is duplicated.
# =============================================================================

source /usr/local/bin/mkv-common.sh || { echo "[CONVERT] ERROR: cannot source mkv-common.sh"; exit 1; }

TARGET_FILE="${1:-}"

detect_hw_accel
log CONVERT "Hardware acceleration: $HW_ACCEL_AVAILABLE"

# Build the work list: target first (if MKV/VOB), then everything else in SOURCE_DIR
if [ -n "$TARGET_FILE" ] && [[ "${TARGET_FILE,,}" == *.mkv || "${TARGET_FILE,,}" == *.vob ]]; then
    mapfile -d '' mkv_files < <(
        printf '%s\0' "$TARGET_FILE"
        find "$SOURCE_DIR" -maxdepth 1 \( -iname "*.mkv" -o -iname "*.vob" \) ! -name "._*" ! -path "$TARGET_FILE" -print0
    )
else
    mapfile -d '' mkv_files < <(find "$SOURCE_DIR" -maxdepth 1 \( -iname "*.mkv" -o -iname "*.vob" \) ! -name "._*" -print0)
fi

if [ "${#mkv_files[@]}" -eq 0 ] || { [ "${#mkv_files[@]}" -eq 1 ] && [ -z "${mkv_files[0]}" ]; }; then
    log CONVERT "No MKV/VOB files found to convert"
    exit 0
fi

# ------------------------------------------------------------------
# Queue ordering: push 10/12-bit high-bit-depth files to the end.
# A batch may contain a mix of quick 8-bit remuxes/encodes and slow
# high-bit-depth SW-only encodes (see FORCE_SW below); without this,
# a single multi-hour 10-bit file at the front of the list would
# block everything else behind it. This is a stable partition — order
# is preserved within each group, so target-file-first priority
# (set above) still holds as long as the target itself isn't 10/12-bit.
# pix_fmt is cached here and reused in the main loop below so each
# file is only probed once for this value.
# ------------------------------------------------------------------
declare -A PIXFMT_CACHE=()
declare -a fast_files=() slow_files=()
for f in "${mkv_files[@]}"; do
    [ -e "$f" ] || continue
    pf=$(get_video_pixfmt "$f")
    PIXFMT_CACHE["$f"]="$pf"
    if [[ "$pf" == *p10* || "$pf" == *p12* ]]; then
        slow_files+=("$f")
    else
        fast_files+=("$f")
    fi
done
if [ "${#slow_files[@]}" -gt 0 ] && [ "${#fast_files[@]}" -gt 0 ]; then
    log CONVERT "Queue reordered: ${#fast_files[@]} quick file(s) first, ${#slow_files[@]} high-bit-depth file(s) deferred to the end"
fi
mkv_files=("${fast_files[@]}" "${slow_files[@]}")

for input in "${mkv_files[@]}"; do
    [ -e "$input" ] || continue
    [[ "$(basename "$input")" == ._* ]] && continue

    src_filename=$(basename "$input")
    src_ext="${src_filename##*.}"
    base_name="${src_filename%.*}"
    output="$SOURCE_DIR/$base_name.mp4"
    working_file="$SOURCE_DIR/CONVERTING_${base_name}.mp4"

    # Clean up any stale working file from a previous crash
    [ -f "$working_file" ] && rm -f -- "$working_file"

    if [ -f "$output" ] && [ -s "$output" ]; then
        log CONVERT "SKIP: $base_name.mp4 already exists"
        continue
    fi

    # ------------------------------------------------------------------
    # Probe the source
    # ------------------------------------------------------------------
    VIDEO_CODEC=$(get_video_codec "$input")
    VIDEO_PROFILE=$(get_video_profile "$input")
    AUDIO_CODEC=$(get_audio_codec "$input")
    PIX_FMT="${PIXFMT_CACHE[$input]:-$(get_video_pixfmt "$input")}"
    SOURCE_BITRATE=$(get_video_bitrate "$input")

    log CONVERT "Probed: $base_name.$src_ext | video=$VIDEO_CODEC profile=${VIDEO_PROFILE:-unknown} audio=$AUDIO_CODEC pix_fmt=$PIX_FMT bitrate=${SOURCE_BITRATE:-unknown}"

    # ------------------------------------------------------------------
    # High bit-depth detection
    # H.265 10-bit and 12-bit content cannot use the HW encoder (h264_v4l2m2m)
    # or baseline libx264 directly. Force SW encode with yuv420p downconversion.
    # Note: on a Pi Zero 2W this will be very slow for feature-length content.
    # ------------------------------------------------------------------
    FORCE_SW=false
    if [[ "$PIX_FMT" == *p10* || "$PIX_FMT" == *p12* ]]; then
        log CONVERT "High bit-depth content detected ($PIX_FMT) — forcing SW encode with yuv420p downconvert: $base_name.$src_ext"
        log CONVERT "WARNING: SW encode of high bit-depth content is slow — this may take several hours on low-power hardware"
        FORCE_SW=true
    fi

    # ------------------------------------------------------------------
    # Explicit stream mapping (video + English audio, subtitles/attachments
    # excluded) for both VOB and MKV sources.
    #
    # VOB: often carries multiple language tracks — behavior unchanged.
    #
    # MKV: relying on ffmpeg's default stream selection is risky. MKV rips
    # (H.265 releases especially) frequently embed PGS/ASS subtitle tracks
    # and font attachments; MP4's default subtitle codec (mov_text) can't
    # take bitmap PGS subs, which fails the whole conversion. They may also
    # carry multiple audio tracks (dual audio, commentary). So MKV now gets
    # the same explicit -map treatment: video + best-guess English audio,
    # with -sn to drop subtitle streams entirely (handled separately via
    # matching .srt files, inline below / mkv-subtitles.sh).
    #
    # get_english_audio_index falls back to the first audio stream when no
    # language tag is found (the common case for single-track English
    # rips), so this is a no-op for those files. It only returns empty if
    # the file has no audio stream at all.
    # ------------------------------------------------------------------
    declare -a MAP_ARGS=()
    ENG_AUDIO_IDX=$(get_english_audio_index "$input")
    if [ -z "$ENG_AUDIO_IDX" ]; then
        if [[ "${src_ext,,}" == "vob" ]]; then
            log CONVERT "ERROR: No English audio track found — skipping $base_name.$src_ext"
            continue
        else
            log CONVERT "WARNING: No audio stream found — proceeding video-only: $base_name.$src_ext"
            MAP_ARGS=(-map 0:v:0 -sn)
        fi
    else
        log CONVERT "Selected audio track: stream $ENG_AUDIO_IDX in $base_name.$src_ext"
        MAP_ARGS=(-map 0:v:0 -map "0:$ENG_AUDIO_IDX" -sn)
    fi

    # ------------------------------------------------------------------
    # Build ffmpeg argument arrays (no word-splitting risk)
    # ------------------------------------------------------------------
    declare -a video_args audio_args
    HW_FOR_BUILD="$HW_ACCEL_AVAILABLE"
    [ "$FORCE_SW" = true ] && HW_FOR_BUILD=false
    build_video_args video_args "$VIDEO_CODEC" "$VIDEO_PROFILE" "$HW_FOR_BUILD"
    VIDEO_IS_COPY=$?   # 0 = remux/copy, 1 = encode required
    build_audio_args audio_args "$AUDIO_CODEC"

    if [ "$VIDEO_IS_COPY" -eq 0 ]; then
        log CONVERT "Remuxing (H264 stream copy): $base_name.$src_ext"
    else
        # Adaptive bitrate: clamp source bitrate to 70%, floor 1.5 Mbps, ceil 4 Mbps
        # Skip adaptive bitrate logic if FORCE_SW — SW path handles its own args
        if [ "$FORCE_SW" = true ]; then
            log CONVERT "Encoding (SW $ENCODER_SW high-bit-depth downconvert): $base_name.$src_ext"
        elif [ "$HW_ACCEL_AVAILABLE" = true ] && [[ "$SOURCE_BITRATE" =~ ^[0-9]+$ ]]; then
            ADAPTIVE=$(( SOURCE_BITRATE * 70 / 100 ))
            [ "$ADAPTIVE" -lt 1500000 ] && ADAPTIVE=1500000
            [ "$ADAPTIVE" -gt 4000000 ] && ADAPTIVE=4000000
            ADAPTIVE_MAX=$(( ADAPTIVE * 150 / 100 ))
            ADAPTIVE_BUF=$(( ADAPTIVE_MAX * 2 ))
            video_args=(
                -c:v "$ENCODER_HW"
                -pix_fmt yuv420p
                -b:v "$ADAPTIVE"
                -maxrate "$ADAPTIVE_MAX"
                -bufsize "$ADAPTIVE_BUF"
                -g "$HW_GOP"
                -keyint_min "$HW_KEYINT_MIN"
                -movflags +faststart
            )
            log CONVERT "Encoding (HW $ENCODER_HW adaptive): $base_name.$src_ext | b:v=${ADAPTIVE} maxrate=${ADAPTIVE_MAX}"
        elif [ "$HW_ACCEL_AVAILABLE" = true ]; then
            log CONVERT "Encoding (HW $ENCODER_HW fixed): $base_name.$src_ext"
        else
            log CONVERT "Encoding (SW $ENCODER_SW): $base_name.$src_ext"
        fi
    fi

    TEMP_LOG=$(mktemp)

    # ------------------------------------------------------------------
    # First attempt
    # ------------------------------------------------------------------
    ffmpeg -hide_banner -y -threads 2 -i "$input" \
        "${MAP_ARGS[@]}" "${video_args[@]}" "${audio_args[@]}" "$working_file" 2>"$TEMP_LOG"
    FFMPEG_STATUS=$?

    # ------------------------------------------------------------------
    # HW failed — fall back to SW
    # Skipped if FORCE_SW=true since the first attempt already used SW
    # ------------------------------------------------------------------
    if [ "$FFMPEG_STATUS" -ne 0 ] && [ "$VIDEO_IS_COPY" -ne 0 ] && [ "$HW_ACCEL_AVAILABLE" = true ] && [ "$FORCE_SW" = false ]; then
        log CONVERT "ERROR: Hardware encode failed — falling back to SW for $base_name.$src_ext"
        rm -f -- "$working_file"
        declare -a video_args_sw audio_args_sw
        build_video_args video_args_sw "$VIDEO_CODEC" "$VIDEO_PROFILE" false
        build_audio_args audio_args_sw "$AUDIO_CODEC"
        ffmpeg -hide_banner -y -threads 3 -i "$input" \
            "${MAP_ARGS[@]}" "${video_args_sw[@]}" "${audio_args_sw[@]}" "$working_file" 2>"$TEMP_LOG"
        FFMPEG_STATUS=$?
    fi

    # ------------------------------------------------------------------
    # Conversion succeeded
    # ------------------------------------------------------------------
    if [ "$FFMPEG_STATUS" -eq 0 ] && [ -s "$working_file" ]; then
        FPS=$(ffprobe -v 0 -select_streams v:0 \
            -show_entries stream=r_frame_rate -of csv=p=0 "$working_file")
        FPS=$(echo "scale=2; $FPS" | bc -l 2>/dev/null || echo "$FPS")
        AVG_FPS=$(grep -oP '(?<=fps=)\d+(\.\d+)?' "$TEMP_LOG" | \
            awk '{sum+=$1; count++} END {if(count>0) printf "%.1f", sum/count; else print "unknown"}')

        mv -- "$working_file" "$output"
        OUTPUT_SIZE=$(du -h "$output" | cut -f1)
        log CONVERT "Done: $base_name.mp4 | fps=$FPS encode_speed=${AVG_FPS:-unknown}fps size=$OUTPUT_SIZE"

        # Scrape metadata for the newly converted file
        # SCRAPER is "/path/to/python3 /path/to/scraper.py" — must expand unquoted
        log CONVERT "Fetching metadata: $base_name.mp4"
        # shellcheck disable=SC2086
        $SCRAPER --file "$output" \
            && log CONVERT "Metadata scrape complete: $base_name.mp4" \
            || log CONVERT "WARNING: Metadata scrape failed: $base_name.mp4"

        # Convert matching SRT → VTT inline
        sub_converted=false
        for sub_src in "$SOURCE_DIR/$base_name".[sS][rR][tT]; do
            if [ -e "$sub_src" ]; then
                vtt_dest="$SOURCE_DIR/$base_name.vtt"
                if [ -f "$vtt_dest" ]; then
                    log CONVERT "SKIP: $base_name.vtt already exists"
                else
                    ffmpeg -hide_banner -y -i "$sub_src" "$vtt_dest" 2>/dev/null
                    if [ $? -eq 0 ] && [ -s "$vtt_dest" ]; then
                        log CONVERT "Subtitle converted: $(basename "$sub_src") → $base_name.vtt"
                    else
                        log CONVERT "ERROR: Failed to convert subtitle $(basename "$sub_src") to VTT"
                        rm -f -- "$vtt_dest"
                    fi
                fi
                sub_converted=true
                break
            fi
        done
        [ "$sub_converted" = false ] && log CONVERT "No subtitle found for $base_name"

        rm -f -- "$input"

    # ------------------------------------------------------------------
    # Conversion failed
    # ------------------------------------------------------------------
    else
        log CONVERT "ERROR: Conversion failed for $base_name.$src_ext"
        log CONVERT "ffmpeg tail:"
        tail -20 "$TEMP_LOG" | while IFS= read -r line; do log CONVERT "  $line"; done
        rm -f -- "$working_file"
    fi

    rm -f -- "$TEMP_LOG"
    unset video_args audio_args video_args_sw audio_args_sw FORCE_SW HW_FOR_BUILD MAP_ARGS ENG_AUDIO_IDX
done
