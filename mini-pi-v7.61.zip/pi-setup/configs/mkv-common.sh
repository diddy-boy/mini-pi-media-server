#!/bin/bash
# =============================================================================
# mkv-common.sh — shared config and helpers for the mkv pipeline
# Source this file; do not execute it directly.
# Location: /usr/local/bin/mkv-common.sh
# =============================================================================

SOURCE_DIR="/var/lib/minidlna/Video"
LOCK_DIR="/tmp/mkv2mp4.lock.d"
SCRAPER="/home/pi/scraper/venv/bin/python3 /home/pi/scraper/scraper.py"

ENCODER_HW="h264_v4l2m2m"
ENCODER_SW="libx264"

HW_BITRATE="2M"
HW_MAXRATE="3M"
HW_BUFSIZE="6M"
HW_GOP="30"
HW_KEYINT_MIN="30"

PROTECTED_DIRS=("Web" "Test-Vids")

# -----------------------------------------------------------------------------
# log PREFIX MESSAGE
# Writes a tagged, prefixed line to stdout (captured by journalctl via watcher)
# -----------------------------------------------------------------------------
log() {
    local prefix="$1"
    shift
    echo "[$prefix] $*"
}

# -----------------------------------------------------------------------------
# is_protected_dir DIRPATH
# Returns 0 (true) if the directory is in the protected list
# -----------------------------------------------------------------------------
is_protected_dir() {
    local dirpath="$1"
    local real
    real=$(realpath "$dirpath" 2>/dev/null) || return 1
    for protected in "${PROTECTED_DIRS[@]}"; do
        local preal
        preal=$(realpath "$SOURCE_DIR/$protected" 2>/dev/null) || continue
        [ "$real" = "$preal" ] && return 0
    done
    return 1
}

# -----------------------------------------------------------------------------
# detect_hw_accel
# Sets HW_ACCEL_AVAILABLE=true/false in the calling scope
# note: for a pi 5, there is no hardware encoder so software encoder is always true
# on a pi 4b and a pi zero 2 w the hardware encoding is always true
# -----------------------------------------------------------------------------
detect_hw_accel() {
    modprobe bcm2835-v4l2 2>/dev/null
    if [ -e /dev/video10 ]; then
        HW_ACCEL_AVAILABLE=true
    else
        HW_ACCEL_AVAILABLE=false
    fi
}

# -----------------------------------------------------------------------------
# ffprobe helpers — all accept a single quoted filepath
# -----------------------------------------------------------------------------
get_video_bitrate() { ffprobe -v quiet -select_streams v:0 -show_entries stream=bit_rate  -of csv=p=0 "$1" 2>/dev/null; }
get_audio_codec()   { ffprobe -v quiet -select_streams a:0 -show_entries stream=codec_name -of csv=p=0 "$1" 2>/dev/null; }
get_video_codec()   { ffprobe -v quiet -select_streams v:0 -show_entries stream=codec_name -of csv=p=0 "$1" 2>/dev/null; }
get_video_pixfmt()  { ffprobe -v quiet -select_streams v:0 -show_entries stream=pix_fmt    -of csv=p=0 "$1" 2>/dev/null; }
get_video_profile() { ffprobe -v quiet -select_streams v:0 -show_entries stream=profile    -of csv=p=0 "$1" 2>/dev/null; }

# -----------------------------------------------------------------------------
# is_h264_profile_browser_safe PROFILE
# codec_name=h264 is not sufficient on its own — High 10 / High 4:2:2 /
# High 4:4:4 Predictive profiles are still H.264 but sit outside what
# browser <video> decoders (and most HW decoders) actually support. These
# turn up occasionally in old archive masters. Returns 0 (safe to remux)
# for ordinary Baseline/Main/High 8-bit 4:2:0, 1 otherwise (needs re-encode).
# -----------------------------------------------------------------------------
is_h264_profile_browser_safe() {
    local profile="$1"
    case "$profile" in
        *"High 10"*|*"4:2:2"*|*"4:4:4"*) return 1 ;;
        *) return 0 ;;
    esac
}

# -----------------------------------------------------------------------------
# get_english_audio_index FILEPATH
# Prints the absolute ffmpeg stream index of the first English-tagged audio
# track. If no language-tagged English stream is found (common with DVD VOBs
# which carry no language metadata), falls back to the index of the first
# audio stream. Returns empty string only if no audio streams exist at all.
# -----------------------------------------------------------------------------
get_english_audio_index() {
    local probe
    probe=$(ffprobe -v quiet -show_entries stream=index:stream_tags=language \
        -select_streams a -of csv=p=0 "$1" 2>/dev/null)

    # Try language-tagged English stream first
    local idx
    idx=$(echo "$probe" | awk -F',' 'tolower($2)=="eng"{print $1; exit}')
    if [ -n "$idx" ]; then
        echo "$idx"
        return
    fi

    # No language tags — fall back to first audio stream index (e.g. DVD VOBs)
    idx=$(echo "$probe" | awk -F',' 'NR==1{print $1; exit}')
    if [ -n "$idx" ]; then
        log "CONVERT" "No English language tag found — falling back to first audio stream (index $idx)" >&2
        echo "$idx"
    fi
}

# -----------------------------------------------------------------------------
# build_audio_args NAMEREF_ARRAY AUDIO_CODEC
# Populates caller's array with ffmpeg audio flags (no word-splitting risk)
# -----------------------------------------------------------------------------
build_audio_args() {
    local -n _audio_arr=$1
    local audio_codec="$2"
    case "$audio_codec" in
        aac) _audio_arr=(-c:a copy) ;;
        *)       _audio_arr=(-c:a aac -b:a 192k) ;;
    esac
}

# -----------------------------------------------------------------------------
# build_video_args NAMEREF_ARRAY VIDEO_CODEC VIDEO_PROFILE HW_ACCEL_AVAILABLE
# Populates caller's array with ffmpeg video flags.
# Returns 0 if stream copy (remux), 1 if encode required.
# -----------------------------------------------------------------------------
build_video_args() {
    local -n _video_arr=$1
    local video_codec="$2"
    local video_profile="$3"
    local hw_available="$4"

    if [ "$video_codec" = "h264" ] && is_h264_profile_browser_safe "$video_profile"; then
        _video_arr=(-c:v copy -movflags +faststart)
        return 0
    fi

    if [ "$video_codec" = "h264" ]; then
        log CONVERT "H.264 profile '$video_profile' isn't browser-safe (High10/4:2:2/4:4:4) — re-encoding instead of remuxing"
    fi

    if [ "$hw_available" = true ]; then
        _video_arr=(
            -c:v "$ENCODER_HW"
            -pix_fmt yuv420p
            -b:v "$HW_BITRATE"
            -maxrate "$HW_MAXRATE"
            -bufsize "$HW_BUFSIZE"
            -g "$HW_GOP"
            -keyint_min "$HW_KEYINT_MIN"
            -movflags +faststart
        )
    else
        # pix_fmt yuv420p is explicit here to ensure high bit-depth (10/12-bit)
        # H.265 content is correctly downconverted to 8-bit for browser compatibility
        _video_arr=(
            -c:v "$ENCODER_SW"
            -pix_fmt yuv420p
            -preset ultrafast
            -profile:v baseline
            -threads 3
            -b:v 1500k
            -vf "scale=960:540:flags=fast_bilinear"
            -movflags +faststart
        )
    fi
    return 1
}