#!/bin/bash

# This script sets the onboard wifi card to ALWAYS be a wifi access point for clients to connect 
# and the ethernet card as an at home network connection.
#
# Added support for Pi 5 but there is a known firmware issue with setting channels and wifi mode which
# this script works around.
# This script should work on a pi 5 as i have tested this script
# Works perfect on a pi 4b as it always has a ethernet and wifi card present.
#
# On a pi 4b, users can connect to the pi 4b access point when away from home and if the pi 4b is
# powered up like on a battery bank, brought home and then the ethernet cable is plugged in, auto routing 
# commences without any need for rebooting.
#
# the pi zero 2 w would work the same way if a person had the usb to ethernet connected all of the time
# but thats not reality and goes against its small portable size.
# 
# On a pi zero 2 w there is guarding if no ethenret card exists (no usb to ethernet adapter connected)
# This script has been tested on a pi zero 2 w with a usb to ethernet adpater and a pi 4b. both work fine.
# 

# --- 1. Dynamic Default Detection ---
PI_HOSTNAME=$(hostname)
CURRENT_COUNTRY=$(raspi-config nonint get_wifi_country)
CURRENT_COUNTRY=${CURRENT_COUNTRY:-GB}

echo "----------------------------------------------------"
echo "      MINI-PI NETWORK CONFIGURATION UTILITY         "
echo "----------------------------------------------------"

# AP Name (SSID)
read -p "Enter WiFi Name (SSID) [default: $PI_HOSTNAME]: " SSID
SSID=${SSID:-$PI_HOSTNAME}

# Password Validation
while true; do
    read -p "Enter WiFi Password (min 8 chars) [default: password]: " PASSWORD
    PASSWORD=${PASSWORD:-password}
    if [ ${#PASSWORD} -ge 8 ]; then
        break
    else
        echo ">> Error: Password must be at least 8 characters long."
    fi
done

# Country Code
echo "Common: GB (UK), US (USA), DE (Germany), FR (France)"
read -p "Enter Country Code [default: $CURRENT_COUNTRY]: " COUNTRY
COUNTRY=${COUNTRY:-$CURRENT_COUNTRY}

# --- 2. Execution Phase ---
echo ""
echo ">> Applying System Settings..."
sudo raspi-config nonint do_wifi_country "$COUNTRY"
sudo sysctl -w net.ipv4.ip_forward=1
echo "net.ipv4.ip_forward=1" | sudo tee /etc/sysctl.d/90-pi-ap.conf > /dev/null

echo ">> Cleaning Network Conflicts..."
# Disable and stop potentially conflicting services
sudo systemctl disable --now dnsmasq 2>/dev/null
sudo systemctl disable --now hostapd 2>/dev/null

# Force kill any process holding the DHCP/DNS ports (Critical for Pi 5)
sudo fuser -k 53/udp 53/tcp 67/udp 2>/dev/null
sudo killall -9 dnsmasq 2>/dev/null
sleep 2

sudo mkdir -p /root/netplan_backup
sudo mv /etc/netplan/90-NM-*.yaml /root/netplan_backup/ 2>/dev/null

# Interface Detection
WLAN_IFACE="wlan0"
ETH_IFACE=$(nmcli -t -f DEVICE,TYPE device | grep ethernet | head -n1 | cut -d: -f1)

# --- Hardware Guarding for Pi Zero 2 W ---
PI_MODEL=$(tr -d '\0' < /proc/device-tree/model)
if [[ "$PI_MODEL" == *"Zero 2 W"* ]]; then
    if [ -z "$ETH_IFACE" ]; then
        echo "!!"
        echo "!! WARNING: PI ZERO 2 W DETECTED BUT NO USB ETHERNET FOUND!"
        echo "!! Please ensure your USB-to-Ethernet adapter is firmly plugged in."
        echo "!!"
        ETH_IFACE="eth0"
    fi
fi

# Fallback for other models (like Pi 4) if cable is unplugged
if [ -z "$ETH_IFACE" ]; then ETH_IFACE="eth0"; fi

IS_PI5=false
if [[ "$PI_MODEL" == *"Raspberry Pi 5"* ]]; then
    IS_PI5=true
fi

echo ">> Preparing Wireless Hardware..."
sudo rfkill unblock wifi
sudo nmcli radio wifi on
sudo nmcli device set "$WLAN_IFACE" managed yes

# NetworkManager Setup
echo ">> Purging all existing NetworkManager connections..."
# Get all connection names and delete them one by one
# This ensures no old 'MiniPi-AP' or old '$SSID' profiles are NOT preserved
for conn in $(nmcli -t -f NAME connection); do
    sudo nmcli con delete "$conn" 2>/dev/null
done

# Restart NetworkManager to ensure the stack is clean
sudo systemctl restart NetworkManager
sleep 2

echo ">> Building Access Point..."
# We now use $SSID for BOTH the internal profile name and the broadcast SSID
sudo nmcli con add type wifi con-name "$SSID" autoconnect yes ssid "$SSID" mode ap
sudo nmcli con modify "$SSID" connection.interface-name "$WLAN_IFACE"

if [ "$IS_PI5" = false ]; then
    # Original stable settings for Pi Zero 2 W and Pi 4
    sudo nmcli con modify "$SSID" ipv4.dhcp-timeout 10
    sudo nmcli con modify "$SSID" 802-11-wireless.band bg
    sudo nmcli con modify "$SSID" 802-11-wireless.channel 6
    # Explicitly set WPA2-AES (RSN/CCMP) for Linux compatibility
    sudo nmcli con modify "$SSID" 802-11-wireless-security.proto rsn
    sudo nmcli con modify "$SSID" 802-11-wireless-security.group ccmp
    sudo nmcli con modify "$SSID" 802-11-wireless-security.pairwise ccmp
    
    # Set PMF to 'Optional' (1) - This is the "sweet spot" for linux
    sudo nmcli con modify "$SSID" 802-11-wireless-security.pmf 1
    sudo nmcli con modify "$SSID" 802-11-wireless.powersave 1
else
    # Pi 5 specific stability and auth fixes
    echo ">> Applying Pi 5 firmware workarounds..."
    sudo nmcli con modify "$SSID" 802-11-wireless.band bg
    sudo nmcli con modify "$SSID" 802-11-wireless.channel 0
    sudo nmcli con modify "$SSID" 802-11-wireless-security.proto rsn
    sudo nmcli con modify "$SSID" 802-11-wireless-security.group ccmp
    sudo nmcli con modify "$SSID" 802-11-wireless-security.pairwise ccmp
    # Disable PMF (Management Frame Protection) to prevent password timeouts on Pi 5
    sudo nmcli con modify "$SSID" 802-11-wireless-security.pmf 1
    sudo nmcli con modify "$SSID" ipv4.dhcp-timeout 10
fi

sudo nmcli con modify "$SSID" 802-11-wireless-security.key-mgmt wpa-psk
sudo nmcli con modify "$SSID" 802-11-wireless-security.psk "$PASSWORD"

echo ">> Configuring IP Sharing (192.168.50.1)..."
sudo nmcli con modify "$SSID" ipv4.method shared
sudo nmcli con modify "$SSID" ipv6.method ignore
sudo nmcli con modify "$SSID" ipv4.addresses 192.168.50.1/24
sudo nmcli con modify "$SSID" connection.zone trusted
# THEN restart it
nmcli con down "$SSID" 2>/dev/null
nmcli con up "$SSID"

# --- 3. Final Summary and Pause ---
clear
echo "===================================================="
echo "          CONFIGURATION SUMMARY (PENDING REBOOT)    "
echo "===================================================="
echo ""
echo "  The following settings will be active after next REBOOT:"
echo ""
echo "  WIFI SSID (NAME):  $SSID"
echo "  WIFI PASSWORD:     $PASSWORD"
echo "  PI STATIC IP:      192.168.50.1"
echo ""
echo "  SERVICES WILL BE ACCESSIBLE AT:"
echo "  - Cockpit:  https://192.168.50.1:9090"
echo "  - Apache:   http://192.168.50.1"
echo "  - Samba:    \\192.168.50.1"
echo ""
echo "===================================================="
echo "  IMPORTANT: You MUST reboot for the Pi 5 to clear  "
echo "  firmware conflicts and start the Access Point.    "
echo "===================================================="
echo ""
read -p "  PRESS [ENTER] TO FINISH AND RETURN TO MAIN SETUP..."

exit 0
