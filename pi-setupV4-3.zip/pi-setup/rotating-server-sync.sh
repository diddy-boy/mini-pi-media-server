#!/usr/bin/env bash
#
# Server Media Sync with dialog set amount of months by user in this script.
#
# NOTE: use this or configure_server_script.sh NOT both. They work in different ways.
# Syncs media files modified within a user-specified number of months from a Samba server share
# to a /var/lib/minidlna (flat structure) folder. 
# If an MP4 file of the same name already exists do NOT rsync the MKV file down from server.
# Deletes local files older than the date range set by the user.
# Uses dialog for user interaction and shows rsync output during sync.
# User can schedule a mkv-2-mp4.sh script that converts MKV files to MP4 to run at midnight.
# User can also remove the sync conversion timer from systemd as well.
# The mkv-2-mp4.sh script will run using a low profile to convert in the background without a performance hit.
# INTELLIGENT: Skips MKV files if MP4 equivalents already exist locally when running rsync
#

# Configuration file path (relative to script directory)
SCRIPT_DIR="$(dirname "$(realpath "$0")")"
CONFIG_FILE="$SCRIPT_DIR/.samba_film_sync.conf"
MKV_CONVERT_SCRIPT="configs/mkv-2-mp4.sh"

# Default config values
SAMBA_SHARE="//192.168.8.10/Films"
SAMBA_USER="username"
SAMBA_PASS=""
DEST_DIR="/var/lib/minidlna/Video"
MONTHS=3
MOUNT_POINT="/mnt/samba_share"

if [[ "$1" == "--cron" ]]; then
    load_config
    run_sync
    exit 0
fi

# Check dependencies
if ! command -v rsync >/dev/null; then
    dialog --msgbox "'rsync' is not installed. Please install it before running." 7 50
    exit 1
fi

if ! command -v mount.cifs >/dev/null; then
    dialog --msgbox "'cifs-utils' is not installed. Please install it before running." 7 60
    exit 1
fi

if ! command -v dialog >/dev/null; then
    dialog --msgbox "'dialog' is not installed. Please install it before running." 7 60
    exit 1
fi

# Load config
load_config() {
    if [ -f "$CONFIG_FILE" ]; then
        source "$CONFIG_FILE"
    fi
}

# Save config
save_config() {
    cat > "$CONFIG_FILE" << EOF
SAMBA_SHARE="$SAMBA_SHARE"
SAMBA_USER="$SAMBA_USER"
SAMBA_PASS="$SAMBA_PASS"
DEST_DIR="$DEST_DIR"
MONTHS=$MONTHS
EOF
    chmod 600 "$CONFIG_FILE"
}

# Setup MKV conversion timer
setup_mkv_conversion_service() {
    SERVICE_FILE="/etc/systemd/system/mkv-conversion.service"
    TIMER_FILE="/etc/systemd/system/mkv-conversion.timer"
    
    # Get the absolute path of THIS script to run it in --cron mode
    SYNC_SCRIPT_PATH="$(realpath "$0")"
    # The path for the conversion script
    MKV_CONVERT_ABS_PATH="/usr/local/bin/mkv-2-mp4.sh"

    # Create systemd service file
    sudo bash -c "cat > $SERVICE_FILE" << EOF
[Unit]
Description=Sync Media from Server and Convert MKV to MP4
Wants=network-online.target
After=network-online.target

[Service]
Type=oneshot
# STEP 1: Run the Sync (Pull from server)
ExecStart=/bin/bash $SYNC_SCRIPT_PATH --cron
# STEP 2: Run the Conversion (Only if it exists)
ExecStartPost=/bin/bash -c 'if [ -f $MKV_CONVERT_ABS_PATH ]; then /bin/bash $MKV_CONVERT_ABS_PATH; fi'
User=root
Group=root
WorkingDirectory=/var/lib/minidlna/Video
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF

    # Create systemd timer file (runs daily at midnight)
    sudo bash -c "cat > $TIMER_FILE" << 'EOF'
[Unit]
Description=Run Media Sync and Conversion daily at 11pm

[Timer]
OnCalendar=*-*-* 23:00:00
Persistent=true

[Install]
WantedBy=timers.target
EOF

    sudo systemctl daemon-reload
    sudo systemctl enable mkv-conversion.timer
    sudo systemctl start mkv-conversion.timer

    dialog --msgbox "Automation Set!\n\nEvery night at midnight, this script will:\n1. Pull files from server (--cron mode)\n2. Run mkv-2-mp4.sh" 12 60
}

# Remove MKV conversion timer
remove_mkv_conversion_service() {
    SERVICE_FILE="/etc/systemd/system/mkv-conversion.service"
    TIMER_FILE="/etc/systemd/system/mkv-conversion.timer"

    if [ ! -f "$SERVICE_FILE" ] && [ ! -f "$TIMER_FILE" ]; then
        dialog --msgbox "No MKV conversion timer or service found." 10 60
        return 1
    fi

    dialog --yesno "Are you sure you want to remove the MKV conversion timer and service?" 10 60
    if [ $? -ne 0 ]; then
        dialog --msgbox "Aborted. The MKV conversion timer and service were not removed." 10 60
        return 1
    fi

    sudo systemctl stop mkv-conversion.timer >/dev/null 2>&1 || true
    sudo systemctl disable mkv-conversion.timer >/dev/null 2>&1 || true
    sudo rm -f "$SERVICE_FILE" "$TIMER_FILE"
    sudo systemctl daemon-reload

    # Check removal status
    if ! systemctl list-timers --all | grep -q mkv-conversion.timer; then
        status="REMOVED"
    else
        status="FAILED TO REMOVE"
    fi

    dialog --msgbox "MKV conversion timer and service have been removed.\nStatus: $status" 10 60
}

# Configure setup menu
configure_setup() {
    while true; do
        CHOICE=$(dialog --clear --backtitle "Rotational Server Media Sync - Configure Setup" \
            --menu "Current Configuration:\n
Samba Share: $SAMBA_SHARE
Username: $SAMBA_USER
Password: [hidden]
Destination: $DEST_DIR
Months to Keep: $MONTHS

Select option to edit:" 16 90 8 \
            1 "Server Share Path" \
            2 "Server Username" \
            3 "Server Password" \
            4 "Local Destination Directory" \
            5 "How many months back do you want to sync Media from" \
            0 "Save and continue" \
            3>&1 1>&2 2>&3)

        case $CHOICE in
            1)
                input=$(dialog --inputbox "Enter Server Share Path (e.g., //192.168.8.10/Films):" 10 60 "$SAMBA_SHARE" 3>&1 1>&2 2>&3)
                if [ -n "$input" ]; then SAMBA_SHARE="$input"; fi
                ;;
            2)
                input=$(dialog --inputbox "Enter a Username to access this server:" 10 50 "$SAMBA_USER" 3>&1 1>&2 2>&3)
                if [ -n "$input" ]; then SAMBA_USER="$input"; fi
                ;;
            3)
                input=$(dialog --insecure --passwordbox "What Password is used to access this server:" 10 50 3>&1 1>&2 2>&3)
                if [ -n "$input" ]; then SAMBA_PASS="$input"; fi
                ;;
            4)
                dest_choice=$(dialog --menu "Select destination directory:" 10 50 3 \
                    1 "/var/lib/minidlna/Video" \
                    2 "/var/lib/minidlna/Music" \
                    3 "/var/lib/minidlna/Pictures" \
                    3>&1 1>&2 2>&3)
                case $dest_choice in
                    1) DEST_DIR="/var/lib/minidlna/Video" ;;
                    2) DEST_DIR="/var/lib/minidlna/Music" ;;
                    3) DEST_DIR="/var/lib/minidlna/Pictures" ;;
                esac
                ;;
            5)
                input=$(dialog --inputbox "How many months back do you want to synchronise media files from :" 8 50 "$MONTHS" 3>&1 1>&2 2>&3)
                if [[ "$input" =~ ^[1-9][0-9]*$ ]]; then
                    MONTHS="$input"
                else
                    dialog --msgbox "Invalid input. Please enter a number of months to sync within" 10 60
                fi
                ;;
            0)
                save_config
                summary="Synchronise files from server: $SAMBA_SHARE\nWith a Username of: $SAMBA_USER\nTo the Destination Directory of: $DEST_DIR\nOnly synchronise media in the past: $MONTHS Months"
                dialog --title "Summary of Settings" --msgbox "$summary" 15 60
                dialog --yesno "Run synchronisation now?" 10 60
                if [ $? -eq 0 ]; then
                    run_sync
                fi
                break
                ;;
            *)
                ;;
        esac
    done
}

# Run sync with intelligent MKV filtering
run_sync() {
    DAYS=$(echo "$MONTHS * 30.42" | bc | cut -d. -f1)
    if ! [[ "$DAYS" =~ ^[0-9]+$ ]] || [ "$DAYS" -lt 1 ]; then
        DAYS=91
    fi

    mkdir -p "$MOUNT_POINT"
    mkdir -p "$DEST_DIR"

    if [ ! -w "$DEST_DIR" ]; then
        dialog --msgbox "No write permission to $DEST_DIR. Run with sudo or fix permissions." 10 60
        return 1
    fi

    if mountpoint -q "$MOUNT_POINT"; then
        mounted=1
    else
        CRED_FILE=$(mktemp)
        echo -e "username=$SAMBA_USER\npassword=$SAMBA_PASS" > "$CRED_FILE"
        chmod 600 "$CRED_FILE"
        sudo mount -t cifs "$SAMBA_SHARE" "$MOUNT_POINT" -o credentials="$CRED_FILE",vers=3.0,nounix,iocharset=utf8
        status=$?
        rm -f "$CRED_FILE"
        if [ $status -ne 0 ]; then
            dialog --msgbox "Failed to mount Server share. Check credentials and network." 10 60
            return 1
        fi
        mounted=0
    fi

    if [ ! -r "$MOUNT_POINT" ] || [ -z "$(ls -A "$MOUNT_POINT")" ]; then
        dialog --msgbox "Mount point $MOUNT_POINT is unreadable or empty. Aborting." 10 60
        if [ $mounted -eq 0 ]; then
            sudo umount "$MOUNT_POINT"
        fi
        return 1
    fi

    dialog --title "Cleanup" --infobox "Deleting files older than $MONTHS months ($DAYS days) in $DEST_DIR..." 10 60
    find "$DEST_DIR" -maxdepth 1 -type f -mtime +"$DAYS" -exec rm -f {} \;

    mapfile -d '' files < <(find "$MOUNT_POINT" -type f -mtime -"$DAYS" -print0)

    total_files=${#files[@]}
    if [ "$total_files" -eq 0 ]; then
        dialog --msgbox "No files found on server modified within $MONTHS months." 10 60
        [ $mounted -eq 0 ] && sudo umount "$MOUNT_POINT"
        return 0
    fi

    clear
    echo "Starting intelligent sync - checking for MKV/MP4 duplicates..."
    
    # Counters for statistics
    synced_files=0
    skipped_mkvs=0
    
    for src_file in "${files[@]}"; do
        filename=$(basename "$src_file")
        base_name="${filename%.*}"
        extension="${filename##*.}"
        
        # Convert extension to lowercase for comparison
        extension_lower=$(echo "$extension" | tr '[:upper:]' '[:lower:]')
        
        # If it's an MKV file, check if MP4 equivalent already exists locally
        if [[ "$extension_lower" == "mkv" ]]; then
            mp4_equivalent="$DEST_DIR/${base_name}.mp4"
            if [[ -f "$mp4_equivalent" ]]; then
                echo "⏭️  Skipping $filename - MP4 version already exists locally"
                ((skipped_mkvs++))
                continue
            else
                echo "📥 Syncing MKV: $filename (no MP4 equivalent found)"
            fi
        else
            echo "📥 Syncing: $filename"
        fi
        
        # Perform the actual sync
        if rsync -av --progress --inplace --ignore-existing -z --exclude='.*' --exclude='*.avi' "$src_file" "$DEST_DIR/$filename"; then
            ((synced_files++))
        else
            echo "❌ Failed to sync: $filename"
        fi
    done

    [ $mounted -eq 0 ] && sudo umount "$MOUNT_POINT"
    chmod -R 775 /var/lib/minidlna
    chown -R minidlna:minidlna /var/lib/minidlna

    # Show sync statistics
    echo ""
    echo "📊 Sync Statistics:"
    echo "   Files synced: $synced_files"
    echo "   MKVs skipped (MP4 file exists): $skipped_mkvs"
    echo "   Total files processed: $total_files"
    echo ""
    
    dialog --title "Sync Complete" --msgbox "Synchronisation completed successfully!\n\nFiles synced: $synced_files\nMKVs skipped (MP4 file exists): $skipped_mkvs\nTotal files processed: $total_files" 12 60
}

# Main menu
load_config
while true; do
    choice=$(dialog --clear --backtitle "Rotational Server Media Sync" --menu "Select an option:" 15 60 5 \
        1 "Create/Edit Setup" \
        2 "Run Synchronisation Now" \
        3 "Setup MKV Conversion Timer" \
        4 "Remove MKV Conversion Timer" \
        5 "Exit" \
        3>&1 1>&2 2>&3)
    case $choice in
        1) configure_setup ;;
        2) run_sync ;;
        3) setup_mkv_conversion_service ;;
        4) remove_mkv_conversion_service ;;
        5) clear; exit 0 ;;
        *) dialog --msgbox "Invalid option. Please choose 1-5." 10 60 ;;
    esac
done
