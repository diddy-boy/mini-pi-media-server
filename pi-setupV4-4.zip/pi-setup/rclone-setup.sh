#!/bin/bash
# rclone-setup.sh for Mini-Pi Media Server v4.4 - Bash Prompt Version

# 1. Root Check
if [[ $EUID -ne 0 ]]; then
   echo "-------------------------------------------------------"
   echo "Error: This script must be run with sudo"
   echo "-------------------------------------------------------"
   exit 1
fi

PI_USER="pi"
SYNC_DIR="/var/lib/minidlna/Video/Web"
SERVICE_NAME="rclone-sync"
REMOTE_NAME="gdrive"
CONFIG_PATH="/root/.config/rclone/rclone.conf"

# 2. Setup Environment & Install Rclone
setup_rclone() {
    clear
    echo "--- STEP 1: Installing Software ---"
    echo "Preparing directories and installing Rclone..."
    
    chmod a+x /var/lib /var/lib/minidlna /var/lib/minidlna/Video
    mkdir -p "$SYNC_DIR"
    
    if ! command -v rclone &> /dev/null; then
        echo "Installing Rclone..."
        curl https://rclone.org/install.sh | sudo bash
    else
        echo "Rclone is already installed."
    fi

    echo ""
    echo "INSTRUCTIONS:"
    echo "1. Log into your Google Drive in a web browser."
    echo "2. Create a folder named 'Video'."
    echo "3. Open that 'Video' folder in the web browser."
    echo "4. Copy the long string of letters/numbers at the end of the URL after the last /."
    echo ""
    echo "Note: It's good practice to save this locally for use on other Mini-Pi servers."
    echo ""
    echo -n "Paste your Folder ID here and press Enter: "
    read USER_FOLDER_ID
    
    if [ ! -z "$USER_FOLDER_ID" ]; then
        echo "$USER_FOLDER_ID" > /root/.rclone_folder_id
        echo "-------------------------------------------------------"
        echo "              Folder ID saved successfully!"
        echo "-------------------------------------------------------"
        sleep 2
    fi
}

# 3. Handle Automated Token Configuration
configure_remote() {
    clear
    echo "--- Step 2: Google Drive Authentication ---"
    echo "To get your token:"
    echo "1. Visit: https://rclone.org/commands/rclone_authorize/ (or use rclone authorize 'drive')"
    echo "2. Follow the Google login prompts."
    echo "3. Copy the JSON block starting with '{' and ending with '}'."
    echo ""
    echo "Note: It's good practice to save this locally for use on other Mini-Pi servers."
    echo ""
    echo "Paste Token (Right-click or Ctrl+Shift+V to paste):"
    read USER_TOKEN

    if [ ! -z "$USER_TOKEN" ]; then
        mkdir -p /root/.config/rclone/
        cat <<EOF > "$CONFIG_PATH"
[$REMOTE_NAME]
type = drive
scope = drive
token = $USER_TOKEN
EOF
        echo "-------------------------------------------------------"
        echo "           Configuration written successfully!"
        echo "-------------------------------------------------------"
        sleep 2
    fi
}

# 4. Install Systemd Service
install_sync_service() {
    if [ ! -f /root/.rclone_folder_id ]; then
        echo "Error: Folder ID not found. Please run Option 1 first."
        sleep 3
        return
    fi

    CURRENT_FOLDER_ID=$(cat /root/.rclone_folder_id)

    cat <<EOF > /etc/systemd/system/${SERVICE_NAME}.service
[Unit]
Description=Rclone Google Drive Sync Service
After=network-online.target

[Service]
Type=simple
User=root
ExecStart=/bin/bash -c 'BEFORE=\$(find $SYNC_DIR -type f | wc -l); /usr/bin/rclone sync ${REMOTE_NAME}: $SYNC_DIR --drive-root-folder-id $CURRENT_FOLDER_ID --config $CONFIG_PATH --delete-during --log-level NOTICE; AFTER=\$(find $SYNC_DIR -type f | wc -l); chown -R www-data:www-data $SYNC_DIR && chmod -R 755 $SYNC_DIR; if [ "\$BEFORE" -ne "\$AFTER" ]; then /usr/sbin/service minidlna restart; fi'
Restart=always
RestartSec=1800

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable ${SERVICE_NAME}.service
    systemctl start ${SERVICE_NAME}.service
    
    echo "-------------------------------------------------------"
    echo "                   Service installed!"
    echo ""
    echo "               Sync runs every 30 minutes."
    echo "    MiniDLNA will only restart if new files are found."
    echo "-------------------------------------------------------"
    sleep 5
}

# --- Main Menu Loop ---
while true; do
    clear
    echo "======================================================="
    echo "          Mini-Pi Google Drive Sync (Rclone)          "
    echo "======================================================="
    echo "Setup your own Google Drive Cloud sync:"
    echo ""
    echo "1) [Setup] Install Software & Set Folder ID"
    echo "2) [Auth]  Paste Google Auth Token"
    echo "3) [Start] Enable 30-Minute Sync Service"
    echo "4) [View]  Check Sync Logs"
    echo "5) Return to Main Setup"
    echo ""
    echo " Normal setup is to choose option 1, 2 and then 3. then exit "
    echo -n "Select an option: "
    read opt

    case $opt in
        1) setup_rclone ;;
        2) configure_remote ;;
        3) install_sync_service ;;
        4) 
            clear
            echo "Press Ctrl+C to exit logs and return to the menu."
            sleep 2
            journalctl -u $SERVICE_NAME -f 
            ;;
        5|"") 
            clear
            exit 0 
            ;;
        *) 
            echo "Invalid option."
            sleep 1
            ;;
    esac
done
