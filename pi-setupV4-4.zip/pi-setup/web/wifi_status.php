<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

function getNetworkStatus() {
    clearstatcache();

    // 1. Check for Ethernet (Home Mode)
    $eth_path = '/sys/class/net/eth0/carrier';
    if (file_exists($eth_path) && trim(file_get_contents($eth_path)) === '1') {
        return ['mode' => 'ETHERNET', 'text' => 'Connected via Ethernet'];
    }

    // 2. Default to Access Point (Away/Camping Mode)
    // No sudo required for this basic reporting.
    return ['mode' => 'AP', 'text' => 'Access Point only'];
}

echo json_encode(getNetworkStatus());
?>
