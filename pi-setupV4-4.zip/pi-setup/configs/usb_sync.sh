#!/bin/bash
#
# USB-to-MiniDLNA Multi-Directory Sync Script (Raspberry Pi Fixed)
# Detects, mounts, and syncs Video/Music/Pictures from a USB drive to /var/lib/minidlna
# Skips existing files and refreshes MiniDLNA after sync
#
# Config
DEST_BASE="/var/lib/minidlna"
MOUNT_POINT="/media/usb"
SYNC_DIRS=("Video" "Music" "Pictures")

# Logging function
log_message() {
    local level="$1"
    local message="$2"
    echo "$message"
    logger -t "usb-minidlna-sync" -p "user.$level" "$message"
}

# Ensure root privileges
if [ "$EUID" -ne 0 ]; then
  log_message "error" "Script must be run with sudo privileges"
  exit 1
fi

log_message "info" "USB-to-MiniDLNA sync script started"

# Check destination base exists
if [ ! -d "$DEST_BASE" ]; then
  log_message "error" "Destination directory $DEST_BASE does not exist"
  exit 1
fi

# Create mount point if needed
mkdir -p "$MOUNT_POINT" || { echo "** Error: Cannot create mount point $MOUNT_POINT. **"; exit 1; }

# Wait briefly for USB device enumeration
sleep 2

echo "Scanning for USB devices..."

# More reliable USB detection for Raspberry Pi (handles NVMe boot drives)
# Method 1: Find USB storage devices, excluding the boot device
USB_DEVICE=""

# Get the boot device (where root filesystem is mounted)
BOOT_DEVICE=$(mount | grep ' on / ' | cut -d' ' -f1 | sed 's/[0-9]*$//')
echo "Boot device detected: $BOOT_DEVICE"

# Find all USB-connected storage devices
for device in /sys/block/sd*; do
    if [ -e "$device" ]; then
        device_name=$(basename "$device")
        device_path="/dev/$device_name"
        
        # Skip if this is the boot device
        if [ "$device_path" = "$BOOT_DEVICE" ]; then
            echo "Skipping boot device: $device_path"
            continue
        fi
        
        # Check if this device is connected via USB
        if [ -L "/sys/block/$device_name" ]; then
            device_sysfs_path=$(readlink -f "/sys/block/$device_name")
            if echo "$device_sysfs_path" | grep -q "/usb"; then
                USB_DEVICE="$device_path"
                echo "Found USB device via sysfs: $USB_DEVICE (not boot device)"
                break
            fi
        fi
    fi
done

# Method 2: If Method 1 didn't work, try removable device detection
if [ -z "$USB_DEVICE" ]; then
    echo "Trying alternative USB detection..."
    
    # Look for mass storage devices that are removable and not the boot device
    for device in /dev/sd*; do
        if [ -b "$device" ] && [[ "$device" =~ /dev/sd[a-z]$ ]]; then
            device_name=$(basename "$device")
            
            # Skip boot device
            if [ "$device" = "$BOOT_DEVICE" ]; then
                echo "Skipping boot device: $device"
                continue
            fi
            
            # Check if it's removable
            if [ -f "/sys/block/$device_name/removable" ]; then
                removable=$(cat "/sys/block/$device_name/removable")
                if [ "$removable" = "1" ]; then
                    USB_DEVICE="$device"
                    echo "Found removable device: $USB_DEVICE (not boot device)"
                    break
                fi
            fi
        fi
    done
fi

# Method 3: Manual detection prompt if automatic methods fail
if [ -z "$USB_DEVICE" ]; then
    echo "Automatic USB detection failed. Available block devices:"
    lsblk -d -o NAME,SIZE,TRAN,TYPE,MOUNTPOINT,RM | grep -v "loop"
    echo ""
    echo "Boot device: $BOOT_DEVICE"
    echo ""
    echo "Available storage devices (excluding boot device):"
    for dev in /dev/sd*; do
        if [ -b "$dev" ] && [[ "$dev" =~ /dev/sd[a-z]$ ]] && [ "$dev" != "$BOOT_DEVICE" ]; then
            echo "  $dev - $(lsblk -dno SIZE,MODEL "$dev" 2>/dev/null || echo "Unknown")"
        fi
    done
    echo ""
    echo "Please check if your USB drive is properly connected and try again."
    echo "If you see your USB drive listed above, there might be an issue with automatic detection."
    exit 1
fi

echo "Selected USB device: $USB_DEVICE"
log_message "info" "Selected USB device: $USB_DEVICE"

# Detect first supported partition
USB_PARTITION=$(lsblk -l -o NAME,FSTYPE "$USB_DEVICE" 2>/dev/null | grep "^${USB_DEVICE##*/}[0-9]" \
  | grep -E "vfat|exfat|ext[2-4]|ntfs" | awk '{print $1}' | head -n 1)

if [ -z "$USB_PARTITION" ]; then
    echo "** Error: No valid partitions found on $USB_DEVICE **"
    echo "Partition table:"
    lsblk "$USB_DEVICE" 2>/dev/null || fdisk -l "$USB_DEVICE" 2>/dev/null
    exit 1
fi

USB_PARTITION="/dev/$USB_PARTITION"
echo "Using partition: $USB_PARTITION"

# Check filesystem type
FS_TYPE=$(lsblk -no FSTYPE "$USB_PARTITION" 2>/dev/null)
echo "Filesystem type: $FS_TYPE"

# Check if already mounted elsewhere
if mount | grep -q "$USB_PARTITION" && ! mountpoint -q "$MOUNT_POINT"; then
  echo "** Error: Partition $USB_PARTITION is already mounted elsewhere: **"
  mount | grep "$USB_PARTITION"
  exit 1
fi

# Filesystem check (non-destructive) - skip for some filesystems
case "$FS_TYPE" in
    "vfat"|"exfat"|"ntfs")
        echo "Skipping fsck for $FS_TYPE filesystem"
        ;;
    *)
        fsck -n "$USB_PARTITION" >/dev/null 2>&1 || {
            echo "** Filesystem errors detected. Repairing... **"
            fsck -y "$USB_PARTITION" || { echo "** Error: Filesystem repair failed. **"; exit 1; }
        }
        ;;
esac

# Mount if not already
if ! mountpoint -q "$MOUNT_POINT"; then
    echo "Mounting $USB_PARTITION at $MOUNT_POINT..."
    mount "$USB_PARTITION" "$MOUNT_POINT" || { 
        echo "** Error: Failed to mount $USB_PARTITION. **"
        echo "Trying with specific filesystem type..."
        if [ -n "$FS_TYPE" ]; then
            mount -t "$FS_TYPE" "$USB_PARTITION" "$MOUNT_POINT" || {
                echo "** Error: Mount failed even with -t $FS_TYPE. **"
                exit 1
            }
        else
            exit 1
        fi
    }
    echo "********** Mounted $USB_PARTITION at $MOUNT_POINT **********"
    log_message "info" "Successfully mounted $USB_PARTITION at $MOUNT_POINT"
fi

# Show what's on the USB drive
echo "Contents of USB drive:"
ls -la "$MOUNT_POINT/"

# Verify source has content
if [ -z "$(ls -A "$MOUNT_POINT" 2>/dev/null)" ]; then
  echo "** Error: Source $MOUNT_POINT is empty or unreadable. **"
  umount "$MOUNT_POINT" 2>/dev/null
  exit 1
fi

# Function to sync a specific directory
sync_directory() {
    local dir_name="$1"
    local source_dir="$MOUNT_POINT/$dir_name"
    local dest_dir="$DEST_BASE/$dir_name"
    
    echo "=========================================="
    echo "Processing $dir_name directory..."
    echo "=========================================="
    
    # Check if source directory exists
    if [ -d "$source_dir" ]; then
        echo "Found $dir_name directory on USB. Contents:"
        find "$source_dir" -type d | head -10
        log_message "info" "Starting sync of $dir_name directory from USB to $dest_dir"
        
        # Create destination directory if it doesn't exist
        mkdir -p "$dest_dir"
        
        # Sync with progress and detailed logging
        echo "Syncing $dir_name files from $source_dir to $dest_dir..."
        
        # Create a temporary log file for this sync
        sync_log="/tmp/sync_${dir_name}_$(date +%s).log"
        
        rsync -av --progress --inplace --whole-file --exclude='.*' --info=NAME,PROGRESS2 "$source_dir/" "$dest_dir" \
          | tee "$sync_log" | stdbuf -oL sed "s/^/[$dir_name] Synced: /"
        
        rsync_exit_code=${PIPESTATUS[0]}
        
        # Log summary of what was synced
        synced_files=$(grep -c "^[^d]" "$sync_log" 2>/dev/null || echo "0")
        log_message "info" "$dir_name sync processed $synced_files files"
        
        # Clean up temp log
        rm -f "$sync_log"
        
        # Check if sync was successful
        if [ $rsync_exit_code -eq 0 ]; then
            echo "********** $dir_name sync completed successfully. **********"
            echo "$dir_name files synced to destination:"
            
            # Show some stats about what was synced
            file_count=$(find "$dest_dir" -type f 2>/dev/null | wc -l)
            dir_count=$(find "$dest_dir" -type d 2>/dev/null | wc -l)
            echo "  - Files: $file_count"
            echo "  - Directories: $dir_count"
            
            log_message "info" "$dir_name sync completed successfully - $file_count files, $dir_count directories"
            
            # Show specific test directories if they exist (like the original Test-Vids check)
            if [ "$dir_name" = "Video" ]; then
                find "$dest_dir" -name "Test-Vids" -type d 2>/dev/null && echo "Test-Vids directory found in Video" || echo "Test-Vids directory not found in Video"
            fi
            
        else
            echo "** Error: $dir_name sync failed. **"
            log_message "error" "$dir_name sync failed"
            return 1
        fi
        
    else
        echo "** Warning: No '$dir_name' directory found on USB drive **"
        echo "Skipping $dir_name sync..."
        log_message "warning" "No $dir_name directory found on USB drive - skipping"
    fi
    
    echo ""  # Add spacing between directories
}

# Main sync process
echo ""
echo "Starting multi-directory sync to $DEST_BASE..."
echo "USB mount point: $MOUNT_POINT"
echo ""

# Show available directories on USB for reference
echo "Available directories on USB:"
find "$MOUNT_POINT" -maxdepth 2 -type d | head -20
echo ""

# Track overall success
overall_success=true
synced_dirs=()

# Sync each directory
for dir in "${SYNC_DIRS[@]}"; do
    if sync_directory "$dir"; then
        synced_dirs+=("$dir")
    else
        overall_success=false
    fi
done

# Final status report
echo "=========================================="
echo "SYNC SUMMARY"
echo "=========================================="

if [ "$overall_success" = true ]; then
    echo "********** ALL SYNCS COMPLETED SUCCESSFULLY **********"
    echo ""
    echo "Successfully synced directories: ${synced_dirs[*]}"
    echo ""
    echo "Final destination structure:"
    for dir in "${synced_dirs[@]}"; do
        dest_dir="$DEST_BASE/$dir"
        if [ -d "$dest_dir" ]; then
            file_count=$(find "$dest_dir" -type f 2>/dev/null | wc -l)
            echo "  $dest_dir: $file_count files"
        fi
    done
    log_message "info" "All directory syncs completed successfully: ${synced_dirs[*]}"
else
    echo "** Warning: Some syncs encountered errors **"
    if [ ${#synced_dirs[@]} -gt 0 ]; then
        echo "Successfully synced: ${synced_dirs[*]}"
        log_message "warning" "Some syncs failed - successfully synced: ${synced_dirs[*]}"
    else
        log_message "error" "All directory syncs failed"
    fi
    umount "$MOUNT_POINT" 2>/dev/null
    exit 1
fi

# Unmount
sync
sleep 1
if umount "$MOUNT_POINT"; then
  echo "********** Unmounted from $MOUNT_POINT. SAFE TO REMOVE USB. **********"
  log_message "info" "USB drive safely unmounted from $MOUNT_POINT"
else
  echo "** Error: Failed to unmount $MOUNT_POINT. **"
  log_message "error" "Failed to unmount USB drive from $MOUNT_POINT"
fi

# set permissions back - if different
sudo chmod 755 "$DEST_BASE"
# Refresh MiniDLNA
if systemctl restart minidlna; then
    echo "MiniDLNA refreshed."
    log_message "info" "MiniDLNA service restarted successfully - sync process complete"
else
    log_message "error" "Failed to restart MiniDLNA service"
fi
exit 0
