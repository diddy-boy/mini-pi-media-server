#!/bin/bash
# MINI-PI NETWORK & SERVICE VERIFICATION TOOL
# This is a verification tool to view the current network configuration

echo "****************************************************"
echo "*          MINI-PI POST-INSTALL DIAGNOSTIC         *"
echo "****************************************************"

# 1. IP Address Verification
IP_WLAN=$(ip addr show wlan0 | grep "inet " | awk '{print $2}')
echo ">> WLAN0 IP Address: $IP_WLAN"
if [[ "$IP_WLAN" == *"192.168.50.1"* ]]; then
    echo "   [PASS] Access Point is on the correct 192.168.50.1 subnet."
else
    echo "   [FAIL] Access Point is on the wrong IP (likely 10.42.0.1)."
fi

# 2. Routing/Forwarding Check
FORWARD=$(cat /proc/sys/net/ipv4/ip_forward)
echo ">> Kernel IP Forwarding: $FORWARD"
if [ "$FORWARD" -eq 1 ]; then
    echo "   [PASS] Routing between WiFi and Ethernet is enabled."
else
    echo "   [FAIL] Routing is disabled. Internet sharing will not work."
fi

# 3. Firewall Zone Check (Critical for Pi 5)
ZONE=$(nmcli -t -f connection.zone con show "MiniPi-AP" | cut -d: -f2)
echo ">> NetworkManager Zone: ${ZONE:-Default}"
if [[ "$ZONE" == "trusted" ]] || [[ "$ZONE" == "internal" ]]; then
    echo "   [PASS] Firewall zone allows local service access."
else
    echo "   [FAIL] Zone is too restrictive. Services might be invisible."
fi

# 4. Service Binding Check
echo ">> Service Availability (192.168.50.1):"
# Check Apache (Port 80)
if nc -z 192.168.50.1 80 2>/dev/null; then
    echo "   [OK] Apache Web Server is REACHABLE."
else
    echo "   [!!] Apache is NOT responding on the WiFi IP."
fi

# Check Cockpit (Port 9090)
if nc -z 192.168.50.1 9090 2>/dev/null; then
    echo "   [OK] Cockpit Dashboard is REACHABLE."
else
    echo "   [!!] Cockpit is NOT responding on the WiFi IP."
fi

# Check MiniDLNA (Port 8200)
if nc -z 192.168.50.1 8200 2>/dev/null; then
    echo "   [OK] MiniDLNA Media Server is REACHABLE."
else
    echo "   [!!] MiniDLNA is NOT responding. Check /etc/minidlna.conf"
fi

echo "===================================================="
