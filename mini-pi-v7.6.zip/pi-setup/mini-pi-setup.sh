#!/bin/bash
#   Mini-Pi-setup
# this is the main setup script to install and configure Apache, cockpit, samba and minidlna
# The supporting folders and files are needed in this exact folder layout in order to install.
# New versions can be downloaded by running :-
# wget -qO- https://raw.githubusercontent.com/diddy-boy/mini-pi-media-server/main/install.sh | bash


set -euo pipefail
IFS=$'\n\t'
export DEBIAN_FRONTEND=noninteractive
VERSION="7.6"

# --- Explicit Paths ---
BASE_DIR="/home/pi/pi-setup"
CONFIG_DIR="$BASE_DIR/configs"
WEB_DIR="$BASE_DIR/web"
IMAGE_DIR="$BASE_DIR/images"

# --- Tracking Variables for Summary ---
CHOICE_SAMBA="[ SKIPPED ]"
CHOICE_SYNC="[ DISABLED ]"
CHOICE_WIFI="[ DISABLED ]"
CHOICE_SCRAPER="[ DISABLED ]"
CHOICE_MKV="[ DISABLED ]"
CHOICE_gdrive="[ DISABLED ]"
CHOICE_TORRENT="[ DISABLED ]"
CHOICE_DISC="[ DISABLED ]"


# Set user to pi explicitly based on your requirements
CURRENT_USER="pi"
HOME_DIR="/home/pi"

sudo apt-get install -y dialog

# Elevate privileges if not running as root
if [ "$EUID" -ne 0 ]; then
    dialog --msgbox "To configure system services like Samba and Apache, this script needs administrative permissions. We will now restart using 'sudo'." 8 60
    exec sudo bash "$0" "$@"
fi

disable_usb_power_warning() {
    # Only applies to Raspberry Pi 5
    local MODEL
    MODEL=$(tr -d '\0' < /proc/device-tree/model 2>/dev/null || echo "unknown")
    if [[ "$MODEL" != *"Raspberry Pi 5"* ]]; then
        return
    fi
    local CONFIG_FILE="/boot/firmware/config.txt"
    if [ ! -f "$CONFIG_FILE" ]; then
        return
    fi
    if ! grep -q "usb_max_current_enable=1" "$CONFIG_FILE"; then
        echo "usb_max_current_enable=1" >> "$CONFIG_FILE"
    fi
}

display_header() {
    clear
    dialog --title "Mini-Pi Media Server Setup - v$VERSION" \
           --msgbox "Welcome! This guide will transform your Pi into a full-featured media server.\n\nWe will set up file sharing, web access, and media management for the user '$CURRENT_USER'." 10 60

    # The Upgrade Tip
    dialog --title "Upgrade Tip" \
           --msgbox "UPGRADING? If you have already configured this server and are just running an update, you can select 'No' on reconfiguration prompts (like WiFi or Samba) to keep your existing settings." 10 60
}

install_packages() {
dialog --infobox "Preparing package installation..." 5 50
{
echo 5
echo "# Updating package lists..."
apt-get update -q

echo 20
echo "# Upgrading existing packages..."
apt-get upgrade -y -q

echo 40
echo "# Installing core utilities..."
apt-get install -y -q --no-install-recommends \
    nano fastfetch

echo 55
echo "# Installing media services..."
apt-get install -y -q --no-install-recommends \
    samba minidlna exfatprogs ntfs-3g cifs-utils

echo 70
echo "# Installing web server..."
apt-get install -y -q --no-install-recommends \
    apache2 php php-cli php-common php-mbstring

echo 85
echo "# Installing admin tools..."
apt-get install -y -q --no-install-recommends \
    cockpit expect network-manager

echo 95
echo "# Installing network tools..."
apt-get install -y -q --no-install-recommends \
    hostapd dnsmasq iw iproute2 bc ffmpeg python3-minimal python3-pip inotify-tools

echo 100
echo "# Packages installed successfully!"

} | dialog --gauge "Installing required packages..." 10 70 0

    # --- Disable cloud-init ---
    # Cloud-init is a VM provisioning tool for AWS/Azure — serves no purpose on a Pi.
    # Disabling it recovers ~20 MB of RAM and reduces swap pressure on low-memory models.
    dialog --infobox "Disabling cloud-init (not needed on a Pi)..." 5 60
    systemctl disable cloud-init cloud-init-local cloud-config cloud-final 2>/dev/null || true
    systemctl stop cloud-init cloud-init-local cloud-config cloud-final 2>/dev/null || true
    touch /etc/cloud/cloud-init.disabled

    # --- Disable exim4 ---
    # Exim4 is a mail transfer agent installed by default on Pi OS — not needed on a
    # media server. Disabling it recovers ~5 MB of swap and reduces background activity.
    dialog --infobox "Disabling exim4 mail server (not needed on a Pi)..." 5 60
    systemctl disable exim4 2>/dev/null || true
    systemctl stop exim4 2>/dev/null || true

    systemctl enable cockpit.socket

    # --- Cockpit Performance Config ---
    # Disables unused modules, suppresses HTTPS nag on LAN, and closes idle sessions.
    mkdir -p /etc/cockpit
    cat > /etc/cockpit/cockpit.conf << 'EOF'
[WebService]
# Suppress HTTPS warning — this is a trusted local network server
AllowUnencrypted = true

[Session]
# Close idle sessions after 15 minutes to release RAM (socket activation restores it)
IdleTimeout = 15

[Plugins]
# Disable pages irrelevant to a Pi media server:
# sosreport = Red Hat diagnostic tool, kdump = kernel crash dumps,
# selinux = not used on Pi OS (AppArmor), packagekit = GUI package manager
DisabledPackages = sosreport kdump selinux packagekit
EOF

    # --- Cockpit Login Branding ---
    mkdir -p /etc/cockpit/branding/debian
    cp --force "$IMAGE_DIR/bg-plain.jpg" /etc/cockpit/branding/debian/
    cat > /etc/cockpit/branding/debian/branding.css << 'EOF'
#login-page-container {
    background-image: url("bg-plain.jpg");
    background-size: cover;
    background-position: center;
}
EOF

    # install navigator plug in for cockpit to allow navigation of files and folders
    dialog --infobox "Installing Cockpit Navigator (remote admin)..." 5 60
    wget -q https://github.com/45Drives/cockpit-navigator/releases/download/v0.5.10/cockpit-navigator_0.5.10-1focal_all.deb
    dpkg -i ./cockpit-navigator_0.5.10-1focal_all.deb
    rm ./cockpit-navigator_0.5.10-1focal_all.deb
}

check_files() {
    dialog --infobox "Checking all files are present before setting up..." 5 60
    local missing=0
    # Check key directories
    for dir in "$CONFIG_DIR" "$WEB_DIR" "$IMAGE_DIR"; do
        if [ ! -d "$dir" ]; then
            dialog --msgbox "Error: Directory $dir not found!" 8 60
            missing=1
        fi
    done

    if [ $missing -eq 1 ]; then exit 1; fi
}

copy_configs() {
    dialog --infobox "Copying files and config files..." 5 60
    
    # Create media structure
    mkdir -p /var/lib/minidlna/{Video,Music,Pictures}
    mkdir -p /media/usb
    
    if [ ! -d "/var/lib/minidlna/Video/Web" ]; then
        mkdir -p /var/lib/minidlna/Video/Web
    fi

    # 1. CLEANUP RECURSIVE LINKS
# Remove symlinks that point back into the minidlna directory
find /var/lib/minidlna -type l -lname '*var/lib/minidlna*' -delete


    # 2. Copy new Media files needed for Apache web backgrounds
    cp --force "$IMAGE_DIR"/{1,2,3,4,5,6,7}.mp4 /var/lib/minidlna/Pictures/
    cp --force "$IMAGE_DIR"/{10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,mini-pi}.jpg /var/lib/minidlna/Pictures/
    
    # 3. Copy System Scripts & Configs
    cp --force "$CONFIG_DIR/usb_sync.sh" /usr/local/bin/
    chmod +x /usr/local/bin/usb_sync.sh
    cp --force "$CONFIG_DIR/99-usb-autosync.rules" /etc/udev/rules.d/
    cp --force "$CONFIG_DIR/usb_sync.service" /etc/systemd/system/
    cp --force "$CONFIG_DIR/motd" /etc/motd
    sed "s/SAMBA_USER/$CURRENT_USER/" "$CONFIG_DIR/smb.conf" > /etc/samba/smb.conf
    cp --force "$CONFIG_DIR/minidlna.conf" /etc/
    cp --force "$CONFIG_DIR/mkv-common.sh" /usr/local/bin/
    chmod +x /usr/local/bin/mkv-common.sh
    cp --force "$CONFIG_DIR/mkv-promote.sh" /usr/local/bin/
    chmod +x /usr/local/bin/mkv-promote.sh
    cp --force "$CONFIG_DIR/mkv-convert.sh" /usr/local/bin/
    chmod +x /usr/local/bin/mkv-convert.sh
    cp --force "$CONFIG_DIR/mkv-subtitles.sh" /usr/local/bin/
    chmod +x /usr/local/bin/mkv-subtitles.sh
    cp --force "$CONFIG_DIR/mkv-scrape.sh" /usr/local/bin/
    chmod +x /usr/local/bin/mkv-scrape.sh
    cp --force "$CONFIG_DIR/mkv-2-mp4.sh" /usr/local/bin/
    chmod +x /usr/local/bin/mkv-2-mp4.sh
    cp --force "$CONFIG_DIR/mkv-watcher.sh" /usr/local/bin/
    chmod +x /usr/local/bin/mkv-watcher.sh
    # archive-movie-downloader.sh already lives directly in $BASE_DIR (extracted
    # alongside this setup script from the GitHub zip), so no copy is
    # needed - just make sure it's executable. Guarded so a missing file
    # (this is an optional extra) can't abort the whole setup.
    if [ -f "$BASE_DIR/archive-movie-downloader.sh" ]; then
        chmod +x "$BASE_DIR/archive-movie-downloader.sh"
    fi

    # 4. clean out Apache Web Files (Apache Root)   
    find /var/www/html -mindepth 1 -delete
    sleep 2
    cp --force $WEB_DIR/{index.html,sync_status.php,disk_status.php,wifi_status.php,get_backgrounds.php,qrcode.min.js,check_updates.php,remote.html,remote_heartbeat.php,remote_devices.php,remote_files.php,remote_command.php} /var/www/html/
    cp --force $IMAGE_DIR/{logo.png,movie.png,music.png,debian-logo.png} /var/www/html/
    cp --force "$CONFIG_DIR/000-default.conf" /etc/apache2/sites-enabled/
    # RE-WRITE VERSION FILE HERE instead of at the top of the script
    echo "$VERSION" > /var/www/html/version.txt
    chown www-data /var/www/html/version.txt

    # 5. Web Files (MiniDLNA Overlays)
    cp --force "$WEB_DIR/get_files.php" /var/lib/minidlna/
    cp --force "$WEB_DIR/index.php" /var/lib/minidlna/
    
	# --- PHP Optimization for Pi Zero 2 W ---
	echo "Configuring PHP for large file uploads..."

	# Detect total RAM and set PHP memory limit proportionally (half of RAM, tiered by board)
	TOTAL_RAM_MB=$(awk '/MemTotal/ {printf "%d", $2/1024}' /proc/meminfo)

	if [ "$TOTAL_RAM_MB" -ge 14000 ]; then
    	PHP_MEMORY="8192M"   # 16GB Pi 5
	elif [ "$TOTAL_RAM_MB" -ge 7000 ]; then
    	PHP_MEMORY="4096M"   # 8GB Pi 5
	elif [ "$TOTAL_RAM_MB" -ge 3500 ]; then
    	PHP_MEMORY="2048M"   # 4GB Pi 5
	elif [ "$TOTAL_RAM_MB" -ge 1800 ]; then
    	PHP_MEMORY="512M"    # 2GB Pi 5
	elif [ "$TOTAL_RAM_MB" -ge 900 ]; then
    	PHP_MEMORY="384M"    # 1GB Pi 5
else
    PHP_MEMORY="256M"    # Pi Zero 2W / 512MB boards
fi

	echo "Detected ${TOTAL_RAM_MB}MB RAM — setting PHP memory_limit to ${PHP_MEMORY}"

# This finds all php.ini files (Apache and CLI) to ensure settings apply everywhere
PHP_INI_FILES=$(find /etc/php -name php.ini)
if [ -n "$PHP_INI_FILES" ]; then
    for INI in $PHP_INI_FILES; do
        echo "Updating $INI for Pi hardware..."

        # 1. Set 4GB Upload Limits
        sed -i "s/^upload_max_filesize = .*/upload_max_filesize = 4000M/" "$INI"
        sed -i "s/^post_max_size = .*/post_max_size = 4000M/" "$INI"

        # 2. Set Memory Limit scaled to detected RAM
        sed -i "s/^memory_limit = .*/memory_limit = ${PHP_MEMORY}/" "$INI"

        # 3. Set long Timeouts for slow SD card writes
        sed -i "s/^max_execution_time = .*/max_execution_time = 14400/" "$INI"
        sed -i "s/^max_input_time = .*/max_input_time = 14400/" "$INI"
    done

    echo "PHP limits optimized for Apache & CLI (memory_limit=${PHP_MEMORY})."
else
    echo "Warning: No php.ini files found in /etc/php"
fi

    # --- Apache Configuration ---
    a2enmod rewrite
    a2enmod headers
    cp --force "$CONFIG_DIR/000-default.conf" /etc/apache2/sites-available/000-default.conf
    # Ensure the site is enabled (links available to enabled)
    ln -sf /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-enabled/000-default.conf
    configure_apache_performance

    # 6. Set Permissions for Web apache
    # Standard Web Root
    chown -R www-data:www-data /var/www/html
    chmod -R 755 /var/www/html
    chmod 644 /var/www/html/*.php
    
    systemctl daemon-reload
    systemctl restart apache2
}

configure_apache_performance() {
    dialog --infobox "Applying Apache performance optimisations for Pi..." 5 60

    # --- 1. Switch to event MPM (much lower RAM use than prefork) ---
    # a2enmod refuses to enable event while prefork is still active even if
    # a2dismod ran first — both must be done in the same command to avoid
    # the "needs to be disabled first" conflict error.
    a2dismod mpm_prefork mpm_worker mpm_itk 2>/dev/null || true
    a2enmod mpm_event 2>/dev/null || true

    # --- 2. Enable sendfile — video streaming bypasses Apache memory entirely ---
    if grep -q "^EnableSendfile" /etc/apache2/apache2.conf; then
        sed -i "s/^EnableSendfile.*/EnableSendfile On/" /etc/apache2/apache2.conf
    else
        echo "EnableSendfile On" >> /etc/apache2/apache2.conf
    fi

    # --- 3. Drop-in performance config ---
    # Written to conf-available and symlinked; safe to remove if needed.
    cat > /etc/apache2/conf-available/pi-performance.conf << 'EOF'
# Pi Media Server — performance tuning (written by mini-pi-setup.sh)

# AllowOverride None — eliminates 3-6 extra filesystem stats per request.
# The mini-pi web root does not use .htaccess files so this is zero-risk.
<Directory /var/www/html>
    AllowOverride None
</Directory>

# event MPM — ~40-60% less RAM per connection vs prefork.
# Conservative values tuned for Pi Zero 2W (512 MB) upward.
<IfModule mpm_event_module>
    StartServers          2
    MinSpareThreads       4
    MaxSpareThreads       8
    ThreadLimit          16
    ThreadsPerChild       8
    MaxRequestWorkers    32
    MaxConnectionsPerChild 500
</IfModule>

# Compress HTML/JSON responses only — never compress media files
# (they are already compressed; compressing them wastes CPU and gains nothing).
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain application/json
</IfModule>

# Minimal access log — fewer SD card writes extends card lifespan.
# Errors are still logged in full.
LogLevel warn
EOF

    a2enconf pi-performance

    # --- 4. Disable unused modules ---
    # Only truly unattended-safe modules are listed here.
    # auth_basic / authn_file / authz_groupfile — Debian marks these "essential";
    #   a2dismod demands a typed confirmation phrase and aborts without it.
    # negotiation — required by some default Apache configs; removing it breaks startup.
    for MOD in cgi cgid status; do
        a2dismod "$MOD" 2>/dev/null || true
    done
}

set_minidlna_friendly_name() {
    local hostname
    hostname=$(hostname)
    if grep -q "^friendly_name=" /etc/minidlna.conf; then
        sed -i "s/^friendly_name=.*/friendly_name=$hostname/" /etc/minidlna.conf
    else
        echo "friendly_name=$hostname" >> /etc/minidlna.conf
    fi
    dialog --msgbox "Success! Your media library will now appear as '$hostname' on your Smart TV and other DLNA devices." 7 60
}

configure_samba() {
    # Get the hostname for the hint
    LOCAL_HOSTNAME="$(hostname).local"

    # 1. Ask the question first
    # This allows upgrading users to skip password re-entry.
    if dialog --title "Network Sharing (Samba)" \
              --yesno "Do you want to configure or change the network password for user '$CURRENT_USER'?\n\nSelect 'No' if Samba is already working or if you are performing an upgrade." 10 70; then
        
        # 2. Show the input box
        dialog --title "Network Sharing (Samba)" \
               --inputbox "Set a network password for user '$CURRENT_USER'.\n\nThis allows network users to access your Pi at:\n\\\\$LOCAL_HOSTNAME" 11 70 2> /tmp/smbpass

        # 3. Check for empty password
        # If they chose 'Yes' but left it blank, we stop to prevent partial configuration.
        if [ ! -s /tmp/smbpass ]; then
            dialog --msgbox "Error: No password provided. Please try again." 7 60
            return 1
        fi

        # 4. Ensure the system user exists
        if ! id "$CURRENT_USER" >/dev/null 2>&1; then
            adduser --system --no-create-home "$CURRENT_USER"
        fi

        # 5. Automate password entry using Expect
        password=$(cat /tmp/smbpass)
        export SMB_PASS="$password"
        export SMB_USER="$CURRENT_USER"

        /usr/bin/expect << 'EOF'
set timeout 10
spawn smbpasswd -a $env(SMB_USER)
expect {
    "New SMB password:" { send "$env(SMB_PASS)\r"; exp_continue }
    "Retype new SMB password:" { send "$env(SMB_PASS)\r"; exp_continue }
    eof
}
EOF

        # 6. Cleanup sensitive data
        unset SMB_PASS
        unset SMB_USER
        rm -f /tmp/smbpass
        
        CHOICE_SAMBA="[ CONFIGURED ]"
        dialog --msgbox "Samba password updated for '$CURRENT_USER'." 7 60
    else
        # 7. IF THEY SAY NO: Mark it as unchanged for the summary.
        CHOICE_SAMBA="[ UNCHANGED ]"
    fi

    # --- 8. Always maintain the symlink and permissions (Safe for upgrades) ---
    # These checks ensure the media folder link remains healthy regardless of password changes.
    SYMLINK_PATH="$HOME_DIR/minidlna-link"
    if [ -L "$SYMLINK_PATH" ]; then
        if [ "$(readlink -f "$SYMLINK_PATH")" != "/var/lib/minidlna" ]; then
            rm "$SYMLINK_PATH"
            ln -s /var/lib/minidlna "$SYMLINK_PATH"
        fi
    elif [ -e "$SYMLINK_PATH" ]; then
        dialog --msgbox "$SYMLINK_PATH exists and is not a symlink. Skipping symlink creation." 6 60
    else
        ln -s /var/lib/minidlna "$SYMLINK_PATH"
    fi
    chown "$CURRENT_USER:$CURRENT_USER" "$SYMLINK_PATH"
}

setup_media_scraper() {
    dialog --infobox "Setting up Media Scraper Service and Metadata directories..." 5 60
    
    mkdir -p /home/pi/scraper
    # 1. Install system dependencies for media scraper
    apt-get install -y python3-venv python3-full
    
    # 2. Setup Metadata directory structure
    mkdir -p /var/lib/minidlna/.metadata/posters
    
    # 3. Setup Scraper application directory
    local SCRAPER_DIR="/home/$CURRENT_USER/scraper"
    
    if [ -f "$BASE_DIR/scraper.py" ]; then
        # Declared unconditionally (not just on the upgrade path below) so the
        # -n checks after the cp never hit an unbound variable under set -u
        # on a genuinely fresh install, where $SCRAPER_DIR/scraper.py doesn't
        # exist yet and this block would otherwise never run.
        local SAVED_KEY="" SAVED_USER="" SAVED_PASS=""
        if [ -f "$SCRAPER_DIR/scraper.py" ]; then
            # Preserve existing credentials before overwriting
            SAVED_KEY=$(grep -E '^OPENSUBTITLES_API_KEY\s*=' "$SCRAPER_DIR/scraper.py" 2>/dev/null | tail -n1 | sed -E "s/^[A-Z_]+\s*=\s*//; s/^['\"]+//; s/['\"]+\$//")
            SAVED_USER=$(grep -E '^OPENSUBTITLES_USERNAME\s*=' "$SCRAPER_DIR/scraper.py" 2>/dev/null | tail -n1 | sed -E "s/^[A-Z_]+\s*=\s*//; s/^['\"]+//; s/['\"]+\$//")
            SAVED_PASS=$(grep -E '^OPENSUBTITLES_PASSWORD\s*=' "$SCRAPER_DIR/scraper.py" 2>/dev/null | tail -n1 | sed -E "s/^[A-Z_]+\s*=\s*//; s/^['\"]+//; s/['\"]+\$//")
        fi

        cp "$BASE_DIR/scraper.py" "$SCRAPER_DIR/"

        # Re-inject saved credentials into the freshly copied scraper.py
        if [ -n "$SAVED_KEY" ] && [ -n "$SAVED_USER" ] && [ -n "$SAVED_PASS" ]; then
            export SAVED_KEY SAVED_USER SAVED_PASS SCRAPER_DIR
            python3 - << 'EOF'
import os, re, sys

def py_str_literal(s):
    # Always emit a plain double-quoted literal (never single-quoted),
    # so the bash-side extraction (which strips '"') stays reliable.
    escaped = s.replace('\\', '\\\\').replace('"', '\\"')
    return f'"{escaped}"'

target_file = os.path.join(os.environ['SCRAPER_DIR'], 'scraper.py')
with open(target_file, 'r') as f:
    content = f.read()

content = re.sub(r'(^OPENSUBTITLES_API_KEY\s*=\s*).*',  lambda m: m.group(1) + py_str_literal(os.environ["SAVED_KEY"]),  content, flags=re.M)
content = re.sub(r'(^OPENSUBTITLES_USERNAME\s*=\s*).*', lambda m: m.group(1) + py_str_literal(os.environ["SAVED_USER"]), content, flags=re.M)
content = re.sub(r'(^OPENSUBTITLES_PASSWORD\s*=\s*).*', lambda m: m.group(1) + py_str_literal(os.environ["SAVED_PASS"]), content, flags=re.M)

with open(target_file, 'w') as f:
    f.write(content)
EOF
            unset SAVED_KEY SAVED_USER SAVED_PASS
        fi
    else
        dialog --msgbox "Error: $BASE_DIR/scraper.py not found!" 8 60
    fi

    # 4. Create/Upgrade Virtual Environment and install packages safely
    cd "$SCRAPER_DIR"
    
    # Self-healing upgrade logic for existing users
    if [ -f "venv/bin/pip" ]; then
        # Quietly purge old package names if they exist to prevent log spam
        ./venv/bin/pip uninstall -y duckduckgo_search subliminal babelfish > /dev/null 2>&1
    else
        # Fresh virtual environment generation for new users
        python3 -m venv venv
    fi

    # subliminal and babelfish no longer needed — we use the OpenSubtitles REST API directly
    ./venv/bin/pip install --upgrade "urllib3<2.5.0" "chardet<6.0.0" requests parse-torrent-title ddgs Pillow beautifulsoup4
    chown -R "$CURRENT_USER:$CURRENT_USER" "$SCRAPER_DIR"

    # 5. OpenSubtitles credentials (optional — for subtitle downloads)
    # Check if credentials are already filled in from a previous install
    local EXISTING_KEY EXISTING_USER EXISTING_PASS
    EXISTING_KEY=$(grep -E '^OPENSUBTITLES_API_KEY\s*=' "$SCRAPER_DIR/scraper.py" 2>/dev/null | tail -n1 | sed -E "s/^[A-Z_]+\s*=\s*//; s/^['\"]+//; s/['\"]+\$//")
    EXISTING_USER=$(grep -E '^OPENSUBTITLES_USERNAME\s*=' "$SCRAPER_DIR/scraper.py" 2>/dev/null | tail -n1 | sed -E "s/^[A-Z_]+\s*=\s*//; s/^['\"]+//; s/['\"]+\$//")

    if [ -n "$EXISTING_KEY" ] && [ -n "$EXISTING_USER" ]; then
        # Credentials already set — ask if they want to change them
        if dialog --title "OpenSubtitles Credentials" \
                  --defaultno \
                 --yesno "OpenSubtitles credentials are already configured:\n\n  User: $EXISTING_USER\n  API Key: ${EXISTING_KEY:0:8}...\n\nDo you want to replace them?" 11 65; then
            _prompt_opensubtitles_credentials "$SCRAPER_DIR"
        fi
    else
        # No credentials set — explain and offer to configure
		dialog --title "Subtitle Downloads (Optional)" \
               --msgbox "The media scraper can automatically download subtitles for your films.\n\nThis requires a FREE account at:\nhttps://www.opensubtitles.com\n\nOnce registered:\n  1. Log in and go to your profile\n  2. Visit: opensubtitles.com/en/consumers\n  3. Create a consumer and copy the API key\n\nFree accounts get 20 subtitle downloads per day.\nSelect No on the next screen to skip this for now." 20 70
        
        if dialog --title "Configure Subtitles?" \
                  --yesno "Do you want to enter your OpenSubtitles credentials now?" 7 60; then
            _prompt_opensubtitles_credentials "$SCRAPER_DIR"
        fi
    fi

    # 6. Create the Systemd Service
    cat << EOF > /etc/systemd/system/media-scraper.service
[Unit]
Description=Media Metadata Scraper
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=$CURRENT_USER
WorkingDirectory=$SCRAPER_DIR
ExecStartPre=/bin/bash -c 'ping -c 1 8.8.8.8 > /dev/null 2>&1'

ExecStart=$SCRAPER_DIR/venv/bin/python3 scraper.py
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

    # 7. Create the Systemd Timer (5am)
    cat << EOF > /etc/systemd/system/media-scraper.timer
[Unit]
Description=Run Media Scraper daily at 5am

[Timer]
OnCalendar=*-*-* 05:00:00
Persistent=true
Unit=media-scraper.service

[Install]
WantedBy=timers.target
EOF

    # 8. Enable and Start
    systemctl daemon-reload
    systemctl enable media-scraper.timer
    systemctl start media-scraper.timer
    CHOICE_SCRAPER="[ ENABLED ]"

    dialog --msgbox "Media Scraper installed.\n\nPath: $SCRAPER_DIR\nPosters & Synopsis: /var/lib/minidlna/.metadata/posters\nTimer: 5:00 AM" 12 60
}

_prompt_opensubtitles_credentials() {
    local SCRAPER_DIR="$1"
    local OS_KEY OS_USER OS_PASS

    OS_KEY=$(dialog --title "OpenSubtitles API Key" \
                    --inputbox "Paste your OpenSubtitles API key:\n(from opensubtitles.com/en/consumers)" 9 65 \
                    3>&1 1>/dev/tty 2>&3)
    [ -z "$OS_KEY" ] && return

    OS_USER=$(dialog --title "OpenSubtitles Username" \
                     --inputbox "Enter your OpenSubtitles username:" 8 65 \
                     3>&1 1>/dev/tty 2>&3)
    [ -z "$OS_USER" ] && return

    OS_PASS=$(dialog --title "OpenSubtitles Password" \
                     --passwordbox "Enter your OpenSubtitles password:" 8 65 \
                     3>&1 1>/dev/tty 2>&3)
    [ -z "$OS_PASS" ] && return

    dialog --infobox "Securely writing credentials to scraper.py..." 5 50

    export OS_KEY OS_USER OS_PASS SCRAPER_DIR

    python3 - << 'EOF'
import os
import re
import sys

target_file = os.path.join(os.environ.get('SCRAPER_DIR', '/home/pi/scraper'), 'scraper.py')
if not os.path.exists(target_file):
    print(f"Error: {target_file} not found", file=sys.stderr)
    sys.exit(1)

with open(target_file, 'r') as f:
    content = f.read()

def py_str_literal(s):
    # Always emit a plain double-quoted literal (never single-quoted),
    # so the bash-side extraction (which strips '"') stays reliable.
    escaped = s.replace('\\', '\\\\').replace('"', '\\"')
    return f'"{escaped}"'

content = re.sub(r'(^OPENSUBTITLES_API_KEY\s*=\s*).*',  lambda m: m.group(1) + py_str_literal(os.environ.get('OS_KEY', '')),  content, flags=re.M)
content = re.sub(r'(^OPENSUBTITLES_USERNAME\s*=\s*).*', lambda m: m.group(1) + py_str_literal(os.environ.get('OS_USER', '')), content, flags=re.M)
content = re.sub(r'(^OPENSUBTITLES_PASSWORD\s*=\s*).*', lambda m: m.group(1) + py_str_literal(os.environ.get('OS_PASS', '')), content, flags=re.M)

with open(target_file, 'w') as f:
    f.write(content)
EOF

    unset OS_KEY OS_USER OS_PASS SCRAPER_DIR

    dialog --msgbox "OpenSubtitles credentials saved.\n\nSubtitles will be downloaded automatically each night." 8 60
}

setup_mkv_conversion_service() {
    local SERVICE_FILE="/etc/systemd/system/mkv-conversion.service"
    local WATCHER_SERVICE="/etc/systemd/system/mkv-watcher.service"
    local MKV_CONVERT_ABS_PATH="/usr/local/bin/mkv-2-mp4.sh"
    local MKV_WATCHER_ABS_PATH="/usr/local/bin/mkv-watcher.sh"

    if [ ! -f "$MKV_CONVERT_ABS_PATH" ]; then
        dialog --msgbox "MKV conversion script $MKV_CONVERT_ABS_PATH not found." 10 70
        return
    fi

    # Check inotifywait is available
    if ! command -v inotifywait > /dev/null 2>&1; then
        dialog --msgbox "inotify-tools not installed.\n\nRun: apt install inotify-tools" 10 70
        return
    fi

    # Stop watcher if already running (upgrade scenario — ensures new scripts are picked up)
    systemctl stop mkv-watcher.service 2>/dev/null || true

    dialog --infobox "Configuring MKV watcher service..." 5 60

    # -------------------------------------------------------------------------
    # One-shot conversion service (now triggered by watcher, not a timer)
    # Keep this — the watcher calls mkv-2-mp4.sh directly, but having a
    # named service lets you also run it manually: systemctl start mkv-conversion
    # -------------------------------------------------------------------------
    cat << EOF > "$SERVICE_FILE"
[Unit]
Description=MKV to MP4 Conversion (on-demand)
After=network.target

[Service]
Type=oneshot
ExecStart=/bin/bash $MKV_CONVERT_ABS_PATH
User=root
Group=root
WorkingDirectory=/var/lib/minidlna/Video
RemainAfterExit=no
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF

    # -------------------------------------------------------------------------
    # inotify watcher — persistent, restarts on failure
    # -------------------------------------------------------------------------
    cat << EOF > "$WATCHER_SERVICE"
[Unit]
Description=MKV file watcher (inotify-driven conversion trigger)
After=network.target
# Restart if it dies unexpectedly (e.g. inotifywait gets killed)
StartLimitIntervalSec=60
StartLimitBurst=5

[Service]
Type=simple
ExecStart=/bin/bash $MKV_WATCHER_ABS_PATH
User=root
Group=root
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable mkv-watcher.service
    systemctl start mkv-watcher.service

    if systemctl is-active --quiet mkv-watcher.service; then
        local status="ACTIVE"
    else
        local status="FAILED TO START"
    fi

    dialog --msgbox "MKV Auto-Conversion: $status\n\
\n\
Any MKV file arriving in your Video folder will now be\n\
automatically converted to MP4 — no midnight schedule needed.\n\
\n\
Triggered by: New file arriving via Transmission, Samba, or Upload\n\
Watcher log:  journalctl -u mkv-watcher -f\n\
Manual run:   systemctl start mkv-conversion" 14 70
}

offer_mkv_conversion() {
    setup_mkv_conversion_service && CHOICE_MKV="[ ENABLED ]" || CHOICE_MKV="[ FAILED ]"
    return 0
}

setup_transmission() {
    dialog --title "Legal Notice" \
       --msgbox "Transmission allows you to download files directly to your Video directory.\n\nPlease use this tool responsibly. The author of this script is not responsible for any misuse or fraudulent activity." 10 70

    dialog --infobox "Setting up Transmission... Please wait." 5 60

    # 1. Install Transmission
    apt-get install -y -q transmission-daemon
    
    # 2. Stop service to edit settings safely
    systemctl stop transmission-daemon

    # 3. Use sed to update settings.json
    local CONFIG="/etc/transmission-daemon/settings.json"
    
    # Apply your specific requirements
    sed -i 's|"download-dir": ".*"|"download-dir": "/var/lib/minidlna/Video"|' "$CONFIG"
    sed -i 's|"incomplete-dir-enabled": .*|"incomplete-dir-enabled": false,|' "$CONFIG"
    sed -i 's|"umask": .*|"umask": 2,|' "$CONFIG"
    sed -i 's|"rpc-authentication-required": .*|"rpc-authentication-required": true,|' "$CONFIG"
    sed -i 's|"rpc-username": ".*"|"rpc-username": "pi"|' "$CONFIG"
    sed -i 's|"rpc-password": ".*"|"rpc-password": "pi"|' "$CONFIG"
    
    # Optimized whitelist for your dual-network setup
    sed -i 's|"rpc-whitelist": ".*"|"rpc-whitelist": "127.0.0.1,192.168.*.*"|' "$CONFIG"
    
    # Create the folder
    mkdir -p /var/lib/minidlna/Video
    
    CHOICE_TORRENT="[ ENABLED ]"
dialog --title "Installation Complete" \
--msgbox "Torrent downloader setup.\n\nLogin is 'pi' and password is 'pi'." 8 50
}

offer_disc_ripping() {
    if dialog --title "CD/DVD Ripping" \
          --defaultno \
          --yesno "Would you like to install CD and DVD ripping capabilities?\n\nThis feature automatically:\n • Rips Audio CDs to MP3 files\n • Rips DVD-Video discs to VOB files\n • Imports media into your Mini-Pi library\n\nRecommended only for Raspberry Pi 4B and above.\nRequires a compatible USB optical drive." \
          16 70; then
        setup_disc_ripping
    else
        CHOICE_DISC="[ DISABLED ]"
    fi
}

setup_disc_ripping() {
    dialog --infobox "Installing CD/DVD ripping support..." 5 60

    if ! apt-get install -y abcde vobcopy eject lame libdvdread8t64 libdvd-pkg jq lsdvd id3v2 eyed3; then
        CHOICE_DISC="[ FAILED ]"
        dialog --msgbox "Failed to install CD/DVD ripping packages." 7 60
        return 1
    fi

    DEBIAN_FRONTEND=noninteractive dpkg-reconfigure libdvd-pkg

    #
    # abcde configuration
    #
    cat > /etc/abcde.conf << 'EOF'
OUTPUTTYPE=mp3
OUTPUTDIR=/var/lib/minidlna/Music
OUTPUTFORMAT='${ALBUMFILE}/${TRACKNUM} - ${TRACKFILE}'
VAOUTPUTFORMAT='${ALBUMFILE}/${TRACKNUM}/${TRACKNUM} - ${TRACKFILE}'
LOWDISK=n
EYED3=/usr/bin/eyeD3
ID3V2=y
CDDBMETHOD=cddb
CDDBHOST=gnudb.gnudb.org
CDDBPORT=8880
CDDBPROTO=6
EOF


    if [ ! -f "$CONFIG_DIR/disc-handler.sh" ]; then
        CHOICE_DISC="[ FAILED ]"
        dialog --msgbox "Error: disc-handler.sh not found in $CONFIG_DIR" 7 60
        return 1
    fi
    #
    # Install disc handler
    #
    cp --force "$CONFIG_DIR/disc-handler.sh" /usr/local/bin/
    chmod +x /usr/local/bin/disc-handler.sh
    cp --force "$CONFIG_DIR/optical_status.php" /var/www/html/
    chown www-data /var/www/html/optical_status.php
    chgrp www-data /var/www/html/optical_status.php

    #
    # systemd service
    #
    cat > /etc/systemd/system/disc-handler.service << 'EOF'
[Unit]
Description=Handle inserted CD/DVD
After=systemd-udevd.service

[Service]
Type=oneshot
ExecStart=/usr/local/bin/disc-handler.sh
TimeoutStartSec=0
EOF

    #
    # udev rule
    #
    cat > /etc/udev/rules.d/99-disc-handler.rules << 'EOF'
ACTION=="change", KERNEL=="sr0", ENV{ID_CDROM}=="1", ENV{DISK_MEDIA_CHANGE}=="1", TAG+="systemd", ENV{SYSTEMD_WANTS}+="disc-handler.service"
EOF

    # Ensure the scratch / working directory exists for vobcopy working and is writable
    mkdir -p /var/lib/minidlna/.tmp_rip
    chown pi:minidlna /var/lib/minidlna/.tmp_rip
    chmod 775 /var/lib/minidlna/.tmp_rip

    systemctl daemon-reload
    udevadm control --reload-rules

    CHOICE_DISC="[ ENABLED ]"

    dialog --msgbox \
    "CD/DVD ripping support installed.\n\nYou can insert a supported Audio CD or DVD-Video disc into a USB DVD Drive and ripping will begin automatically." \
    9 80
}

show_final_summary() {
    local ap_details=""
    
    if [ "$CHOICE_WIFI" = "[ ENABLED ]" ]; then
        local ap_name=$(nmcli -t -f NAME,IP4.METHOD connection show | grep ":shared" | cut -d: -f1 | head -n1)
        if [ -n "$ap_name" ]; then
            local actual_ssid=$(nmcli -s -g 802-11-wireless.ssid connection show "$ap_name")
            local actual_pass=$(nmcli -s -g 802-11-wireless-security.psk connection show "$ap_name")
            ap_details="\n    - Wi-Fi Name:             $actual_ssid\n    - Wi-Fi Password:         $actual_pass"
        else
            ap_details="\n    - Status: WiFI access point will not be activated until reboot"
        fi
    fi
    IP_ADDR=$(hostname -I | awk '{print $1}')

    local msg="Setup Complete! Here is your server summary:\n\n\
    - User Account:            $CURRENT_USER\n\
    - Samba Access:            $CHOICE_SAMBA\n\
    - File Sharing:            Samba (User: $CURRENT_USER)\n\
    - Web Interface:           http://$IP_ADDR\n\
    - Remote Server Sync:      $CHOICE_SYNC\n\
    - Google Drive Sync:       $CHOICE_gdrive\n\
    - Torrent Downloader:      $CHOICE_TORRENT\n\
    - WiFi Mode:               $CHOICE_WIFI$ap_details\n\
    - Media Scraper:           $CHOICE_SCRAPER\n\
    - MKV Conversion:          $CHOICE_MKV\n\
    - CD/DVD Ripping:          $CHOICE_DISC\n\n\
The system will now reboot."

    dialog --title "Installation Summary" --msgbox "$msg" 18 70
}

finalize_setup() {
    
     # 1. Remote Server Sync Configuration
    SYNC_CHOICE=$(dialog --clear \
                --title " Remote Server Sync " \
                --menu "\nSelect your preferred media sync method:" 15 60 3 \
                1 "Mirror sync from remote server (uses same space as server)" \
                2 "Sync from a server for the past X months (Rotating)" \
                3 "Skip / Don't change current sync" \
                3>&1 1>/dev/tty 2>&3)

    case $SYNC_CHOICE in
        1)
            if [ -f "$BASE_DIR/configure_server_sync.sh" ]; then
                bash "$BASE_DIR/configure_server_sync.sh"
                CHOICE_SYNC="[ MIRROR ]"
            else
                dialog --msgbox "Error: configure_server_sync.sh not found!" 8 60
                CHOICE_SYNC="[ FILE MISSING ]"
            fi
            ;;
        2)
            if [ -f "$BASE_DIR/rotating-server-sync.sh" ]; then
                bash "$BASE_DIR/rotating-server-sync.sh"
                CHOICE_SYNC="[ ROTATING ]"
            else
                dialog --msgbox "Error: rotating-server-sync.sh not found!" 8 60
                CHOICE_SYNC="[ FILE MISSING ]"
            fi
            ;;
        3) CHOICE_SYNC="[ DISABLED ]" ;;
    esac

    # 2. Cloud Drive Sync choice
    if dialog --title "Cloud Drive Sync" --yesno "Would you like to set up Cloud sync?" 7 60; then
        if [ -f "$BASE_DIR/rclone-setup.sh" ]; then
            bash "$BASE_DIR/rclone-setup.sh"
            CHOICE_gdrive="[ CONFIGURED ]"
        else
            dialog --msgbox "Error: rclone-setup.sh not found!" 8 60
            CHOICE_gdrive="[ FILE MISSING ]"
        fi
    else
        CHOICE_gdrive="[ DISABLED ]"
    fi

    # 3. Torrent Downloader Choice
    if dialog --title "Torrent Downloader" --yesno "Would you like to install the Transmission Web-Based Torrent Downloader?" 7 60; then
        setup_transmission
    else
        CHOICE_TORRENT="[ DISABLED ]"
    fi

    # 4. WiFi Reconfiguration
if dialog --title "Reconfigure WiFi" \
--defaultno \
--yesno "Do you want to switch from connecting to your WiFi network to hosting your own Access Point from the Pi?\n\nNOTE: Selecting 'Yes' requires an Ethernet cable to maintain a network connection for this Pi." 12 75; then
        if [ -f "$BASE_DIR/reconfigure-wifi.sh" ]; then
            sudo bash "$BASE_DIR/reconfigure-wifi.sh"
            [ $? -eq 0 ] && CHOICE_WIFI="[ ENABLED ]" || CHOICE_WIFI="[ FAILED ]"
        else
            CHOICE_WIFI="[ FILE MISSING ]"
            dialog --msgbox "Error: reconfigure-wifi.sh not found!" 8 60
        fi
    else
        CHOICE_WIFI="[ SKIPPED ]"
    fi

        # --- Final Permissions Master Fix ---
    # Ensure all services are in the shared group
    usermod -aG minidlna www-data
    usermod -aG minidlna debian-transmission 2>/dev/null || true
    usermod -aG minidlna "$CURRENT_USER"
    usermod -aG www-data "$CURRENT_USER"

    # Set global ownership for the media library
    chown -R pi:minidlna /var/lib/minidlna

    # Apply directory permissions (SetGID bit '2' is the secret sauce)
    find /var/lib/minidlna -type d -exec chmod 2775 {} +

    # Apply file permissions (664 allows Apache/Samba/Pi to read/write)
    find /var/lib/minidlna -type f -exec chmod 664 {} +
    
    # 5. Metadata Security
    # Ensure the hidden metadata folder is fully accessible to the scraper service
    chmod -R 775 /var/lib/minidlna/.metadata 2>/dev/null || true    
    
    show_final_summary

    # Optional extra: Internet Archive Movie Downloader
    # Not run automatically (requires SSH/Cockpit terminal access for the
    # dialog UI), just make sure it's executable and let the user know
    # it's there.
    if [ -f "$BASE_DIR/archive-movie-downloader.sh" ]; then
    dialog --title "Extra: Internet Archive Movie Downloader" --msgbox \
    "An optional tool has been included to browse and download classic films straight into your media library - handy if your library's currently empty and you want something on it to test with.\n\nEverything it fetches is public domain or openly licensed (Internet Archive, Wikimedia Commons, Public Domain Torrents) - completely legal to download and keep, no grey areas.\n\nTo use it, SSH into the Pi (or use the Cockpit terminal), then from the pi-setup folder run:\n\n  ./archive-movie-downloader.sh" \
    16 70
fi

    return 0
}

#--- Run Order ---
display_header
disable_usb_power_warning
check_files
install_packages
copy_configs
set_minidlna_friendly_name
configure_samba
set +e
offer_mkv_conversion
offer_disc_ripping
setup_media_scraper
finalize_setup
set -e

# Final reboot prompt
if dialog --title "Reboot Required" --yesno "The setup is complete. Would you like to reboot now?" 7 60; then
    reboot
fi
