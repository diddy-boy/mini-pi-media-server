<?php
// remote_devices.php
// Returns the list of devices that have heartbeated in the last 30s.
// GET ?exclude=<id> to leave the caller's own id out of the list.

header('Content-Type: application/json');

$storeFile = sys_get_temp_dir() . '/mini-pi-remote/devices.json';
$exclude = isset($_GET['exclude']) ? trim($_GET['exclude']) : '';

$devices = [];
if (file_exists($storeFile)) {
    $devices = json_decode(file_get_contents($storeFile), true);
    if (!is_array($devices)) $devices = [];
}

$now = time();
$result = [];
foreach ($devices as $id => $dev) {
    if (($now - $dev['last_seen']) > 30) continue; // stale, treat as offline
    if ($id === $exclude) continue;
    $result[] = [
        'id' => $id,
        'name' => $dev['name'],
        'seconds_ago' => $now - $dev['last_seen']
    ];
}

usort($result, function ($a, $b) { return $a['seconds_ago'] <=> $b['seconds_ago']; });

echo json_encode(['success' => true, 'devices' => $result]);
