<?php
// remote_heartbeat.php
// POST: devices call this every 10s to say "I'm open and idle."
// DELETE: a device calls this itself the instant it starts playing a
//         cast, so it drops off remote.html's list straight away instead
//         of lingering there (stale-but-not-yet-expired) for up to 30s.

header('Content-Type: application/json');

$dataDir = sys_get_temp_dir() . '/mini-pi-remote';
if (!is_dir($dataDir)) {
    @mkdir($dataDir, 0777, true);
}
$storeFile = $dataDir . '/devices.json';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);
$id = isset($input['id']) ? trim($input['id']) : '';

if ($id === '' || strlen($id) > 128) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid device id']);
    exit;
}

$fp = fopen($storeFile, 'c+');
if (!$fp) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Could not open device store']);
    exit;
}

flock($fp, LOCK_EX);
$raw = stream_get_contents($fp);
$devices = json_decode($raw, true);
if (!is_array($devices)) $devices = [];

if ($method === 'DELETE') {
    unset($devices[$id]);
} else {
    $name = isset($input['name']) ? trim($input['name']) : 'Unknown Device';
    $name = mb_substr($name, 0, 64);
    $devices[$id] = ['name' => $name, 'last_seen' => time()];
}

// Garbage collect devices that have missed a couple of heartbeats
$now = time();
foreach ($devices as $devId => $dev) {
    if (($now - $dev['last_seen']) > 30) {
        unset($devices[$devId]);
    }
}

ftruncate($fp, 0);
rewind($fp);
fwrite($fp, json_encode($devices));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);

echo json_encode(['success' => true]);
